INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email) 
VALUES
  	('abdul', 'hameed', 'hameed@gmail.com'),
  	('John', 'Doe', 'xyz@email.com');