package com.test.demo.util;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.demo.model.outpt.OutptClaim;

public class Utility {

	public static String ObjectToJson(Object obj) throws JsonGenerationException, JsonMappingException, IOException {
		String jsonString = null;
		String jsonInString2 = null;
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(new File("c:\\test\\" + obj.getClass().getSimpleName() + ".json"), obj);

		jsonString = mapper.writeValueAsString(obj);
		System.out.println(jsonString);

		jsonInString2 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
		System.out.println("jsonString2 value : " + jsonInString2);
		System.out.println("jsonString value : " + jsonString);
		return jsonInString2;
	}

	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {

		OutptClaim claim = new OutptClaim();
		claim.setOutptClaimId(1);
		claim.setOutptClaimAccident(false);
		claim.setOutptClaimAccidentDeath(false);
		String data = ObjectToJson(claim);
		System.out.println("data: " + data);
	}

}
