package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Diagnosis;

/**
 * This is inptCaseDiagnosis class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_diagnosis"
 ,catalog="marcmy"
)
public class InptCaseDiagnosis  implements java.io.Serializable {


  private Integer inptCaseDiagId;
  private Diagnosis diagnosis;
  private InptCase inptCase;
  private Integer inptCaseDiagCreatedBy;
  private Date inptCaseDiagCreatedDate;
  private Integer inptCaseDiagLastEdittedBy;
  private Date inptCaseDiagLastEdittedDate;
  private String inptCaseDiagName;
  private String inptCaseDiagIcd10code;
  private String inptCaseDiagRemarks;
  private String inptCaseDiagOnset;

 public InptCaseDiagnosis() {
 }

	
 public InptCaseDiagnosis(Diagnosis diagnosis, InptCase inptCase) {
     this.diagnosis = diagnosis;
     this.inptCase = inptCase;
 }
 public InptCaseDiagnosis(Diagnosis diagnosis, InptCase inptCase, Integer inptCaseDiagCreatedBy, Date inptCaseDiagCreatedDate, Integer inptCaseDiagLastEdittedBy, Date inptCaseDiagLastEdittedDate, String inptCaseDiagName, String inptCaseDiagIcd10code, String inptCaseDiagRemarks, String inptCaseDiagOnset) {
    this.diagnosis = diagnosis;
    this.inptCase = inptCase;
    this.inptCaseDiagCreatedBy = inptCaseDiagCreatedBy;
    this.inptCaseDiagCreatedDate = inptCaseDiagCreatedDate;
    this.inptCaseDiagLastEdittedBy = inptCaseDiagLastEdittedBy;
    this.inptCaseDiagLastEdittedDate = inptCaseDiagLastEdittedDate;
    this.inptCaseDiagName = inptCaseDiagName;
    this.inptCaseDiagIcd10code = inptCaseDiagIcd10code;
    this.inptCaseDiagRemarks = inptCaseDiagRemarks;
    this.inptCaseDiagOnset = inptCaseDiagOnset;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseDiagId", unique=true, nullable=false)
 public Integer getInptCaseDiagId() {
     return this.inptCaseDiagId;
 }
 
 public void setInptCaseDiagId(Integer inptCaseDiagId) {
     this.inptCaseDiagId = inptCaseDiagId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseDiagDiagnosisId", nullable=false)
 public Diagnosis getDiagnosis() {
     return this.diagnosis;
 }
 
 public void setDiagnosis(Diagnosis diagnosis) {
     this.diagnosis = diagnosis;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseDiagCaseId", nullable=false)
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="inptCaseDiagCreatedBy")
 public Integer getInptCaseDiagCreatedBy() {
     return this.inptCaseDiagCreatedBy;
 }
 
 public void setInptCaseDiagCreatedBy(Integer inptCaseDiagCreatedBy) {
     this.inptCaseDiagCreatedBy = inptCaseDiagCreatedBy;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptCaseDiagCreatedDate", length=10)
 public Date getInptCaseDiagCreatedDate() {
     return this.inptCaseDiagCreatedDate;
 }
 
 public void setInptCaseDiagCreatedDate(Date inptCaseDiagCreatedDate) {
     this.inptCaseDiagCreatedDate = inptCaseDiagCreatedDate;
 }

 
 @Column(name="inptCaseDiagLastEdittedBy")
 public Integer getInptCaseDiagLastEdittedBy() {
     return this.inptCaseDiagLastEdittedBy;
 }
 
 public void setInptCaseDiagLastEdittedBy(Integer inptCaseDiagLastEdittedBy) {
     this.inptCaseDiagLastEdittedBy = inptCaseDiagLastEdittedBy;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptCaseDiagLastEdittedDate", length=10)
 public Date getInptCaseDiagLastEdittedDate() {
     return this.inptCaseDiagLastEdittedDate;
 }
 
 public void setInptCaseDiagLastEdittedDate(Date inptCaseDiagLastEdittedDate) {
     this.inptCaseDiagLastEdittedDate = inptCaseDiagLastEdittedDate;
 }

 
 @Column(name="inptCaseDiagName", length=150)
 public String getInptCaseDiagName() {
     return this.inptCaseDiagName;
 }
 
 public void setInptCaseDiagName(String inptCaseDiagName) {
     this.inptCaseDiagName = inptCaseDiagName;
 }

 
 @Column(name="inptCaseDiagIcd10Code", length=10)
 public String getInptCaseDiagIcd10code() {
     return this.inptCaseDiagIcd10code;
 }
 
 public void setInptCaseDiagIcd10code(String inptCaseDiagIcd10code) {
     this.inptCaseDiagIcd10code = inptCaseDiagIcd10code;
 }

 
 @Column(name="inptCaseDiagRemarks", length=250)
 public String getInptCaseDiagRemarks() {
     return this.inptCaseDiagRemarks;
 }
 
 public void setInptCaseDiagRemarks(String inptCaseDiagRemarks) {
     this.inptCaseDiagRemarks = inptCaseDiagRemarks;
 }

 
 @Column(name="inptCaseDiagOnset", length=50)
 public String getInptCaseDiagOnset() {
     return this.inptCaseDiagOnset;
 }
 
 public void setInptCaseDiagOnset(String inptCaseDiagOnset) {
     this.inptCaseDiagOnset = inptCaseDiagOnset;
 }




}


