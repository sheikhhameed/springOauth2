package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.DocumentType;

/**
 * This is inptCaseDoc class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_doc"
 ,catalog="marcmy"
)
public class InptCaseDoc  implements java.io.Serializable {


  private Integer inptCaseDocId;
  private DocumentType documentType;
  private InptCase inptCase;
  private Integer inptCaseDocCreatedBy;
  private String inptCaseDocSentByAbbvName;
  private Date inptCaseDocCreatedDate;
  private String inptCaseDocName;
  private String inptCaseDocFaxEmail;
  private String inptCaseDocAttn;
  private String inptCaseDocAttnType;
  private String inptCaseDocCc;
  private String inptCaseDocBcc;
  private String inptCaseDocContent;
  private Character inptCaseDocSendAs;
  private String inptCaseDocSendAsName;
  private String inptCaseDocSendAsEmail;
  private String inptCaseDocCurrency;
  private BigDecimal inptCaseDocLgAmt;
  private String inptCaseDocEmailSubject;
  private String inptCaseDocRemarks;
  private Boolean inptCaseDocIsSpecAutho;
  private Integer inptCaseDocSpecAuthoBy;
  private String inptCaseDocSpecAuthoRemark;
  private Date inptCaseDocTatDate;
  private boolean inptCaseDocIsNotiSend;
  private Date inptCaseDocSentDate;
  private String inptCaseDocResentByAbbvName;
  private Date inptCaseDocResentDate;

 public InptCaseDoc() {
 }

	
 public InptCaseDoc(InptCase inptCase, boolean inptCaseDocIsNotiSend) {
     this.inptCase = inptCase;
     this.inptCaseDocIsNotiSend = inptCaseDocIsNotiSend;
 }
 public InptCaseDoc(DocumentType documentType, InptCase inptCase, Integer inptCaseDocCreatedBy, String inptCaseDocSentByAbbvName, Date inptCaseDocCreatedDate, String inptCaseDocName, String inptCaseDocFaxEmail, String inptCaseDocAttn, String inptCaseDocAttnType, String inptCaseDocCc, String inptCaseDocBcc, String inptCaseDocContent, Character inptCaseDocSendAs, String inptCaseDocSendAsName, String inptCaseDocSendAsEmail, String inptCaseDocCurrency, BigDecimal inptCaseDocLgAmt, String inptCaseDocEmailSubject, String inptCaseDocRemarks, Boolean inptCaseDocIsSpecAutho, Integer inptCaseDocSpecAuthoBy, String inptCaseDocSpecAuthoRemark, Date inptCaseDocTatDate, boolean inptCaseDocIsNotiSend, Date inptCaseDocSentDate, String inptCaseDocResentByAbbvName, Date inptCaseDocResentDate) {
    this.documentType = documentType;
    this.inptCase = inptCase;
    this.inptCaseDocCreatedBy = inptCaseDocCreatedBy;
    this.inptCaseDocSentByAbbvName = inptCaseDocSentByAbbvName;
    this.inptCaseDocCreatedDate = inptCaseDocCreatedDate;
    this.inptCaseDocName = inptCaseDocName;
    this.inptCaseDocFaxEmail = inptCaseDocFaxEmail;
    this.inptCaseDocAttn = inptCaseDocAttn;
    this.inptCaseDocAttnType = inptCaseDocAttnType;
    this.inptCaseDocCc = inptCaseDocCc;
    this.inptCaseDocBcc = inptCaseDocBcc;
    this.inptCaseDocContent = inptCaseDocContent;
    this.inptCaseDocSendAs = inptCaseDocSendAs;
    this.inptCaseDocSendAsName = inptCaseDocSendAsName;
    this.inptCaseDocSendAsEmail = inptCaseDocSendAsEmail;
    this.inptCaseDocCurrency = inptCaseDocCurrency;
    this.inptCaseDocLgAmt = inptCaseDocLgAmt;
    this.inptCaseDocEmailSubject = inptCaseDocEmailSubject;
    this.inptCaseDocRemarks = inptCaseDocRemarks;
    this.inptCaseDocIsSpecAutho = inptCaseDocIsSpecAutho;
    this.inptCaseDocSpecAuthoBy = inptCaseDocSpecAuthoBy;
    this.inptCaseDocSpecAuthoRemark = inptCaseDocSpecAuthoRemark;
    this.inptCaseDocTatDate = inptCaseDocTatDate;
    this.inptCaseDocIsNotiSend = inptCaseDocIsNotiSend;
    this.inptCaseDocSentDate = inptCaseDocSentDate;
    this.inptCaseDocResentByAbbvName = inptCaseDocResentByAbbvName;
    this.inptCaseDocResentDate = inptCaseDocResentDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseDocId", unique=true, nullable=false)
 public Integer getInptCaseDocId() {
     return this.inptCaseDocId;
 }
 
 public void setInptCaseDocId(Integer inptCaseDocId) {
     this.inptCaseDocId = inptCaseDocId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseDocDocumentTypeId")
 public DocumentType getDocumentType() {
     return this.documentType;
 }
 
 public void setDocumentType(DocumentType documentType) {
     this.documentType = documentType;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseDocInptCaseId", nullable=false)
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="inptCaseDocCreatedBy")
 public Integer getInptCaseDocCreatedBy() {
     return this.inptCaseDocCreatedBy;
 }
 
 public void setInptCaseDocCreatedBy(Integer inptCaseDocCreatedBy) {
     this.inptCaseDocCreatedBy = inptCaseDocCreatedBy;
 }

 
 @Column(name="inptCaseDocSentByAbbvName", length=8)
 public String getInptCaseDocSentByAbbvName() {
     return this.inptCaseDocSentByAbbvName;
 }
 
 public void setInptCaseDocSentByAbbvName(String inptCaseDocSentByAbbvName) {
     this.inptCaseDocSentByAbbvName = inptCaseDocSentByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseDocCreatedDate", length=19)
 public Date getInptCaseDocCreatedDate() {
     return this.inptCaseDocCreatedDate;
 }
 
 public void setInptCaseDocCreatedDate(Date inptCaseDocCreatedDate) {
     this.inptCaseDocCreatedDate = inptCaseDocCreatedDate;
 }

 
 @Column(name="inptCaseDocName", length=100)
 public String getInptCaseDocName() {
     return this.inptCaseDocName;
 }
 
 public void setInptCaseDocName(String inptCaseDocName) {
     this.inptCaseDocName = inptCaseDocName;
 }

 
 @Column(name="inptCaseDocFaxEmail", length=16777215)
 public String getInptCaseDocFaxEmail() {
     return this.inptCaseDocFaxEmail;
 }
 
 public void setInptCaseDocFaxEmail(String inptCaseDocFaxEmail) {
     this.inptCaseDocFaxEmail = inptCaseDocFaxEmail;
 }

 
 @Column(name="inptCaseDocAttn", length=100)
 public String getInptCaseDocAttn() {
     return this.inptCaseDocAttn;
 }
 
 public void setInptCaseDocAttn(String inptCaseDocAttn) {
     this.inptCaseDocAttn = inptCaseDocAttn;
 }

 
 @Column(name="inptCaseDocAttnType", length=3)
 public String getInptCaseDocAttnType() {
     return this.inptCaseDocAttnType;
 }
 
 public void setInptCaseDocAttnType(String inptCaseDocAttnType) {
     this.inptCaseDocAttnType = inptCaseDocAttnType;
 }

 
 @Column(name="inptCaseDocCc", length=16777215)
 public String getInptCaseDocCc() {
     return this.inptCaseDocCc;
 }
 
 public void setInptCaseDocCc(String inptCaseDocCc) {
     this.inptCaseDocCc = inptCaseDocCc;
 }

 
 @Column(name="inptCaseDocBcc", length=16777215)
 public String getInptCaseDocBcc() {
     return this.inptCaseDocBcc;
 }
 
 public void setInptCaseDocBcc(String inptCaseDocBcc) {
     this.inptCaseDocBcc = inptCaseDocBcc;
 }

 
 @Column(name="inptCaseDocContent")
 public String getInptCaseDocContent() {
     return this.inptCaseDocContent;
 }
 
 public void setInptCaseDocContent(String inptCaseDocContent) {
     this.inptCaseDocContent = inptCaseDocContent;
 }

 
 @Column(name="inptCaseDocSendAs", length=1)
 public Character getInptCaseDocSendAs() {
     return this.inptCaseDocSendAs;
 }
 
 public void setInptCaseDocSendAs(Character inptCaseDocSendAs) {
     this.inptCaseDocSendAs = inptCaseDocSendAs;
 }

 
 @Column(name="inptCaseDocSendAsName", length=100)
 public String getInptCaseDocSendAsName() {
     return this.inptCaseDocSendAsName;
 }
 
 public void setInptCaseDocSendAsName(String inptCaseDocSendAsName) {
     this.inptCaseDocSendAsName = inptCaseDocSendAsName;
 }

 
 @Column(name="inptCaseDocSendAsEmail", length=250)
 public String getInptCaseDocSendAsEmail() {
     return this.inptCaseDocSendAsEmail;
 }
 
 public void setInptCaseDocSendAsEmail(String inptCaseDocSendAsEmail) {
     this.inptCaseDocSendAsEmail = inptCaseDocSendAsEmail;
 }

 
 @Column(name="inptCaseDocCurrency", length=4)
 public String getInptCaseDocCurrency() {
     return this.inptCaseDocCurrency;
 }
 
 public void setInptCaseDocCurrency(String inptCaseDocCurrency) {
     this.inptCaseDocCurrency = inptCaseDocCurrency;
 }

 
 @Column(name="inptCaseDocLgAmt", precision=9)
 public BigDecimal getInptCaseDocLgAmt() {
     return this.inptCaseDocLgAmt;
 }
 
 public void setInptCaseDocLgAmt(BigDecimal inptCaseDocLgAmt) {
     this.inptCaseDocLgAmt = inptCaseDocLgAmt;
 }

 
 @Column(name="inptCaseDocEmailSubject", length=250)
 public String getInptCaseDocEmailSubject() {
     return this.inptCaseDocEmailSubject;
 }
 
 public void setInptCaseDocEmailSubject(String inptCaseDocEmailSubject) {
     this.inptCaseDocEmailSubject = inptCaseDocEmailSubject;
 }

 
 @Column(name="inptCaseDocRemarks", length=80)
 public String getInptCaseDocRemarks() {
     return this.inptCaseDocRemarks;
 }
 
 public void setInptCaseDocRemarks(String inptCaseDocRemarks) {
     this.inptCaseDocRemarks = inptCaseDocRemarks;
 }

 
 @Column(name="inptCaseDocIsSpecAutho")
 public Boolean getInptCaseDocIsSpecAutho() {
     return this.inptCaseDocIsSpecAutho;
 }
 
 public void setInptCaseDocIsSpecAutho(Boolean inptCaseDocIsSpecAutho) {
     this.inptCaseDocIsSpecAutho = inptCaseDocIsSpecAutho;
 }

 
 @Column(name="inptCaseDocSpecAuthoBy")
 public Integer getInptCaseDocSpecAuthoBy() {
     return this.inptCaseDocSpecAuthoBy;
 }
 
 public void setInptCaseDocSpecAuthoBy(Integer inptCaseDocSpecAuthoBy) {
     this.inptCaseDocSpecAuthoBy = inptCaseDocSpecAuthoBy;
 }

 
 @Column(name="inptCaseDocSpecAuthoRemark", length=16777215)
 public String getInptCaseDocSpecAuthoRemark() {
     return this.inptCaseDocSpecAuthoRemark;
 }
 
 public void setInptCaseDocSpecAuthoRemark(String inptCaseDocSpecAuthoRemark) {
     this.inptCaseDocSpecAuthoRemark = inptCaseDocSpecAuthoRemark;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseDocTatDate", length=19)
 public Date getInptCaseDocTatDate() {
     return this.inptCaseDocTatDate;
 }
 
 public void setInptCaseDocTatDate(Date inptCaseDocTatDate) {
     this.inptCaseDocTatDate = inptCaseDocTatDate;
 }

 
 @Column(name="inptCaseDocIsNotiSend", nullable=false)
 public boolean isInptCaseDocIsNotiSend() {
     return this.inptCaseDocIsNotiSend;
 }
 
 public void setInptCaseDocIsNotiSend(boolean inptCaseDocIsNotiSend) {
     this.inptCaseDocIsNotiSend = inptCaseDocIsNotiSend;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseDocSentDate", length=19)
 public Date getInptCaseDocSentDate() {
     return this.inptCaseDocSentDate;
 }
 
 public void setInptCaseDocSentDate(Date inptCaseDocSentDate) {
     this.inptCaseDocSentDate = inptCaseDocSentDate;
 }

 
 @Column(name="inptCaseDocResentByAbbvName", length=8)
 public String getInptCaseDocResentByAbbvName() {
     return this.inptCaseDocResentByAbbvName;
 }
 
 public void setInptCaseDocResentByAbbvName(String inptCaseDocResentByAbbvName) {
     this.inptCaseDocResentByAbbvName = inptCaseDocResentByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseDocResentDate", length=19)
 public Date getInptCaseDocResentDate() {
     return this.inptCaseDocResentDate;
 }
 
 public void setInptCaseDocResentDate(Date inptCaseDocResentDate) {
     this.inptCaseDocResentDate = inptCaseDocResentDate;
 }




}


