//package com.test.demo.model.common;
//
//import com.fasterxml.jackson.annotation.JsonTypeInfo;
//import com.fasterxml.jackson.databind.jsontype.impl.TypeIdResolverBase;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//
//abstract class ApiSubError {
//
//}
//
//@Data
//@EqualsAndHashCode
//@AllArgsConstructor
//class ApiValidationError extends ApiSubError {
//    private String object;
//    private String field;
//    private Object rejectedValue;
//    private String message;
//
//    ApiValidationError(String object, String field, Object rejectedValue , String message) {
//        this.object = object;
//        this.field = field;
//        this.rejectedValue = rejectedValue;
//        this.message = message;
//    }
//    ApiValidationError(String object, String message) {
//        this.object = object;
//        this.message = message;
//    }
//}
//
//class LowerCaseClassNameResolver extends TypeIdResolverBase {
//
//@Override
//public String idFromValue(Object value) {
//    return value.getClass().getSimpleName().toLowerCase();
//}
//
//@Override
//public String idFromValueAndType(Object value, Class<?> suggestedType) {
//    return idFromValue(value);
//}
//
//@Override
//public JsonTypeInfo.Id getMechanism() {
//    return JsonTypeInfo.Id.CUSTOM;
//}
//}