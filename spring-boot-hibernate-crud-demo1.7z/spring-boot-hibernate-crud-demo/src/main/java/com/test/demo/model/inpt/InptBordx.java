package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Client;

/**
 * This is intBordx class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_bordx"
 ,catalog="marcmy"
)
public class InptBordx  implements java.io.Serializable {


  private Integer inptBdxId;
  private Client client;
  private String inptBdxNo;
  private String inptBdxDisbursementNo;
  private String inptBdxType;
  private Character inptBdxClaimType;
  private String inptBdxAddress;
  private String inptBdxAttn;
  private String inptBdxRemarks;
  private Date inptBdxSubmitDate;
  private BigDecimal inptBdxTotal;
  private Boolean inptBdxEnabled;
  private Boolean inptBdxMcisTextfileExtract;
  private Integer inptBdxCreatedBy;
  private Date inptBdxCreatedDate;
  private Integer inptBdxLastEdittedBy;
  private Date inptBdxLastEdittedDate;
  private Set<InptBordxItem> inptBordxItems = new HashSet<InptBordxItem>(0);

 public InptBordx() {
 }

	
 public InptBordx(Client client, String inptBdxNo) {
     this.client = client;
     this.inptBdxNo = inptBdxNo;
 }
 public InptBordx(Client client, String inptBdxNo, String inptBdxDisbursementNo, String inptBdxType, Character inptBdxClaimType, String inptBdxAddress, String inptBdxAttn, String inptBdxRemarks, Date inptBdxSubmitDate, BigDecimal inptBdxTotal, Boolean inptBdxEnabled, Boolean inptBdxMcisTextfileExtract, Integer inptBdxCreatedBy, Date inptBdxCreatedDate, Integer inptBdxLastEdittedBy, Date inptBdxLastEdittedDate, Set<InptBordxItem> inptBordxItems) {
    this.client = client;
    this.inptBdxNo = inptBdxNo;
    this.inptBdxDisbursementNo = inptBdxDisbursementNo;
    this.inptBdxType = inptBdxType;
    this.inptBdxClaimType = inptBdxClaimType;
    this.inptBdxAddress = inptBdxAddress;
    this.inptBdxAttn = inptBdxAttn;
    this.inptBdxRemarks = inptBdxRemarks;
    this.inptBdxSubmitDate = inptBdxSubmitDate;
    this.inptBdxTotal = inptBdxTotal;
    this.inptBdxEnabled = inptBdxEnabled;
    this.inptBdxMcisTextfileExtract = inptBdxMcisTextfileExtract;
    this.inptBdxCreatedBy = inptBdxCreatedBy;
    this.inptBdxCreatedDate = inptBdxCreatedDate;
    this.inptBdxLastEdittedBy = inptBdxLastEdittedBy;
    this.inptBdxLastEdittedDate = inptBdxLastEdittedDate;
    this.inptBordxItems = inptBordxItems;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptBdxId", unique=true, nullable=false)
 public Integer getInptBdxId() {
     return this.inptBdxId;
 }
 
 public void setInptBdxId(Integer inptBdxId) {
     this.inptBdxId = inptBdxId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptBdxClientId", nullable=false)
 public Client getClient() {
     return this.client;
 }
 
 public void setClient(Client client) {
     this.client = client;
 }

 
 @Column(name="inptBdxNo", nullable=false, length=30)
 public String getInptBdxNo() {
     return this.inptBdxNo;
 }
 
 public void setInptBdxNo(String inptBdxNo) {
     this.inptBdxNo = inptBdxNo;
 }

 
 @Column(name="inptBdxDisbursementNo", length=30)
 public String getInptBdxDisbursementNo() {
     return this.inptBdxDisbursementNo;
 }
 
 public void setInptBdxDisbursementNo(String inptBdxDisbursementNo) {
     this.inptBdxDisbursementNo = inptBdxDisbursementNo;
 }

 
 @Column(name="inptBdxType", length=2)
 public String getInptBdxType() {
     return this.inptBdxType;
 }
 
 public void setInptBdxType(String inptBdxType) {
     this.inptBdxType = inptBdxType;
 }

 
 @Column(name="inptBdxClaimType", length=1)
 public Character getInptBdxClaimType() {
     return this.inptBdxClaimType;
 }
 
 public void setInptBdxClaimType(Character inptBdxClaimType) {
     this.inptBdxClaimType = inptBdxClaimType;
 }

 
 @Column(name="inptBdxAddress", length=16777215)
 public String getInptBdxAddress() {
     return this.inptBdxAddress;
 }
 
 public void setInptBdxAddress(String inptBdxAddress) {
     this.inptBdxAddress = inptBdxAddress;
 }

 
 @Column(name="inptBdxAttn", length=250)
 public String getInptBdxAttn() {
     return this.inptBdxAttn;
 }
 
 public void setInptBdxAttn(String inptBdxAttn) {
     this.inptBdxAttn = inptBdxAttn;
 }

 
 @Column(name="inptBdxRemarks")
 public String getInptBdxRemarks() {
     return this.inptBdxRemarks;
 }
 
 public void setInptBdxRemarks(String inptBdxRemarks) {
     this.inptBdxRemarks = inptBdxRemarks;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptBdxSubmitDate", length=10)
 public Date getInptBdxSubmitDate() {
     return this.inptBdxSubmitDate;
 }
 
 public void setInptBdxSubmitDate(Date inptBdxSubmitDate) {
     this.inptBdxSubmitDate = inptBdxSubmitDate;
 }

 
 @Column(name="inptBdxTotal", precision=9)
 public BigDecimal getInptBdxTotal() {
     return this.inptBdxTotal;
 }
 
 public void setInptBdxTotal(BigDecimal inptBdxTotal) {
     this.inptBdxTotal = inptBdxTotal;
 }

 
 @Column(name="inptBdxEnabled")
 public Boolean getInptBdxEnabled() {
     return this.inptBdxEnabled;
 }
 
 public void setInptBdxEnabled(Boolean inptBdxEnabled) {
     this.inptBdxEnabled = inptBdxEnabled;
 }

 
 @Column(name="inptBdxMcisTextfileExtract")
 public Boolean getInptBdxMcisTextfileExtract() {
     return this.inptBdxMcisTextfileExtract;
 }
 
 public void setInptBdxMcisTextfileExtract(Boolean inptBdxMcisTextfileExtract) {
     this.inptBdxMcisTextfileExtract = inptBdxMcisTextfileExtract;
 }

 
 @Column(name="inptBdxCreatedBy")
 public Integer getInptBdxCreatedBy() {
     return this.inptBdxCreatedBy;
 }
 
 public void setInptBdxCreatedBy(Integer inptBdxCreatedBy) {
     this.inptBdxCreatedBy = inptBdxCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptBdxCreatedDate", length=19)
 public Date getInptBdxCreatedDate() {
     return this.inptBdxCreatedDate;
 }
 
 public void setInptBdxCreatedDate(Date inptBdxCreatedDate) {
     this.inptBdxCreatedDate = inptBdxCreatedDate;
 }

 
 @Column(name="inptBdxLastEdittedBy")
 public Integer getInptBdxLastEdittedBy() {
     return this.inptBdxLastEdittedBy;
 }
 
 public void setInptBdxLastEdittedBy(Integer inptBdxLastEdittedBy) {
     this.inptBdxLastEdittedBy = inptBdxLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptBdxLastEdittedDate", length=19)
 public Date getInptBdxLastEdittedDate() {
     return this.inptBdxLastEdittedDate;
 }
 
 public void setInptBdxLastEdittedDate(Date inptBdxLastEdittedDate) {
     this.inptBdxLastEdittedDate = inptBdxLastEdittedDate;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptBordx")
 public Set<InptBordxItem> getInptBordxItems() {
     return this.inptBordxItems;
 }
 
 public void setInptBordxItems(Set<InptBordxItem> inptBordxItems) {
     this.inptBordxItems = inptBordxItems;
 }




}


