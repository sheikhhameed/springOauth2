package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is OutptCaseReminder class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_case_reminder"
 ,catalog="marcmy"
)
public class OutptCaseReminder  implements java.io.Serializable {


  private Integer ocrId;
  private OutptCase outptCase;
  private Date ocrCreatedDate;
  private String ocrCreatedByAbbvName;
  private Date ocrEdittedDate;
  private String ocrEdittedByAbbvName;
  private String ocrReminderType;
  private Date ocrNextActionDate;
  private String ocrTask;
  private String ocrActionTaken;
  private String ocrAssignedTo;
  private boolean ocrCompleted;
  private boolean ocrCancelled;
  private String ocrAudit;
  private String ocrActionItem;
  private Date ocrCompletedDate;
  private Boolean ocrIsAppropriate;

 public OutptCaseReminder() {
 }

	
 public OutptCaseReminder(boolean ocrCompleted, boolean ocrCancelled) {
     this.ocrCompleted = ocrCompleted;
     this.ocrCancelled = ocrCancelled;
 }
 public OutptCaseReminder(OutptCase outptCase, Date ocrCreatedDate, String ocrCreatedByAbbvName, Date ocrEdittedDate, String ocrEdittedByAbbvName, String ocrReminderType, Date ocrNextActionDate, String ocrTask, String ocrActionTaken, String ocrAssignedTo, boolean ocrCompleted, boolean ocrCancelled, String ocrAudit, String ocrActionItem, Date ocrCompletedDate, Boolean ocrIsAppropriate) {
    this.outptCase = outptCase;
    this.ocrCreatedDate = ocrCreatedDate;
    this.ocrCreatedByAbbvName = ocrCreatedByAbbvName;
    this.ocrEdittedDate = ocrEdittedDate;
    this.ocrEdittedByAbbvName = ocrEdittedByAbbvName;
    this.ocrReminderType = ocrReminderType;
    this.ocrNextActionDate = ocrNextActionDate;
    this.ocrTask = ocrTask;
    this.ocrActionTaken = ocrActionTaken;
    this.ocrAssignedTo = ocrAssignedTo;
    this.ocrCompleted = ocrCompleted;
    this.ocrCancelled = ocrCancelled;
    this.ocrAudit = ocrAudit;
    this.ocrActionItem = ocrActionItem;
    this.ocrCompletedDate = ocrCompletedDate;
    this.ocrIsAppropriate = ocrIsAppropriate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ocrId", unique=true, nullable=false)
 public Integer getOcrId() {
     return this.ocrId;
 }
 
 public void setOcrId(Integer ocrId) {
     this.ocrId = ocrId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ocrOutptCaseId")
 public OutptCase getOutptCase() {
     return this.outptCase;
 }
 
 public void setOutptCase(OutptCase outptCase) {
     this.outptCase = outptCase;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ocrCreatedDate", length=19)
 public Date getOcrCreatedDate() {
     return this.ocrCreatedDate;
 }
 
 public void setOcrCreatedDate(Date ocrCreatedDate) {
     this.ocrCreatedDate = ocrCreatedDate;
 }

 
 @Column(name="ocrCreatedByAbbvName", length=8)
 public String getOcrCreatedByAbbvName() {
     return this.ocrCreatedByAbbvName;
 }
 
 public void setOcrCreatedByAbbvName(String ocrCreatedByAbbvName) {
     this.ocrCreatedByAbbvName = ocrCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ocrEdittedDate", length=19)
 public Date getOcrEdittedDate() {
     return this.ocrEdittedDate;
 }
 
 public void setOcrEdittedDate(Date ocrEdittedDate) {
     this.ocrEdittedDate = ocrEdittedDate;
 }

 
 @Column(name="ocrEdittedByAbbvName", length=8)
 public String getOcrEdittedByAbbvName() {
     return this.ocrEdittedByAbbvName;
 }
 
 public void setOcrEdittedByAbbvName(String ocrEdittedByAbbvName) {
     this.ocrEdittedByAbbvName = ocrEdittedByAbbvName;
 }

 
 @Column(name="ocrReminderType", length=2)
 public String getOcrReminderType() {
     return this.ocrReminderType;
 }
 
 public void setOcrReminderType(String ocrReminderType) {
     this.ocrReminderType = ocrReminderType;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ocrNextActionDate", length=19)
 public Date getOcrNextActionDate() {
     return this.ocrNextActionDate;
 }
 
 public void setOcrNextActionDate(Date ocrNextActionDate) {
     this.ocrNextActionDate = ocrNextActionDate;
 }

 
 @Column(name="ocrTask", length=250)
 public String getOcrTask() {
     return this.ocrTask;
 }
 
 public void setOcrTask(String ocrTask) {
     this.ocrTask = ocrTask;
 }

 
 @Column(name="ocrActionTaken", length=16777215)
 public String getOcrActionTaken() {
     return this.ocrActionTaken;
 }
 
 public void setOcrActionTaken(String ocrActionTaken) {
     this.ocrActionTaken = ocrActionTaken;
 }

 
 @Column(name="ocrAssignedTo", length=8)
 public String getOcrAssignedTo() {
     return this.ocrAssignedTo;
 }
 
 public void setOcrAssignedTo(String ocrAssignedTo) {
     this.ocrAssignedTo = ocrAssignedTo;
 }

 
 @Column(name="ocrCompleted", nullable=false)
 public boolean isOcrCompleted() {
     return this.ocrCompleted;
 }
 
 public void setOcrCompleted(boolean ocrCompleted) {
     this.ocrCompleted = ocrCompleted;
 }

 
 @Column(name="ocrCancelled", nullable=false)
 public boolean isOcrCancelled() {
     return this.ocrCancelled;
 }
 
 public void setOcrCancelled(boolean ocrCancelled) {
     this.ocrCancelled = ocrCancelled;
 }

 
 @Column(name="ocrAudit")
 public String getOcrAudit() {
     return this.ocrAudit;
 }
 
 public void setOcrAudit(String ocrAudit) {
     this.ocrAudit = ocrAudit;
 }

 
 @Column(name="ocrActionItem", length=50)
 public String getOcrActionItem() {
     return this.ocrActionItem;
 }
 
 public void setOcrActionItem(String ocrActionItem) {
     this.ocrActionItem = ocrActionItem;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ocrCompletedDate", length=19)
 public Date getOcrCompletedDate() {
     return this.ocrCompletedDate;
 }
 
 public void setOcrCompletedDate(Date ocrCompletedDate) {
     this.ocrCompletedDate = ocrCompletedDate;
 }

 
 @Column(name="ocrIsAppropriate")
 public Boolean getOcrIsAppropriate() {
     return this.ocrIsAppropriate;
 }
 
 public void setOcrIsAppropriate(Boolean ocrIsAppropriate) {
     this.ocrIsAppropriate = ocrIsAppropriate;
 }




}


