package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Diagnosis;

/**
 * This is outptClaimDiagnosis class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_diagnosis"
 ,catalog="marcmy"
)
public class OutptClaimDiagnosis  implements java.io.Serializable {


  private Integer ocdId;
  private Diagnosis diagnosis;
  private OutptClaim outptClaim;
  private Integer ocdCreatedBy;
  private Date ocdCreatedDate;
  private boolean ocdIsInitial;
  private String ocdRemarks;

 public OutptClaimDiagnosis() {
 }

	
 public OutptClaimDiagnosis(Diagnosis diagnosis, OutptClaim outptClaim, boolean ocdIsInitial) {
     this.diagnosis = diagnosis;
     this.outptClaim = outptClaim;
     this.ocdIsInitial = ocdIsInitial;
 }
 public OutptClaimDiagnosis(Diagnosis diagnosis, OutptClaim outptClaim, Integer ocdCreatedBy, Date ocdCreatedDate, boolean ocdIsInitial, String ocdRemarks) {
    this.diagnosis = diagnosis;
    this.outptClaim = outptClaim;
    this.ocdCreatedBy = ocdCreatedBy;
    this.ocdCreatedDate = ocdCreatedDate;
    this.ocdIsInitial = ocdIsInitial;
    this.ocdRemarks = ocdRemarks;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ocdId", unique=true, nullable=false)
 public Integer getOcdId() {
     return this.ocdId;
 }
 
 public void setOcdId(Integer ocdId) {
     this.ocdId = ocdId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ocdDiagnosisId", nullable=false)
 public Diagnosis getDiagnosis() {
     return this.diagnosis;
 }
 
 public void setDiagnosis(Diagnosis diagnosis) {
     this.diagnosis = diagnosis;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ocdOutptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="ocdCreatedBy")
 public Integer getOcdCreatedBy() {
     return this.ocdCreatedBy;
 }
 
 public void setOcdCreatedBy(Integer ocdCreatedBy) {
     this.ocdCreatedBy = ocdCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ocdCreatedDate", length=19)
 public Date getOcdCreatedDate() {
     return this.ocdCreatedDate;
 }
 
 public void setOcdCreatedDate(Date ocdCreatedDate) {
     this.ocdCreatedDate = ocdCreatedDate;
 }

 
 @Column(name="ocdIsInitial", nullable=false)
 public boolean isOcdIsInitial() {
     return this.ocdIsInitial;
 }
 
 public void setOcdIsInitial(boolean ocdIsInitial) {
     this.ocdIsInitial = ocdIsInitial;
 }

 
 @Column(name="ocdRemarks", length=250)
 public String getOcdRemarks() {
     return this.ocdRemarks;
 }
 
 public void setOcdRemarks(String ocdRemarks) {
     this.ocdRemarks = ocdRemarks;
 }




}


