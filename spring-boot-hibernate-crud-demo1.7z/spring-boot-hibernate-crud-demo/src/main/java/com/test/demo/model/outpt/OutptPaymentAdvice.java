package com.test.demo.model.outpt;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Client;
import com.test.demo.model.common.MedicalProvider;

/**
 * This is outptPaymentAdvice class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name = "outpt_payment_advice",
     catalog = "marcmy"
)
public class OutptPaymentAdvice implements java.io.Serializable {

 private Integer outptPayAdvId;
 private Client client;
 private MedicalProvider medicalProvider;
 private OutptPaymentBatch outptPaymentBatch;
 private boolean outptPayAdvEnabled;
 private Date outptPayAdvCreatedDate;
 private String outptPayAdvCreatedByAbbvName;
 private Date outptPayAdvLastEdittedDate;
 private String outptPayAdvLastEdittedByAbbvName;
 private String outptPayAdvPayeeName;
 private String outptPayAdvRemark;
 private String outptPayAdvCurrency;
 private BigDecimal outptPayAdvTotalBillAmount;
 private BigDecimal outptPayAdvTotalGstAmount;
 private BigDecimal outptPayAdvTotalApprovedAmount;
 private BigDecimal outptPayAdvTotalDeclinedAmount;
 private BigDecimal outptPayAdvTotalAmount;
 private Date outptPayAdvTransactionDate;
 private String outptPayAdvTransactionNum;
 private String outptPayAdvTransactionType;
 private String outptPayAdvTransferNo;
 private String outptPayAdvChequeNo;
 private BigDecimal outptPayAdvBankFee;
 private BigDecimal outptPayAdvWhtAmount;
 private BigDecimal outptPayAdvInterestAmount;
 private String outptPayAdvPaidTo;
 private String outptPayAdvPayNote;
 private String outptPayAdvWhtTaxNo;
 private Date outptPayAdvPaymentDate;
 private Integer outptPayAdvBdxNumber;
 private String outptPayAdvBankName;
 private String outptPayAdvBankCode;
 private String outptPayAdvBankBranchName;
 private String outptPayAdvAccountNumber;
 private String outptPayAdvType;
 private Date outptPayAdvReissueRequestDate;
 private String outptPayAdvReissueReason;
 private Date outptPayAdvBankFileCreatedDate;
 private Integer outptPayAdvBankFileCreatedBy;
 private boolean outptPayAdvBankFlag;
 private Set<OutptPaymentActivityLog> outptPaymentActivityLogs = new HashSet<OutptPaymentActivityLog>(0);
 
 private String outptPayAdvInvoiceNum;

 public OutptPaymentAdvice() {
 }

 public OutptPaymentAdvice(boolean outptPayAdvEnabled, boolean outptPayAdvBankFlag) {
     this.outptPayAdvEnabled = outptPayAdvEnabled;
     this.outptPayAdvBankFlag = outptPayAdvBankFlag;
 }

 public OutptPaymentAdvice(Client client, MedicalProvider medicalProvider, OutptPaymentBatch outptPaymentBatch, boolean outptPayAdvEnabled, Date outptPayAdvCreatedDate, String outptPayAdvCreatedByAbbvName, Date outptPayAdvLastEdittedDate, String outptPayAdvLastEdittedByAbbvName, String outptPayAdvPayeeName, String outptPayAdvRemark, String outptPayAdvCurrency, BigDecimal outptPayAdvTotalBillAmount, BigDecimal outptPayAdvTotalGstAmount, BigDecimal outptPayAdvTotalApprovedAmount, BigDecimal outptPayAdvTotalDeclinedAmount, BigDecimal outptPayAdvTotalAmount, Date outptPayAdvTransactionDate, String outptPayAdvTransactionNum, String outptPayAdvTransactionType, String outptPayAdvTransferNo, String outptPayAdvChequeNo, BigDecimal outptPayAdvBankFee, BigDecimal outptPayAdvWhtAmount, BigDecimal outptPayAdvInterestAmount, String outptPayAdvPaidTo, String outptPayAdvPayNote, String outptPayAdvWhtTaxNo, Date outptPayAdvPaymentDate, Integer outptPayAdvBdxNumber, String outptPayAdvBankName, String outptPayAdvBankCode, String outptPayAdvBankBranchName, String outptPayAdvAccountNumber, String outptPayAdvType, Date outptPayAdvReissueRequestDate, String outptPayAdvReissueReason, Date outptPayAdvBankFileCreatedDate, Integer outptPayAdvBankFileCreatedBy, boolean outptPayAdvBankFlag, Set<OutptPaymentActivityLog> outptPaymentActivityLogs) {
     this.client = client;
     this.medicalProvider = medicalProvider;
     this.outptPaymentBatch = outptPaymentBatch;
     this.outptPayAdvEnabled = outptPayAdvEnabled;
     this.outptPayAdvCreatedDate = outptPayAdvCreatedDate;
     this.outptPayAdvCreatedByAbbvName = outptPayAdvCreatedByAbbvName;
     this.outptPayAdvLastEdittedDate = outptPayAdvLastEdittedDate;
     this.outptPayAdvLastEdittedByAbbvName = outptPayAdvLastEdittedByAbbvName;
     this.outptPayAdvPayeeName = outptPayAdvPayeeName;
     this.outptPayAdvRemark = outptPayAdvRemark;
     this.outptPayAdvCurrency = outptPayAdvCurrency;
     this.outptPayAdvTotalBillAmount = outptPayAdvTotalBillAmount;
     this.outptPayAdvTotalGstAmount = outptPayAdvTotalGstAmount;
     this.outptPayAdvTotalApprovedAmount = outptPayAdvTotalApprovedAmount;
     this.outptPayAdvTotalDeclinedAmount = outptPayAdvTotalDeclinedAmount;
     this.outptPayAdvTotalAmount = outptPayAdvTotalAmount;
     this.outptPayAdvTransactionDate = outptPayAdvTransactionDate;
     this.outptPayAdvTransactionNum = outptPayAdvTransactionNum;
     this.outptPayAdvTransactionType = outptPayAdvTransactionType;
     this.outptPayAdvTransferNo = outptPayAdvTransferNo;
     this.outptPayAdvChequeNo = outptPayAdvChequeNo;
     this.outptPayAdvBankFee = outptPayAdvBankFee;
     this.outptPayAdvWhtAmount = outptPayAdvWhtAmount;
     this.outptPayAdvInterestAmount = outptPayAdvInterestAmount;
     this.outptPayAdvPaidTo = outptPayAdvPaidTo;
     this.outptPayAdvPayNote = outptPayAdvPayNote;
     this.outptPayAdvWhtTaxNo = outptPayAdvWhtTaxNo;
     this.outptPayAdvPaymentDate = outptPayAdvPaymentDate;
     this.outptPayAdvBdxNumber = outptPayAdvBdxNumber;
     this.outptPayAdvBankName = outptPayAdvBankName;
     this.outptPayAdvBankCode = outptPayAdvBankCode;
     this.outptPayAdvBankBranchName = outptPayAdvBankBranchName;
     this.outptPayAdvAccountNumber = outptPayAdvAccountNumber;
     this.outptPayAdvType = outptPayAdvType;
     this.outptPayAdvReissueRequestDate = outptPayAdvReissueRequestDate;
     this.outptPayAdvReissueReason = outptPayAdvReissueReason;
     this.outptPayAdvBankFileCreatedDate = outptPayAdvBankFileCreatedDate;
     this.outptPayAdvBankFileCreatedBy = outptPayAdvBankFileCreatedBy;
     this.outptPayAdvBankFlag = outptPayAdvBankFlag;
     this.outptPaymentActivityLogs = outptPaymentActivityLogs;
 }

 @Id
 @GeneratedValue(strategy = IDENTITY)

 @Column(name = "outptPayAdvId", unique = true, nullable = false)
 public Integer getOutptPayAdvId() {
     return this.outptPayAdvId;
 }

 public void setOutptPayAdvId(Integer outptPayAdvId) {
     this.outptPayAdvId = outptPayAdvId;
 }

 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptPayAdvClientId")
 public Client getClient() {
     return this.client;
 }

 public void setClient(Client client) {
     this.client = client;
 }

 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptPayAdvMedicalProviderId")
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }

 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }

 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptPayAdvBatchId")
 public OutptPaymentBatch getOutptPaymentBatch() {
     return this.outptPaymentBatch;
 }

 public void setOutptPaymentBatch(OutptPaymentBatch outptPaymentBatch) {
     this.outptPaymentBatch = outptPaymentBatch;
 }

 @Column(name = "outptPayAdvEnabled", nullable = false)
 public boolean isOutptPayAdvEnabled() {
     return this.outptPayAdvEnabled;
 }

 public void setOutptPayAdvEnabled(boolean outptPayAdvEnabled) {
     this.outptPayAdvEnabled = outptPayAdvEnabled;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptPayAdvCreatedDate", length = 19)
 public Date getOutptPayAdvCreatedDate() {
     return this.outptPayAdvCreatedDate;
 }

 public void setOutptPayAdvCreatedDate(Date outptPayAdvCreatedDate) {
     this.outptPayAdvCreatedDate = outptPayAdvCreatedDate;
 }

 @Column(name = "outptPayAdvCreatedByAbbvName", length = 8)
 public String getOutptPayAdvCreatedByAbbvName() {
     return this.outptPayAdvCreatedByAbbvName;
 }

 public void setOutptPayAdvCreatedByAbbvName(String outptPayAdvCreatedByAbbvName) {
     this.outptPayAdvCreatedByAbbvName = outptPayAdvCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptPayAdvLastEdittedDate", length = 19)
 public Date getOutptPayAdvLastEdittedDate() {
     return this.outptPayAdvLastEdittedDate;
 }

 public void setOutptPayAdvLastEdittedDate(Date outptPayAdvLastEdittedDate) {
     this.outptPayAdvLastEdittedDate = outptPayAdvLastEdittedDate;
 }

 @Column(name = "outptPayAdvLastEdittedByAbbvName", length = 8)
 public String getOutptPayAdvLastEdittedByAbbvName() {
     return this.outptPayAdvLastEdittedByAbbvName;
 }

 public void setOutptPayAdvLastEdittedByAbbvName(String outptPayAdvLastEdittedByAbbvName) {
     this.outptPayAdvLastEdittedByAbbvName = outptPayAdvLastEdittedByAbbvName;
 }

 @Column(name = "outptPayAdvPayeeName", length = 100)
 public String getOutptPayAdvPayeeName() {
     return this.outptPayAdvPayeeName;
 }

 public void setOutptPayAdvPayeeName(String outptPayAdvPayeeName) {
     this.outptPayAdvPayeeName = outptPayAdvPayeeName;
 }

 @Column(name = "outptPayAdvRemark", length = 250)
 public String getOutptPayAdvRemark() {
     return this.outptPayAdvRemark;
 }

 public void setOutptPayAdvRemark(String outptPayAdvRemark) {
     this.outptPayAdvRemark = outptPayAdvRemark;
 }

 @Column(name = "outptPayAdvCurrency", length = 3)
 public String getOutptPayAdvCurrency() {
     return this.outptPayAdvCurrency;
 }

 public void setOutptPayAdvCurrency(String outptPayAdvCurrency) {
     this.outptPayAdvCurrency = outptPayAdvCurrency;
 }

 @Column(name = "outptPayAdvTotalBillAmount", precision = 16)
 public BigDecimal getOutptPayAdvTotalBillAmount() {
     return this.outptPayAdvTotalBillAmount;
 }

 public void setOutptPayAdvTotalBillAmount(BigDecimal outptPayAdvTotalBillAmount) {
     this.outptPayAdvTotalBillAmount = outptPayAdvTotalBillAmount;
 }

 @Column(name = "outptPayAdvTotalGstAmount", precision = 16)
 public BigDecimal getOutptPayAdvTotalGstAmount() {
     return this.outptPayAdvTotalGstAmount;
 }

 public void setOutptPayAdvTotalGstAmount(BigDecimal outptPayAdvTotalGstAmount) {
     this.outptPayAdvTotalGstAmount = outptPayAdvTotalGstAmount;
 }

 @Column(name = "outptPayAdvTotalApprovedAmount", precision = 16)
 public BigDecimal getOutptPayAdvTotalApprovedAmount() {
     return this.outptPayAdvTotalApprovedAmount;
 }

 public void setOutptPayAdvTotalApprovedAmount(BigDecimal outptPayAdvTotalApprovedAmount) {
     this.outptPayAdvTotalApprovedAmount = outptPayAdvTotalApprovedAmount;
 }

 @Column(name = "outptPayAdvTotalDeclinedAmount", precision = 16)
 public BigDecimal getOutptPayAdvTotalDeclinedAmount() {
     return this.outptPayAdvTotalDeclinedAmount;
 }

 public void setOutptPayAdvTotalDeclinedAmount(BigDecimal outptPayAdvTotalDeclinedAmount) {
     this.outptPayAdvTotalDeclinedAmount = outptPayAdvTotalDeclinedAmount;
 }

 @Column(name = "outptPayAdvTotalAmount", precision = 16)
 public BigDecimal getOutptPayAdvTotalAmount() {
     return this.outptPayAdvTotalAmount;
 }

 public void setOutptPayAdvTotalAmount(BigDecimal outptPayAdvTotalAmount) {
     this.outptPayAdvTotalAmount = outptPayAdvTotalAmount;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptPayAdvTransactionDate", length = 19)
 public Date getOutptPayAdvTransactionDate() {
     return this.outptPayAdvTransactionDate;
 }

 public void setOutptPayAdvTransactionDate(Date outptPayAdvTransactionDate) {
     this.outptPayAdvTransactionDate = outptPayAdvTransactionDate;
 }

 @Column(name = "outptPayAdvTransactionNum", length = 20)
 public String getOutptPayAdvTransactionNum() {
     return this.outptPayAdvTransactionNum;
 }

 public void setOutptPayAdvTransactionNum(String outptPayAdvTransactionNum) {
     this.outptPayAdvTransactionNum = outptPayAdvTransactionNum;
 }

 @Column(name = "outptPayAdvTransactionType", length = 1)
 public String getOutptPayAdvTransactionType() {
     return this.outptPayAdvTransactionType;
 }

 public void setOutptPayAdvTransactionType(String outptPayAdvTransactionType) {
     this.outptPayAdvTransactionType = outptPayAdvTransactionType;
 }

 @Column(name = "outptPayAdvTransferNo", length = 20)
 public String getOutptPayAdvTransferNo() {
     return this.outptPayAdvTransferNo;
 }

 public void setOutptPayAdvTransferNo(String outptPayAdvTransferNo) {
     this.outptPayAdvTransferNo = outptPayAdvTransferNo;
 }

 @Column(name = "outptPayAdvChequeNo", length = 20)
 public String getOutptPayAdvChequeNo() {
     return this.outptPayAdvChequeNo;
 }

 public void setOutptPayAdvChequeNo(String outptPayAdvChequeNo) {
     this.outptPayAdvChequeNo = outptPayAdvChequeNo;
 }

 @Column(name = "outptPayAdvBankFee", precision = 16)
 public BigDecimal getOutptPayAdvBankFee() {
     return this.outptPayAdvBankFee;
 }

 public void setOutptPayAdvBankFee(BigDecimal outptPayAdvBankFee) {
     this.outptPayAdvBankFee = outptPayAdvBankFee;
 }

 @Column(name = "outptPayAdvWhtAmount", precision = 16)
 public BigDecimal getOutptPayAdvWhtAmount() {
     return this.outptPayAdvWhtAmount;
 }

 public void setOutptPayAdvWhtAmount(BigDecimal outptPayAdvWhtAmount) {
     this.outptPayAdvWhtAmount = outptPayAdvWhtAmount;
 }

 @Column(name = "outptPayAdvInterestAmount", precision = 16)
 public BigDecimal getOutptPayAdvInterestAmount() {
     return this.outptPayAdvInterestAmount;
 }

 public void setOutptPayAdvInterestAmount(BigDecimal outptPayAdvInterestAmount) {
     this.outptPayAdvInterestAmount = outptPayAdvInterestAmount;
 }

 @Column(name = "outptPayAdvPaidTo", length = 20)
 public String getOutptPayAdvPaidTo() {
     return this.outptPayAdvPaidTo;
 }

 public void setOutptPayAdvPaidTo(String outptPayAdvPaidTo) {
     this.outptPayAdvPaidTo = outptPayAdvPaidTo;
 }

 @Column(name = "outptPayAdvPayNote", length = 250)
 public String getOutptPayAdvPayNote() {
     return this.outptPayAdvPayNote;
 }

 public void setOutptPayAdvPayNote(String outptPayAdvPayNote) {
     this.outptPayAdvPayNote = outptPayAdvPayNote;
 }

 @Column(name = "outptPayAdvWhtTaxNo", length = 12)
 public String getOutptPayAdvWhtTaxNo() {
     return this.outptPayAdvWhtTaxNo;
 }

 public void setOutptPayAdvWhtTaxNo(String outptPayAdvWhtTaxNo) {
     this.outptPayAdvWhtTaxNo = outptPayAdvWhtTaxNo;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptPayAdvPaymentDate", length = 19)
 public Date getOutptPayAdvPaymentDate() {
     return this.outptPayAdvPaymentDate;
 }

 public void setOutptPayAdvPaymentDate(Date outptPayAdvPaymentDate) {
     this.outptPayAdvPaymentDate = outptPayAdvPaymentDate;
 }

 @Column(name = "outptPayAdvBdxNumber")
 public Integer getOutptPayAdvBdxNumber() {
     return this.outptPayAdvBdxNumber;
 }

 public void setOutptPayAdvBdxNumber(Integer outptPayAdvBdxNumber) {
     this.outptPayAdvBdxNumber = outptPayAdvBdxNumber;
 }

 @Column(name = "outptPayAdvBankName", length = 50)
 public String getOutptPayAdvBankName() {
     return this.outptPayAdvBankName;
 }

 public void setOutptPayAdvBankName(String outptPayAdvBankName) {
     this.outptPayAdvBankName = outptPayAdvBankName;
 }

 @Column(name = "outptPayAdvBankCode", length = 15)
 public String getOutptPayAdvBankCode() {
     return this.outptPayAdvBankCode;
 }

 public void setOutptPayAdvBankCode(String outptPayAdvBankCode) {
     this.outptPayAdvBankCode = outptPayAdvBankCode;
 }

 @Column(name = "outptPayAdvBankBranchName", length = 50)
 public String getOutptPayAdvBankBranchName() {
     return this.outptPayAdvBankBranchName;
 }

 public void setOutptPayAdvBankBranchName(String outptPayAdvBankBranchName) {
     this.outptPayAdvBankBranchName = outptPayAdvBankBranchName;
 }

 @Column(name = "outptPayAdvAccountNumber", length = 50)
 public String getOutptPayAdvAccountNumber() {
     return this.outptPayAdvAccountNumber;
 }

 public void setOutptPayAdvAccountNumber(String outptPayAdvAccountNumber) {
     this.outptPayAdvAccountNumber = outptPayAdvAccountNumber;
 }

 @Column(name = "outptPayAdvType", length = 2)
 public String getOutptPayAdvType() {
     return this.outptPayAdvType;
 }

 public void setOutptPayAdvType(String outptPayAdvType) {
     this.outptPayAdvType = outptPayAdvType;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptPayAdvReissueRequestDate", length = 10)
 public Date getOutptPayAdvReissueRequestDate() {
     return this.outptPayAdvReissueRequestDate;
 }

 public void setOutptPayAdvReissueRequestDate(Date outptPayAdvReissueRequestDate) {
     this.outptPayAdvReissueRequestDate = outptPayAdvReissueRequestDate;
 }

 @Column(name = "outptPayAdvReissueReason", length = 190)
 public String getOutptPayAdvReissueReason() {
     return this.outptPayAdvReissueReason;
 }

 public void setOutptPayAdvReissueReason(String outptPayAdvReissueReason) {
     this.outptPayAdvReissueReason = outptPayAdvReissueReason;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptPayAdvBankFileCreatedDate", length = 10)
 public Date getOutptPayAdvBankFileCreatedDate() {
     return this.outptPayAdvBankFileCreatedDate;
 }

 public void setOutptPayAdvBankFileCreatedDate(Date outptPayAdvBankFileCreatedDate) {
     this.outptPayAdvBankFileCreatedDate = outptPayAdvBankFileCreatedDate;
 }

 @Column(name = "outptPayAdvBankFileCreatedBy")
 public Integer getOutptPayAdvBankFileCreatedBy() {
     return this.outptPayAdvBankFileCreatedBy;
 }

 public void setOutptPayAdvBankFileCreatedBy(Integer outptPayAdvBankFileCreatedBy) {
     this.outptPayAdvBankFileCreatedBy = outptPayAdvBankFileCreatedBy;
 }

 @Column(name = "outptPayAdvBankFlag", nullable = false)
 public boolean isOutptPayAdvBankFlag() {
     return this.outptPayAdvBankFlag;
 }

 public void setOutptPayAdvBankFlag(boolean outptPayAdvBankFlag) {
     this.outptPayAdvBankFlag = outptPayAdvBankFlag;
 }

 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptPaymentAdvice")
 public Set<OutptPaymentActivityLog> getOutptPaymentActivityLogs() {
     return this.outptPaymentActivityLogs;
 }

 public void setOutptPaymentActivityLogs(Set<OutptPaymentActivityLog> outptPaymentActivityLogs) {
     this.outptPaymentActivityLogs = outptPaymentActivityLogs;
 }

  @Column(name = "outptPayAdvInvoiceNum", length = 50)
 public String getOutptPayAdvInvoiceNum() {
     return this.outptPayAdvInvoiceNum;
 }

 public void setOutptPayAdvInvoiceNum(String outptPayAdvInvoiceNum) {
     this.outptPayAdvInvoiceNum = outptPayAdvInvoiceNum;
 }

}
