package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is specialization class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="specialization"
 ,catalog="marcmy"
)
public class Specialization  implements java.io.Serializable {


  private Integer specId;
  private Integer specCreatedBy;
  private Date specCreatedDate;
  private Integer specLastEdittedBy;
  private Date specLastEdittedDate;
  private String specName;
  private Set<Doctor> doctors = new HashSet<Doctor>(0);

 public Specialization() {
 }

 public Specialization(Integer specCreatedBy, Date specCreatedDate, Integer specLastEdittedBy, Date specLastEdittedDate, String specName, Set<Doctor> doctors) {
    this.specCreatedBy = specCreatedBy;
    this.specCreatedDate = specCreatedDate;
    this.specLastEdittedBy = specLastEdittedBy;
    this.specLastEdittedDate = specLastEdittedDate;
    this.specName = specName;
    this.doctors = doctors;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="specId", unique=true, nullable=false)
 public Integer getSpecId() {
     return this.specId;
 }
 
 public void setSpecId(Integer specId) {
     this.specId = specId;
 }

 
 @Column(name="specCreatedBy")
 public Integer getSpecCreatedBy() {
     return this.specCreatedBy;
 }
 
 public void setSpecCreatedBy(Integer specCreatedBy) {
     this.specCreatedBy = specCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="specCreatedDate", length=19)
 public Date getSpecCreatedDate() {
     return this.specCreatedDate;
 }
 
 public void setSpecCreatedDate(Date specCreatedDate) {
     this.specCreatedDate = specCreatedDate;
 }

 
 @Column(name="specLastEdittedBy")
 public Integer getSpecLastEdittedBy() {
     return this.specLastEdittedBy;
 }
 
 public void setSpecLastEdittedBy(Integer specLastEdittedBy) {
     this.specLastEdittedBy = specLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="specLastEdittedDate", length=19)
 public Date getSpecLastEdittedDate() {
     return this.specLastEdittedDate;
 }
 
 public void setSpecLastEdittedDate(Date specLastEdittedDate) {
     this.specLastEdittedDate = specLastEdittedDate;
 }

 
 @Column(name="specName", length=150)
 public String getSpecName() {
     return this.specName;
 }
 
 public void setSpecName(String specName) {
     this.specName = specName;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="specialization")
 public Set<Doctor> getDoctors() {
     return this.doctors;
 }
 
 public void setDoctors(Set<Doctor> doctors) {
     this.doctors = doctors;
 }




}


