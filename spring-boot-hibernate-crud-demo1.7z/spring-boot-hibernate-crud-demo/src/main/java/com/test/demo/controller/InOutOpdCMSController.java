package com.test.demo.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.model.common.EmployeeEntity;
import com.test.demo.model.common.ResponseData;
import com.test.demo.model.outpt.OutptClaim;
import com.test.demo.service.OutptCaseService;
import com.test.demo.util.Utility;

import ch.qos.logback.classic.Logger;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
 /**
  * This is controller class of employees data
  *  
  * @author smannan
  *
  */
@RestController
@RequestMapping("/cms")
@Api(value="Outpt Management System", description="Operations for out patients management System")
public class InOutOpdCMSController
{
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(InOutOpdCMSController.class);
    
	@Autowired
	OutptCaseService outptClaimService;
 
    /**
     * This method is used to get all the data
     * 
     * @return
     */
    @GetMapping
    public ResponseEntity<List<EmployeeEntity>> getAllEmployees() {
    	
    	List<EmployeeEntity> list = new ArrayList<EmployeeEntity>();
    	
    	ResponseEntity<List<EmployeeEntity>> responseEntity= new ResponseEntity<List<EmployeeEntity>>(HttpStatus.NOT_MODIFIED) ; 
    	 list = outptClaimService.getAllEmployees();
    	 responseEntity = new ResponseEntity<List<EmployeeEntity>>(list, new HttpHeaders(), HttpStatus.OK);
         
        return responseEntity;
    }
 
    @GetMapping("/{id}")
    @ApiOperation(value="Get employee by Id", notes="${EmployeeController.getEmployeeById.notes}")
    public ResponseEntity<EmployeeEntity> getEmployeeById(@PathVariable("id") Long id)
                                                     {
        EmployeeEntity entity = new EmployeeEntity();
		
//			entity = service.getEmployeeById(id);
	System.out.println("the id : "+id);
 
        return new ResponseEntity<EmployeeEntity>(entity, new HttpHeaders(), HttpStatus.OK);
    }
 
    @PostMapping
    public ResponseEntity<EmployeeEntity> createOrUpdateEmployee( String data )
                                                    {
    	EmployeeEntity employee = new EmployeeEntity();
    	
        EmployeeEntity updated = new EmployeeEntity();
		
			updated = outptClaimService.createOrUpdateEmployee(employee);
		
        return new ResponseEntity<EmployeeEntity>(updated, new HttpHeaders(), HttpStatus.OK);
    }
 
    @DeleteMapping("/{id}")
    public HttpStatus deleteEmployeeById(@PathVariable("id") Long id)
                                                    {
//        try {
			outptClaimService.deleteEmployeeById(id);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
        return HttpStatus.FORBIDDEN;
    }
 
    @ApiOperation(value="Get a list of claims by claimId", response=ResponseEntity.class)
	@ApiResponses(value= {
			@ApiResponse(code=200, message="Successfully retrieve Eclaims !"),
			@ApiResponse(code=401, message="You are authorize to view the resource"),
			@ApiResponse(code=403, message="Accessing to the resource you were trying to reach is forbitten"),
			@ApiResponse(code=404, message="The resource you are trying to reach not found")
	})
    @GetMapping("/claim/{claimId}")
	public ResponseEntity<ResponseData> getOutptClaim(@ApiParam(value="claimId from which claims can be retrieve")
		@PathVariable("claimId") int claimId) throws Exception {

		ResponseEntity<ResponseData> responseEntity = new ResponseEntity<ResponseData>(HttpStatus.NOT_MODIFIED);
		System.out.println("claimId : " + claimId);
		if (0 >= claimId) {
			throw new Exception("claimId parameter missing");
		}
		OutptClaim outptClaim = outptClaimService.getOutptClaim(claimId);
		if (outptClaim == null) {
			throw new Exception("Claims not found");
		}

		String outptClaimJson = Utility.ObjectToJson(outptClaim);

		ResponseData responseData = new ResponseData();
		responseData.setRespCode(HttpStatus.OK.toString());
		responseData.setRespMessage(outptClaimJson);
		responseData.setTimestamp(LocalDateTime.now());
		responseEntity = new ResponseEntity<ResponseData>(responseData, HttpStatus.OK);

		return responseEntity;
	}
}