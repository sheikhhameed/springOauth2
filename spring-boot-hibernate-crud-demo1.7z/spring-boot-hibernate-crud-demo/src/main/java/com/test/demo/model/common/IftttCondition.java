package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.outpt.OutptStatus;

/**
 * This is IftttCondition class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="ifttt_condition"
 ,catalog="marcmy"
)
public class IftttCondition  implements java.io.Serializable {


  private Integer iftttCondtId;
  private Country country;
  private Diagnosis diagnosis;
  private Doctor doctor;
  private IftttFields iftttFields;
  private IftttRule iftttRule;
  private MedicalProvider medicalProvider;
  private OutptStatus outptStatus;
  private SurgicalSchedule surgicalSchedule;
  private Symptom symptom;
  private String iftttCondt;
  private Boolean iftttAndCondt;
  private Boolean iftttOrCondt;
  private Integer iftttCondtSequence;
  private String iftttFieldFreeText;
  private Date iftttFieldDate;
  private String iftttRejectRemark;
  private Integer iftttFieldInt;
  private Boolean iftttFieldBoolean;
  private String iftttGender;
  private String iftttClaimType;
  private String iftttApprovalType;

 public IftttCondition() {
 }

	
 public IftttCondition(IftttFields iftttFields, IftttRule iftttRule, String iftttCondt) {
     this.iftttFields = iftttFields;
     this.iftttRule = iftttRule;
     this.iftttCondt = iftttCondt;
 }
 public IftttCondition(Country country, Diagnosis diagnosis, Doctor doctor, IftttFields iftttFields, IftttRule iftttRule, MedicalProvider medicalProvider, OutptStatus outptStatus, SurgicalSchedule surgicalSchedule, Symptom symptom, String iftttCondt, Boolean iftttAndCondt, Boolean iftttOrCondt, Integer iftttCondtSequence, String iftttFieldFreeText, Date iftttFieldDate, String iftttRejectRemark, Integer iftttFieldInt, Boolean iftttFieldBoolean, String iftttGender, String iftttClaimType, String iftttApprovalType) {
    this.country = country;
    this.diagnosis = diagnosis;
    this.doctor = doctor;
    this.iftttFields = iftttFields;
    this.iftttRule = iftttRule;
    this.medicalProvider = medicalProvider;
    this.outptStatus = outptStatus;
    this.surgicalSchedule = surgicalSchedule;
    this.symptom = symptom;
    this.iftttCondt = iftttCondt;
    this.iftttAndCondt = iftttAndCondt;
    this.iftttOrCondt = iftttOrCondt;
    this.iftttCondtSequence = iftttCondtSequence;
    this.iftttFieldFreeText = iftttFieldFreeText;
    this.iftttFieldDate = iftttFieldDate;
    this.iftttRejectRemark = iftttRejectRemark;
    this.iftttFieldInt = iftttFieldInt;
    this.iftttFieldBoolean = iftttFieldBoolean;
    this.iftttGender = iftttGender;
    this.iftttClaimType = iftttClaimType;
    this.iftttApprovalType = iftttApprovalType;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="iftttCondtId", unique=true, nullable=false)
 public Integer getIftttCondtId() {
     return this.iftttCondtId;
 }
 
 public void setIftttCondtId(Integer iftttCondtId) {
     this.iftttCondtId = iftttCondtId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttCountryId")
 public Country getCountry() {
     return this.country;
 }
 
 public void setCountry(Country country) {
     this.country = country;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttDiagId")
 public Diagnosis getDiagnosis() {
     return this.diagnosis;
 }
 
 public void setDiagnosis(Diagnosis diagnosis) {
     this.diagnosis = diagnosis;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttDrId")
 public Doctor getDoctor() {
     return this.doctor;
 }
 
 public void setDoctor(Doctor doctor) {
     this.doctor = doctor;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttCondtFieldId", nullable=false)
 public IftttFields getIftttFields() {
     return this.iftttFields;
 }
 
 public void setIftttFields(IftttFields iftttFields) {
     this.iftttFields = iftttFields;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttRuleId", nullable=false)
 public IftttRule getIftttRule() {
     return this.iftttRule;
 }
 
 public void setIftttRule(IftttRule iftttRule) {
     this.iftttRule = iftttRule;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttMedPrvId")
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }
 
 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttOutptClaimStatusId")
 public OutptStatus getOutptStatus() {
     return this.outptStatus;
 }
 
 public void setOutptStatus(OutptStatus outptStatus) {
     this.outptStatus = outptStatus;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttSurgicalScheduleId")
 public SurgicalSchedule getSurgicalSchedule() {
     return this.surgicalSchedule;
 }
 
 public void setSurgicalSchedule(SurgicalSchedule surgicalSchedule) {
     this.surgicalSchedule = surgicalSchedule;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="iftttSymptomId")
 public Symptom getSymptom() {
     return this.symptom;
 }
 
 public void setSymptom(Symptom symptom) {
     this.symptom = symptom;
 }

 
 @Column(name="iftttCondt", nullable=false, length=5)
 public String getIftttCondt() {
     return this.iftttCondt;
 }
 
 public void setIftttCondt(String iftttCondt) {
     this.iftttCondt = iftttCondt;
 }

 
 @Column(name="iftttAndCondt")
 public Boolean getIftttAndCondt() {
     return this.iftttAndCondt;
 }
 
 public void setIftttAndCondt(Boolean iftttAndCondt) {
     this.iftttAndCondt = iftttAndCondt;
 }

 
 @Column(name="iftttOrCondt")
 public Boolean getIftttOrCondt() {
     return this.iftttOrCondt;
 }
 
 public void setIftttOrCondt(Boolean iftttOrCondt) {
     this.iftttOrCondt = iftttOrCondt;
 }

 
 @Column(name="iftttCondtSequence")
 public Integer getIftttCondtSequence() {
     return this.iftttCondtSequence;
 }
 
 public void setIftttCondtSequence(Integer iftttCondtSequence) {
     this.iftttCondtSequence = iftttCondtSequence;
 }

 
 @Column(name="iftttFieldFreeText", length=250)
 public String getIftttFieldFreeText() {
     return this.iftttFieldFreeText;
 }
 
 public void setIftttFieldFreeText(String iftttFieldFreeText) {
     this.iftttFieldFreeText = iftttFieldFreeText;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="iftttFieldDate", length=10)
 public Date getIftttFieldDate() {
     return this.iftttFieldDate;
 }
 
 public void setIftttFieldDate(Date iftttFieldDate) {
     this.iftttFieldDate = iftttFieldDate;
 }

 
 @Column(name="iftttRejectRemark", length=250)
 public String getIftttRejectRemark() {
     return this.iftttRejectRemark;
 }
 
 public void setIftttRejectRemark(String iftttRejectRemark) {
     this.iftttRejectRemark = iftttRejectRemark;
 }

 
 @Column(name="iftttFieldInt")
 public Integer getIftttFieldInt() {
     return this.iftttFieldInt;
 }
 
 public void setIftttFieldInt(Integer iftttFieldInt) {
     this.iftttFieldInt = iftttFieldInt;
 }

 
 @Column(name="iftttFieldBoolean")
 public Boolean getIftttFieldBoolean() {
     return this.iftttFieldBoolean;
 }
 
 public void setIftttFieldBoolean(Boolean iftttFieldBoolean) {
     this.iftttFieldBoolean = iftttFieldBoolean;
 }

 
 @Column(name="iftttGender", length=1)
 public String getIftttGender() {
     return this.iftttGender;
 }
 
 public void setIftttGender(String iftttGender) {
     this.iftttGender = iftttGender;
 }

 
 @Column(name="iftttClaimType", length=1)
 public String getIftttClaimType() {
     return this.iftttClaimType;
 }
 
 public void setIftttClaimType(String iftttClaimType) {
     this.iftttClaimType = iftttClaimType;
 }

 
 @Column(name="iftttApprovalType", length=1)
 public String getIftttApprovalType() {
     return this.iftttApprovalType;
 }
 
 public void setIftttApprovalType(String iftttApprovalType) {
     this.iftttApprovalType = iftttApprovalType;
 }




}


