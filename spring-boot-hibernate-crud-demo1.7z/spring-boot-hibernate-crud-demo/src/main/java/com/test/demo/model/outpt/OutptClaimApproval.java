package com.test.demo.model.outpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptClaimApproval class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_approval"
 ,catalog="marcmy"
)
public class OutptClaimApproval  implements java.io.Serializable {


  private Integer outptClaimAppvId;
  private OutptClaim outptClaim;
  private String outptClaimAppvCurrency;
  private BigDecimal outptClaimAppvAmount;
  private String outptClaimAppvForex;
  private Date outptClaimAppvForexDate;
  private BigDecimal outptClaimAppvForexRate;
  private String outptClaimAppvRemark;
  private String outptClaimAppvType;
  private String outptClaimAppvYesNo;
  private Boolean outptClaimAppvIsSpecAutho;
  private Integer outptClaimAppvAuthorizeBy;
  private String outptClaimAppvAuthorizeByAbbvName;
  private Integer outptClaimAppvCreatedBy;
  private String outptClaimAppvCreatedByAbbvName;
  private Date outptClaimAppvCreatedDate;
  private boolean outptClaimAppvVoid;
  private Integer outptClaimAppvVoidBy;
  private String outptClaimAppvVoidByAbbvName;
  private Date outptClaimAppvVoidDate;

 public OutptClaimApproval() {
 }

	
 public OutptClaimApproval(boolean outptClaimAppvVoid) {
     this.outptClaimAppvVoid = outptClaimAppvVoid;
 }
 public OutptClaimApproval(OutptClaim outptClaim, String outptClaimAppvCurrency, BigDecimal outptClaimAppvAmount, String outptClaimAppvForex, Date outptClaimAppvForexDate, BigDecimal outptClaimAppvForexRate, String outptClaimAppvRemark, String outptClaimAppvType, String outptClaimAppvYesNo, Boolean outptClaimAppvIsSpecAutho, Integer outptClaimAppvAuthorizeBy, String outptClaimAppvAuthorizeByAbbvName, Integer outptClaimAppvCreatedBy, String outptClaimAppvCreatedByAbbvName, Date outptClaimAppvCreatedDate, boolean outptClaimAppvVoid, Integer outptClaimAppvVoidBy, String outptClaimAppvVoidByAbbvName, Date outptClaimAppvVoidDate) {
    this.outptClaim = outptClaim;
    this.outptClaimAppvCurrency = outptClaimAppvCurrency;
    this.outptClaimAppvAmount = outptClaimAppvAmount;
    this.outptClaimAppvForex = outptClaimAppvForex;
    this.outptClaimAppvForexDate = outptClaimAppvForexDate;
    this.outptClaimAppvForexRate = outptClaimAppvForexRate;
    this.outptClaimAppvRemark = outptClaimAppvRemark;
    this.outptClaimAppvType = outptClaimAppvType;
    this.outptClaimAppvYesNo = outptClaimAppvYesNo;
    this.outptClaimAppvIsSpecAutho = outptClaimAppvIsSpecAutho;
    this.outptClaimAppvAuthorizeBy = outptClaimAppvAuthorizeBy;
    this.outptClaimAppvAuthorizeByAbbvName = outptClaimAppvAuthorizeByAbbvName;
    this.outptClaimAppvCreatedBy = outptClaimAppvCreatedBy;
    this.outptClaimAppvCreatedByAbbvName = outptClaimAppvCreatedByAbbvName;
    this.outptClaimAppvCreatedDate = outptClaimAppvCreatedDate;
    this.outptClaimAppvVoid = outptClaimAppvVoid;
    this.outptClaimAppvVoidBy = outptClaimAppvVoidBy;
    this.outptClaimAppvVoidByAbbvName = outptClaimAppvVoidByAbbvName;
    this.outptClaimAppvVoidDate = outptClaimAppvVoidDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptClaimAppvId", unique=true, nullable=false)
 public Integer getOutptClaimAppvId() {
     return this.outptClaimAppvId;
 }
 
 public void setOutptClaimAppvId(Integer outptClaimAppvId) {
     this.outptClaimAppvId = outptClaimAppvId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptClaimAppvOutptClaimId")
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="outptClaimAppvCurrency", length=4)
 public String getOutptClaimAppvCurrency() {
     return this.outptClaimAppvCurrency;
 }
 
 public void setOutptClaimAppvCurrency(String outptClaimAppvCurrency) {
     this.outptClaimAppvCurrency = outptClaimAppvCurrency;
 }

 
 @Column(name="outptClaimAppvAmount", precision=16)
 public BigDecimal getOutptClaimAppvAmount() {
     return this.outptClaimAppvAmount;
 }
 
 public void setOutptClaimAppvAmount(BigDecimal outptClaimAppvAmount) {
     this.outptClaimAppvAmount = outptClaimAppvAmount;
 }

 
 @Column(name="outptClaimAppvForex", length=3)
 public String getOutptClaimAppvForex() {
     return this.outptClaimAppvForex;
 }
 
 public void setOutptClaimAppvForex(String outptClaimAppvForex) {
     this.outptClaimAppvForex = outptClaimAppvForex;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="outptClaimAppvForexDate", length=10)
 public Date getOutptClaimAppvForexDate() {
     return this.outptClaimAppvForexDate;
 }
 
 public void setOutptClaimAppvForexDate(Date outptClaimAppvForexDate) {
     this.outptClaimAppvForexDate = outptClaimAppvForexDate;
 }

 
 @Column(name="outptClaimAppvForexRate", precision=14, scale=11)
 public BigDecimal getOutptClaimAppvForexRate() {
     return this.outptClaimAppvForexRate;
 }
 
 public void setOutptClaimAppvForexRate(BigDecimal outptClaimAppvForexRate) {
     this.outptClaimAppvForexRate = outptClaimAppvForexRate;
 }

 
 @Column(name="outptClaimAppvRemark", length=250)
 public String getOutptClaimAppvRemark() {
     return this.outptClaimAppvRemark;
 }
 
 public void setOutptClaimAppvRemark(String outptClaimAppvRemark) {
     this.outptClaimAppvRemark = outptClaimAppvRemark;
 }

 
 @Column(name="outptClaimAppvType", length=100)
 public String getOutptClaimAppvType() {
     return this.outptClaimAppvType;
 }
 
 public void setOutptClaimAppvType(String outptClaimAppvType) {
     this.outptClaimAppvType = outptClaimAppvType;
 }

 
 @Column(name="outptClaimAppvYesNo", length=1)
 public String getOutptClaimAppvYesNo() {
     return this.outptClaimAppvYesNo;
 }
 
 public void setOutptClaimAppvYesNo(String outptClaimAppvYesNo) {
     this.outptClaimAppvYesNo = outptClaimAppvYesNo;
 }

 
 @Column(name="outptClaimAppvIsSpecAutho")
 public Boolean getOutptClaimAppvIsSpecAutho() {
     return this.outptClaimAppvIsSpecAutho;
 }
 
 public void setOutptClaimAppvIsSpecAutho(Boolean outptClaimAppvIsSpecAutho) {
     this.outptClaimAppvIsSpecAutho = outptClaimAppvIsSpecAutho;
 }

 
 @Column(name="outptClaimAppvAuthorizeBy")
 public Integer getOutptClaimAppvAuthorizeBy() {
     return this.outptClaimAppvAuthorizeBy;
 }
 
 public void setOutptClaimAppvAuthorizeBy(Integer outptClaimAppvAuthorizeBy) {
     this.outptClaimAppvAuthorizeBy = outptClaimAppvAuthorizeBy;
 }

 
 @Column(name="outptClaimAppvAuthorizeByAbbvName", length=8)
 public String getOutptClaimAppvAuthorizeByAbbvName() {
     return this.outptClaimAppvAuthorizeByAbbvName;
 }
 
 public void setOutptClaimAppvAuthorizeByAbbvName(String outptClaimAppvAuthorizeByAbbvName) {
     this.outptClaimAppvAuthorizeByAbbvName = outptClaimAppvAuthorizeByAbbvName;
 }

 
 @Column(name="outptClaimAppvCreatedBy")
 public Integer getOutptClaimAppvCreatedBy() {
     return this.outptClaimAppvCreatedBy;
 }
 
 public void setOutptClaimAppvCreatedBy(Integer outptClaimAppvCreatedBy) {
     this.outptClaimAppvCreatedBy = outptClaimAppvCreatedBy;
 }

 
 @Column(name="outptClaimAppvCreatedByAbbvName", length=8)
 public String getOutptClaimAppvCreatedByAbbvName() {
     return this.outptClaimAppvCreatedByAbbvName;
 }
 
 public void setOutptClaimAppvCreatedByAbbvName(String outptClaimAppvCreatedByAbbvName) {
     this.outptClaimAppvCreatedByAbbvName = outptClaimAppvCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptClaimAppvCreatedDate", length=19)
 public Date getOutptClaimAppvCreatedDate() {
     return this.outptClaimAppvCreatedDate;
 }
 
 public void setOutptClaimAppvCreatedDate(Date outptClaimAppvCreatedDate) {
     this.outptClaimAppvCreatedDate = outptClaimAppvCreatedDate;
 }

 
 @Column(name="outptClaimAppvVoid", nullable=false)
 public boolean isOutptClaimAppvVoid() {
     return this.outptClaimAppvVoid;
 }
 
 public void setOutptClaimAppvVoid(boolean outptClaimAppvVoid) {
     this.outptClaimAppvVoid = outptClaimAppvVoid;
 }

 
 @Column(name="outptClaimAppvVoidBy")
 public Integer getOutptClaimAppvVoidBy() {
     return this.outptClaimAppvVoidBy;
 }
 
 public void setOutptClaimAppvVoidBy(Integer outptClaimAppvVoidBy) {
     this.outptClaimAppvVoidBy = outptClaimAppvVoidBy;
 }

 
 @Column(name="outptClaimAppvVoidByAbbvName", length=8)
 public String getOutptClaimAppvVoidByAbbvName() {
     return this.outptClaimAppvVoidByAbbvName;
 }
 
 public void setOutptClaimAppvVoidByAbbvName(String outptClaimAppvVoidByAbbvName) {
     this.outptClaimAppvVoidByAbbvName = outptClaimAppvVoidByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptClaimAppvVoidDate", length=19)
 public Date getOutptClaimAppvVoidDate() {
     return this.outptClaimAppvVoidDate;
 }
 
 public void setOutptClaimAppvVoidDate(Date outptClaimAppvVoidDate) {
     this.outptClaimAppvVoidDate = outptClaimAppvVoidDate;
 }




}


