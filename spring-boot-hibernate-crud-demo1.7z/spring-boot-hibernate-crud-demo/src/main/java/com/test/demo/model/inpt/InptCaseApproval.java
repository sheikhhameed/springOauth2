package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCaseApproval class 
 *  
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_approval"
 ,catalog="marcmy"
)
public class InptCaseApproval  implements java.io.Serializable {


  private Integer inptCaseAppvId;
  private InptCase inptCase;
  private String inptCaseAppvCurrency;
  private BigDecimal inptCaseAppvAmount;
  private BigDecimal inptCaseAppvPayableAmount;
  private String inptCaseAppvForex;
  private Date inptCaseAppvForexDate;
  private BigDecimal inptCaseAppvForexRate;
  private BigDecimal inptCaseAppvPayoutAmount;
  private String inptCaseAppvCaseFeeCurrency;
  private BigDecimal inptCaseAppvCaseFee;
  private String inptCaseAppvMedRptPayeeName;
  private String inptCaseAppvRemark;
  private String inptCaseAppvType;
  private String inptCaseAppvYesNo;
  private BigDecimal inptCaseAppvAmount2;
  private String inptCaseAppvRemark2;
  private Integer inptCaseAppvCreatedBy;
  private String inptCaseAppvCreatedByAbbvName;
  private Date inptCaseAppvCreatedDate;
  private Integer inptCaseAppvCreatedBy2;
  private String inptCaseAppvCreatedByAbbvName2;
  private Date inptCaseAppvCreatedDate2;
  private String inptCaseAppvEndorseBy;
  private Date inptCaseAppvActualCreatedDate;
  private Date inptCaseAppvPaySubmissionDate;
  private boolean inptCaseAppvVoid;
  private Integer inptCaseAppvVoidBy;
  private String inptCaseAppvVoidByAbbvName;
  private Date inptCaseAppvVoidDate;
  private Boolean inptCaseAppvIsSpecAutho;

 public InptCaseApproval() {
 }

	
 public InptCaseApproval(boolean inptCaseAppvVoid) {
     this.inptCaseAppvVoid = inptCaseAppvVoid;
 }
 public InptCaseApproval(InptCase inptCase, String inptCaseAppvCurrency, BigDecimal inptCaseAppvAmount, BigDecimal inptCaseAppvPayableAmount, String inptCaseAppvForex, Date inptCaseAppvForexDate, BigDecimal inptCaseAppvForexRate, BigDecimal inptCaseAppvPayoutAmount, String inptCaseAppvCaseFeeCurrency, BigDecimal inptCaseAppvCaseFee, String inptCaseAppvMedRptPayeeName, String inptCaseAppvRemark, String inptCaseAppvType, String inptCaseAppvYesNo, BigDecimal inptCaseAppvAmount2, String inptCaseAppvRemark2, Integer inptCaseAppvCreatedBy, String inptCaseAppvCreatedByAbbvName, Date inptCaseAppvCreatedDate, Integer inptCaseAppvCreatedBy2, String inptCaseAppvCreatedByAbbvName2, Date inptCaseAppvCreatedDate2, String inptCaseAppvEndorseBy, Date inptCaseAppvActualCreatedDate, Date inptCaseAppvPaySubmissionDate, boolean inptCaseAppvVoid, Integer inptCaseAppvVoidBy, String inptCaseAppvVoidByAbbvName, Date inptCaseAppvVoidDate, Boolean inptCaseAppvIsSpecAutho) {
    this.inptCase = inptCase;
    this.inptCaseAppvCurrency = inptCaseAppvCurrency;
    this.inptCaseAppvAmount = inptCaseAppvAmount;
    this.inptCaseAppvPayableAmount = inptCaseAppvPayableAmount;
    this.inptCaseAppvForex = inptCaseAppvForex;
    this.inptCaseAppvForexDate = inptCaseAppvForexDate;
    this.inptCaseAppvForexRate = inptCaseAppvForexRate;
    this.inptCaseAppvPayoutAmount = inptCaseAppvPayoutAmount;
    this.inptCaseAppvCaseFeeCurrency = inptCaseAppvCaseFeeCurrency;
    this.inptCaseAppvCaseFee = inptCaseAppvCaseFee;
    this.inptCaseAppvMedRptPayeeName = inptCaseAppvMedRptPayeeName;
    this.inptCaseAppvRemark = inptCaseAppvRemark;
    this.inptCaseAppvType = inptCaseAppvType;
    this.inptCaseAppvYesNo = inptCaseAppvYesNo;
    this.inptCaseAppvAmount2 = inptCaseAppvAmount2;
    this.inptCaseAppvRemark2 = inptCaseAppvRemark2;
    this.inptCaseAppvCreatedBy = inptCaseAppvCreatedBy;
    this.inptCaseAppvCreatedByAbbvName = inptCaseAppvCreatedByAbbvName;
    this.inptCaseAppvCreatedDate = inptCaseAppvCreatedDate;
    this.inptCaseAppvCreatedBy2 = inptCaseAppvCreatedBy2;
    this.inptCaseAppvCreatedByAbbvName2 = inptCaseAppvCreatedByAbbvName2;
    this.inptCaseAppvCreatedDate2 = inptCaseAppvCreatedDate2;
    this.inptCaseAppvEndorseBy = inptCaseAppvEndorseBy;
    this.inptCaseAppvActualCreatedDate = inptCaseAppvActualCreatedDate;
    this.inptCaseAppvPaySubmissionDate = inptCaseAppvPaySubmissionDate;
    this.inptCaseAppvVoid = inptCaseAppvVoid;
    this.inptCaseAppvVoidBy = inptCaseAppvVoidBy;
    this.inptCaseAppvVoidByAbbvName = inptCaseAppvVoidByAbbvName;
    this.inptCaseAppvVoidDate = inptCaseAppvVoidDate;
    this.inptCaseAppvIsSpecAutho = inptCaseAppvIsSpecAutho;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseAppvId", unique=true, nullable=false)
 public Integer getInptCaseAppvId() {
     return this.inptCaseAppvId;
 }
 
 public void setInptCaseAppvId(Integer inptCaseAppvId) {
     this.inptCaseAppvId = inptCaseAppvId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseAppvInptCaseId")
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="inptCaseAppvCurrency", length=4)
 public String getInptCaseAppvCurrency() {
     return this.inptCaseAppvCurrency;
 }
 
 public void setInptCaseAppvCurrency(String inptCaseAppvCurrency) {
     this.inptCaseAppvCurrency = inptCaseAppvCurrency;
 }

 
 @Column(name="inptCaseAppvAmount", precision=16)
 public BigDecimal getInptCaseAppvAmount() {
     return this.inptCaseAppvAmount;
 }
 
 public void setInptCaseAppvAmount(BigDecimal inptCaseAppvAmount) {
     this.inptCaseAppvAmount = inptCaseAppvAmount;
 }

 
 @Column(name="inptCaseAppvPayableAmount", precision=16)
 public BigDecimal getInptCaseAppvPayableAmount() {
     return this.inptCaseAppvPayableAmount;
 }
 
 public void setInptCaseAppvPayableAmount(BigDecimal inptCaseAppvPayableAmount) {
     this.inptCaseAppvPayableAmount = inptCaseAppvPayableAmount;
 }

 
 @Column(name="inptCaseAppvForex", length=3)
 public String getInptCaseAppvForex() {
     return this.inptCaseAppvForex;
 }
 
 public void setInptCaseAppvForex(String inptCaseAppvForex) {
     this.inptCaseAppvForex = inptCaseAppvForex;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptCaseAppvForexDate", length=10)
 public Date getInptCaseAppvForexDate() {
     return this.inptCaseAppvForexDate;
 }
 
 public void setInptCaseAppvForexDate(Date inptCaseAppvForexDate) {
     this.inptCaseAppvForexDate = inptCaseAppvForexDate;
 }

 
 @Column(name="inptCaseAppvForexRate", precision=14, scale=11)
 public BigDecimal getInptCaseAppvForexRate() {
     return this.inptCaseAppvForexRate;
 }
 
 public void setInptCaseAppvForexRate(BigDecimal inptCaseAppvForexRate) {
     this.inptCaseAppvForexRate = inptCaseAppvForexRate;
 }

 
 @Column(name="inptCaseAppvPayoutAmount", precision=16)
 public BigDecimal getInptCaseAppvPayoutAmount() {
     return this.inptCaseAppvPayoutAmount;
 }
 
 public void setInptCaseAppvPayoutAmount(BigDecimal inptCaseAppvPayoutAmount) {
     this.inptCaseAppvPayoutAmount = inptCaseAppvPayoutAmount;
 }

 
 @Column(name="inptCaseAppvCaseFeeCurrency", length=3)
 public String getInptCaseAppvCaseFeeCurrency() {
     return this.inptCaseAppvCaseFeeCurrency;
 }
 
 public void setInptCaseAppvCaseFeeCurrency(String inptCaseAppvCaseFeeCurrency) {
     this.inptCaseAppvCaseFeeCurrency = inptCaseAppvCaseFeeCurrency;
 }

 
 @Column(name="inptCaseAppvCaseFee", precision=16)
 public BigDecimal getInptCaseAppvCaseFee() {
     return this.inptCaseAppvCaseFee;
 }
 
 public void setInptCaseAppvCaseFee(BigDecimal inptCaseAppvCaseFee) {
     this.inptCaseAppvCaseFee = inptCaseAppvCaseFee;
 }

 
 @Column(name="inptCaseAppvMedRptPayeeName", length=250)
 public String getInptCaseAppvMedRptPayeeName() {
     return this.inptCaseAppvMedRptPayeeName;
 }
 
 public void setInptCaseAppvMedRptPayeeName(String inptCaseAppvMedRptPayeeName) {
     this.inptCaseAppvMedRptPayeeName = inptCaseAppvMedRptPayeeName;
 }

 
 @Column(name="inptCaseAppvRemark", length=250)
 public String getInptCaseAppvRemark() {
     return this.inptCaseAppvRemark;
 }
 
 public void setInptCaseAppvRemark(String inptCaseAppvRemark) {
     this.inptCaseAppvRemark = inptCaseAppvRemark;
 }

 
 @Column(name="inptCaseAppvType", length=100)
 public String getInptCaseAppvType() {
     return this.inptCaseAppvType;
 }
 
 public void setInptCaseAppvType(String inptCaseAppvType) {
     this.inptCaseAppvType = inptCaseAppvType;
 }

 
 @Column(name="inptCaseAppvYesNo", length=1)
 public String getInptCaseAppvYesNo() {
     return this.inptCaseAppvYesNo;
 }
 
 public void setInptCaseAppvYesNo(String inptCaseAppvYesNo) {
     this.inptCaseAppvYesNo = inptCaseAppvYesNo;
 }

 
 @Column(name="inptCaseAppvAmount2", precision=16)
 public BigDecimal getInptCaseAppvAmount2() {
     return this.inptCaseAppvAmount2;
 }
 
 public void setInptCaseAppvAmount2(BigDecimal inptCaseAppvAmount2) {
     this.inptCaseAppvAmount2 = inptCaseAppvAmount2;
 }

 
 @Column(name="inptCaseAppvRemark2", length=250)
 public String getInptCaseAppvRemark2() {
     return this.inptCaseAppvRemark2;
 }
 
 public void setInptCaseAppvRemark2(String inptCaseAppvRemark2) {
     this.inptCaseAppvRemark2 = inptCaseAppvRemark2;
 }

 
 @Column(name="inptCaseAppvCreatedBy")
 public Integer getInptCaseAppvCreatedBy() {
     return this.inptCaseAppvCreatedBy;
 }
 
 public void setInptCaseAppvCreatedBy(Integer inptCaseAppvCreatedBy) {
     this.inptCaseAppvCreatedBy = inptCaseAppvCreatedBy;
 }

 
 @Column(name="inptCaseAppvCreatedByAbbvName", length=8)
 public String getInptCaseAppvCreatedByAbbvName() {
     return this.inptCaseAppvCreatedByAbbvName;
 }
 
 public void setInptCaseAppvCreatedByAbbvName(String inptCaseAppvCreatedByAbbvName) {
     this.inptCaseAppvCreatedByAbbvName = inptCaseAppvCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAppvCreatedDate", length=19)
 public Date getInptCaseAppvCreatedDate() {
     return this.inptCaseAppvCreatedDate;
 }
 
 public void setInptCaseAppvCreatedDate(Date inptCaseAppvCreatedDate) {
     this.inptCaseAppvCreatedDate = inptCaseAppvCreatedDate;
 }

 
 @Column(name="inptCaseAppvCreatedBy2")
 public Integer getInptCaseAppvCreatedBy2() {
     return this.inptCaseAppvCreatedBy2;
 }
 
 public void setInptCaseAppvCreatedBy2(Integer inptCaseAppvCreatedBy2) {
     this.inptCaseAppvCreatedBy2 = inptCaseAppvCreatedBy2;
 }

 
 @Column(name="inptCaseAppvCreatedByAbbvName2", length=8)
 public String getInptCaseAppvCreatedByAbbvName2() {
     return this.inptCaseAppvCreatedByAbbvName2;
 }
 
 public void setInptCaseAppvCreatedByAbbvName2(String inptCaseAppvCreatedByAbbvName2) {
     this.inptCaseAppvCreatedByAbbvName2 = inptCaseAppvCreatedByAbbvName2;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAppvCreatedDate2", length=19)
 public Date getInptCaseAppvCreatedDate2() {
     return this.inptCaseAppvCreatedDate2;
 }
 
 public void setInptCaseAppvCreatedDate2(Date inptCaseAppvCreatedDate2) {
     this.inptCaseAppvCreatedDate2 = inptCaseAppvCreatedDate2;
 }

 
 @Column(name="inptCaseAppvEndorseBy", length=8)
 public String getInptCaseAppvEndorseBy() {
     return this.inptCaseAppvEndorseBy;
 }
 
 public void setInptCaseAppvEndorseBy(String inptCaseAppvEndorseBy) {
     this.inptCaseAppvEndorseBy = inptCaseAppvEndorseBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAppvActualCreatedDate", length=19)
 public Date getInptCaseAppvActualCreatedDate() {
     return this.inptCaseAppvActualCreatedDate;
 }
 
 public void setInptCaseAppvActualCreatedDate(Date inptCaseAppvActualCreatedDate) {
     this.inptCaseAppvActualCreatedDate = inptCaseAppvActualCreatedDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAppvPaySubmissionDate", length=19)
 public Date getInptCaseAppvPaySubmissionDate() {
     return this.inptCaseAppvPaySubmissionDate;
 }
 
 public void setInptCaseAppvPaySubmissionDate(Date inptCaseAppvPaySubmissionDate) {
     this.inptCaseAppvPaySubmissionDate = inptCaseAppvPaySubmissionDate;
 }

 
 @Column(name="inptCaseAppvVoid", nullable=false)
 public boolean isInptCaseAppvVoid() {
     return this.inptCaseAppvVoid;
 }
 
 public void setInptCaseAppvVoid(boolean inptCaseAppvVoid) {
     this.inptCaseAppvVoid = inptCaseAppvVoid;
 }

 
 @Column(name="inptCaseAppvVoidBy")
 public Integer getInptCaseAppvVoidBy() {
     return this.inptCaseAppvVoidBy;
 }
 
 public void setInptCaseAppvVoidBy(Integer inptCaseAppvVoidBy) {
     this.inptCaseAppvVoidBy = inptCaseAppvVoidBy;
 }

 
 @Column(name="inptCaseAppvVoidByAbbvName", length=8)
 public String getInptCaseAppvVoidByAbbvName() {
     return this.inptCaseAppvVoidByAbbvName;
 }
 
 public void setInptCaseAppvVoidByAbbvName(String inptCaseAppvVoidByAbbvName) {
     this.inptCaseAppvVoidByAbbvName = inptCaseAppvVoidByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAppvVoidDate", length=19)
 public Date getInptCaseAppvVoidDate() {
     return this.inptCaseAppvVoidDate;
 }
 
 public void setInptCaseAppvVoidDate(Date inptCaseAppvVoidDate) {
     this.inptCaseAppvVoidDate = inptCaseAppvVoidDate;
 }

 
 @Column(name="inptCaseAppvIsSpecAutho")
 public Boolean getInptCaseAppvIsSpecAutho() {
     return this.inptCaseAppvIsSpecAutho;
 }
 
 public void setInptCaseAppvIsSpecAutho(Boolean inptCaseAppvIsSpecAutho) {
     this.inptCaseAppvIsSpecAutho = inptCaseAppvIsSpecAutho;
 }




}


