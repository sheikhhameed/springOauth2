package com.test.demo.model.inpt;


import static javax.persistence.GenerationType.IDENTITY;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.IftttRule;
import com.test.demo.model.common.MedicalProviderCoPay;
import com.test.demo.model.common.ProgramService;

/**
 * This is inptPlan class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_plan"
 ,catalog="marcmy"
)
public class InptPlan  implements java.io.Serializable {


  private Integer inptPlanId;
  private InptPlanLimits inptPlanLimits;
  private InptPlanLimitsRemark inptPlanLimitsRemark;
  private ProgramService programService;
  private Integer inptPlanCreatedBy;
  private Date inptPlanCreatedDate;
  private Integer inptPlanLastEdittedBy;
  private Date inptPlanLastEdittedDate;
  private String inptPlanName;
  private String inptPlanExtCode;
  private Boolean inptPlanGstNotDeductAl;
  private Boolean inptPlanGhGl;
  private Boolean inptPlanEnabled;
  private Boolean inptPlanBackToBack;
  private Integer inptPlanClientMailId;
  private String inptPlanPolicyType;
  private Boolean inptPlanImaEnabled;
  private Long inptPlanImaLimit;
  private String inptPlanCurrency;
  private Integer inptPlanPostFollowUpDaysS;
  private Integer inptPlanPostFollowUpDaysNs;
  private Integer inptPlanPostFollowUpDays;
  private BigDecimal inptPlanCoPayPercent;
  private BigDecimal inptPlanCoPayBufferPercent;
  private BigDecimal inptPlanThresholdAmt;
  private Character inptPlanCoPayRbType;
  private Integer inptPlanCoPayMaxAmt;
  private Integer inptPlanCoPayMinAmt;
  private BigDecimal inptPlanCoPayImagingPercent;
  private BigDecimal inptPlanCoInsPercent;
  private Integer inptPlanCoInsMaxAmt;
  private Integer inptPlanCoInsMinAmt;
  private Character inptPlanCoInsApplyWhich;
  private BigDecimal inptPlanMajMedCoInsPercent;
  private Character inptPlanMajMedPaidBy;
  private Integer inptPlanScaleDownPercent;
  private Boolean inptPlanVarianceEnabled;
  private BigDecimal inptPlanVarianceAllowPercent;
  private Character inptPlanCummDeductResetFreq;
  private Character inptPlanExcessPaidBy;
  private String inptPlanWsTemplateName1;
  private String inptPlanWsTemplateName2;
  private String inptPlanWsTemplateName3;
  private String inptPlanWsTemplateName4;
  private String inptPlanWsTemplateName5;
  private String inptPlanCsuWsTemplateName1;
  private String inptPlanCsuWsTemplateName2;
  private String inptPlanCsuWsTemplateName3;
  private String inptPlanCsuWsTemplateName4;
  private String inptPlanCsuWsTemplateName5;
  private Integer inptPlanFrontMedicalCard;
  private Integer inptPlanBackMedicalCard;
  private String inptPlanFrontMedicalCardDetailHtml;
  private String inptPlanBackMedicalCardDetailHtml;
  private Boolean inptPlanMedPrvCoPayIsPercent;
  private BigDecimal inptPlanMedPrvCoPayInValue;
  private BigDecimal inptPlanMedPrvCoPayOutValue;
  private String inptPlanNotes;
  private Integer inptPlanRbsbillingPrdId;
  private Integer inptPlanAccProfileInsurerPaidBy;
  private Integer inptPlanAccProfileB2bPaidBy;
  private boolean inptPlanEmmAllowEmember;
  private boolean inptPlanEmmAllowQrCheckIn;
  private boolean inptPlanEmmAllowInptCaseSubmission;
  private boolean inptPlanEmmAllowInptPlanList;
  private boolean inptPlanEmmAllowInptCaseList;
  private boolean inptPlanEmmAllowOutptCaseSubmission;
  private boolean inptPlanEmmAllowOutptCaseList;
  private boolean inptPlanEmmAllowOutptPlanList;
  private boolean inptPlanEmmAllowProviderSearch;
  private boolean inptPlanEmmAllowContactUs;
  private Set<IftttRule> iftttRules = new HashSet<IftttRule>(0);
  private Set<InptPolicyPlan> inptPolicyPlans = new HashSet<InptPolicyPlan>(0);
  private Set<InptPlanFileRepo> inptPlanFileRepos = new HashSet<InptPlanFileRepo>(0);
  private Set<MedicalProviderCoPay> medicalProviderCoPays = new HashSet<MedicalProviderCoPay>(0);

 public InptPlan() {
 }

	
 public InptPlan(InptPlanLimits inptPlanLimits, InptPlanLimitsRemark inptPlanLimitsRemark, ProgramService programService, boolean inptPlanEmmAllowEmember, boolean inptPlanEmmAllowQrCheckIn, boolean inptPlanEmmAllowInptCaseSubmission, boolean inptPlanEmmAllowInptPlanList, boolean inptPlanEmmAllowInptCaseList, boolean inptPlanEmmAllowOutptCaseSubmission, boolean inptPlanEmmAllowOutptCaseList, boolean inptPlanEmmAllowOutptPlanList, boolean inptPlanEmmAllowProviderSearch, boolean inptPlanEmmAllowContactUs) {
     this.inptPlanLimits = inptPlanLimits;
     this.inptPlanLimitsRemark = inptPlanLimitsRemark;
     this.programService = programService;
     this.inptPlanEmmAllowEmember = inptPlanEmmAllowEmember;
     this.inptPlanEmmAllowQrCheckIn = inptPlanEmmAllowQrCheckIn;
     this.inptPlanEmmAllowInptCaseSubmission = inptPlanEmmAllowInptCaseSubmission;
     this.inptPlanEmmAllowInptPlanList = inptPlanEmmAllowInptPlanList;
     this.inptPlanEmmAllowInptCaseList = inptPlanEmmAllowInptCaseList;
     this.inptPlanEmmAllowOutptCaseSubmission = inptPlanEmmAllowOutptCaseSubmission;
     this.inptPlanEmmAllowOutptCaseList = inptPlanEmmAllowOutptCaseList;
     this.inptPlanEmmAllowOutptPlanList = inptPlanEmmAllowOutptPlanList;
     this.inptPlanEmmAllowProviderSearch = inptPlanEmmAllowProviderSearch;
     this.inptPlanEmmAllowContactUs = inptPlanEmmAllowContactUs;
 }
 public InptPlan(InptPlanLimits inptPlanLimits, InptPlanLimitsRemark inptPlanLimitsRemark, ProgramService programService, Integer inptPlanCreatedBy, Date inptPlanCreatedDate, Integer inptPlanLastEdittedBy, Date inptPlanLastEdittedDate, String inptPlanName, String inptPlanExtCode, Boolean inptPlanGstNotDeductAl, Boolean inptPlanGhGl, Boolean inptPlanEnabled, Boolean inptPlanBackToBack, Integer inptPlanClientMailId, String inptPlanPolicyType, Boolean inptPlanImaEnabled, Long inptPlanImaLimit, String inptPlanCurrency, Integer inptPlanPostFollowUpDaysS, Integer inptPlanPostFollowUpDaysNs, Integer inptPlanPostFollowUpDays, BigDecimal inptPlanCoPayPercent, BigDecimal inptPlanCoPayBufferPercent, BigDecimal inptPlanThresholdAmt, Character inptPlanCoPayRbType, Integer inptPlanCoPayMaxAmt, Integer inptPlanCoPayMinAmt, BigDecimal inptPlanCoPayImagingPercent, BigDecimal inptPlanCoInsPercent, Integer inptPlanCoInsMaxAmt, Integer inptPlanCoInsMinAmt, Character inptPlanCoInsApplyWhich, BigDecimal inptPlanMajMedCoInsPercent, Character inptPlanMajMedPaidBy, Integer inptPlanScaleDownPercent, Boolean inptPlanVarianceEnabled, BigDecimal inptPlanVarianceAllowPercent, Character inptPlanCummDeductResetFreq, Character inptPlanExcessPaidBy, String inptPlanWsTemplateName1, String inptPlanWsTemplateName2, String inptPlanWsTemplateName3, String inptPlanWsTemplateName4, String inptPlanWsTemplateName5, String inptPlanCsuWsTemplateName1, String inptPlanCsuWsTemplateName2, String inptPlanCsuWsTemplateName3, String inptPlanCsuWsTemplateName4, String inptPlanCsuWsTemplateName5, Integer inptPlanFrontMedicalCard, Integer inptPlanBackMedicalCard, String inptPlanFrontMedicalCardDetailHtml, String inptPlanBackMedicalCardDetailHtml, Boolean inptPlanMedPrvCoPayIsPercent, BigDecimal inptPlanMedPrvCoPayInValue, BigDecimal inptPlanMedPrvCoPayOutValue, String inptPlanNotes, Integer inptPlanRbsbillingPrdId, Integer inptPlanAccProfileInsurerPaidBy, Integer inptPlanAccProfileB2bPaidBy, boolean inptPlanEmmAllowEmember, boolean inptPlanEmmAllowQrCheckIn, boolean inptPlanEmmAllowInptCaseSubmission, boolean inptPlanEmmAllowInptPlanList, boolean inptPlanEmmAllowInptCaseList, boolean inptPlanEmmAllowOutptCaseSubmission, boolean inptPlanEmmAllowOutptCaseList, boolean inptPlanEmmAllowOutptPlanList, boolean inptPlanEmmAllowProviderSearch, boolean inptPlanEmmAllowContactUs, Set<IftttRule> iftttRules, Set<InptPolicyPlan> inptPolicyPlans, Set<InptPlanFileRepo> inptPlanFileRepos, Set<MedicalProviderCoPay> medicalProviderCoPays) {
    this.inptPlanLimits = inptPlanLimits;
    this.inptPlanLimitsRemark = inptPlanLimitsRemark;
    this.programService = programService;
    this.inptPlanCreatedBy = inptPlanCreatedBy;
    this.inptPlanCreatedDate = inptPlanCreatedDate;
    this.inptPlanLastEdittedBy = inptPlanLastEdittedBy;
    this.inptPlanLastEdittedDate = inptPlanLastEdittedDate;
    this.inptPlanName = inptPlanName;
    this.inptPlanExtCode = inptPlanExtCode;
    this.inptPlanGstNotDeductAl = inptPlanGstNotDeductAl;
    this.inptPlanGhGl = inptPlanGhGl;
    this.inptPlanEnabled = inptPlanEnabled;
    this.inptPlanBackToBack = inptPlanBackToBack;
    this.inptPlanClientMailId = inptPlanClientMailId;
    this.inptPlanPolicyType = inptPlanPolicyType;
    this.inptPlanImaEnabled = inptPlanImaEnabled;
    this.inptPlanImaLimit = inptPlanImaLimit;
    this.inptPlanCurrency = inptPlanCurrency;
    this.inptPlanPostFollowUpDaysS = inptPlanPostFollowUpDaysS;
    this.inptPlanPostFollowUpDaysNs = inptPlanPostFollowUpDaysNs;
    this.inptPlanPostFollowUpDays = inptPlanPostFollowUpDays;
    this.inptPlanCoPayPercent = inptPlanCoPayPercent;
    this.inptPlanCoPayBufferPercent = inptPlanCoPayBufferPercent;
    this.inptPlanThresholdAmt = inptPlanThresholdAmt;
    this.inptPlanCoPayRbType = inptPlanCoPayRbType;
    this.inptPlanCoPayMaxAmt = inptPlanCoPayMaxAmt;
    this.inptPlanCoPayMinAmt = inptPlanCoPayMinAmt;
    this.inptPlanCoPayImagingPercent = inptPlanCoPayImagingPercent;
    this.inptPlanCoInsPercent = inptPlanCoInsPercent;
    this.inptPlanCoInsMaxAmt = inptPlanCoInsMaxAmt;
    this.inptPlanCoInsMinAmt = inptPlanCoInsMinAmt;
    this.inptPlanCoInsApplyWhich = inptPlanCoInsApplyWhich;
    this.inptPlanMajMedCoInsPercent = inptPlanMajMedCoInsPercent;
    this.inptPlanMajMedPaidBy = inptPlanMajMedPaidBy;
    this.inptPlanScaleDownPercent = inptPlanScaleDownPercent;
    this.inptPlanVarianceEnabled = inptPlanVarianceEnabled;
    this.inptPlanVarianceAllowPercent = inptPlanVarianceAllowPercent;
    this.inptPlanCummDeductResetFreq = inptPlanCummDeductResetFreq;
    this.inptPlanExcessPaidBy = inptPlanExcessPaidBy;
    this.inptPlanWsTemplateName1 = inptPlanWsTemplateName1;
    this.inptPlanWsTemplateName2 = inptPlanWsTemplateName2;
    this.inptPlanWsTemplateName3 = inptPlanWsTemplateName3;
    this.inptPlanWsTemplateName4 = inptPlanWsTemplateName4;
    this.inptPlanWsTemplateName5 = inptPlanWsTemplateName5;
    this.inptPlanCsuWsTemplateName1 = inptPlanCsuWsTemplateName1;
    this.inptPlanCsuWsTemplateName2 = inptPlanCsuWsTemplateName2;
    this.inptPlanCsuWsTemplateName3 = inptPlanCsuWsTemplateName3;
    this.inptPlanCsuWsTemplateName4 = inptPlanCsuWsTemplateName4;
    this.inptPlanCsuWsTemplateName5 = inptPlanCsuWsTemplateName5;
    this.inptPlanFrontMedicalCard = inptPlanFrontMedicalCard;
    this.inptPlanBackMedicalCard = inptPlanBackMedicalCard;
    this.inptPlanFrontMedicalCardDetailHtml = inptPlanFrontMedicalCardDetailHtml;
    this.inptPlanBackMedicalCardDetailHtml = inptPlanBackMedicalCardDetailHtml;
    this.inptPlanMedPrvCoPayIsPercent = inptPlanMedPrvCoPayIsPercent;
    this.inptPlanMedPrvCoPayInValue = inptPlanMedPrvCoPayInValue;
    this.inptPlanMedPrvCoPayOutValue = inptPlanMedPrvCoPayOutValue;
    this.inptPlanNotes = inptPlanNotes;
    this.inptPlanRbsbillingPrdId = inptPlanRbsbillingPrdId;
    this.inptPlanAccProfileInsurerPaidBy = inptPlanAccProfileInsurerPaidBy;
    this.inptPlanAccProfileB2bPaidBy = inptPlanAccProfileB2bPaidBy;
    this.inptPlanEmmAllowEmember = inptPlanEmmAllowEmember;
    this.inptPlanEmmAllowQrCheckIn = inptPlanEmmAllowQrCheckIn;
    this.inptPlanEmmAllowInptCaseSubmission = inptPlanEmmAllowInptCaseSubmission;
    this.inptPlanEmmAllowInptPlanList = inptPlanEmmAllowInptPlanList;
    this.inptPlanEmmAllowInptCaseList = inptPlanEmmAllowInptCaseList;
    this.inptPlanEmmAllowOutptCaseSubmission = inptPlanEmmAllowOutptCaseSubmission;
    this.inptPlanEmmAllowOutptCaseList = inptPlanEmmAllowOutptCaseList;
    this.inptPlanEmmAllowOutptPlanList = inptPlanEmmAllowOutptPlanList;
    this.inptPlanEmmAllowProviderSearch = inptPlanEmmAllowProviderSearch;
    this.inptPlanEmmAllowContactUs = inptPlanEmmAllowContactUs;
    this.iftttRules = iftttRules;
    this.inptPolicyPlans = inptPolicyPlans;
    this.inptPlanFileRepos = inptPlanFileRepos;
    this.medicalProviderCoPays = medicalProviderCoPays;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptPlanId", unique=true, nullable=false)
 public Integer getInptPlanId() {
     return this.inptPlanId;
 }
 
 public void setInptPlanId(Integer inptPlanId) {
     this.inptPlanId = inptPlanId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptPlanInptPlanLimitsId", nullable=false)
 public InptPlanLimits getInptPlanLimits() {
     return this.inptPlanLimits;
 }
 
 public void setInptPlanLimits(InptPlanLimits inptPlanLimits) {
     this.inptPlanLimits = inptPlanLimits;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptPlanInptPlanLimitsRemarkId", nullable=false)
 public InptPlanLimitsRemark getInptPlanLimitsRemark() {
     return this.inptPlanLimitsRemark;
 }
 
 public void setInptPlanLimitsRemark(InptPlanLimitsRemark inptPlanLimitsRemark) {
     this.inptPlanLimitsRemark = inptPlanLimitsRemark;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptPlanPrgSvcId", nullable=false)
 public ProgramService getProgramService() {
     return this.programService;
 }
 
 public void setProgramService(ProgramService programService) {
     this.programService = programService;
 }

 
 @Column(name="inptPlanCreatedBy")
 public Integer getInptPlanCreatedBy() {
     return this.inptPlanCreatedBy;
 }
 
 public void setInptPlanCreatedBy(Integer inptPlanCreatedBy) {
     this.inptPlanCreatedBy = inptPlanCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptPlanCreatedDate", length=19)
 public Date getInptPlanCreatedDate() {
     return this.inptPlanCreatedDate;
 }
 
 public void setInptPlanCreatedDate(Date inptPlanCreatedDate) {
     this.inptPlanCreatedDate = inptPlanCreatedDate;
 }

 
 @Column(name="inptPlanLastEdittedBy")
 public Integer getInptPlanLastEdittedBy() {
     return this.inptPlanLastEdittedBy;
 }
 
 public void setInptPlanLastEdittedBy(Integer inptPlanLastEdittedBy) {
     this.inptPlanLastEdittedBy = inptPlanLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptPlanLastEdittedDate", length=19)
 public Date getInptPlanLastEdittedDate() {
     return this.inptPlanLastEdittedDate;
 }
 
 public void setInptPlanLastEdittedDate(Date inptPlanLastEdittedDate) {
     this.inptPlanLastEdittedDate = inptPlanLastEdittedDate;
 }

 
 @Column(name="inptPlanName", length=100)
 public String getInptPlanName() {
     return this.inptPlanName;
 }
 
 public void setInptPlanName(String inptPlanName) {
     this.inptPlanName = inptPlanName;
 }

 
 @Column(name="inptPlanExtCode", length=100)
 public String getInptPlanExtCode() {
     return this.inptPlanExtCode;
 }
 
 public void setInptPlanExtCode(String inptPlanExtCode) {
     this.inptPlanExtCode = inptPlanExtCode;
 }

 
 @Column(name="inptPlanGstNotDeductAl")
 public Boolean getInptPlanGstNotDeductAl() {
     return this.inptPlanGstNotDeductAl;
 }
 
 public void setInptPlanGstNotDeductAl(Boolean inptPlanGstNotDeductAl) {
     this.inptPlanGstNotDeductAl = inptPlanGstNotDeductAl;
 }

 
 @Column(name="inptPlanGhGl")
 public Boolean getInptPlanGhGl() {
     return this.inptPlanGhGl;
 }
 
 public void setInptPlanGhGl(Boolean inptPlanGhGl) {
     this.inptPlanGhGl = inptPlanGhGl;
 }

 
 @Column(name="inptPlanEnabled")
 public Boolean getInptPlanEnabled() {
     return this.inptPlanEnabled;
 }
 
 public void setInptPlanEnabled(Boolean inptPlanEnabled) {
     this.inptPlanEnabled = inptPlanEnabled;
 }

 
 @Column(name="inptPlanBackToBack")
 public Boolean getInptPlanBackToBack() {
     return this.inptPlanBackToBack;
 }
 
 public void setInptPlanBackToBack(Boolean inptPlanBackToBack) {
     this.inptPlanBackToBack = inptPlanBackToBack;
 }

 
 @Column(name="inptPlanClientMailId")
 public Integer getInptPlanClientMailId() {
     return this.inptPlanClientMailId;
 }
 
 public void setInptPlanClientMailId(Integer inptPlanClientMailId) {
     this.inptPlanClientMailId = inptPlanClientMailId;
 }

 
 @Column(name="inptPlanPolicyType", length=2)
 public String getInptPlanPolicyType() {
     return this.inptPlanPolicyType;
 }
 
 public void setInptPlanPolicyType(String inptPlanPolicyType) {
     this.inptPlanPolicyType = inptPlanPolicyType;
 }

 
 @Column(name="inptPlanImaEnabled")
 public Boolean getInptPlanImaEnabled() {
     return this.inptPlanImaEnabled;
 }
 
 public void setInptPlanImaEnabled(Boolean inptPlanImaEnabled) {
     this.inptPlanImaEnabled = inptPlanImaEnabled;
 }

 
 @Column(name="inptPlanImaLimit")
 public Long getInptPlanImaLimit() {
     return this.inptPlanImaLimit;
 }
 
 public void setInptPlanImaLimit(Long inptPlanImaLimit) {
     this.inptPlanImaLimit = inptPlanImaLimit;
 }

 
 @Column(name="inptPlanCurrency", length=4)
 public String getInptPlanCurrency() {
     return this.inptPlanCurrency;
 }
 
 public void setInptPlanCurrency(String inptPlanCurrency) {
     this.inptPlanCurrency = inptPlanCurrency;
 }

 
 @Column(name="inptPlanPostFollowUpDaysS")
 public Integer getInptPlanPostFollowUpDaysS() {
     return this.inptPlanPostFollowUpDaysS;
 }
 
 public void setInptPlanPostFollowUpDaysS(Integer inptPlanPostFollowUpDaysS) {
     this.inptPlanPostFollowUpDaysS = inptPlanPostFollowUpDaysS;
 }

 
 @Column(name="inptPlanPostFollowUpDaysNs")
 public Integer getInptPlanPostFollowUpDaysNs() {
     return this.inptPlanPostFollowUpDaysNs;
 }
 
 public void setInptPlanPostFollowUpDaysNs(Integer inptPlanPostFollowUpDaysNs) {
     this.inptPlanPostFollowUpDaysNs = inptPlanPostFollowUpDaysNs;
 }

 
 @Column(name="inptPlanPostFollowUpDays")
 public Integer getInptPlanPostFollowUpDays() {
     return this.inptPlanPostFollowUpDays;
 }
 
 public void setInptPlanPostFollowUpDays(Integer inptPlanPostFollowUpDays) {
     this.inptPlanPostFollowUpDays = inptPlanPostFollowUpDays;
 }

 
 @Column(name="inptPlanCoPayPercent", precision=9, scale=5)
 public BigDecimal getInptPlanCoPayPercent() {
     return this.inptPlanCoPayPercent;
 }
 
 public void setInptPlanCoPayPercent(BigDecimal inptPlanCoPayPercent) {
     this.inptPlanCoPayPercent = inptPlanCoPayPercent;
 }

 
 @Column(name="inptPlanCoPayBufferPercent", precision=9, scale=5)
 public BigDecimal getInptPlanCoPayBufferPercent() {
     return this.inptPlanCoPayBufferPercent;
 }
 
 public void setInptPlanCoPayBufferPercent(BigDecimal inptPlanCoPayBufferPercent) {
     this.inptPlanCoPayBufferPercent = inptPlanCoPayBufferPercent;
 }

 
 @Column(name="inptPlanThresholdAmt", precision=9)
 public BigDecimal getInptPlanThresholdAmt() {
     return this.inptPlanThresholdAmt;
 }
 
 public void setInptPlanThresholdAmt(BigDecimal inptPlanThresholdAmt) {
     this.inptPlanThresholdAmt = inptPlanThresholdAmt;
 }

 
 @Column(name="inptPlanCoPayRbType", length=1)
 public Character getInptPlanCoPayRbType() {
     return this.inptPlanCoPayRbType;
 }
 
 public void setInptPlanCoPayRbType(Character inptPlanCoPayRbType) {
     this.inptPlanCoPayRbType = inptPlanCoPayRbType;
 }

 
 @Column(name="inptPlanCoPayMaxAmt")
 public Integer getInptPlanCoPayMaxAmt() {
     return this.inptPlanCoPayMaxAmt;
 }
 
 public void setInptPlanCoPayMaxAmt(Integer inptPlanCoPayMaxAmt) {
     this.inptPlanCoPayMaxAmt = inptPlanCoPayMaxAmt;
 }

 
 @Column(name="inptPlanCoPayMinAmt")
 public Integer getInptPlanCoPayMinAmt() {
     return this.inptPlanCoPayMinAmt;
 }
 
 public void setInptPlanCoPayMinAmt(Integer inptPlanCoPayMinAmt) {
     this.inptPlanCoPayMinAmt = inptPlanCoPayMinAmt;
 }

 
 @Column(name="inptPlanCoPayImagingPercent", precision=9, scale=5)
 public BigDecimal getInptPlanCoPayImagingPercent() {
     return this.inptPlanCoPayImagingPercent;
 }
 
 public void setInptPlanCoPayImagingPercent(BigDecimal inptPlanCoPayImagingPercent) {
     this.inptPlanCoPayImagingPercent = inptPlanCoPayImagingPercent;
 }

 
 @Column(name="inptPlanCoInsPercent", precision=9, scale=5)
 public BigDecimal getInptPlanCoInsPercent() {
     return this.inptPlanCoInsPercent;
 }
 
 public void setInptPlanCoInsPercent(BigDecimal inptPlanCoInsPercent) {
     this.inptPlanCoInsPercent = inptPlanCoInsPercent;
 }

 
 @Column(name="inptPlanCoInsMaxAmt")
 public Integer getInptPlanCoInsMaxAmt() {
     return this.inptPlanCoInsMaxAmt;
 }
 
 public void setInptPlanCoInsMaxAmt(Integer inptPlanCoInsMaxAmt) {
     this.inptPlanCoInsMaxAmt = inptPlanCoInsMaxAmt;
 }

 
 @Column(name="inptPlanCoInsMinAmt")
 public Integer getInptPlanCoInsMinAmt() {
     return this.inptPlanCoInsMinAmt;
 }
 
 public void setInptPlanCoInsMinAmt(Integer inptPlanCoInsMinAmt) {
     this.inptPlanCoInsMinAmt = inptPlanCoInsMinAmt;
 }

 
 @Column(name="inptPlanCoInsApplyWhich", length=1)
 public Character getInptPlanCoInsApplyWhich() {
     return this.inptPlanCoInsApplyWhich;
 }
 
 public void setInptPlanCoInsApplyWhich(Character inptPlanCoInsApplyWhich) {
     this.inptPlanCoInsApplyWhich = inptPlanCoInsApplyWhich;
 }

 
 @Column(name="inptPlanMajMedCoInsPercent", precision=9, scale=5)
 public BigDecimal getInptPlanMajMedCoInsPercent() {
     return this.inptPlanMajMedCoInsPercent;
 }
 
 public void setInptPlanMajMedCoInsPercent(BigDecimal inptPlanMajMedCoInsPercent) {
     this.inptPlanMajMedCoInsPercent = inptPlanMajMedCoInsPercent;
 }

 
 @Column(name="inptPlanMajMedPaidBy", length=1)
 public Character getInptPlanMajMedPaidBy() {
     return this.inptPlanMajMedPaidBy;
 }
 
 public void setInptPlanMajMedPaidBy(Character inptPlanMajMedPaidBy) {
     this.inptPlanMajMedPaidBy = inptPlanMajMedPaidBy;
 }

 
 @Column(name="inptPlanScaleDownPercent")
 public Integer getInptPlanScaleDownPercent() {
     return this.inptPlanScaleDownPercent;
 }
 
 public void setInptPlanScaleDownPercent(Integer inptPlanScaleDownPercent) {
     this.inptPlanScaleDownPercent = inptPlanScaleDownPercent;
 }

 
 @Column(name="inptPlanVarianceEnabled")
 public Boolean getInptPlanVarianceEnabled() {
     return this.inptPlanVarianceEnabled;
 }
 
 public void setInptPlanVarianceEnabled(Boolean inptPlanVarianceEnabled) {
     this.inptPlanVarianceEnabled = inptPlanVarianceEnabled;
 }

 
 @Column(name="inptPlanVarianceAllowPercent", precision=9, scale=5)
 public BigDecimal getInptPlanVarianceAllowPercent() {
     return this.inptPlanVarianceAllowPercent;
 }
 
 public void setInptPlanVarianceAllowPercent(BigDecimal inptPlanVarianceAllowPercent) {
     this.inptPlanVarianceAllowPercent = inptPlanVarianceAllowPercent;
 }

 
 @Column(name="inptPlanCummDeductResetFreq", length=1)
 public Character getInptPlanCummDeductResetFreq() {
     return this.inptPlanCummDeductResetFreq;
 }
 
 public void setInptPlanCummDeductResetFreq(Character inptPlanCummDeductResetFreq) {
     this.inptPlanCummDeductResetFreq = inptPlanCummDeductResetFreq;
 }

 
 @Column(name="inptPlanExcessPaidBy", length=1)
 public Character getInptPlanExcessPaidBy() {
     return this.inptPlanExcessPaidBy;
 }
 
 public void setInptPlanExcessPaidBy(Character inptPlanExcessPaidBy) {
     this.inptPlanExcessPaidBy = inptPlanExcessPaidBy;
 }

 
 @Column(name="inptPlanWsTemplateName1", length=100)
 public String getInptPlanWsTemplateName1() {
     return this.inptPlanWsTemplateName1;
 }
 
 public void setInptPlanWsTemplateName1(String inptPlanWsTemplateName1) {
     this.inptPlanWsTemplateName1 = inptPlanWsTemplateName1;
 }

 
 @Column(name="inptPlanWsTemplateName2", length=100)
 public String getInptPlanWsTemplateName2() {
     return this.inptPlanWsTemplateName2;
 }
 
 public void setInptPlanWsTemplateName2(String inptPlanWsTemplateName2) {
     this.inptPlanWsTemplateName2 = inptPlanWsTemplateName2;
 }

 
 @Column(name="inptPlanWsTemplateName3", length=100)
 public String getInptPlanWsTemplateName3() {
     return this.inptPlanWsTemplateName3;
 }
 
 public void setInptPlanWsTemplateName3(String inptPlanWsTemplateName3) {
     this.inptPlanWsTemplateName3 = inptPlanWsTemplateName3;
 }

 
 @Column(name="inptPlanWsTemplateName4", length=100)
 public String getInptPlanWsTemplateName4() {
     return this.inptPlanWsTemplateName4;
 }
 
 public void setInptPlanWsTemplateName4(String inptPlanWsTemplateName4) {
     this.inptPlanWsTemplateName4 = inptPlanWsTemplateName4;
 }

 
 @Column(name="inptPlanWsTemplateName5", length=100)
 public String getInptPlanWsTemplateName5() {
     return this.inptPlanWsTemplateName5;
 }
 
 public void setInptPlanWsTemplateName5(String inptPlanWsTemplateName5) {
     this.inptPlanWsTemplateName5 = inptPlanWsTemplateName5;
 }

 
 @Column(name="inptPlanCsuWsTemplateName1", length=100)
 public String getInptPlanCsuWsTemplateName1() {
     return this.inptPlanCsuWsTemplateName1;
 }
 
 public void setInptPlanCsuWsTemplateName1(String inptPlanCsuWsTemplateName1) {
     this.inptPlanCsuWsTemplateName1 = inptPlanCsuWsTemplateName1;
 }

 
 @Column(name="inptPlanCsuWsTemplateName2", length=100)
 public String getInptPlanCsuWsTemplateName2() {
     return this.inptPlanCsuWsTemplateName2;
 }
 
 public void setInptPlanCsuWsTemplateName2(String inptPlanCsuWsTemplateName2) {
     this.inptPlanCsuWsTemplateName2 = inptPlanCsuWsTemplateName2;
 }

 
 @Column(name="inptPlanCsuWsTemplateName3", length=100)
 public String getInptPlanCsuWsTemplateName3() {
     return this.inptPlanCsuWsTemplateName3;
 }
 
 public void setInptPlanCsuWsTemplateName3(String inptPlanCsuWsTemplateName3) {
     this.inptPlanCsuWsTemplateName3 = inptPlanCsuWsTemplateName3;
 }

 
 @Column(name="inptPlanCsuWsTemplateName4", length=100)
 public String getInptPlanCsuWsTemplateName4() {
     return this.inptPlanCsuWsTemplateName4;
 }
 
 public void setInptPlanCsuWsTemplateName4(String inptPlanCsuWsTemplateName4) {
     this.inptPlanCsuWsTemplateName4 = inptPlanCsuWsTemplateName4;
 }

 
 @Column(name="inptPlanCsuWsTemplateName5", length=100)
 public String getInptPlanCsuWsTemplateName5() {
     return this.inptPlanCsuWsTemplateName5;
 }
 
 public void setInptPlanCsuWsTemplateName5(String inptPlanCsuWsTemplateName5) {
     this.inptPlanCsuWsTemplateName5 = inptPlanCsuWsTemplateName5;
 }

 
 @Column(name="InptPlanFrontMedicalCard")
 public Integer getInptPlanFrontMedicalCard() {
     return this.inptPlanFrontMedicalCard;
 }
 
 public void setInptPlanFrontMedicalCard(Integer inptPlanFrontMedicalCard) {
     this.inptPlanFrontMedicalCard = inptPlanFrontMedicalCard;
 }

 
 @Column(name="InptPlanBackMedicalCard")
 public Integer getInptPlanBackMedicalCard() {
     return this.inptPlanBackMedicalCard;
 }
 
 public void setInptPlanBackMedicalCard(Integer inptPlanBackMedicalCard) {
     this.inptPlanBackMedicalCard = inptPlanBackMedicalCard;
 }

 
 @Column(name="InptPlanFrontMedicalCardDetailHtml")
 public String getInptPlanFrontMedicalCardDetailHtml() {
     return this.inptPlanFrontMedicalCardDetailHtml;
 }
 
 public void setInptPlanFrontMedicalCardDetailHtml(String inptPlanFrontMedicalCardDetailHtml) {
     this.inptPlanFrontMedicalCardDetailHtml = inptPlanFrontMedicalCardDetailHtml;
 }

 
 @Column(name="InptPlanBackMedicalCardDetailHtml")
 public String getInptPlanBackMedicalCardDetailHtml() {
     return this.inptPlanBackMedicalCardDetailHtml;
 }
 
 public void setInptPlanBackMedicalCardDetailHtml(String inptPlanBackMedicalCardDetailHtml) {
     this.inptPlanBackMedicalCardDetailHtml = inptPlanBackMedicalCardDetailHtml;
 }

 
 @Column(name="InptPlanMedPrvCoPayIsPercent")
 public Boolean getInptPlanMedPrvCoPayIsPercent() {
     return this.inptPlanMedPrvCoPayIsPercent;
 }
 
 public void setInptPlanMedPrvCoPayIsPercent(Boolean inptPlanMedPrvCoPayIsPercent) {
     this.inptPlanMedPrvCoPayIsPercent = inptPlanMedPrvCoPayIsPercent;
 }

 
 @Column(name="InptPlanMedPrvCoPayInValue", precision=9, scale=5)
 public BigDecimal getInptPlanMedPrvCoPayInValue() {
     return this.inptPlanMedPrvCoPayInValue;
 }
 
 public void setInptPlanMedPrvCoPayInValue(BigDecimal inptPlanMedPrvCoPayInValue) {
     this.inptPlanMedPrvCoPayInValue = inptPlanMedPrvCoPayInValue;
 }

 
 @Column(name="InptPlanMedPrvCoPayOutValue", precision=9, scale=5)
 public BigDecimal getInptPlanMedPrvCoPayOutValue() {
     return this.inptPlanMedPrvCoPayOutValue;
 }
 
 public void setInptPlanMedPrvCoPayOutValue(BigDecimal inptPlanMedPrvCoPayOutValue) {
     this.inptPlanMedPrvCoPayOutValue = inptPlanMedPrvCoPayOutValue;
 }

 
 @Column(name="inptPlanNotes", length=16777215)
 public String getInptPlanNotes() {
     return this.inptPlanNotes;
 }
 
 public void setInptPlanNotes(String inptPlanNotes) {
     this.inptPlanNotes = inptPlanNotes;
 }

 
 @Column(name="inptPlanRBSBillingPrdId")
 public Integer getInptPlanRbsbillingPrdId() {
     return this.inptPlanRbsbillingPrdId;
 }
 
 public void setInptPlanRbsbillingPrdId(Integer inptPlanRbsbillingPrdId) {
     this.inptPlanRbsbillingPrdId = inptPlanRbsbillingPrdId;
 }

 
 @Column(name="inptPlanAccProfileInsurerPaidBy")
 public Integer getInptPlanAccProfileInsurerPaidBy() {
     return this.inptPlanAccProfileInsurerPaidBy;
 }
 
 public void setInptPlanAccProfileInsurerPaidBy(Integer inptPlanAccProfileInsurerPaidBy) {
     this.inptPlanAccProfileInsurerPaidBy = inptPlanAccProfileInsurerPaidBy;
 }

 
 @Column(name="inptPlanAccProfileB2bPaidBy")
 public Integer getInptPlanAccProfileB2bPaidBy() {
     return this.inptPlanAccProfileB2bPaidBy;
 }
 
 public void setInptPlanAccProfileB2bPaidBy(Integer inptPlanAccProfileB2bPaidBy) {
     this.inptPlanAccProfileB2bPaidBy = inptPlanAccProfileB2bPaidBy;
 }

 
 @Column(name="inptPlanEmmAllowEmember", nullable=false)
 public boolean isInptPlanEmmAllowEmember() {
     return this.inptPlanEmmAllowEmember;
 }
 
 public void setInptPlanEmmAllowEmember(boolean inptPlanEmmAllowEmember) {
     this.inptPlanEmmAllowEmember = inptPlanEmmAllowEmember;
 }

 
 @Column(name="inptPlanEmmAllowQrCheckIn", nullable=false)
 public boolean isInptPlanEmmAllowQrCheckIn() {
     return this.inptPlanEmmAllowQrCheckIn;
 }
 
 public void setInptPlanEmmAllowQrCheckIn(boolean inptPlanEmmAllowQrCheckIn) {
     this.inptPlanEmmAllowQrCheckIn = inptPlanEmmAllowQrCheckIn;
 }

 
 @Column(name="inptPlanEmmAllowInptCaseSubmission", nullable=false)
 public boolean isInptPlanEmmAllowInptCaseSubmission() {
     return this.inptPlanEmmAllowInptCaseSubmission;
 }
 
 public void setInptPlanEmmAllowInptCaseSubmission(boolean inptPlanEmmAllowInptCaseSubmission) {
     this.inptPlanEmmAllowInptCaseSubmission = inptPlanEmmAllowInptCaseSubmission;
 }

 
 @Column(name="inptPlanEmmAllowInptPlanList", nullable=false)
 public boolean isInptPlanEmmAllowInptPlanList() {
     return this.inptPlanEmmAllowInptPlanList;
 }
 
 public void setInptPlanEmmAllowInptPlanList(boolean inptPlanEmmAllowInptPlanList) {
     this.inptPlanEmmAllowInptPlanList = inptPlanEmmAllowInptPlanList;
 }

 
 @Column(name="inptPlanEmmAllowInptCaseList", nullable=false)
 public boolean isInptPlanEmmAllowInptCaseList() {
     return this.inptPlanEmmAllowInptCaseList;
 }
 
 public void setInptPlanEmmAllowInptCaseList(boolean inptPlanEmmAllowInptCaseList) {
     this.inptPlanEmmAllowInptCaseList = inptPlanEmmAllowInptCaseList;
 }

 
 @Column(name="inptPlanEmmAllowOutptCaseSubmission", nullable=false)
 public boolean isInptPlanEmmAllowOutptCaseSubmission() {
     return this.inptPlanEmmAllowOutptCaseSubmission;
 }
 
 public void setInptPlanEmmAllowOutptCaseSubmission(boolean inptPlanEmmAllowOutptCaseSubmission) {
     this.inptPlanEmmAllowOutptCaseSubmission = inptPlanEmmAllowOutptCaseSubmission;
 }

 
 @Column(name="inptPlanEmmAllowOutptCaseList", nullable=false)
 public boolean isInptPlanEmmAllowOutptCaseList() {
     return this.inptPlanEmmAllowOutptCaseList;
 }
 
 public void setInptPlanEmmAllowOutptCaseList(boolean inptPlanEmmAllowOutptCaseList) {
     this.inptPlanEmmAllowOutptCaseList = inptPlanEmmAllowOutptCaseList;
 }

 
 @Column(name="inptPlanEmmAllowOutptPlanList", nullable=false)
 public boolean isInptPlanEmmAllowOutptPlanList() {
     return this.inptPlanEmmAllowOutptPlanList;
 }
 
 public void setInptPlanEmmAllowOutptPlanList(boolean inptPlanEmmAllowOutptPlanList) {
     this.inptPlanEmmAllowOutptPlanList = inptPlanEmmAllowOutptPlanList;
 }

 
 @Column(name="inptPlanEmmAllowProviderSearch", nullable=false)
 public boolean isInptPlanEmmAllowProviderSearch() {
     return this.inptPlanEmmAllowProviderSearch;
 }
 
 public void setInptPlanEmmAllowProviderSearch(boolean inptPlanEmmAllowProviderSearch) {
     this.inptPlanEmmAllowProviderSearch = inptPlanEmmAllowProviderSearch;
 }

 
 @Column(name="inptPlanEmmAllowContactUs", nullable=false)
 public boolean isInptPlanEmmAllowContactUs() {
     return this.inptPlanEmmAllowContactUs;
 }
 
 public void setInptPlanEmmAllowContactUs(boolean inptPlanEmmAllowContactUs) {
     this.inptPlanEmmAllowContactUs = inptPlanEmmAllowContactUs;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPlan")
 public Set<IftttRule> getIftttRules() {
     return this.iftttRules;
 }
 
 public void setIftttRules(Set<IftttRule> iftttRules) {
     this.iftttRules = iftttRules;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPlan")
 public Set<InptPolicyPlan> getInptPolicyPlans() {
     return this.inptPolicyPlans;
 }
 
 public void setInptPolicyPlans(Set<InptPolicyPlan> inptPolicyPlans) {
     this.inptPolicyPlans = inptPolicyPlans;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPlan")
 public Set<InptPlanFileRepo> getInptPlanFileRepos() {
     return this.inptPlanFileRepos;
 }
 
 public void setInptPlanFileRepos(Set<InptPlanFileRepo> inptPlanFileRepos) {
     this.inptPlanFileRepos = inptPlanFileRepos;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPlan")
 public Set<MedicalProviderCoPay> getMedicalProviderCoPays() {
     return this.medicalProviderCoPays;
 }
 
 public void setMedicalProviderCoPays(Set<MedicalProviderCoPay> medicalProviderCoPays) {
     this.medicalProviderCoPays = medicalProviderCoPays;
 }




}


