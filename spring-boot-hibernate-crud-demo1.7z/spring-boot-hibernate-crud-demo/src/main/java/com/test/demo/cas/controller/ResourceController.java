//package com.test.demo.cas.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.oauth2.provider.endpoint.TokenEndpoint;
//import org.springframework.security.oauth2.provider.token.TokenStore;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.test.demo.cas.service.GenericService;
//
//@RestController
//@RequestMapping("/jwttest")
//public class ResourceController {
//
//	@Autowired
//	private GenericService userService;
//	
//	@Autowired
//	private TokenEndpoint tokenEndpoint; 
//	
//	@Autowired
//	private TokenStore tokenStore;
//	
////	@RequestMapping(value="/cities")
////	@PreAuthorize("hasAuthority('ADMIN_USER') or hasAuthority('STANDARD_USER')")
////	public List<RandomCity> getUser(){
//////		return userService.findAllRandomCities();
////	}
//}
