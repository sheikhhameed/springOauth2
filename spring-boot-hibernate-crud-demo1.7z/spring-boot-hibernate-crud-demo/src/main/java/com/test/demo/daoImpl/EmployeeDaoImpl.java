package com.test.demo.daoImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.spi.ServiceException;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.test.demo.dao.EmployeeDao;
import com.test.demo.model.common.EmployeeEntity;
import com.test.demo.model.outpt.OutptClaim;
import com.test.demo.repository.EmployeeRepository;
import com.test.demo.repository.OutptClaimRepository;

@Component
public class EmployeeDaoImpl implements EmployeeDao{

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeDaoImpl.class);
    @Autowired
    EmployeeRepository repository;
    
    @Autowired
    OutptClaimRepository outptClaimRepository;
     
    /**
     * This method is to get the list of employee
     * 
     */
    public List<EmployeeEntity> getAllEmployees()
    {
    	LOGGER.info("Entering into the getAllEmployee method !");
        List<EmployeeEntity> employeeList = repository.findAll();
         
        if(employeeList.size() > 0) {
            return employeeList;
        } else {
            return new ArrayList<EmployeeEntity>();
        }
    }
     /**
      * This method is to get the employee details by employeeId
      * @param id
      */
    public EmployeeEntity getEmployeeById(Long id) 
    {
    	EmployeeEntity employeeEntity = new EmployeeEntity();
         try {
        	 
        	 Optional<EmployeeEntity> employee = repository.findById(id);
        	 if(employee.isPresent()) {
        		 employeeEntity= employee.get();
             } 
         }catch (Exception e) {
			System.out.println("no recordd: "+e+" and exception is : "+e.getCause());
		}
       
//        else {
//            throw new RecordNotFoundException("No employee record exist for given id");
//        }
         return employeeEntity;
    }
     
    /**
     * This method is to create or update the employees
     * @param entity
     */
    public EmployeeEntity createOrUpdateEmployee(EmployeeEntity entity)    {
        Optional<EmployeeEntity> employee = repository.findById(entity.getId());
         
        if(employee.isPresent())
        {
            EmployeeEntity newEntity = employee.get();
            newEntity.setEmail(entity.getEmail());
            newEntity.setFirstName(entity.getFirstName());
            newEntity.setLastName(entity.getLastName());
 
            newEntity = repository.save(newEntity);
             
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    }
     
    /**
     * This mehthod is to delete the employee by id
     * 
     * @param id
     */
    public void deleteEmployeeById(Long id) 
	{
		EmployeeEntity employeeEntity = new EmployeeEntity();
		try {

			Optional<EmployeeEntity> employee = repository.findById(id);

			repository.deleteById(id);
//			if (employee.isPresent()) {
//				repository.deleteById(id);
//			}
//        else {
//            throw new RecordNotFoundException("No employee record exist for given id");
//        }
		} catch (ServiceException e) {
			System.out.println("no recordd: " + e + " and exception is : " + e.getCause());
		}

//    else {
//        throw new RecordNotFoundException("No employee record exist for given id");
//    }
//     return employeeEntity;
	}
	@Override
	public OutptClaim getOutptClaim(int claimId) {
		
		Optional<OutptClaim> outptClaim ;
		outptClaim= outptClaimRepository.findById(claimId);
		return outptClaim.get();		
	}
}
