package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is accountProfile class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="account_profile"
 ,catalog="marcmy"
)
public class AccountProfile  implements java.io.Serializable {


  private Integer apId;
  private Client client;
  private String apCustomerId;
  private String apCustomerName;
  private String apItemNo;
  private Boolean apEnabled;
  private Integer apCreatedBy;
  private Date apCreatedDate;
  private Integer apLastEditedBy;
  private Date apLastEditedDate;
  private String apServices;

 public AccountProfile() {
 }

 public AccountProfile(Client client, String apCustomerId, String apCustomerName, String apItemNo, Boolean apEnabled, Integer apCreatedBy, Date apCreatedDate, Integer apLastEditedBy, Date apLastEditedDate,String apServices) {
    this.client = client;
    this.apCustomerId = apCustomerId;
    this.apCustomerName = apCustomerName;
    this.apItemNo = apItemNo;
    this.apEnabled = apEnabled;
    this.apCreatedBy = apCreatedBy;
    this.apCreatedDate = apCreatedDate;
    this.apLastEditedBy = apLastEditedBy;
    this.apLastEditedDate = apLastEditedDate;
    this.apServices = apServices;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="apId", unique=true, nullable=false)
 public Integer getApId() {
     return this.apId;
 }
 
 public void setApId(Integer apId) {
     this.apId = apId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="apClientId")
 public Client getClient() {
     return this.client;
 }
 
 public void setClient(Client client) {
     this.client = client;
 }

 
 @Column(name="apCustomerId", length=20)
 public String getApCustomerId() {
     return this.apCustomerId;
 }
 
 public void setApCustomerId(String apCustomerId) {
     this.apCustomerId = apCustomerId;
 }

 
 @Column(name="apCustomerName", length=100)
 public String getApCustomerName() {
     return this.apCustomerName;
 }
 
 public void setApCustomerName(String apCustomerName) {
     this.apCustomerName = apCustomerName;
 }

 
 @Column(name="apItemNo", length=20)
 public String getApItemNo() {
     return this.apItemNo;
 }
 
 public void setApItemNo(String apItemNo) {
     this.apItemNo = apItemNo;
 }

 
 @Column(name="apEnabled")
 public Boolean getApEnabled() {
     return this.apEnabled;
 }
 
 public void setApEnabled(Boolean apEnabled) {
     this.apEnabled = apEnabled;
 }

 
 @Column(name="apCreatedBy")
 public Integer getApCreatedBy() {
     return this.apCreatedBy;
 }
 
 public void setApCreatedBy(Integer apCreatedBy) {
     this.apCreatedBy = apCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="apCreatedDate", length=19)
 public Date getApCreatedDate() {
     return this.apCreatedDate;
 }
 
 public void setApCreatedDate(Date apCreatedDate) {
     this.apCreatedDate = apCreatedDate;
 }

 
 @Column(name="apLastEditedBy")
 public Integer getApLastEditedBy() {
     return this.apLastEditedBy;
 }
 
 public void setApLastEditedBy(Integer apLastEditedBy) {
     this.apLastEditedBy = apLastEditedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="apLastEditedDate", length=19)
 public Date getApLastEditedDate() {
     return this.apLastEditedDate;
 }
 
 public void setApLastEditedDate(Date apLastEditedDate) {
     this.apLastEditedDate = apLastEditedDate;
 }

 @Column(name="apServices", length=50)
 public String getApServices() {
     return apServices;
 }

 public void setApServices(String apServices) {
     this.apServices = apServices;
 }


}


