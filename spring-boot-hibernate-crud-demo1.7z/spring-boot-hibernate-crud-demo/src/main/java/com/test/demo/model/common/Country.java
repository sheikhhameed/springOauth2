package com.test.demo.model.common;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This is country class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="country"
 ,catalog="marcmy"
)
public class Country  implements java.io.Serializable {


  private Integer countryId;
  private String iso;
  private String name;
  private String printableName;
  private String iso3;
  private Short numcode;
  private String currency;
  private Set<IftttCondition> iftttConditions = new HashSet<IftttCondition>(0);
  private Set<User> users = new HashSet<User>(0);

 public Country() {
 }

	
 public Country(String iso, String name, String printableName) {
     this.iso = iso;
     this.name = name;
     this.printableName = printableName;
 }
 public Country(String iso, String name, String printableName, String iso3, Short numcode, String currency, Set<IftttCondition> iftttConditions, Set<User> users) {
    this.iso = iso;
    this.name = name;
    this.printableName = printableName;
    this.iso3 = iso3;
    this.numcode = numcode;
    this.currency = currency;
    this.iftttConditions = iftttConditions;
    this.users = users;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="countryId", unique=true, nullable=false)
 public Integer getCountryId() {
     return this.countryId;
 }
 
 public void setCountryId(Integer countryId) {
     this.countryId = countryId;
 }

 
 @Column(name="iso", nullable=false, length=2)
 public String getIso() {
     return this.iso;
 }
 
 public void setIso(String iso) {
     this.iso = iso;
 }

 
 @Column(name="name", nullable=false, length=80)
 public String getName() {
     return this.name;
 }
 
 public void setName(String name) {
     this.name = name;
 }

 
 @Column(name="printable_name", nullable=false, length=80)
 public String getPrintableName() {
     return this.printableName;
 }
 
 public void setPrintableName(String printableName) {
     this.printableName = printableName;
 }

 
 @Column(name="iso3", length=3)
 public String getIso3() {
     return this.iso3;
 }
 
 public void setIso3(String iso3) {
     this.iso3 = iso3;
 }

 
 @Column(name="numcode")
 public Short getNumcode() {
     return this.numcode;
 }
 
 public void setNumcode(Short numcode) {
     this.numcode = numcode;
 }

 
 @Column(name="currency", length=4)
 public String getCurrency() {
     return this.currency;
 }
 
 public void setCurrency(String currency) {
     this.currency = currency;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="country")
 public Set<IftttCondition> getIftttConditions() {
     return this.iftttConditions;
 }
 
 public void setIftttConditions(Set<IftttCondition> iftttConditions) {
     this.iftttConditions = iftttConditions;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="country")
 public Set<User> getUsers() {
     return this.users;
 }
 
 public void setUsers(Set<User> users) {
     this.users = users;
 }




}


