package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is CCM class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="ccm"
 ,catalog="marcmy"
)
public class Ccm  implements java.io.Serializable {


  private Integer ccmId;
  private Client client;
  private Integer ccmCreatedBy;
  private Date ccmCreatedDate;
  private String ccmCreatedByAbbvName;
  private Integer ccmLastEdittedBy;
  private String ccmLastEdittedByAbbvName;
  private Date ccmLastEdittedDate;
  private String ccmStatus;
  private Character ccmCallType;
  private String ccmCallerName;
  private Character ccmCategory;
  private Character ccmChannel;
  private Character ccmMedium;
  private String ccmProduct;
  private String ccmMatters;
  private String ccmActionTaken;
  private String ccmRemarks;
  private String ccmDissatisfaction;
  private String ccmAgentCode;
  private String ccmIncidentLocation;
  private Date ccmClosedDate;
  private Date ccmCallDate;
  private String ccmMmName;
  private String ccmMmChineseName;
  private String ccmMmNric;
  private String ccmMmExtRef;
  private String ccmMmOtherIc;
  private Date ccmMmDob;
  private String ccmMmPolicyNum;
  private String ccmMmAddress1;
  private String ccmMmAddress2;
  private String ccmMmAddress3;
  private String ccmMmAddress4;
  private String ccmMmPostal;
  private String ccmMmCity;
  private String ccmMmCountry;
  private String ccmMmEmailAddress;
  private String ccmMmPhoneNum;
  private Integer ccmMmImppId;
  private Integer ccmMmOmpId;
  private String ccmCallerLocation;
  private String ccmCallerPhoneNum;
  private String ccmCallerAddress1;
  private String ccmCallerAddress2;
  private String ccmCallerAddress3;
  private String ccmCallerAddress4;
  private String ccmPolInsurerAgencyName;
  private String ccmPolInsurerAgencyChineseName;
  private String ccmPolInsurerAgencyCode;
  private Boolean ccmPostedToInptCasePhoneLog;
  private Boolean ccmIsPanelHospital;
  private String ccmInptCaseId;
  private String ccmInOutCaseId;

 public Ccm() {
 }

 public Ccm(Client client, Integer ccmCreatedBy, Date ccmCreatedDate, String ccmCreatedByAbbvName, Integer ccmLastEdittedBy, String ccmLastEdittedByAbbvName, Date ccmLastEdittedDate, String ccmStatus, Character ccmCallType, String ccmCallerName, Character ccmCategory, Character ccmChannel, Character ccmMedium, String ccmProduct, String ccmMatters, String ccmActionTaken, String ccmRemarks, String ccmDissatisfaction, String ccmAgentCode, String ccmIncidentLocation, Date ccmClosedDate, Date ccmCallDate, String ccmMmName, String ccmMmChineseName, String ccmMmNric, String ccmMmExtRef, String ccmMmOtherIc, Date ccmMmDob, String ccmMmPolicyNum, String ccmMmAddress1, String ccmMmAddress2, String ccmMmAddress3, String ccmMmAddress4, String ccmMmPostal, String ccmMmCity, String ccmMmCountry, String ccmMmEmailAddress, String ccmMmPhoneNum, Integer ccmMmImppId, Integer ccmMmOmpId, String ccmCallerLocation, String ccmCallerPhoneNum, String ccmCallerAddress1, String ccmCallerAddress2, String ccmCallerAddress3, String ccmCallerAddress4, String ccmPolInsurerAgencyName, String ccmPolInsurerAgencyChineseName, String ccmPolInsurerAgencyCode, Boolean ccmPostedToInptCasePhoneLog, Boolean ccmIsPanelHospital, String ccmInptCaseId, String ccmInOutCaseId) {
    this.client = client;
    this.ccmCreatedBy = ccmCreatedBy;
    this.ccmCreatedDate = ccmCreatedDate;
    this.ccmCreatedByAbbvName = ccmCreatedByAbbvName;
    this.ccmLastEdittedBy = ccmLastEdittedBy;
    this.ccmLastEdittedByAbbvName = ccmLastEdittedByAbbvName;
    this.ccmLastEdittedDate = ccmLastEdittedDate;
    this.ccmStatus = ccmStatus;
    this.ccmCallType = ccmCallType;
    this.ccmCallerName = ccmCallerName;
    this.ccmCategory = ccmCategory;
    this.ccmChannel = ccmChannel;
    this.ccmMedium = ccmMedium;
    this.ccmProduct = ccmProduct;
    this.ccmMatters = ccmMatters;
    this.ccmActionTaken = ccmActionTaken;
    this.ccmRemarks = ccmRemarks;
    this.ccmDissatisfaction = ccmDissatisfaction;
    this.ccmAgentCode = ccmAgentCode;
    this.ccmIncidentLocation = ccmIncidentLocation;
    this.ccmClosedDate = ccmClosedDate;
    this.ccmCallDate = ccmCallDate;
    this.ccmMmName = ccmMmName;
    this.ccmMmChineseName = ccmMmChineseName;
    this.ccmMmNric = ccmMmNric;
    this.ccmMmExtRef = ccmMmExtRef;
    this.ccmMmOtherIc = ccmMmOtherIc;
    this.ccmMmDob = ccmMmDob;
    this.ccmMmPolicyNum = ccmMmPolicyNum;
    this.ccmMmAddress1 = ccmMmAddress1;
    this.ccmMmAddress2 = ccmMmAddress2;
    this.ccmMmAddress3 = ccmMmAddress3;
    this.ccmMmAddress4 = ccmMmAddress4;
    this.ccmMmPostal = ccmMmPostal;
    this.ccmMmCity = ccmMmCity;
    this.ccmMmCountry = ccmMmCountry;
    this.ccmMmEmailAddress = ccmMmEmailAddress;
    this.ccmMmPhoneNum = ccmMmPhoneNum;
    this.ccmMmImppId = ccmMmImppId;
    this.ccmMmOmpId = ccmMmOmpId;
    this.ccmCallerLocation = ccmCallerLocation;
    this.ccmCallerPhoneNum = ccmCallerPhoneNum;
    this.ccmCallerAddress1 = ccmCallerAddress1;
    this.ccmCallerAddress2 = ccmCallerAddress2;
    this.ccmCallerAddress3 = ccmCallerAddress3;
    this.ccmCallerAddress4 = ccmCallerAddress4;
    this.ccmPolInsurerAgencyName = ccmPolInsurerAgencyName;
    this.ccmPolInsurerAgencyChineseName = ccmPolInsurerAgencyChineseName;
    this.ccmPolInsurerAgencyCode = ccmPolInsurerAgencyCode;
    this.ccmPostedToInptCasePhoneLog = ccmPostedToInptCasePhoneLog;
    this.ccmIsPanelHospital = ccmIsPanelHospital;
    this.ccmInptCaseId = ccmInptCaseId;
    this.ccmInOutCaseId = ccmInOutCaseId;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ccmId", unique=true, nullable=false)
 public Integer getCcmId() {
     return this.ccmId;
 }
 
 public void setCcmId(Integer ccmId) {
     this.ccmId = ccmId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ccmClientId")
 public Client getClient() {
     return this.client;
 }
 
 public void setClient(Client client) {
     this.client = client;
 }

 
 @Column(name="ccmCreatedBy")
 public Integer getCcmCreatedBy() {
     return this.ccmCreatedBy;
 }
 
 public void setCcmCreatedBy(Integer ccmCreatedBy) {
     this.ccmCreatedBy = ccmCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ccmCreatedDate", length=19)
 public Date getCcmCreatedDate() {
     return this.ccmCreatedDate;
 }
 
 public void setCcmCreatedDate(Date ccmCreatedDate) {
     this.ccmCreatedDate = ccmCreatedDate;
 }

 
 @Column(name="ccmCreatedByAbbvName", length=8)
 public String getCcmCreatedByAbbvName() {
     return this.ccmCreatedByAbbvName;
 }
 
 public void setCcmCreatedByAbbvName(String ccmCreatedByAbbvName) {
     this.ccmCreatedByAbbvName = ccmCreatedByAbbvName;
 }

 
 @Column(name="ccmLastEdittedBy")
 public Integer getCcmLastEdittedBy() {
     return this.ccmLastEdittedBy;
 }
 
 public void setCcmLastEdittedBy(Integer ccmLastEdittedBy) {
     this.ccmLastEdittedBy = ccmLastEdittedBy;
 }

 
 @Column(name="ccmLastEdittedByAbbvName", length=8)
 public String getCcmLastEdittedByAbbvName() {
     return this.ccmLastEdittedByAbbvName;
 }
 
 public void setCcmLastEdittedByAbbvName(String ccmLastEdittedByAbbvName) {
     this.ccmLastEdittedByAbbvName = ccmLastEdittedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ccmLastEdittedDate", length=19)
 public Date getCcmLastEdittedDate() {
     return this.ccmLastEdittedDate;
 }
 
 public void setCcmLastEdittedDate(Date ccmLastEdittedDate) {
     this.ccmLastEdittedDate = ccmLastEdittedDate;
 }

 
 @Column(name="ccmStatus", length=10)
 public String getCcmStatus() {
     return this.ccmStatus;
 }
 
 public void setCcmStatus(String ccmStatus) {
     this.ccmStatus = ccmStatus;
 }

 
 @Column(name="ccmCallType", length=1)
 public Character getCcmCallType() {
     return this.ccmCallType;
 }
 
 public void setCcmCallType(Character ccmCallType) {
     this.ccmCallType = ccmCallType;
 }

 
 @Column(name="ccmCallerName", length=100)
 public String getCcmCallerName() {
     return this.ccmCallerName;
 }
 
 public void setCcmCallerName(String ccmCallerName) {
     this.ccmCallerName = ccmCallerName;
 }

 
 @Column(name="ccmCategory", length=1)
 public Character getCcmCategory() {
     return this.ccmCategory;
 }
 
 public void setCcmCategory(Character ccmCategory) {
     this.ccmCategory = ccmCategory;
 }

 
 @Column(name="ccmChannel", length=1)
 public Character getCcmChannel() {
     return this.ccmChannel;
 }
 
 public void setCcmChannel(Character ccmChannel) {
     this.ccmChannel = ccmChannel;
 }

 
 @Column(name="ccmMedium", length=1)
 public Character getCcmMedium() {
     return this.ccmMedium;
 }
 
 public void setCcmMedium(Character ccmMedium) {
     this.ccmMedium = ccmMedium;
 }

 
 @Column(name="ccmProduct", length=50)
 public String getCcmProduct() {
     return this.ccmProduct;
 }
 
 public void setCcmProduct(String ccmProduct) {
     this.ccmProduct = ccmProduct;
 }

 
 @Column(name="ccmMatters", length=16777215)
 public String getCcmMatters() {
     return this.ccmMatters;
 }
 
 public void setCcmMatters(String ccmMatters) {
     this.ccmMatters = ccmMatters;
 }

 
 @Column(name="ccmActionTaken", length=16777215)
 public String getCcmActionTaken() {
     return this.ccmActionTaken;
 }
 
 public void setCcmActionTaken(String ccmActionTaken) {
     this.ccmActionTaken = ccmActionTaken;
 }

 
 @Column(name="ccmRemarks", length=16777215)
 public String getCcmRemarks() {
     return this.ccmRemarks;
 }
 
 public void setCcmRemarks(String ccmRemarks) {
     this.ccmRemarks = ccmRemarks;
 }

 
 @Column(name="ccmDissatisfaction", length=250)
 public String getCcmDissatisfaction() {
     return this.ccmDissatisfaction;
 }
 
 public void setCcmDissatisfaction(String ccmDissatisfaction) {
     this.ccmDissatisfaction = ccmDissatisfaction;
 }

 
 @Column(name="ccmAgentCode", length=100)
 public String getCcmAgentCode() {
     return this.ccmAgentCode;
 }
 
 public void setCcmAgentCode(String ccmAgentCode) {
     this.ccmAgentCode = ccmAgentCode;
 }

 
 @Column(name="ccmIncidentLocation", length=250)
 public String getCcmIncidentLocation() {
     return this.ccmIncidentLocation;
 }
 
 public void setCcmIncidentLocation(String ccmIncidentLocation) {
     this.ccmIncidentLocation = ccmIncidentLocation;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ccmClosedDate", length=19)
 public Date getCcmClosedDate() {
     return this.ccmClosedDate;
 }
 
 public void setCcmClosedDate(Date ccmClosedDate) {
     this.ccmClosedDate = ccmClosedDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ccmCallDate", length=19)
 public Date getCcmCallDate() {
     return this.ccmCallDate;
 }
 
 public void setCcmCallDate(Date ccmCallDate) {
     this.ccmCallDate = ccmCallDate;
 }

 
 @Column(name="ccmMmName", length=100)
 public String getCcmMmName() {
     return this.ccmMmName;
 }
 
 public void setCcmMmName(String ccmMmName) {
     this.ccmMmName = ccmMmName;
 }

 
 @Column(name="ccmMmChineseName", length=5)
 public String getCcmMmChineseName() {
     return this.ccmMmChineseName;
 }
 
 public void setCcmMmChineseName(String ccmMmChineseName) {
     this.ccmMmChineseName = ccmMmChineseName;
 }

 
 @Column(name="ccmMmNric", length=30)
 public String getCcmMmNric() {
     return this.ccmMmNric;
 }
 
 public void setCcmMmNric(String ccmMmNric) {
     this.ccmMmNric = ccmMmNric;
 }

 
 @Column(name="ccmMmExtRef", length=20)
 public String getCcmMmExtRef() {
     return this.ccmMmExtRef;
 }
 
 public void setCcmMmExtRef(String ccmMmExtRef) {
     this.ccmMmExtRef = ccmMmExtRef;
 }

 
 @Column(name="ccmMmOtherIc", length=30)
 public String getCcmMmOtherIc() {
     return this.ccmMmOtherIc;
 }
 
 public void setCcmMmOtherIc(String ccmMmOtherIc) {
     this.ccmMmOtherIc = ccmMmOtherIc;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ccmMmDob", length=10)
 public Date getCcmMmDob() {
     return this.ccmMmDob;
 }
 
 public void setCcmMmDob(Date ccmMmDob) {
     this.ccmMmDob = ccmMmDob;
 }

 
 @Column(name="ccmMmPolicyNum", length=25)
 public String getCcmMmPolicyNum() {
     return this.ccmMmPolicyNum;
 }
 
 public void setCcmMmPolicyNum(String ccmMmPolicyNum) {
     this.ccmMmPolicyNum = ccmMmPolicyNum;
 }

 
 @Column(name="ccmMmAddress1", length=150)
 public String getCcmMmAddress1() {
     return this.ccmMmAddress1;
 }
 
 public void setCcmMmAddress1(String ccmMmAddress1) {
     this.ccmMmAddress1 = ccmMmAddress1;
 }

 
 @Column(name="ccmMmAddress2", length=150)
 public String getCcmMmAddress2() {
     return this.ccmMmAddress2;
 }
 
 public void setCcmMmAddress2(String ccmMmAddress2) {
     this.ccmMmAddress2 = ccmMmAddress2;
 }

 
 @Column(name="ccmMmAddress3", length=150)
 public String getCcmMmAddress3() {
     return this.ccmMmAddress3;
 }
 
 public void setCcmMmAddress3(String ccmMmAddress3) {
     this.ccmMmAddress3 = ccmMmAddress3;
 }

 
 @Column(name="ccmMmAddress4", length=150)
 public String getCcmMmAddress4() {
     return this.ccmMmAddress4;
 }
 
 public void setCcmMmAddress4(String ccmMmAddress4) {
     this.ccmMmAddress4 = ccmMmAddress4;
 }

 
 @Column(name="ccmMmPostal", length=10)
 public String getCcmMmPostal() {
     return this.ccmMmPostal;
 }
 
 public void setCcmMmPostal(String ccmMmPostal) {
     this.ccmMmPostal = ccmMmPostal;
 }

 
 @Column(name="ccmMmCity", length=60)
 public String getCcmMmCity() {
     return this.ccmMmCity;
 }
 
 public void setCcmMmCity(String ccmMmCity) {
     this.ccmMmCity = ccmMmCity;
 }

 
 @Column(name="ccmMmCountry", length=80)
 public String getCcmMmCountry() {
     return this.ccmMmCountry;
 }
 
 public void setCcmMmCountry(String ccmMmCountry) {
     this.ccmMmCountry = ccmMmCountry;
 }

 
 @Column(name="ccmMmEmailAddress", length=100)
 public String getCcmMmEmailAddress() {
     return this.ccmMmEmailAddress;
 }
 
 public void setCcmMmEmailAddress(String ccmMmEmailAddress) {
     this.ccmMmEmailAddress = ccmMmEmailAddress;
 }

 
 @Column(name="ccmMmPhoneNum", length=50)
 public String getCcmMmPhoneNum() {
     return this.ccmMmPhoneNum;
 }
 
 public void setCcmMmPhoneNum(String ccmMmPhoneNum) {
     this.ccmMmPhoneNum = ccmMmPhoneNum;
 }

 
 @Column(name="ccmMmImppId")
 public Integer getCcmMmImppId() {
     return this.ccmMmImppId;
 }
 
 public void setCcmMmImppId(Integer ccmMmImppId) {
     this.ccmMmImppId = ccmMmImppId;
 }

 
 @Column(name="ccmMmOmpId")
 public Integer getCcmMmOmpId() {
     return this.ccmMmOmpId;
 }
 
 public void setCcmMmOmpId(Integer ccmMmOmpId) {
     this.ccmMmOmpId = ccmMmOmpId;
 }

 
 @Column(name="ccmCallerLocation", length=100)
 public String getCcmCallerLocation() {
     return this.ccmCallerLocation;
 }
 
 public void setCcmCallerLocation(String ccmCallerLocation) {
     this.ccmCallerLocation = ccmCallerLocation;
 }

 
 @Column(name="ccmCallerPhoneNum", length=50)
 public String getCcmCallerPhoneNum() {
     return this.ccmCallerPhoneNum;
 }
 
 public void setCcmCallerPhoneNum(String ccmCallerPhoneNum) {
     this.ccmCallerPhoneNum = ccmCallerPhoneNum;
 }

 
 @Column(name="ccmCallerAddress1", length=150)
 public String getCcmCallerAddress1() {
     return this.ccmCallerAddress1;
 }
 
 public void setCcmCallerAddress1(String ccmCallerAddress1) {
     this.ccmCallerAddress1 = ccmCallerAddress1;
 }

 
 @Column(name="ccmCallerAddress2", length=150)
 public String getCcmCallerAddress2() {
     return this.ccmCallerAddress2;
 }
 
 public void setCcmCallerAddress2(String ccmCallerAddress2) {
     this.ccmCallerAddress2 = ccmCallerAddress2;
 }

 
 @Column(name="ccmCallerAddress3", length=150)
 public String getCcmCallerAddress3() {
     return this.ccmCallerAddress3;
 }
 
 public void setCcmCallerAddress3(String ccmCallerAddress3) {
     this.ccmCallerAddress3 = ccmCallerAddress3;
 }

 
 @Column(name="ccmCallerAddress4", length=150)
 public String getCcmCallerAddress4() {
     return this.ccmCallerAddress4;
 }
 
 public void setCcmCallerAddress4(String ccmCallerAddress4) {
     this.ccmCallerAddress4 = ccmCallerAddress4;
 }

 
 @Column(name="ccmPolInsurerAgencyName", length=100)
 public String getCcmPolInsurerAgencyName() {
     return this.ccmPolInsurerAgencyName;
 }
 
 public void setCcmPolInsurerAgencyName(String ccmPolInsurerAgencyName) {
     this.ccmPolInsurerAgencyName = ccmPolInsurerAgencyName;
 }

 
 @Column(name="ccmPolInsurerAgencyChineseName", length=30)
 public String getCcmPolInsurerAgencyChineseName() {
     return this.ccmPolInsurerAgencyChineseName;
 }
 
 public void setCcmPolInsurerAgencyChineseName(String ccmPolInsurerAgencyChineseName) {
     this.ccmPolInsurerAgencyChineseName = ccmPolInsurerAgencyChineseName;
 }

 
 @Column(name="ccmPolInsurerAgencyCode", length=25)
 public String getCcmPolInsurerAgencyCode() {
     return this.ccmPolInsurerAgencyCode;
 }
 
 public void setCcmPolInsurerAgencyCode(String ccmPolInsurerAgencyCode) {
     this.ccmPolInsurerAgencyCode = ccmPolInsurerAgencyCode;
 }

 
 @Column(name="ccmPostedToInptCasePhoneLog")
 public Boolean getCcmPostedToInptCasePhoneLog() {
     return this.ccmPostedToInptCasePhoneLog;
 }
 
 public void setCcmPostedToInptCasePhoneLog(Boolean ccmPostedToInptCasePhoneLog) {
     this.ccmPostedToInptCasePhoneLog = ccmPostedToInptCasePhoneLog;
 }

 
 @Column(name="ccmIsPanelHospital")
 public Boolean getCcmIsPanelHospital() {
     return this.ccmIsPanelHospital;
 }
 
 public void setCcmIsPanelHospital(Boolean ccmIsPanelHospital) {
     this.ccmIsPanelHospital = ccmIsPanelHospital;
 }

 
 @Column(name="ccmInptCaseId", length=250)
 public String getCcmInptCaseId() {
     return this.ccmInptCaseId;
 }
 
 public void setCcmInptCaseId(String ccmInptCaseId) {
     this.ccmInptCaseId = ccmInptCaseId;
 }

 
 @Column(name="ccmInOutCaseId", length=250)
 public String getCcmInOutCaseId() {
     return this.ccmInOutCaseId;
 }
 
 public void setCcmInOutCaseId(String ccmInOutCaseId) {
     this.ccmInOutCaseId = ccmInOutCaseId;
 }




}


