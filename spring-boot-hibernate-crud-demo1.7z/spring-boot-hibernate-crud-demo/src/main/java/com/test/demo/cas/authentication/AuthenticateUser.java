package com.test.demo.cas.authentication;

import java.util.Set;

import com.test.demo.cas.constant.GlobalConstant;
import com.test.demo.model.common.User;
import com.test.demo.model.common.UserClient;
import com.test.demo.model.outpt.OutptClaim;

/**
 * This class is to authenticate the user from the authType
 * 
 * @author smannan
 *
 */
public class AuthenticateUser {

	public static Boolean validateClaimId(User user, String authType, OutptClaim outptClaim) {
		Boolean invalidClaimId = false;
		// Check JWT token - extract the userFullName & check it against the claim
		if (GlobalConstant.JWT_AUTH.equals(authType)) {
			String caseMmFullName = outptClaim.getOutptCase().getOutptCaseMmFullName();
			String authMmFullName = user.getMember().getMmFullName();
			if (!caseMmFullName.equalsIgnoreCase(authMmFullName)) {
				invalidClaimId = true;
			}
		}

		// Check Basic Auth - extract list of clients & check it against the case
		if (GlobalConstant.BASIC_AUTH.equals(authType)) {
			Integer[] clientIds = getClientIds(user.getUserClients());
			Integer caseClientId = outptClaim.getOutptCase().getOutptCaseClientId();
			Boolean found = false;
			for (Integer clientId : clientIds) {
				if (clientId.equals(caseClientId)) {
					found = true;
					break;
				}
			}

		}

		return invalidClaimId;
	}

	public static Integer[] getClientIds(Set<UserClient> userClients) {
		Integer[] clientIds = new Integer[userClients.size()];
        int i = 0;
        for (UserClient uc : userClients) {
            clientIds[i] = uc.getClient().getClientId();
            i++;
        }
        return clientIds;
    }
}
