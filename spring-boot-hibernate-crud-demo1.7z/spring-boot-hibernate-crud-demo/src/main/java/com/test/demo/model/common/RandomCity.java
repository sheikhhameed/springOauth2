package com.test.demo.model.common;

public class RandomCity {

}
