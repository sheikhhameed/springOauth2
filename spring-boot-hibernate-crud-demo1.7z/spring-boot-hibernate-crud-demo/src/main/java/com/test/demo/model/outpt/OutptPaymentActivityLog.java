package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptPaymentActivityLog class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_payment_activity_log"
 ,catalog="marcmy"
)
public class OutptPaymentActivityLog  implements java.io.Serializable {


  private Integer opalogId;
  private OutptClaim outptClaim;
  private OutptPaymentAdvice outptPaymentAdvice;
  private Boolean opalogReissueEnabled;
  private Boolean opalogVoid;
  private Integer opalogCreatedBy;
  private Date opalogCreatedDate;
  private Integer opalogLastEdittedBy;
  private Date opalogLastEdittedDate;

 public OutptPaymentActivityLog() {
 }

	
 public OutptPaymentActivityLog(OutptClaim outptClaim, OutptPaymentAdvice outptPaymentAdvice) {
     this.outptClaim = outptClaim;
     this.outptPaymentAdvice = outptPaymentAdvice;
 }
 public OutptPaymentActivityLog(OutptClaim outptClaim, OutptPaymentAdvice outptPaymentAdvice, Boolean opalogReissueEnabled, Boolean opalogVoid, Integer opalogCreatedBy, Date opalogCreatedDate, Integer opalogLastEdittedBy, Date opalogLastEdittedDate) {
    this.outptClaim = outptClaim;
    this.outptPaymentAdvice = outptPaymentAdvice;
    this.opalogReissueEnabled = opalogReissueEnabled;
    this.opalogVoid = opalogVoid;
    this.opalogCreatedBy = opalogCreatedBy;
    this.opalogCreatedDate = opalogCreatedDate;
    this.opalogLastEdittedBy = opalogLastEdittedBy;
    this.opalogLastEdittedDate = opalogLastEdittedDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="opalogId", unique=true, nullable=false)
 public Integer getOpalogId() {
     return this.opalogId;
 }
 
 public void setOpalogId(Integer opalogId) {
     this.opalogId = opalogId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="opalogOutptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="opalogOutptPayAdvId", nullable=false)
 public OutptPaymentAdvice getOutptPaymentAdvice() {
     return this.outptPaymentAdvice;
 }
 
 public void setOutptPaymentAdvice(OutptPaymentAdvice outptPaymentAdvice) {
     this.outptPaymentAdvice = outptPaymentAdvice;
 }

 
 @Column(name="opalogReissueEnabled")
 public Boolean getOpalogReissueEnabled() {
     return this.opalogReissueEnabled;
 }
 
 public void setOpalogReissueEnabled(Boolean opalogReissueEnabled) {
     this.opalogReissueEnabled = opalogReissueEnabled;
 }

 
 @Column(name="opalogVoid")
 public Boolean getOpalogVoid() {
     return this.opalogVoid;
 }
 
 public void setOpalogVoid(Boolean opalogVoid) {
     this.opalogVoid = opalogVoid;
 }

 
 @Column(name="opalogCreatedBy")
 public Integer getOpalogCreatedBy() {
     return this.opalogCreatedBy;
 }
 
 public void setOpalogCreatedBy(Integer opalogCreatedBy) {
     this.opalogCreatedBy = opalogCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="opalogCreatedDate", length=19)
 public Date getOpalogCreatedDate() {
     return this.opalogCreatedDate;
 }
 
 public void setOpalogCreatedDate(Date opalogCreatedDate) {
     this.opalogCreatedDate = opalogCreatedDate;
 }

 
 @Column(name="opalogLastEdittedBy")
 public Integer getOpalogLastEdittedBy() {
     return this.opalogLastEdittedBy;
 }
 
 public void setOpalogLastEdittedBy(Integer opalogLastEdittedBy) {
     this.opalogLastEdittedBy = opalogLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="opalogLastEdittedDate", length=19)
 public Date getOpalogLastEdittedDate() {
     return this.opalogLastEdittedDate;
 }
 
 public void setOpalogLastEdittedDate(Date opalogLastEdittedDate) {
     this.opalogLastEdittedDate = opalogLastEdittedDate;
 }




}


