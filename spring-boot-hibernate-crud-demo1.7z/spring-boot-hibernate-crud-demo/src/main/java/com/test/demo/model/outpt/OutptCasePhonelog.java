package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptCasePhoneLog class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_case_phonelog"
 ,catalog="marcmy"
)
public class OutptCasePhonelog  implements java.io.Serializable {


  private Integer outptCasePhLogId;
  private OutptCase outptCase;
  private OutptClaim outptClaim;
  private Integer outptCasePhLogCreatedBy;
  private String outptCasePhLogCreatedByAbbvName;
  private Date outptCasePhLogCreatedDate;
  private Character outptCasePhLogType;
  private String outptCasePhLogSpokeTo;
  private String outptCasePhLogDept;
  private String outptCasePhLogMedium;
  private String outptCasePhLogContactInfo;
  private String outptCasePhLogDesc;
  private String outptCasePhLogColor;
  private String outptCasePhLogMeta;

 public OutptCasePhonelog() {
 }

	
 public OutptCasePhonelog(OutptCase outptCase) {
     this.outptCase = outptCase;
 }
 public OutptCasePhonelog(OutptCase outptCase, OutptClaim outptClaim, Integer outptCasePhLogCreatedBy, String outptCasePhLogCreatedByAbbvName, Date outptCasePhLogCreatedDate, Character outptCasePhLogType, String outptCasePhLogSpokeTo, String outptCasePhLogDept, String outptCasePhLogMedium, String outptCasePhLogContactInfo, String outptCasePhLogDesc, String outptCasePhLogColor, String outptCasePhLogMeta) {
    this.outptCase = outptCase;
    this.outptClaim = outptClaim;
    this.outptCasePhLogCreatedBy = outptCasePhLogCreatedBy;
    this.outptCasePhLogCreatedByAbbvName = outptCasePhLogCreatedByAbbvName;
    this.outptCasePhLogCreatedDate = outptCasePhLogCreatedDate;
    this.outptCasePhLogType = outptCasePhLogType;
    this.outptCasePhLogSpokeTo = outptCasePhLogSpokeTo;
    this.outptCasePhLogDept = outptCasePhLogDept;
    this.outptCasePhLogMedium = outptCasePhLogMedium;
    this.outptCasePhLogContactInfo = outptCasePhLogContactInfo;
    this.outptCasePhLogDesc = outptCasePhLogDesc;
    this.outptCasePhLogColor = outptCasePhLogColor;
    this.outptCasePhLogMeta = outptCasePhLogMeta;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptCasePhLogId", unique=true, nullable=false)
 public Integer getOutptCasePhLogId() {
     return this.outptCasePhLogId;
 }
 
 public void setOutptCasePhLogId(Integer outptCasePhLogId) {
     this.outptCasePhLogId = outptCasePhLogId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptCasePhLogCaseId", nullable=false)
 public OutptCase getOutptCase() {
     return this.outptCase;
 }
 
 public void setOutptCase(OutptCase outptCase) {
     this.outptCase = outptCase;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptCasePhLogClaimId")
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="outptCasePhLogCreatedBy")
 public Integer getOutptCasePhLogCreatedBy() {
     return this.outptCasePhLogCreatedBy;
 }
 
 public void setOutptCasePhLogCreatedBy(Integer outptCasePhLogCreatedBy) {
     this.outptCasePhLogCreatedBy = outptCasePhLogCreatedBy;
 }

 
 @Column(name="outptCasePhLogCreatedByAbbvName", length=8)
 public String getOutptCasePhLogCreatedByAbbvName() {
     return this.outptCasePhLogCreatedByAbbvName;
 }
 
 public void setOutptCasePhLogCreatedByAbbvName(String outptCasePhLogCreatedByAbbvName) {
     this.outptCasePhLogCreatedByAbbvName = outptCasePhLogCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptCasePhLogCreatedDate", length=19)
 public Date getOutptCasePhLogCreatedDate() {
     return this.outptCasePhLogCreatedDate;
 }
 
 public void setOutptCasePhLogCreatedDate(Date outptCasePhLogCreatedDate) {
     this.outptCasePhLogCreatedDate = outptCasePhLogCreatedDate;
 }

 
 @Column(name="outptCasePhLogType", length=1)
 public Character getOutptCasePhLogType() {
     return this.outptCasePhLogType;
 }
 
 public void setOutptCasePhLogType(Character outptCasePhLogType) {
     this.outptCasePhLogType = outptCasePhLogType;
 }

 
 @Column(name="outptCasePhLogSpokeTo", length=50)
 public String getOutptCasePhLogSpokeTo() {
     return this.outptCasePhLogSpokeTo;
 }
 
 public void setOutptCasePhLogSpokeTo(String outptCasePhLogSpokeTo) {
     this.outptCasePhLogSpokeTo = outptCasePhLogSpokeTo;
 }

 
 @Column(name="outptCasePhLogDept", length=50)
 public String getOutptCasePhLogDept() {
     return this.outptCasePhLogDept;
 }
 
 public void setOutptCasePhLogDept(String outptCasePhLogDept) {
     this.outptCasePhLogDept = outptCasePhLogDept;
 }

 
 @Column(name="outptCasePhLogMedium", length=2)
 public String getOutptCasePhLogMedium() {
     return this.outptCasePhLogMedium;
 }
 
 public void setOutptCasePhLogMedium(String outptCasePhLogMedium) {
     this.outptCasePhLogMedium = outptCasePhLogMedium;
 }

 
 @Column(name="outptCasePhLogContactInfo", length=100)
 public String getOutptCasePhLogContactInfo() {
     return this.outptCasePhLogContactInfo;
 }
 
 public void setOutptCasePhLogContactInfo(String outptCasePhLogContactInfo) {
     this.outptCasePhLogContactInfo = outptCasePhLogContactInfo;
 }

 
 @Column(name="outptCasePhLogDesc", length=16777215)
 public String getOutptCasePhLogDesc() {
     return this.outptCasePhLogDesc;
 }
 
 public void setOutptCasePhLogDesc(String outptCasePhLogDesc) {
     this.outptCasePhLogDesc = outptCasePhLogDesc;
 }

 
 @Column(name="outptCasePhLogColor", length=7)
 public String getOutptCasePhLogColor() {
     return this.outptCasePhLogColor;
 }
 
 public void setOutptCasePhLogColor(String outptCasePhLogColor) {
     this.outptCasePhLogColor = outptCasePhLogColor;
 }

 
 @Column(name="outptCasePhLogMeta", length=250)
 public String getOutptCasePhLogMeta() {
     return this.outptCasePhLogMeta;
 }
 
 public void setOutptCasePhLogMeta(String outptCasePhLogMeta) {
     this.outptCasePhLogMeta = outptCasePhLogMeta;
 }




}


