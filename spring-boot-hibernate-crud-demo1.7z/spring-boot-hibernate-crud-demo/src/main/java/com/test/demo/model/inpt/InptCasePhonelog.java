package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCasePhoneLog class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_phonelog"
 ,catalog="marcmy"
)
public class InptCasePhonelog  implements java.io.Serializable {


  private Integer inptCasePhLogId;
  private InptCase inptCase;
  private Integer inptCasePhLogCreatedBy;
  private String inptCasePhLogCreatedByAbbvName;
  private Date inptCasePhLogCreatedDate;
  private Character inptCasePhLogType;
  private String inptCasePhLogSpokeTo;
  private String inptCasePhLogDept;
  private String inptCasePhLogMedium;
  private String inptCasePhLogContactInfo;
  private String inptCasePhLogDesc;
  private String inptCasePhLogColor;
  private String inptCasePhLogMeta;
  private String inptCasePhLogHlaRiderDetails;
  private String inptCasePhLogHlaDocType;
  private Boolean inptCasePhLogHlaApiEnabled;

 public InptCasePhonelog() {
 }

	
 public InptCasePhonelog(InptCase inptCase) {
     this.inptCase = inptCase;
 }
 public InptCasePhonelog(InptCase inptCase, Integer inptCasePhLogCreatedBy, String inptCasePhLogCreatedByAbbvName, Date inptCasePhLogCreatedDate, Character inptCasePhLogType, String inptCasePhLogSpokeTo, String inptCasePhLogDept, String inptCasePhLogMedium, String inptCasePhLogContactInfo, String inptCasePhLogDesc, String inptCasePhLogColor, String inptCasePhLogMeta, String inptCasePhLogHlaRiderDetails, String inptCasePhLogHlaDocType, Boolean inptCasePhLogHlaApiEnabled) {
    this.inptCase = inptCase;
    this.inptCasePhLogCreatedBy = inptCasePhLogCreatedBy;
    this.inptCasePhLogCreatedByAbbvName = inptCasePhLogCreatedByAbbvName;
    this.inptCasePhLogCreatedDate = inptCasePhLogCreatedDate;
    this.inptCasePhLogType = inptCasePhLogType;
    this.inptCasePhLogSpokeTo = inptCasePhLogSpokeTo;
    this.inptCasePhLogDept = inptCasePhLogDept;
    this.inptCasePhLogMedium = inptCasePhLogMedium;
    this.inptCasePhLogContactInfo = inptCasePhLogContactInfo;
    this.inptCasePhLogDesc = inptCasePhLogDesc;
    this.inptCasePhLogColor = inptCasePhLogColor;
    this.inptCasePhLogMeta = inptCasePhLogMeta;
    this.inptCasePhLogHlaRiderDetails = inptCasePhLogHlaRiderDetails;
    this.inptCasePhLogHlaDocType = inptCasePhLogHlaDocType;
    this.inptCasePhLogHlaApiEnabled = inptCasePhLogHlaApiEnabled;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCasePhLogId", unique=true, nullable=false)
 public Integer getInptCasePhLogId() {
     return this.inptCasePhLogId;
 }
 
 public void setInptCasePhLogId(Integer inptCasePhLogId) {
     this.inptCasePhLogId = inptCasePhLogId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCasePhLogCaseId", nullable=false)
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="inptCasePhLogCreatedBy")
 public Integer getInptCasePhLogCreatedBy() {
     return this.inptCasePhLogCreatedBy;
 }
 
 public void setInptCasePhLogCreatedBy(Integer inptCasePhLogCreatedBy) {
     this.inptCasePhLogCreatedBy = inptCasePhLogCreatedBy;
 }

 
 @Column(name="inptCasePhLogCreatedByAbbvName", length=8)
 public String getInptCasePhLogCreatedByAbbvName() {
     return this.inptCasePhLogCreatedByAbbvName;
 }
 
 public void setInptCasePhLogCreatedByAbbvName(String inptCasePhLogCreatedByAbbvName) {
     this.inptCasePhLogCreatedByAbbvName = inptCasePhLogCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCasePhLogCreatedDate", length=19)
 public Date getInptCasePhLogCreatedDate() {
     return this.inptCasePhLogCreatedDate;
 }
 
 public void setInptCasePhLogCreatedDate(Date inptCasePhLogCreatedDate) {
     this.inptCasePhLogCreatedDate = inptCasePhLogCreatedDate;
 }

 
 @Column(name="inptCasePhLogType", length=1)
 public Character getInptCasePhLogType() {
     return this.inptCasePhLogType;
 }
 
 public void setInptCasePhLogType(Character inptCasePhLogType) {
     this.inptCasePhLogType = inptCasePhLogType;
 }

 
 @Column(name="inptCasePhLogSpokeTo", length=100)
 public String getInptCasePhLogSpokeTo() {
     return this.inptCasePhLogSpokeTo;
 }
 
 public void setInptCasePhLogSpokeTo(String inptCasePhLogSpokeTo) {
     this.inptCasePhLogSpokeTo = inptCasePhLogSpokeTo;
 }

 
 @Column(name="inptCasePhLogDept", length=50)
 public String getInptCasePhLogDept() {
     return this.inptCasePhLogDept;
 }
 
 public void setInptCasePhLogDept(String inptCasePhLogDept) {
     this.inptCasePhLogDept = inptCasePhLogDept;
 }

 
 @Column(name="inptCasePhLogMedium", length=2)
 public String getInptCasePhLogMedium() {
     return this.inptCasePhLogMedium;
 }
 
 public void setInptCasePhLogMedium(String inptCasePhLogMedium) {
     this.inptCasePhLogMedium = inptCasePhLogMedium;
 }

 
 @Column(name="inptCasePhLogContactInfo", length=16777215)
 public String getInptCasePhLogContactInfo() {
     return this.inptCasePhLogContactInfo;
 }
 
 public void setInptCasePhLogContactInfo(String inptCasePhLogContactInfo) {
     this.inptCasePhLogContactInfo = inptCasePhLogContactInfo;
 }

 
 @Column(name="inptCasePhLogDesc", length=16777215)
 public String getInptCasePhLogDesc() {
     return this.inptCasePhLogDesc;
 }
 
 public void setInptCasePhLogDesc(String inptCasePhLogDesc) {
     this.inptCasePhLogDesc = inptCasePhLogDesc;
 }

 
 @Column(name="inptCasePhLogColor", length=7)
 public String getInptCasePhLogColor() {
     return this.inptCasePhLogColor;
 }
 
 public void setInptCasePhLogColor(String inptCasePhLogColor) {
     this.inptCasePhLogColor = inptCasePhLogColor;
 }

 
 @Column(name="inptCasePhLogMeta", length=250)
 public String getInptCasePhLogMeta() {
     return this.inptCasePhLogMeta;
 }
 
 public void setInptCasePhLogMeta(String inptCasePhLogMeta) {
     this.inptCasePhLogMeta = inptCasePhLogMeta;
 }

 
 @Column(name="inptCasePhLogHlaRiderDetails", length=100)
 public String getInptCasePhLogHlaRiderDetails() {
     return this.inptCasePhLogHlaRiderDetails;
 }
 
 public void setInptCasePhLogHlaRiderDetails(String inptCasePhLogHlaRiderDetails) {
     this.inptCasePhLogHlaRiderDetails = inptCasePhLogHlaRiderDetails;
 }

 
 @Column(name="inptCasePhLogHlaDocType", length=2)
 public String getInptCasePhLogHlaDocType() {
     return this.inptCasePhLogHlaDocType;
 }
 
 public void setInptCasePhLogHlaDocType(String inptCasePhLogHlaDocType) {
     this.inptCasePhLogHlaDocType = inptCasePhLogHlaDocType;
 }

 
 @Column(name="inptCasePhLogHlaApiEnabled")
 public Boolean getInptCasePhLogHlaApiEnabled() {
     return this.inptCasePhLogHlaApiEnabled;
 }
 
 public void setInptCasePhLogHlaApiEnabled(Boolean inptCasePhLogHlaApiEnabled) {
     this.inptCasePhLogHlaApiEnabled = inptCasePhLogHlaApiEnabled;
 }




}


