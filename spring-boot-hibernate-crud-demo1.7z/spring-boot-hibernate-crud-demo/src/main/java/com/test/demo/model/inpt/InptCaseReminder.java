package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCaseReminder class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_reminder"
 ,catalog="marcmy"
)
public class InptCaseReminder  implements java.io.Serializable {


  private Integer icrId;
  private InptCase inptCase;
  private String icrCreatedByAbbvName;
  private Date icrCreatedDate;
  private String icrEdittedByAbbvName;
  private Date icrEdittedDate;
  private String icrType;
  private String icrActionItem;
  private Date icrNextActionDate;
  private String icrTask;
  private String icrActionTaken;
  private String icrAssignedTo;
  private Date icrCompletedDate;
  private boolean icrCompleted;
  private boolean icrCancelled;
  private String icrAudit;

 public InptCaseReminder() {
 }

	
 public InptCaseReminder(String icrType, boolean icrCompleted, boolean icrCancelled) {
     this.icrType = icrType;
     this.icrCompleted = icrCompleted;
     this.icrCancelled = icrCancelled;
 }
 public InptCaseReminder(InptCase inptCase, String icrCreatedByAbbvName, Date icrCreatedDate, String icrEdittedByAbbvName, Date icrEdittedDate, String icrType, String icrActionItem, Date icrNextActionDate, String icrTask, String icrActionTaken, String icrAssignedTo, Date icrCompletedDate, boolean icrCompleted, boolean icrCancelled, String icrAudit) {
    this.inptCase = inptCase;
    this.icrCreatedByAbbvName = icrCreatedByAbbvName;
    this.icrCreatedDate = icrCreatedDate;
    this.icrEdittedByAbbvName = icrEdittedByAbbvName;
    this.icrEdittedDate = icrEdittedDate;
    this.icrType = icrType;
    this.icrActionItem = icrActionItem;
    this.icrNextActionDate = icrNextActionDate;
    this.icrTask = icrTask;
    this.icrActionTaken = icrActionTaken;
    this.icrAssignedTo = icrAssignedTo;
    this.icrCompletedDate = icrCompletedDate;
    this.icrCompleted = icrCompleted;
    this.icrCancelled = icrCancelled;
    this.icrAudit = icrAudit;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="icrId", unique=true, nullable=false)
 public Integer getIcrId() {
     return this.icrId;
 }
 
 public void setIcrId(Integer icrId) {
     this.icrId = icrId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="icrInptCaseId")
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="icrCreatedByAbbvName", length=8)
 public String getIcrCreatedByAbbvName() {
     return this.icrCreatedByAbbvName;
 }
 
 public void setIcrCreatedByAbbvName(String icrCreatedByAbbvName) {
     this.icrCreatedByAbbvName = icrCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="icrCreatedDate", length=19)
 public Date getIcrCreatedDate() {
     return this.icrCreatedDate;
 }
 
 public void setIcrCreatedDate(Date icrCreatedDate) {
     this.icrCreatedDate = icrCreatedDate;
 }

 
 @Column(name="icrEdittedByAbbvName", length=8)
 public String getIcrEdittedByAbbvName() {
     return this.icrEdittedByAbbvName;
 }
 
 public void setIcrEdittedByAbbvName(String icrEdittedByAbbvName) {
     this.icrEdittedByAbbvName = icrEdittedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="icrEdittedDate", length=19)
 public Date getIcrEdittedDate() {
     return this.icrEdittedDate;
 }
 
 public void setIcrEdittedDate(Date icrEdittedDate) {
     this.icrEdittedDate = icrEdittedDate;
 }

 
 @Column(name="icrType", nullable=false, length=1)
 public String getIcrType() {
     return this.icrType;
 }
 
 public void setIcrType(String icrType) {
     this.icrType = icrType;
 }

 
 @Column(name="icrActionItem", length=50)
 public String getIcrActionItem() {
     return this.icrActionItem;
 }
 
 public void setIcrActionItem(String icrActionItem) {
     this.icrActionItem = icrActionItem;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="icrNextActionDate", length=19)
 public Date getIcrNextActionDate() {
     return this.icrNextActionDate;
 }
 
 public void setIcrNextActionDate(Date icrNextActionDate) {
     this.icrNextActionDate = icrNextActionDate;
 }

 
 @Column(name="icrTask", length=16777215)
 public String getIcrTask() {
     return this.icrTask;
 }
 
 public void setIcrTask(String icrTask) {
     this.icrTask = icrTask;
 }

 
 @Column(name="icrActionTaken", length=16777215)
 public String getIcrActionTaken() {
     return this.icrActionTaken;
 }
 
 public void setIcrActionTaken(String icrActionTaken) {
     this.icrActionTaken = icrActionTaken;
 }

 
 @Column(name="icrAssignedTo", length=8)
 public String getIcrAssignedTo() {
     return this.icrAssignedTo;
 }
 
 public void setIcrAssignedTo(String icrAssignedTo) {
     this.icrAssignedTo = icrAssignedTo;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="icrCompletedDate", length=19)
 public Date getIcrCompletedDate() {
     return this.icrCompletedDate;
 }
 
 public void setIcrCompletedDate(Date icrCompletedDate) {
     this.icrCompletedDate = icrCompletedDate;
 }

 
 @Column(name="icrCompleted", nullable=false)
 public boolean isIcrCompleted() {
     return this.icrCompleted;
 }
 
 public void setIcrCompleted(boolean icrCompleted) {
     this.icrCompleted = icrCompleted;
 }

 
 @Column(name="icrCancelled", nullable=false)
 public boolean isIcrCancelled() {
     return this.icrCancelled;
 }
 
 public void setIcrCancelled(boolean icrCancelled) {
     this.icrCancelled = icrCancelled;
 }

 
 @Column(name="icrAudit")
 public String getIcrAudit() {
     return this.icrAudit;
 }
 
 public void setIcrAudit(String icrAudit) {
     this.icrAudit = icrAudit;
 }




}


