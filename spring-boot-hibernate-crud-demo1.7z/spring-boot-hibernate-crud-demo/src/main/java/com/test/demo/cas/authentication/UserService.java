//package com.test.demo.cas.authentication;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Component;
//
//import com.test.demo.repository.UserRepository;
//
//@Component
//public class UserService implements UserDetailsService {
//
//	@Autowired
//   private final UserRepository repository;
//
//   public UserService(UserRepository repository) {
//       this.repository = repository;
//   }
//
//   @Override
//   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//
//	   User user = repository.findbyUsername(username);
//	   if(user==null) {
//		throw new UsernameNotFoundException(String.format("The username %s doesn't exist", username));   
//	   }
//	   List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
//	   user.getRoles().forEach(role ->{
//		   	authorities.add(new SimpleGrantedAuthority(role.toString()));
//	   });
//	   
//	   UserDetails userDetails = new org.springframework.security.core.userdetails.User(user.getName(), user.getPassword(),
//			   authorities);
//	   return userDetails;
//	   
//   }
//}