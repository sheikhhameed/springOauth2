package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is userPrivilege class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name = "user_privilege",
      catalog = "marcmy"
)
public class UserPrivilege implements java.io.Serializable {

 private Integer userPrivilegeId;
 private Integer userPrivilegeCreatedBy;
 private Date userPrivilegeCreatedDate;
 private Integer userPrivilegeLastEdittedBy;
 private Date userPrivilegeLastEdittedDate;
 private String userPrivilegeName;
 private String userPrivilegeDescription;
 private Short userPrivilegeInptCase;
 private short userPrivilegeInptCaseMm;
 private short userPrivilegeInptCaseProp;
 private short userPrivilegeInptCaseHistory;
 private short userPrivilegeInptCasePlanNotes;
 private short userPrivilegeInptCasePolMvnt;
 private short userPrivilegeInptCaseAdm;
 private short userPrivilegeInptCaseDisc;
 private short userPrivilegeInptCaseCalcs;
 private short userPrivilegeInptCaseWs;
 private short userPrivilegeInptCasePhLog;
 private short userPrivilegeInptCaseDoc;
 private short userPrivilegeInptCaseAppv;
 private short userPrivilegeInptCaseImg;
 private short userPrivilegeInptCaseCostCu;
 private short userPrivilegeInptCaseCaseNote;
 private short userPrivilegeInptCaseAcc;
 private short userPrivilegeInptCaseReminder;
 private short userPrivilegeInptCaseTodo;
 private Short userPrivilegeInptCaseExt;
 private short userPrivilegeInptCaseTriage;
 private short userPrivilegeCcmCase;
 private short userPrivilegeCcmCaseInpt;
 private short userPrivilegeCcmCaseOutpt;
 private Short userPrivilegeAnnounce;
 private short userPrivilegeClient;
 private short userPrivilegeBank;
 private short userPrivilegeServices;
 private short userPrivilegeProgram;
 private short userPrivilegeBillingProfile;
 private short userPrivilegeAccountProfile;
 private short userPrivilegeInptPlan;
 private short userPrivilegeInptPolicy;
 private short userPrivilegeMedPrv;
 private short userPrivilegeMedPrvPanel;
 private short userPrivilegeWsCat;
 private short userPrivilegeWsTemp;
 private short userPrivilegeWsItems;
 private short userPrivilegeDr;
 private short userPrivilegeDrSpec;
 private short userPrivilegeMemberInvitationRoot;
 private short userPrivilegeMemberInvitationAdmin;
 private short userPrivilegeMember;
 private short userPrivilegeMemberInpt;
 private short userPrivilegeMemberOutpt;
 private short userPrivilegeDiagnosis;
 private short userPrivilegeDrug;
 private short userPrivilegeSymptom;
 private short userPrivilegeDashboard;
 private short userPrivilegeSurgSchedule;
 private short userPrivilegeDocTemp;
 private short userPrivilegeBdx;
 private short userPrivilegeImport;
 private short userPrivilegeAppointmentBooking;
 private short userPrivilegeUser;
 private short userPrivilegeUserPrivilege;
 private short userPrivilegeUserApiPrivilege;
 private short userPrivilegeUserClient;
 private short userPrivilegeUserDept;
 private short userPrivilegeUserHospital;
 private short userPrivilegeUserApi;
 private short userPrivilegeDocSpeAutho;
 private short userPrivilegeIftttRule;
 private short userPrivilegeIftttField;
 private short userPrivilegeCsuCases;
 private short userPrivilegeClaimGuidelines;
 private short userPrivilegePolicyJacket;
 private short userPrivilegeInptBillRegistration;
 private short userPrivilegeOutptBillRegistration;
 private short userPrivilegeWorksheet;
 private short userPrivilegeIpWhitelist;
 private short userPrivilegeInptCaseType;
 private short userPrivilegeInptCaseRejectType;
 private short userPrivilegeOutptBenefit;
 private short userPrivilegeOutptItem;
 private short userPrivilegeOutptPlan;
 private short userPrivilegeOutptMember;
 private short userPrivilegeOutptClaim;
 private short userPrivilegeOutptClaimLog;
 private short userPrivilegeOutptClaimDoc;
 private short userPrivilegeOutptClaimImg;
 private short userPrivilegeOutptClaimReminders;
 private short userPrivilegeOutptClaimCba;
 private short userPrivilegeOutptClaimHistory;
 private short userPrivilegeOutptClaimFwa;
 private short userPrivilegeOutptClaimGeneralAdmin;
 private short userPrivilegeOutptClaimPayAdv;
 private short userPrivilegeOutptClaimTriage;
 private short userPrivilegeOutptStatus;
 private short userPrivilegeOutptAutoAdj;
 private short userPrivilegeOutptBdx;
 private short userPrivilegeOutptPayAdv;
 private short userPrivilegeOutptInvestigation;
 private short userPrivilegeFileRepo;
 private short userPrivilegeEaDashboard;
 private short userPrivilegeEaMember;
 private short userPrivilegeEaCases;
 private short userPrivilegeEaAnnounce;
 private short userPrivilegeEclientAllowImpersonation;
 private short userPrivilegeEclientDashboard;
 private short userPrivilegeEclientInptCase;
 private short userPrivilegeEclientInptIncludeOutpt;
 private short userPrivilegeEclientInptShowMedicalInfo;
 private short userPrivilegeEclientInptShowPruPlan;
 private short userPrivilegeEclientInptExternalCase;
 private short userPrivilegeEclientInptMember;
 private short userPrivilegeEclientInptUtilReport;
 private short userPrivilegeEclientInptCaseAdm;
 private short userPrivilegeEclientInptCaseMember;
 private short userPrivilegeEclientInptCaseDisc;
 private short userPrivilegeEclientInptCaseCalc;
 private short userPrivilegeEclientInptCaseWorksheet;
 private short userPrivilegeEclientInptCaseDoc;
 private short userPrivilegeEclientInptCaseLogs;
 private short userPrivilegeEclientInptCaseApproval;
 private short userPrivilegeEclientInptCaseImage;
 private short userPrivilegeEclientInptCasePingbox;
 private short userPrivilegeEclientInptCaseInptCsuCase;
 private short userPrivilegeEclientInptCsuCase;
 private short userPrivilegeEclientInptCsuCaseAdm;
 private short userPrivilegeEclientInptCsuCaseDisc;
 private short userPrivilegeEclientInptCsuCaseWorksheet;
 private short userPrivilegeEclientInptCsuCaseDoc;
 private short userPrivilegeEclientInptCsuCaseImage;
 private short userPrivilegeEclientInOutOutptCase;
 private short userPrivilegeEclientInOutInptCase;
 private short userPrivilegeEclientInOutShowMedicalInfo;
 private short userPrivilegeEclientInOutDocs;
 private short userPrivilegeEclientInOutLogs;
 private short userPrivilegeEclientInOutApproval;
 private short userPrivilegeEclientInOutImage;
 private short userPrivilegeEclientInOutMember;
 private short userPrivilegeEclientPingbox;
 private short userPrivilegeEclientInvestigation;
 private short userPrivilegeEclientReport;
 private short userPrivilegeEclientMySetting;
 private short userPrivilegeEclaimAllowImpersonation;
 private short userPrivilegeEclaimInptCases;
 private short userPrivilegeEclaimInptIncludeOutpt;
 private short userPrivilegeEclaimInptMember;
 private short userPrivilegeEclaimInptDocUpload;
 private short userPrivilegeEclaimInOutOpdCases;
 private short userPrivilegeEclaimInOutMember;
 private short userPrivilegeEclaimInOutIpdMember;
 private short userPrivilegeEclaimInOutOpdMember;
 private short userPrivilegeEclaimInOutIpdCases;
 private short userPrivilegeEclaimInOutOpdPayAdv;
 private short userPrivilegeEclaimQr;
 private short userPrivilegeEclaimMySetting;
 private short userPrivilegeEclaimContactUs;
 private short userPrivilegeEclaimMyForm;
 private short userPrivilegeEclaimSgForm;
 private short userPrivilegeEclaimThForm;
 private short userPrivilegeEclaimDocumentCentral;
 private short userPrivilegeAllInptMmCountReport;
 private short userPrivilegeAllMemberUuidReport;
 private short userPrivilegeAllCcmReport;
 private short userPrivilegeAllInptReminderReport;
 private short userPrivilegeAllInptCaseTodoReport;
 private short userPrivilegeMyInptAccountingReport;
 private short userPrivilegeMyInptB2bReport;
 private short userPrivilegeMyInptBordTempReport;
 private short userPrivilegeMyInptHccReport;
 private short userPrivilegeMyInptMarketingReport;
 private short userPrivilegeMyInptMasterFileTempReport;
 private short userPrivilegeMyInptNoObAgingReport;
 private short userPrivilegeMyInptOutstandingReport;
 private short userPrivilegeMyInptPaymentReport;
 private short userPrivilegeMyInptUtilReport;
 private short userPrivilegeMyInptImportPurchaseReport;
 private short userPrivilegeMyInptBillRegReport;
 private short userPrivilegeMyInptHoldPaymentReport;
 private short userPrivilegeMyInptReleasePaymentReport;
 private short userPrivilegeMyInptCaseTriageReport;
 private short userPrivilegeMyInptHeadCountReport;
 private short userPrivilegeMyInptBordMyobReport;
 private short userPrivilegeMyInptPaymentForMyobReport;
 private short userPrivilegeMyInptMemberNoClaimReport;
 private short userPrivilegeMyAccPacArReport;
 private short userPrivilegeMyAccPacApReport;
 private short userPrivilegeMyAccPacReport;
 private short userPrivilegeMyAccPayableReport;
 private short userPrivilegeMyAccReceivableReport;
 private short userPrivilegeMyAxaTextFileGPReport;
 private short userPrivilegeMyBsiInptTextFileReport;
 private short userPrivilegeMyAmmetlifeTxtReport;
 private short userPrivilegeMyBsiPostTextFileReport;
 private short userPrivilegeMyAlimIndReport;
 private short userPrivilegeMyAlimGrpReport;
 private short userPrivilegeMyHlaTxtReport;
 private short userPrivilegeMyAxaTxtReport;
 private short userPrivilegeMyLonpacTxtReport;
 private short userPrivilegeMyLonpacDcaTxtReport;
 private short userPrivilegeMyMcisGrpTxtReport;
 private short userPrivilegeMyMcisIndTxtReport;
 private short userPrivilegeMyMpiMseTxtReport;
 private short userPrivilegeMyMpiPtgTxtReport;
 private short userPrivilegeMyStmbTxtReport;
 private short userPrivilegeMyStmbRbTxtReport;
 private short userPrivilegeMyStmbCashTxtReport;
 private short userPrivilegeMyTisbTxtReport;
 private short userPrivilegeMyTokioMarineTxtReport;
 private short userPrivilegeMySpikpaTxtReport;
 private short userPrivilegeMyEtiqaMcsTxtReport;
 private short userPrivilegeMyMbasTextFileReport;
 private short userPrivilegeAsiaInptClaimsBdxReport;
 private short userPrivilegeAsiaInptMasterReport;
 private short userPrivilegeAsiaInptClaimsReturnReport;
 private short userPrivilegeAsiaInptSettlementReport;
 private short userPrivilegeAsiaDailyInptCasesReport;
 private short userPrivilegeAsiaInptUtilReport;
 private short userPrivilegeAsiaInptCostContainmentReport;
 private short userPrivilegeAsiaInptPostAuditReport;
 private short userPrivilegeAsiaInptPaymentAdvReport;
 private short userPrivilegeAsiaInptDailyImagingReport;
 private short userPrivilegeAsiInptaMedicalFeeReport;
 private short userPrivilegeAsiaInptAccountPaymentReport;
 private short userPrivilegeAsiaInptSummarySettleReport;
 private short userPrivilegeAsiaInptMedicalFeeReport;
 private short userPrivilegePhAxaHcpReport;
 private short userPrivilegePhInptClaimBdxReport;
 private short userPrivilegePhMabiFileReport;
 private short userPrivilegePhSmsFileReport;
 private short userPrivilegePhSmsFileGroupReport;
 private short userPrivilegePhGhaClaimsReturnReport;
 private short userPrivilegeSgAxaHcpReport;
 private short userPrivilegeSgAhmStarhubSmsReport;
 private short userPrivilegeSgAgiIndonAdmedikaReport;
 private short userPrivilegeHkAhmPaReport;
 private short userPrivilegeHkInptPendingReport;
 private short userPrivilegeHkPruMmCountReport;
 private short userPrivilegeHkPruMemReport;
 private short userPrivilegeHkPruClaimReturnReport;
 private short userPrivilegeHkPruInptPhoneLogReport;
 private short userPrivilegeHkAceLifeDailyReport;
 private short userPrivilegeHkWempClaimReport;
 private short userPrivilegeHkWempG400report;
 private short userPrivilegeHkSunLifeReport;
 private short userPrivilegeHkPruOwsClaimPpmReport;
 private short userPrivilegeHkInptClaimsBdxReport;
 private short userPrivilegeHkAppointmentBookingReport;
 private short userPrivilegeHkLetterLabelPrintReport;
 private short userPrivilegeHkMembershipCardPrintReport;
 private short userPrivilegeHkPpmClaimLettersReport;
 private short userPrivilegeHkPpmControlFileReport;
 private short userPrivilegeHkPruInptClaimRefReport;
 private short userPrivilegeHkPruInptPendingFileReport;
 private short userPrivilegeCnUnitedEfileReport;
 private short userPrivilegeCnStudentCareInptClaimBdxReport;
 private short userPrivilegeThKtaxaPaymentBankReport;
 private short userPrivilegeThAgiPaymentBankReport;
 private short userPrivilegeThKtaxaEmailSmsReport;
 private short userPrivilegeThKtaxaActuarial1report;
 private short userPrivilegeThKtaxaActuarial2report;
 private short userPrivilegeThKtaxaChequeAutoRefundReport;
 private short userPrivilegeThKtaxaSlaPreFaxReport;
 private short userPrivilegeThKtaxaSlaDirectReport;
 private short userPrivilegeThKtaxaSmsMonthlyFeeReport;
 private short userPrivilegeThKtaxaClaimPaymentReport;
 private short userPrivilegeThKtaxaActuarialPaymentDailyReport;
 private short userPrivilegeThKtaxaPaymentOutstandingReport;
 private short userPrivilegeThKtaxaCdbPolicyMasterReport;
 private short userPrivilegeThKtaxaCdbInsuredDetailsReport;
 private short userPrivilegeThKtaxaCdbServiceProviderEnReport;
 private short userPrivilegeThKtaxaCdbServiceProviderThReport;
 private short userPrivilegeThKtaxaCdbClaimStatusReport;
 private short userPrivilegeThKtaxaCdbBenefitCodeMappingReport;
 private short userPrivilegeThKtaxaCdbBenefitMasterReport;
 private short userPrivilegeThKtaxaCdbClaimHeaderReport;
 private short userPrivilegeThKtaxaCdbClaimDetailDecisionReport;
 private short userPrivilegeThKtaxaCdbClaimDetailPaymentReport;
 private short userPrivilegeThKtaxaCdbPaymentDetailsReport;
 private short userPrivilegeThKtaxaCdbProductMasterReport;
 private short userPrivilegeThAgiClaimHistoryForRenewalReport;
 private short userPrivilegeThAgiSlaFaxClaimReport;
 private short userPrivilegeThAgiSlaCreditDirectClaimReport;
 private short userPrivilegeThAgiInptDetailsReport;
 private short userPrivilegeThAgiReceivedDateReport;
 private short userPrivilegeThAgiClaimPaymentReport;
 private short userPrivilegeThAgiClaimRepaymentReport;
 private short userPrivilegeThAgiFaxClaimSummaryReport;
 private short userPrivilegeThAathSlaFaxClaimReport;
 private short userPrivilegeThAathSlaPreCerRegisterReport;
 private short userPrivilegeThAathC1ieReport;
 private short userPrivilegeFnAlimTextFileReport;
 private short userPrivilegeApiReqToken;
 private short userPrivilegeApiChgPw;
 private short userPrivilegeApiLostPw;
 private short userPrivilegeApiSignUp;
 private short userPrivilegeApiMemberInit;
 private short userPrivilegeApiReqInptPlan;
 private short userPrivilegeApiReqInptCase;
 private short userPrivilegeApiReqInptCases;
 private short userPrivilegeApiCreateInptCase;
 private short userPrivilegeApiReqOutptPlan;
 private short userPrivilegeApiReqOutptClaim;
 private short userPrivilegeApiReqOutptClaims;
 private short userPrivilegeApiMemberValidate;
 private short userPrivilegeApiClaimSubmit;
 private short userPrivilegeApiCreateOutptClaimDraft;
 private short userPrivilegeApiSearchProvider;
 private short userPrivilegeApiQrSearchProvider;
 private short userPrivilegeApiReqCountry;
 private short userPrivilegeApiSubmitFeedback;
 private short userPrivilegeApiReqHafStat;
 private short userPrivilegeApiReqLog;
 private short userPrivilegeApiReqImpp;
 private short userPrivilegeBencomKey;
 private short userPrivilegeBencom;
 private short userPrivilegeEclaimDocUpload;
 private short userPrivilegeMyOutptStmbTxtReport;
 private Set<User> users = new HashSet<User>(0);

 public UserPrivilege() {
 }

// public UserPrivilege(short userPrivilegeInptCaseMm, short userPrivilegeInptCaseProp, short userPrivilegeInptCaseHistory, short userPrivilegeInptCasePlanNotes, short userPrivilegeInptCasePolMvnt, short userPrivilegeInptCaseAdm, short userPrivilegeInptCaseDisc, short userPrivilegeInptCaseCalcs, short userPrivilegeInptCaseWs, short userPrivilegeInptCasePhLog, short userPrivilegeInptCaseDoc, short userPrivilegeInptCaseAppv, short userPrivilegeInptCaseImg, short userPrivilegeInptCaseCostCu, short userPrivilegeInptCaseCaseNote, short userPrivilegeInptCaseAcc, short userPrivilegeInptCaseReminder, short userPrivilegeInptCaseTodo, short userPrivilegeInptCaseTriage, short userPrivilegeCcmCase, short userPrivilegeCcmCaseInpt, short userPrivilegeCcmCaseOutpt, short userPrivilegeClient, short userPrivilegeBank, short userPrivilegeServices, short userPrivilegeProgram, short userPrivilegeBillingProfile, short userPrivilegeAccountProfile, short userPrivilegeInptPlan, short userPrivilegeInptPolicy, short userPrivilegeMedPrv, short userPrivilegeMedPrvPanel, short userPrivilegeWsCat, short userPrivilegeWsTemp, short userPrivilegeWsItems, short userPrivilegeDr, short userPrivilegeDrSpec, short userPrivilegeMember, short userPrivilegeMemberInpt, short userPrivilegeMemberOutpt, short userPrivilegeDiagnosis, short userPrivilegeDrug, short userPrivilegeSymptom, short userPrivilegeDashboard, short userPrivilegeSurgSchedule, short userPrivilegeDocTemp, short userPrivilegeBdx, short userPrivilegeImport, short userPrivilegeAppointmentBooking, short userPrivilegeUser, short userPrivilegeUserPrivilege, short userPrivilegeUserApiPrivilege, short userPrivilegeUserClient, short userPrivilegeUserDept, short userPrivilegeUserHospital, short userPrivilegeUserApi, short userPrivilegeDocSpeAutho, short userPrivilegeIftttRule, short userPrivilegeIftttField, short userPrivilegeCsuCases, short userPrivilegeClaimGuidelines, short userPrivilegePolicyJacket, short userPrivilegeInptBillRegistration, short userPrivilegeOutptBillRegistration, short userPrivilegeWorksheet, short userPrivilegeIpWhitelist, short userPrivilegeInptCaseType, short userPrivilegeInptCaseRejectType, short userPrivilegeOutptBenefit, short userPrivilegeOutptItem, short userPrivilegeOutptPlan, short userPrivilegeOutptMember, short userPrivilegeOutptClaim, short userPrivilegeOutptClaimLog, short userPrivilegeOutptClaimDoc, short userPrivilegeOutptClaimImg, short userPrivilegeOutptClaimReminders, short userPrivilegeOutptClaimCba, short userPrivilegeOutptClaimHistory, short userPrivilegeOutptClaimFwa, short userPrivilegeOutptClaimGeneralAdmin, short userPrivilegeOutptClaimPayAdv, short userPrivilegeOutptClaimTriage, short userPrivilegeOutptStatus, short userPrivilegeOutptAutoAdj, short userPrivilegeOutptBdx, short userPrivilegeOutptPayAdv, short userPrivilegeOutptInvestigation, short userPrivilegeFileRepo, short userPrivilegeEaDashboard, short userPrivilegeEaMember, short userPrivilegeEaCases, short userPrivilegeEaAnnounce, short userPrivilegeEclientAllowImpersonation, short userPrivilegeEclientDashboard, short userPrivilegeEclientInptCase, short userPrivilegeEclientInptIncludeOutpt, short userPrivilegeEclientInptShowMedicalInfo, short userPrivilegeEclientInptShowPruPlan, short userPrivilegeEclientInptExternalCase, short userPrivilegeEclientInptMember, short userPrivilegeEclientInptUtilReport, short userPrivilegeEclientInptCaseAdm, short userPrivilegeEclientInptCaseMember, short userPrivilegeEclientInptCaseDisc, short userPrivilegeEclientInptCaseCalc, short userPrivilegeEclientInptCaseWorksheet, short userPrivilegeEclientInptCaseDoc, short userPrivilegeEclientInptCaseLogs, short userPrivilegeEclientInptCaseApproval, short userPrivilegeEclientInptCaseImage, short userPrivilegeEclientInptCasePingbox, short userPrivilegeEclientInptCaseInptCsuCase, short userPrivilegeEclientInptCsuCase, short userPrivilegeEclientInptCsuCaseAdm, short userPrivilegeEclientInptCsuCaseDisc, short userPrivilegeEclientInptCsuCaseWorksheet, short userPrivilegeEclientInptCsuCaseDoc, short userPrivilegeEclientInptCsuCaseImage, short userPrivilegeEclientInOutOutptCase, short userPrivilegeEclientInOutInptCase, short userPrivilegeEclientInOutShowMedicalInfo, short userPrivilegeEclientInOutDocs, short userPrivilegeEclientInOutLogs, short userPrivilegeEclientInOutApproval, short userPrivilegeEclientInOutImage, short userPrivilegeEclientInOutMember, short userPrivilegeEclientPingbox, short userPrivilegeEclientInvestigation, short userPrivilegeEclientReport, short userPrivilegeEclientMySetting, short userPrivilegeEclaimAllowImpersonation, short userPrivilegeEclaimInptCases, short userPrivilegeEclaimInptIncludeOutpt, short userPrivilegeEclaimInptMember, short userPrivilegeEclaimInptDocUpload, short userPrivilegeEclaimInOutOpdCases, short userPrivilegeEclaimInOutMember, short userPrivilegeEclaimInOutIpdMember, short userPrivilegeEclaimInOutOpdMember, short userPrivilegeEclaimInOutIpdCases, short userPrivilegeEclaimInOutOpdPayAdv, short userPrivilegeEclaimQr, short userPrivilegeEclaimMySetting, short userPrivilegeEclaimContactUs, short userPrivilegeEclaimMyForm, short userPrivilegeEclaimSgForm, short userPrivilegeEclaimThForm, short userPrivilegeEclaimDocumentCentral, short userPrivilegeAllInptMmCountReport, short userPrivilegeAllMemberUuidReport, short userPrivilegeAllCcmReport, short userPrivilegeAllInptReminderReport, short userPrivilegeAllInptCaseTodoReport, short userPrivilegeMyInptAccountingReport, short userPrivilegeMyInptB2bReport, short userPrivilegeMyInptBordTempReport, short userPrivilegeMyInptHccReport, short userPrivilegeMyInptMarketingReport, short userPrivilegeMyInptMasterFileTempReport, short userPrivilegeMyInptNoObAgingReport, short userPrivilegeMyInptOutstandingReport, short userPrivilegeMyInptPaymentReport, short userPrivilegeMyInptUtilReport, short userPrivilegeMyInptImportPurchaseReport, short userPrivilegeMyInptBillRegReport, short userPrivilegeMyInptHoldPaymentReport, short userPrivilegeMyInptReleasePaymentReport, short userPrivilegeMyInptCaseTriageReport, short userPrivilegeMyInptHeadCountReport, short userPrivilegeMyInptBordMyobReport, short userPrivilegeMyInptPaymentForMyobReport, short userPrivilegeMyInptMemberNoClaimReport, short userPrivilegeMyAccPacArReport, short userPrivilegeMyAccPacApReport, short userPrivilegeMyAccPacReport, short userPrivilegeMyAccPayableReport, short userPrivilegeMyAccReceivableReport,shortuserPrivilegeMyAxaTextFileGPReport, short userPrivilegeMyBsiInptTextFileReport, short userPrivilegeMyAmmetlifeTxtReport, short userPrivilegeMyBsiPostTextFileReport, short userPrivilegeMyAlimIndReport, short userPrivilegeMyAlimGrpReport, short userPrivilegeMyHlaTxtReport, short userPrivilegeMyAxaTxtReport, short userPrivilegeMyLonpacTxtReport, short userPrivilegeMyLonpacDcaTxtReport, short userPrivilegeMyMcisGrpTxtReport, short userPrivilegeMyMcisIndTxtReport, short userPrivilegeMyMpiMseTxtReport, short userPrivilegeMyMpiPtgTxtReport, short userPrivilegeMyStmbTxtReport, short userPrivilegeMyStmbRbTxtReport, short userPrivilegeMyStmbCashTxtReport, short userPrivilegeMyTisbTxtReport, short userPrivilegeMyTokioMarineTxtReport, short userPrivilegeMySpikpaTxtReport, short userPrivilegeMyEtiqaMcsTxtReport, short userPrivilegeMyMbasTextFileReport, short userPrivilegeAsiaInptClaimsBdxReport, short userPrivilegeAsiaInptMasterReport, short userPrivilegeAsiaInptClaimsReturnReport, short userPrivilegeAsiaInptSettlementReport, short userPrivilegeAsiaDailyInptCasesReport, short userPrivilegeAsiaInptUtilReport, short userPrivilegeAsiaInptCostContainmentReport, short userPrivilegeAsiaInptPostAuditReport, short userPrivilegeAsiaInptPaymentAdvReport, short userPrivilegeAsiaInptDailyImagingReport, short userPrivilegeAsiInptaMedicalFeeReport, short userPrivilegeAsiaInptAccountPaymentReport, short userPrivilegeAsiaInptSummarySettleReport, short userPrivilegeAsiaInptMedicalFeeReport, short userPrivilegePhAxaHcpReport, short userPrivilegePhInptClaimBdxReport, short userPrivilegePhMabiFileReport, short userPrivilegePhSmsFileReport, short userPrivilegePhSmsFileGroupReport, short userPrivilegePhGhaClaimsReturnReport, short userPrivilegeSgAxaHcpReport, short userPrivilegeSgAhmStarhubSmsReport, short userPrivilegeSgAgiIndonAdmedikaReport, short userPrivilegeHkAhmPaReport, short userPrivilegeHkInptPendingReport, short userPrivilegeHkPruMmCountReport, short userPrivilegeHkPruMemReport, short userPrivilegeHkPruClaimReturnReport, short userPrivilegeHkPruInptPhoneLogReport, short userPrivilegeHkAceLifeDailyReport, short userPrivilegeHkWempClaimReport, short userPrivilegeHkWempG400report, short userPrivilegeHkSunLifeReport, short userPrivilegeHkPruOwsClaimPpmReport, short userPrivilegeHkInptClaimsBdxReport, short userPrivilegeHkAppointmentBookingReport, short userPrivilegeHkLetterLabelPrintReport, short userPrivilegeHkMembershipCardPrintReport, short userPrivilegeHkPpmClaimLettersReport, short userPrivilegeHkPpmControlFileReport, short userPrivilegeHkPruInptClaimRefReport, short userPrivilegeHkPruInptPendingFileReport, short userPrivilegeCnUnitedEfileReport, short userPrivilegeCnStudentCareInptClaimBdxReport, short userPrivilegeThKtaxaPaymentBankReport, short userPrivilegeThAgiPaymentBankReport, short userPrivilegeThKtaxaEmailSmsReport, short userPrivilegeThKtaxaActuarial1report, short userPrivilegeThKtaxaActuarial2report, short userPrivilegeThKtaxaChequeAutoRefundReport, short userPrivilegeThKtaxaSlaPreFaxReport, short userPrivilegeThKtaxaSlaDirectReport, short userPrivilegeThKtaxaSmsMonthlyFeeReport, short userPrivilegeThKtaxaClaimPaymentReport, short userPrivilegeThKtaxaActuarialPaymentDailyReport, short userPrivilegeThKtaxaPaymentOutstandingReport, short userPrivilegeThKtaxaCdbPolicyMasterReport, short userPrivilegeThKtaxaCdbInsuredDetailsReport, short userPrivilegeThKtaxaCdbServiceProviderEnReport, short userPrivilegeThKtaxaCdbServiceProviderThReport, short userPrivilegeThKtaxaCdbClaimStatusReport, short userPrivilegeThKtaxaCdbBenefitCodeMappingReport, short userPrivilegeThKtaxaCdbBenefitMasterReport, short userPrivilegeThKtaxaCdbClaimHeaderReport, short userPrivilegeThKtaxaCdbClaimDetailDecisionReport, short userPrivilegeThKtaxaCdbClaimDetailPaymentReport, short userPrivilegeThKtaxaCdbPaymentDetailsReport, short userPrivilegeThKtaxaCdbProductMasterReport, short userPrivilegeThAgiClaimHistoryForRenewalReport, short userPrivilegeThAgiSlaFaxClaimReport, short userPrivilegeThAgiSlaCreditDirectClaimReport, short userPrivilegeThAgiInptDetailsReport, short userPrivilegeThAgiReceivedDateReport, short userPrivilegeThAgiClaimPaymentReport, short userPrivilegeThAgiClaimRepaymentReport, short userPrivilegeThAgiFaxClaimSummaryReport, short userPrivilegeThAathSlaFaxClaimReport, short userPrivilegeThAathSlaPreCerRegisterReport, short userPrivilegeThAathC1ieReport, short userPrivilegeFnAlimTextFileReport, short userPrivilegeApiReqToken, short userPrivilegeApiChgPw, short userPrivilegeApiLostPw, short userPrivilegeApiSignUp, short userPrivilegeApiMemberInit, short userPrivilegeApiReqInptPlan, short userPrivilegeApiReqInptCase, short userPrivilegeApiReqInptCases, short userPrivilegeApiCreateInptCase, short userPrivilegeApiReqOutptPlan, short userPrivilegeApiReqOutptClaim, short userPrivilegeApiReqOutptClaims, short userPrivilegeApiMemberValidate, short userPrivilegeApiClaimSubmit, short userPrivilegeApiCreateOutptClaimDraft, short userPrivilegeApiSearchProvider, short userPrivilegeApiQrSearchProvider, short userPrivilegeApiReqCountry, short userPrivilegeApiSubmitFeedback, short userPrivilegeApiReqHafStat, short userPrivilegeApiReqLog, short userPrivilegeApiReqImpp, short userPrivilegeBencomKey, short userPrivilegeBencom, short userPrivilegeEclaimDocUpload) {
//     this.userPrivilegeInptCaseMm = userPrivilegeInptCaseMm;
//     this.userPrivilegeInptCaseProp = userPrivilegeInptCaseProp;
//     this.userPrivilegeInptCaseHistory = userPrivilegeInptCaseHistory;
//     this.userPrivilegeInptCasePlanNotes = userPrivilegeInptCasePlanNotes;
//     this.userPrivilegeInptCasePolMvnt = userPrivilegeInptCasePolMvnt;
//     this.userPrivilegeInptCaseAdm = userPrivilegeInptCaseAdm;
//     this.userPrivilegeInptCaseDisc = userPrivilegeInptCaseDisc;
//     this.userPrivilegeInptCaseCalcs = userPrivilegeInptCaseCalcs;
//     this.userPrivilegeInptCaseWs = userPrivilegeInptCaseWs;
//     this.userPrivilegeInptCasePhLog = userPrivilegeInptCasePhLog;
//     this.userPrivilegeInptCaseDoc = userPrivilegeInptCaseDoc;
//     this.userPrivilegeInptCaseAppv = userPrivilegeInptCaseAppv;
//     this.userPrivilegeInptCaseImg = userPrivilegeInptCaseImg;
//     this.userPrivilegeInptCaseCostCu = userPrivilegeInptCaseCostCu;
//     this.userPrivilegeInptCaseCaseNote = userPrivilegeInptCaseCaseNote;
//     this.userPrivilegeInptCaseAcc = userPrivilegeInptCaseAcc;
//     this.userPrivilegeInptCaseReminder = userPrivilegeInptCaseReminder;
//     this.userPrivilegeInptCaseTodo = userPrivilegeInptCaseTodo;
//     this.userPrivilegeInptCaseTriage = userPrivilegeInptCaseTriage;
//     this.userPrivilegeCcmCase = userPrivilegeCcmCase;
//     this.userPrivilegeCcmCaseInpt = userPrivilegeCcmCaseInpt;
//     this.userPrivilegeCcmCaseOutpt = userPrivilegeCcmCaseOutpt;
//     this.userPrivilegeClient = userPrivilegeClient;
//     this.userPrivilegeBank = userPrivilegeBank;
//     this.userPrivilegeServices = userPrivilegeServices;
//     this.userPrivilegeProgram = userPrivilegeProgram;
//     this.userPrivilegeBillingProfile = userPrivilegeBillingProfile;
//     this.userPrivilegeAccountProfile = userPrivilegeAccountProfile;
//     this.userPrivilegeInptPlan = userPrivilegeInptPlan;
//     this.userPrivilegeInptPolicy = userPrivilegeInptPolicy;
//     this.userPrivilegeMedPrv = userPrivilegeMedPrv;
//     this.userPrivilegeMedPrvPanel = userPrivilegeMedPrvPanel;
//     this.userPrivilegeWsCat = userPrivilegeWsCat;
//     this.userPrivilegeWsTemp = userPrivilegeWsTemp;
//     this.userPrivilegeWsItems = userPrivilegeWsItems;
//     this.userPrivilegeDr = userPrivilegeDr;
//     this.userPrivilegeDrSpec = userPrivilegeDrSpec;
//     this.userPrivilegeMember = userPrivilegeMember;
//     this.userPrivilegeMemberInpt = userPrivilegeMemberInpt;
//     this.userPrivilegeMemberOutpt = userPrivilegeMemberOutpt;
//     this.userPrivilegeDiagnosis = userPrivilegeDiagnosis;
//     this.userPrivilegeDrug = userPrivilegeDrug;
//     this.userPrivilegeSymptom = userPrivilegeSymptom;
//     this.userPrivilegeDashboard = userPrivilegeDashboard;
//     this.userPrivilegeSurgSchedule = userPrivilegeSurgSchedule;
//     this.userPrivilegeDocTemp = userPrivilegeDocTemp;
//     this.userPrivilegeBdx = userPrivilegeBdx;
//     this.userPrivilegeImport = userPrivilegeImport;
//     this.userPrivilegeAppointmentBooking = userPrivilegeAppointmentBooking;
//     this.userPrivilegeUser = userPrivilegeUser;
//     this.userPrivilegeUserPrivilege = userPrivilegeUserPrivilege;
//     this.userPrivilegeUserApiPrivilege = userPrivilegeUserApiPrivilege;
//     this.userPrivilegeUserClient = userPrivilegeUserClient;
//     this.userPrivilegeUserDept = userPrivilegeUserDept;
//     this.userPrivilegeUserHospital = userPrivilegeUserHospital;
//     this.userPrivilegeUserApi = userPrivilegeUserApi;
//     this.userPrivilegeDocSpeAutho = userPrivilegeDocSpeAutho;
//     this.userPrivilegeIftttRule = userPrivilegeIftttRule;
//     this.userPrivilegeIftttField = userPrivilegeIftttField;
//     this.userPrivilegeCsuCases = userPrivilegeCsuCases;
//     this.userPrivilegeClaimGuidelines = userPrivilegeClaimGuidelines;
//     this.userPrivilegePolicyJacket = userPrivilegePolicyJacket;
//     this.userPrivilegeInptBillRegistration = userPrivilegeInptBillRegistration;
//     this.userPrivilegeOutptBillRegistration = userPrivilegeOutptBillRegistration;
//     this.userPrivilegeWorksheet = userPrivilegeWorksheet;
//     this.userPrivilegeIpWhitelist = userPrivilegeIpWhitelist;
//     this.userPrivilegeInptCaseType = userPrivilegeInptCaseType;
//     this.userPrivilegeInptCaseRejectType = userPrivilegeInptCaseRejectType;
//     this.userPrivilegeOutptBenefit = userPrivilegeOutptBenefit;
//     this.userPrivilegeOutptItem = userPrivilegeOutptItem;
//     this.userPrivilegeOutptPlan = userPrivilegeOutptPlan;
//     this.userPrivilegeOutptMember = userPrivilegeOutptMember;
//     this.userPrivilegeOutptClaim = userPrivilegeOutptClaim;
//     this.userPrivilegeOutptClaimLog = userPrivilegeOutptClaimLog;
//     this.userPrivilegeOutptClaimDoc = userPrivilegeOutptClaimDoc;
//     this.userPrivilegeOutptClaimImg = userPrivilegeOutptClaimImg;
//     this.userPrivilegeOutptClaimReminders = userPrivilegeOutptClaimReminders;
//     this.userPrivilegeOutptClaimCba = userPrivilegeOutptClaimCba;
//     this.userPrivilegeOutptClaimHistory = userPrivilegeOutptClaimHistory;
//     this.userPrivilegeOutptClaimFwa = userPrivilegeOutptClaimFwa;
//     this.userPrivilegeOutptClaimGeneralAdmin = userPrivilegeOutptClaimGeneralAdmin;
//     this.userPrivilegeOutptClaimPayAdv = userPrivilegeOutptClaimPayAdv;
//     this.userPrivilegeOutptClaimTriage = userPrivilegeOutptClaimTriage;
//     this.userPrivilegeOutptStatus = userPrivilegeOutptStatus;
//     this.userPrivilegeOutptAutoAdj = userPrivilegeOutptAutoAdj;
//     this.userPrivilegeOutptBdx = userPrivilegeOutptBdx;
//     this.userPrivilegeOutptPayAdv = userPrivilegeOutptPayAdv;
//     this.userPrivilegeOutptInvestigation = userPrivilegeOutptInvestigation;
//     this.userPrivilegeFileRepo = userPrivilegeFileRepo;
//     this.userPrivilegeEaDashboard = userPrivilegeEaDashboard;
//     this.userPrivilegeEaMember = userPrivilegeEaMember;
//     this.userPrivilegeEaCases = userPrivilegeEaCases;
//     this.userPrivilegeEaAnnounce = userPrivilegeEaAnnounce;
//     this.userPrivilegeEclientAllowImpersonation = userPrivilegeEclientAllowImpersonation;
//     this.userPrivilegeEclientDashboard = userPrivilegeEclientDashboard;
//     this.userPrivilegeEclientInptCase = userPrivilegeEclientInptCase;
//     this.userPrivilegeEclientInptIncludeOutpt = userPrivilegeEclientInptIncludeOutpt;
//     this.userPrivilegeEclientInptShowMedicalInfo = userPrivilegeEclientInptShowMedicalInfo;
//     this.userPrivilegeEclientInptShowPruPlan = userPrivilegeEclientInptShowPruPlan;
//     this.userPrivilegeEclientInptExternalCase = userPrivilegeEclientInptExternalCase;
//     this.userPrivilegeEclientInptMember = userPrivilegeEclientInptMember;
//     this.userPrivilegeEclientInptUtilReport = userPrivilegeEclientInptUtilReport;
//     this.userPrivilegeEclientInptCaseAdm = userPrivilegeEclientInptCaseAdm;
//     this.userPrivilegeEclientInptCaseMember = userPrivilegeEclientInptCaseMember;
//     this.userPrivilegeEclientInptCaseDisc = userPrivilegeEclientInptCaseDisc;
//     this.userPrivilegeEclientInptCaseCalc = userPrivilegeEclientInptCaseCalc;
//     this.userPrivilegeEclientInptCaseWorksheet = userPrivilegeEclientInptCaseWorksheet;
//     this.userPrivilegeEclientInptCaseDoc = userPrivilegeEclientInptCaseDoc;
//     this.userPrivilegeEclientInptCaseLogs = userPrivilegeEclientInptCaseLogs;
//     this.userPrivilegeEclientInptCaseApproval = userPrivilegeEclientInptCaseApproval;
//     this.userPrivilegeEclientInptCaseImage = userPrivilegeEclientInptCaseImage;
//     this.userPrivilegeEclientInptCasePingbox = userPrivilegeEclientInptCasePingbox;
//     this.userPrivilegeEclientInptCaseInptCsuCase = userPrivilegeEclientInptCaseInptCsuCase;
//     this.userPrivilegeEclientInptCsuCase = userPrivilegeEclientInptCsuCase;
//     this.userPrivilegeEclientInptCsuCaseAdm = userPrivilegeEclientInptCsuCaseAdm;
//     this.userPrivilegeEclientInptCsuCaseDisc = userPrivilegeEclientInptCsuCaseDisc;
//     this.userPrivilegeEclientInptCsuCaseWorksheet = userPrivilegeEclientInptCsuCaseWorksheet;
//     this.userPrivilegeEclientInptCsuCaseDoc = userPrivilegeEclientInptCsuCaseDoc;
//     this.userPrivilegeEclientInptCsuCaseImage = userPrivilegeEclientInptCsuCaseImage;
//     this.userPrivilegeEclientInOutOutptCase = userPrivilegeEclientInOutOutptCase;
//     this.userPrivilegeEclientInOutInptCase = userPrivilegeEclientInOutInptCase;
//     this.userPrivilegeEclientInOutShowMedicalInfo = userPrivilegeEclientInOutShowMedicalInfo;
//     this.userPrivilegeEclientInOutDocs = userPrivilegeEclientInOutDocs;
//     this.userPrivilegeEclientInOutLogs = userPrivilegeEclientInOutLogs;
//     this.userPrivilegeEclientInOutApproval = userPrivilegeEclientInOutApproval;
//     this.userPrivilegeEclientInOutImage = userPrivilegeEclientInOutImage;
//     this.userPrivilegeEclientInOutMember = userPrivilegeEclientInOutMember;
//     this.userPrivilegeEclientPingbox = userPrivilegeEclientPingbox;
//     this.userPrivilegeEclientInvestigation = userPrivilegeEclientInvestigation;
//     this.userPrivilegeEclientReport = userPrivilegeEclientReport;
//     this.userPrivilegeEclientMySetting = userPrivilegeEclientMySetting;
//     this.userPrivilegeEclaimAllowImpersonation = userPrivilegeEclaimAllowImpersonation;
//     this.userPrivilegeEclaimInptCases = userPrivilegeEclaimInptCases;
//     this.userPrivilegeEclaimInptIncludeOutpt = userPrivilegeEclaimInptIncludeOutpt;
//     this.userPrivilegeEclaimInptMember = userPrivilegeEclaimInptMember;
//     this.userPrivilegeEclaimInptDocUpload = userPrivilegeEclaimInptDocUpload;
//     this.userPrivilegeEclaimInOutOpdCases = userPrivilegeEclaimInOutOpdCases;
//     this.userPrivilegeEclaimInOutMember = userPrivilegeEclaimInOutMember;
//     this.userPrivilegeEclaimInOutIpdMember = userPrivilegeEclaimInOutIpdMember;
//     this.userPrivilegeEclaimInOutOpdMember = userPrivilegeEclaimInOutOpdMember;
//     this.userPrivilegeEclaimInOutIpdCases = userPrivilegeEclaimInOutIpdCases;
//     this.userPrivilegeEclaimInOutOpdPayAdv = userPrivilegeEclaimInOutOpdPayAdv;
//     this.userPrivilegeEclaimQr = userPrivilegeEclaimQr;
//     this.userPrivilegeEclaimMySetting = userPrivilegeEclaimMySetting;
//     this.userPrivilegeEclaimContactUs = userPrivilegeEclaimContactUs;
//     this.userPrivilegeEclaimMyForm = userPrivilegeEclaimMyForm;
//     this.userPrivilegeEclaimSgForm = userPrivilegeEclaimSgForm;
//     this.userPrivilegeEclaimThForm = userPrivilegeEclaimThForm;
//     this.userPrivilegeEclaimDocumentCentral = userPrivilegeEclaimDocumentCentral;
//     this.userPrivilegeAllInptMmCountReport = userPrivilegeAllInptMmCountReport;
//     this.userPrivilegeAllMemberUuidReport = userPrivilegeAllMemberUuidReport;
//     this.userPrivilegeAllCcmReport = userPrivilegeAllCcmReport;
//     this.userPrivilegeAllInptReminderReport = userPrivilegeAllInptReminderReport;
//     this.userPrivilegeAllInptCaseTodoReport = userPrivilegeAllInptCaseTodoReport;
//     this.userPrivilegeMyInptAccountingReport = userPrivilegeMyInptAccountingReport;
//     this.userPrivilegeMyInptB2bReport = userPrivilegeMyInptB2bReport;
//     this.userPrivilegeMyInptBordTempReport = userPrivilegeMyInptBordTempReport;
//     this.userPrivilegeMyInptHccReport = userPrivilegeMyInptHccReport;
//     this.userPrivilegeMyInptMarketingReport = userPrivilegeMyInptMarketingReport;
//     this.userPrivilegeMyInptMasterFileTempReport = userPrivilegeMyInptMasterFileTempReport;
//     this.userPrivilegeMyInptNoObAgingReport = userPrivilegeMyInptNoObAgingReport;
//     this.userPrivilegeMyInptOutstandingReport = userPrivilegeMyInptOutstandingReport;
//     this.userPrivilegeMyInptPaymentReport = userPrivilegeMyInptPaymentReport;
//     this.userPrivilegeMyInptUtilReport = userPrivilegeMyInptUtilReport;
//     this.userPrivilegeMyInptImportPurchaseReport = userPrivilegeMyInptImportPurchaseReport;
//     this.userPrivilegeMyInptBillRegReport = userPrivilegeMyInptBillRegReport;
//     this.userPrivilegeMyInptHoldPaymentReport = userPrivilegeMyInptHoldPaymentReport;
//     this.userPrivilegeMyInptReleasePaymentReport = userPrivilegeMyInptReleasePaymentReport;
//     this.userPrivilegeMyInptCaseTriageReport = userPrivilegeMyInptCaseTriageReport;
//     this.userPrivilegeMyInptHeadCountReport = userPrivilegeMyInptHeadCountReport;
//     this.userPrivilegeMyInptBordMyobReport = userPrivilegeMyInptBordMyobReport;
//     this.userPrivilegeMyInptPaymentForMyobReport = userPrivilegeMyInptPaymentForMyobReport;
//     this.userPrivilegeMyInptMemberNoClaimReport = userPrivilegeMyInptMemberNoClaimReport;
//     this.userPrivilegeMyAccPacArReport = userPrivilegeMyAccPacArReport;
//     this.userPrivilegeMyAccPacApReport = userPrivilegeMyAccPacApReport;
//     this.userPrivilegeMyAccPacReport = userPrivilegeMyAccPacReport;
//     this.userPrivilegeMyAccPayableReport = userPrivilegeMyAccPayableReport;
//     this.userPrivilegeMyAccReceivableReport = userPrivilegeMyAccReceivableReport;
//     this.userPrivilegeMyBsiInptTextFileReport = userPrivilegeMyBsiInptTextFileReport;
//     this.userPrivilegeMyAmmetlifeTxtReport = userPrivilegeMyAmmetlifeTxtReport;
//     this.userPrivilegeMyBsiPostTextFileReport = userPrivilegeMyBsiPostTextFileReport;
//     this.userPrivilegeMyAlimIndReport = userPrivilegeMyAlimIndReport;
//     this.userPrivilegeMyAlimGrpReport = userPrivilegeMyAlimGrpReport;
//     this.userPrivilegeMyHlaTxtReport = userPrivilegeMyHlaTxtReport;
//     this.userPrivilegeMyAxaTxtReport = userPrivilegeMyAxaTxtReport;
//     this.userPrivilegeMyLonpacTxtReport = userPrivilegeMyLonpacTxtReport;
//     this.userPrivilegeMyLonpacDcaTxtReport = userPrivilegeMyLonpacDcaTxtReport;
//     this.userPrivilegeMyMcisGrpTxtReport = userPrivilegeMyMcisGrpTxtReport;
//     this.userPrivilegeMyMcisIndTxtReport = userPrivilegeMyMcisIndTxtReport;
//     this.userPrivilegeMyMpiMseTxtReport = userPrivilegeMyMpiMseTxtReport;
//     this.userPrivilegeMyMpiPtgTxtReport = userPrivilegeMyMpiPtgTxtReport;
//     this.userPrivilegeMyStmbTxtReport = userPrivilegeMyStmbTxtReport;
//     this.userPrivilegeMyStmbRbTxtReport = userPrivilegeMyStmbRbTxtReport;
//     this.userPrivilegeMyStmbCashTxtReport = userPrivilegeMyStmbCashTxtReport;
//     this.userPrivilegeMyTisbTxtReport = userPrivilegeMyTisbTxtReport;
//     this.userPrivilegeMyTokioMarineTxtReport = userPrivilegeMyTokioMarineTxtReport;
//     this.userPrivilegeMySpikpaTxtReport = userPrivilegeMySpikpaTxtReport;
//     this.userPrivilegeMyEtiqaMcsTxtReport = userPrivilegeMyEtiqaMcsTxtReport;
//     this.userPrivilegeMyMbasTextFileReport = userPrivilegeMyMbasTextFileReport;
//     this.userPrivilegeAsiaInptClaimsBdxReport = userPrivilegeAsiaInptClaimsBdxReport;
//     this.userPrivilegeAsiaInptMasterReport = userPrivilegeAsiaInptMasterReport;
//     this.userPrivilegeAsiaInptClaimsReturnReport = userPrivilegeAsiaInptClaimsReturnReport;
//     this.userPrivilegeAsiaInptSettlementReport = userPrivilegeAsiaInptSettlementReport;
//     this.userPrivilegeAsiaDailyInptCasesReport = userPrivilegeAsiaDailyInptCasesReport;
//     this.userPrivilegeAsiaInptUtilReport = userPrivilegeAsiaInptUtilReport;
//     this.userPrivilegeAsiaInptCostContainmentReport = userPrivilegeAsiaInptCostContainmentReport;
//     this.userPrivilegeAsiaInptPostAuditReport = userPrivilegeAsiaInptPostAuditReport;
//     this.userPrivilegeAsiaInptPaymentAdvReport = userPrivilegeAsiaInptPaymentAdvReport;
//     this.userPrivilegeAsiaInptDailyImagingReport = userPrivilegeAsiaInptDailyImagingReport;
//     this.userPrivilegeAsiInptaMedicalFeeReport = userPrivilegeAsiInptaMedicalFeeReport;
//     this.userPrivilegeAsiaInptAccountPaymentReport = userPrivilegeAsiaInptAccountPaymentReport;
//     this.userPrivilegeAsiaInptSummarySettleReport = userPrivilegeAsiaInptSummarySettleReport;
//     this.userPrivilegeAsiaInptMedicalFeeReport = userPrivilegeAsiaInptMedicalFeeReport;
//     this.userPrivilegePhAxaHcpReport = userPrivilegePhAxaHcpReport;
//     this.userPrivilegePhInptClaimBdxReport = userPrivilegePhInptClaimBdxReport;
//     this.userPrivilegePhMabiFileReport = userPrivilegePhMabiFileReport;
//     this.userPrivilegePhSmsFileReport = userPrivilegePhSmsFileReport;
//     this.userPrivilegePhSmsFileGroupReport = userPrivilegePhSmsFileGroupReport;
//     this.userPrivilegePhGhaClaimsReturnReport = userPrivilegePhGhaClaimsReturnReport;
//     this.userPrivilegeSgAxaHcpReport = userPrivilegeSgAxaHcpReport;
//     this.userPrivilegeSgAhmStarhubSmsReport = userPrivilegeSgAhmStarhubSmsReport;
//     this.userPrivilegeSgAgiIndonAdmedikaReport = userPrivilegeSgAgiIndonAdmedikaReport;
//     this.userPrivilegeHkAhmPaReport = userPrivilegeHkAhmPaReport;
//     this.userPrivilegeHkInptPendingReport = userPrivilegeHkInptPendingReport;
//     this.userPrivilegeHkPruMmCountReport = userPrivilegeHkPruMmCountReport;
//     this.userPrivilegeHkPruMemReport = userPrivilegeHkPruMemReport;
//     this.userPrivilegeHkPruClaimReturnReport = userPrivilegeHkPruClaimReturnReport;
//     this.userPrivilegeHkPruInptPhoneLogReport = userPrivilegeHkPruInptPhoneLogReport;
//     this.userPrivilegeHkAceLifeDailyReport = userPrivilegeHkAceLifeDailyReport;
//     this.userPrivilegeHkWempClaimReport = userPrivilegeHkWempClaimReport;
//     this.userPrivilegeHkWempG400report = userPrivilegeHkWempG400report;
//     this.userPrivilegeHkSunLifeReport = userPrivilegeHkSunLifeReport;
//     this.userPrivilegeHkPruOwsClaimPpmReport = userPrivilegeHkPruOwsClaimPpmReport;
//     this.userPrivilegeHkInptClaimsBdxReport = userPrivilegeHkInptClaimsBdxReport;
//     this.userPrivilegeHkAppointmentBookingReport = userPrivilegeHkAppointmentBookingReport;
//     this.userPrivilegeHkLetterLabelPrintReport = userPrivilegeHkLetterLabelPrintReport;
//     this.userPrivilegeHkMembershipCardPrintReport = userPrivilegeHkMembershipCardPrintReport;
//     this.userPrivilegeHkPpmClaimLettersReport = userPrivilegeHkPpmClaimLettersReport;
//     this.userPrivilegeHkPpmControlFileReport = userPrivilegeHkPpmControlFileReport;
//     this.userPrivilegeHkPruInptClaimRefReport = userPrivilegeHkPruInptClaimRefReport;
//     this.userPrivilegeHkPruInptPendingFileReport = userPrivilegeHkPruInptPendingFileReport;
//     this.userPrivilegeCnUnitedEfileReport = userPrivilegeCnUnitedEfileReport;
//     this.userPrivilegeCnStudentCareInptClaimBdxReport = userPrivilegeCnStudentCareInptClaimBdxReport;
//     this.userPrivilegeThKtaxaPaymentBankReport = userPrivilegeThKtaxaPaymentBankReport;
//     this.userPrivilegeThAgiPaymentBankReport = userPrivilegeThAgiPaymentBankReport;
//     this.userPrivilegeThKtaxaEmailSmsReport = userPrivilegeThKtaxaEmailSmsReport;
//     this.userPrivilegeThKtaxaActuarial1report = userPrivilegeThKtaxaActuarial1report;
//     this.userPrivilegeThKtaxaActuarial2report = userPrivilegeThKtaxaActuarial2report;
//     this.userPrivilegeThKtaxaChequeAutoRefundReport = userPrivilegeThKtaxaChequeAutoRefundReport;
//     this.userPrivilegeThKtaxaSlaPreFaxReport = userPrivilegeThKtaxaSlaPreFaxReport;
//     this.userPrivilegeThKtaxaSlaDirectReport = userPrivilegeThKtaxaSlaDirectReport;
//     this.userPrivilegeThKtaxaSmsMonthlyFeeReport = userPrivilegeThKtaxaSmsMonthlyFeeReport;
//     this.userPrivilegeThKtaxaClaimPaymentReport = userPrivilegeThKtaxaClaimPaymentReport;
//     this.userPrivilegeThKtaxaActuarialPaymentDailyReport = userPrivilegeThKtaxaActuarialPaymentDailyReport;
//     this.userPrivilegeThKtaxaPaymentOutstandingReport = userPrivilegeThKtaxaPaymentOutstandingReport;
//     this.userPrivilegeThKtaxaCdbPolicyMasterReport = userPrivilegeThKtaxaCdbPolicyMasterReport;
//     this.userPrivilegeThKtaxaCdbInsuredDetailsReport = userPrivilegeThKtaxaCdbInsuredDetailsReport;
//     this.userPrivilegeThKtaxaCdbServiceProviderEnReport = userPrivilegeThKtaxaCdbServiceProviderEnReport;
//     this.userPrivilegeThKtaxaCdbServiceProviderThReport = userPrivilegeThKtaxaCdbServiceProviderThReport;
//     this.userPrivilegeThKtaxaCdbClaimStatusReport = userPrivilegeThKtaxaCdbClaimStatusReport;
//     this.userPrivilegeThKtaxaCdbBenefitCodeMappingReport = userPrivilegeThKtaxaCdbBenefitCodeMappingReport;
//     this.userPrivilegeThKtaxaCdbBenefitMasterReport = userPrivilegeThKtaxaCdbBenefitMasterReport;
//     this.userPrivilegeThKtaxaCdbClaimHeaderReport = userPrivilegeThKtaxaCdbClaimHeaderReport;
//     this.userPrivilegeThKtaxaCdbClaimDetailDecisionReport = userPrivilegeThKtaxaCdbClaimDetailDecisionReport;
//     this.userPrivilegeThKtaxaCdbClaimDetailPaymentReport = userPrivilegeThKtaxaCdbClaimDetailPaymentReport;
//     this.userPrivilegeThKtaxaCdbPaymentDetailsReport = userPrivilegeThKtaxaCdbPaymentDetailsReport;
//     this.userPrivilegeThKtaxaCdbProductMasterReport = userPrivilegeThKtaxaCdbProductMasterReport;
//     this.userPrivilegeThAgiClaimHistoryForRenewalReport = userPrivilegeThAgiClaimHistoryForRenewalReport;
//     this.userPrivilegeThAgiSlaFaxClaimReport = userPrivilegeThAgiSlaFaxClaimReport;
//     this.userPrivilegeThAgiSlaCreditDirectClaimReport = userPrivilegeThAgiSlaCreditDirectClaimReport;
//     this.userPrivilegeThAgiInptDetailsReport = userPrivilegeThAgiInptDetailsReport;
//     this.userPrivilegeThAgiReceivedDateReport = userPrivilegeThAgiReceivedDateReport;
//     this.userPrivilegeThAgiClaimPaymentReport = userPrivilegeThAgiClaimPaymentReport;
//     this.userPrivilegeThAgiClaimRepaymentReport = userPrivilegeThAgiClaimRepaymentReport;
//     this.userPrivilegeThAgiFaxClaimSummaryReport = userPrivilegeThAgiFaxClaimSummaryReport;
//     this.userPrivilegeThAathSlaFaxClaimReport = userPrivilegeThAathSlaFaxClaimReport;
//     this.userPrivilegeThAathSlaPreCerRegisterReport = userPrivilegeThAathSlaPreCerRegisterReport;
//     this.userPrivilegeThAathC1ieReport = userPrivilegeThAathC1ieReport;
//     this.userPrivilegeFnAlimTextFileReport = userPrivilegeFnAlimTextFileReport;
//     this.userPrivilegeApiReqToken = userPrivilegeApiReqToken;
//     this.userPrivilegeApiChgPw = userPrivilegeApiChgPw;
//     this.userPrivilegeApiLostPw = userPrivilegeApiLostPw;
//     this.userPrivilegeApiSignUp = userPrivilegeApiSignUp;
//     this.userPrivilegeApiMemberInit = userPrivilegeApiMemberInit;
//     this.userPrivilegeApiReqInptPlan = userPrivilegeApiReqInptPlan;
//     this.userPrivilegeApiReqInptCase = userPrivilegeApiReqInptCase;
//     this.userPrivilegeApiReqInptCases = userPrivilegeApiReqInptCases;
//     this.userPrivilegeApiCreateInptCase = userPrivilegeApiCreateInptCase;
//     this.userPrivilegeApiReqOutptPlan = userPrivilegeApiReqOutptPlan;
//     this.userPrivilegeApiReqOutptClaim = userPrivilegeApiReqOutptClaim;
//     this.userPrivilegeApiReqOutptClaims = userPrivilegeApiReqOutptClaims;
//     this.userPrivilegeApiMemberValidate = userPrivilegeApiMemberValidate;
//     this.userPrivilegeApiClaimSubmit = userPrivilegeApiClaimSubmit;
//     this.userPrivilegeApiCreateOutptClaimDraft = userPrivilegeApiCreateOutptClaimDraft;
//     this.userPrivilegeApiSearchProvider = userPrivilegeApiSearchProvider;
//     this.userPrivilegeApiQrSearchProvider = userPrivilegeApiQrSearchProvider;
//     this.userPrivilegeApiReqCountry = userPrivilegeApiReqCountry;
//     this.userPrivilegeApiSubmitFeedback = userPrivilegeApiSubmitFeedback;
//     this.userPrivilegeApiReqHafStat = userPrivilegeApiReqHafStat;
//     this.userPrivilegeApiReqLog = userPrivilegeApiReqLog;
//     this.userPrivilegeApiReqImpp = userPrivilegeApiReqImpp;
//     this.userPrivilegeBencomKey = userPrivilegeBencomKey;
//     this.userPrivilegeBencom = userPrivilegeBencom;
//     this.userPrivilegeEclaimDocUpload = userPrivilegeEclaimDocUpload;
// }
// public UserPrivilege(Integer userPrivilegeCreatedBy, Date userPrivilegeCreatedDate, Integer userPrivilegeLastEdittedBy, Date userPrivilegeLastEdittedDate, String userPrivilegeName, String userPrivilegeDescription, Short userPrivilegeInptCase, short userPrivilegeInptCaseMm, short userPrivilegeInptCaseProp, short userPrivilegeInptCaseHistory, short userPrivilegeInptCasePlanNotes, short userPrivilegeInptCasePolMvnt, short userPrivilegeInptCaseAdm, short userPrivilegeInptCaseDisc, short userPrivilegeInptCaseCalcs, short userPrivilegeInptCaseWs, short userPrivilegeInptCasePhLog, short userPrivilegeInptCaseDoc, short userPrivilegeInptCaseAppv, short userPrivilegeInptCaseImg, short userPrivilegeInptCaseCostCu, short userPrivilegeInptCaseCaseNote, short userPrivilegeInptCaseAcc, short userPrivilegeInptCaseReminder, short userPrivilegeInptCaseTodo, Short userPrivilegeInptCaseExt, short userPrivilegeInptCaseTriage, short userPrivilegeCcmCase, short userPrivilegeCcmCaseInpt, short userPrivilegeCcmCaseOutpt, Short userPrivilegeAnnounce, short userPrivilegeClient, short userPrivilegeBank, short userPrivilegeServices, short userPrivilegeProgram, short userPrivilegeBillingProfile, short userPrivilegeAccountProfile, short userPrivilegeInptPlan, short userPrivilegeInptPolicy, short userPrivilegeMedPrv, short userPrivilegeMedPrvPanel, short userPrivilegeWsCat, short userPrivilegeWsTemp, short userPrivilegeWsItems, short userPrivilegeDr, short userPrivilegeDrSpec, short userPrivilegeMember, short userPrivilegeMemberInpt, short userPrivilegeMemberOutpt, short userPrivilegeDiagnosis, short userPrivilegeDrug, short userPrivilegeSymptom, short userPrivilegeDashboard, short userPrivilegeSurgSchedule, short userPrivilegeDocTemp, short userPrivilegeBdx, short userPrivilegeImport, short userPrivilegeAppointmentBooking, short userPrivilegeUser, short userPrivilegeUserPrivilege, short userPrivilegeUserApiPrivilege, short userPrivilegeUserClient, short userPrivilegeUserDept, short userPrivilegeUserHospital, short userPrivilegeUserApi, short userPrivilegeDocSpeAutho, short userPrivilegeIftttRule, short userPrivilegeIftttField, short userPrivilegeCsuCases, short userPrivilegeClaimGuidelines, short userPrivilegePolicyJacket, short userPrivilegeInptBillRegistration, short userPrivilegeOutptBillRegistration, short userPrivilegeWorksheet, short userPrivilegeIpWhitelist, short userPrivilegeInptCaseType, short userPrivilegeInptCaseRejectType, short userPrivilegeOutptBenefit, short userPrivilegeOutptItem, short userPrivilegeOutptPlan, short userPrivilegeOutptMember, short userPrivilegeOutptClaim, short userPrivilegeOutptClaimLog, short userPrivilegeOutptClaimDoc, short userPrivilegeOutptClaimImg, short userPrivilegeOutptClaimReminders, short userPrivilegeOutptClaimCba, short userPrivilegeOutptClaimHistory, short userPrivilegeOutptClaimFwa, short userPrivilegeOutptClaimGeneralAdmin, short userPrivilegeOutptClaimPayAdv, short userPrivilegeOutptClaimTriage, short userPrivilegeOutptStatus, short userPrivilegeOutptAutoAdj, short userPrivilegeOutptBdx, short userPrivilegeOutptPayAdv, short userPrivilegeOutptInvestigation, short userPrivilegeFileRepo, short userPrivilegeEaDashboard, short userPrivilegeEaMember, short userPrivilegeEaCases, short userPrivilegeEaAnnounce, short userPrivilegeEclientAllowImpersonation, short userPrivilegeEclientDashboard, short userPrivilegeEclientInptCase, short userPrivilegeEclientInptIncludeOutpt, short userPrivilegeEclientInptShowMedicalInfo, short userPrivilegeEclientInptShowPruPlan, short userPrivilegeEclientInptExternalCase, short userPrivilegeEclientInptMember, short userPrivilegeEclientInptUtilReport, short userPrivilegeEclientInptCaseAdm, short userPrivilegeEclientInptCaseMember, short userPrivilegeEclientInptCaseDisc, short userPrivilegeEclientInptCaseCalc, short userPrivilegeEclientInptCaseWorksheet, short userPrivilegeEclientInptCaseDoc, short userPrivilegeEclientInptCaseLogs, short userPrivilegeEclientInptCaseApproval, short userPrivilegeEclientInptCaseImage, short userPrivilegeEclientInptCasePingbox, short userPrivilegeEclientInptCaseInptCsuCase, short userPrivilegeEclientInptCsuCase, short userPrivilegeEclientInptCsuCaseAdm, short userPrivilegeEclientInptCsuCaseDisc, short userPrivilegeEclientInptCsuCaseWorksheet, short userPrivilegeEclientInptCsuCaseDoc, short userPrivilegeEclientInptCsuCaseImage, short userPrivilegeEclientInOutOutptCase, short userPrivilegeEclientInOutInptCase, short userPrivilegeEclientInOutShowMedicalInfo, short userPrivilegeEclientInOutDocs, short userPrivilegeEclientInOutLogs, short userPrivilegeEclientInOutApproval, short userPrivilegeEclientInOutImage, short userPrivilegeEclientInOutMember, short userPrivilegeEclientPingbox, short userPrivilegeEclientInvestigation, short userPrivilegeEclientReport, short userPrivilegeEclientMySetting, short userPrivilegeEclaimAllowImpersonation, short userPrivilegeEclaimInptCases, short userPrivilegeEclaimInptIncludeOutpt, short userPrivilegeEclaimInptMember, short userPrivilegeEclaimInptDocUpload, short userPrivilegeEclaimInOutOpdCases, short userPrivilegeEclaimInOutMember, short userPrivilegeEclaimInOutIpdMember, short userPrivilegeEclaimInOutOpdMember, short userPrivilegeEclaimInOutIpdCases, short userPrivilegeEclaimInOutOpdPayAdv, short userPrivilegeEclaimQr, short userPrivilegeEclaimMySetting, short userPrivilegeEclaimContactUs, short userPrivilegeEclaimMyForm, short userPrivilegeEclaimSgForm, short userPrivilegeEclaimThForm, short userPrivilegeEclaimDocumentCentral, short userPrivilegeAllInptMmCountReport, short userPrivilegeAllMemberUuidReport, short userPrivilegeAllCcmReport, short userPrivilegeAllInptReminderReport, short userPrivilegeAllInptCaseTodoReport, short userPrivilegeMyInptAccountingReport, short userPrivilegeMyInptB2bReport, short userPrivilegeMyInptBordTempReport, short userPrivilegeMyInptHccReport, short userPrivilegeMyInptMarketingReport, short userPrivilegeMyInptMasterFileTempReport, short userPrivilegeMyInptNoObAgingReport, short userPrivilegeMyInptOutstandingReport, short userPrivilegeMyInptPaymentReport, short userPrivilegeMyInptUtilReport, short userPrivilegeMyInptImportPurchaseReport, short userPrivilegeMyInptBillRegReport, short userPrivilegeMyInptHoldPaymentReport, short userPrivilegeMyInptReleasePaymentReport, short userPrivilegeMyInptCaseTriageReport, short userPrivilegeMyInptHeadCountReport, short userPrivilegeMyInptBordMyobReport, short userPrivilegeMyInptPaymentForMyobReport, short userPrivilegeMyInptMemberNoClaimReport, short userPrivilegeMyAccPacArReport, short userPrivilegeMyAccPacApReport, short userPrivilegeMyAccPacReport, short userPrivilegeMyAccPayableReport, short userPrivilegeMyAccReceivableReport, short userPrivilegeMyBsiInptTextFileReport, short userPrivilegeMyAmmetlifeTxtReport, short userPrivilegeMyBsiPostTextFileReport, short userPrivilegeMyAlimIndReport, short userPrivilegeMyAlimGrpReport, short userPrivilegeMyHlaTxtReport, short userPrivilegeMyAxaTxtReport, short userPrivilegeMyLonpacTxtReport, short userPrivilegeMyLonpacDcaTxtReport, short userPrivilegeMyMcisGrpTxtReport, short userPrivilegeMyMcisIndTxtReport, short userPrivilegeMyMpiMseTxtReport, short userPrivilegeMyMpiPtgTxtReport, short userPrivilegeMyStmbTxtReport, short userPrivilegeMyStmbRbTxtReport, short userPrivilegeMyStmbCashTxtReport, short userPrivilegeMyTisbTxtReport, short userPrivilegeMyTokioMarineTxtReport, short userPrivilegeMySpikpaTxtReport, short userPrivilegeMyEtiqaMcsTxtReport, short userPrivilegeMyMbasTextFileReport, short userPrivilegeAsiaInptClaimsBdxReport, short userPrivilegeAsiaInptMasterReport, short userPrivilegeAsiaInptClaimsReturnReport, short userPrivilegeAsiaInptSettlementReport, short userPrivilegeAsiaDailyInptCasesReport, short userPrivilegeAsiaInptUtilReport, short userPrivilegeAsiaInptCostContainmentReport, short userPrivilegeAsiaInptPostAuditReport, short userPrivilegeAsiaInptPaymentAdvReport, short userPrivilegeAsiaInptDailyImagingReport, short userPrivilegeAsiInptaMedicalFeeReport, short userPrivilegeAsiaInptAccountPaymentReport, short userPrivilegeAsiaInptSummarySettleReport, short userPrivilegeAsiaInptMedicalFeeReport, short userPrivilegePhAxaHcpReport, short userPrivilegePhInptClaimBdxReport, short userPrivilegePhMabiFileReport, short userPrivilegePhSmsFileReport, short userPrivilegePhSmsFileGroupReport, short userPrivilegePhGhaClaimsReturnReport, short userPrivilegeSgAxaHcpReport, short userPrivilegeSgAhmStarhubSmsReport, short userPrivilegeSgAgiIndonAdmedikaReport, short userPrivilegeHkAhmPaReport, short userPrivilegeHkInptPendingReport, short userPrivilegeHkPruMmCountReport, short userPrivilegeHkPruMemReport, short userPrivilegeHkPruClaimReturnReport, short userPrivilegeHkPruInptPhoneLogReport, short userPrivilegeHkAceLifeDailyReport, short userPrivilegeHkWempClaimReport, short userPrivilegeHkWempG400report, short userPrivilegeHkSunLifeReport, short userPrivilegeHkPruOwsClaimPpmReport, short userPrivilegeHkInptClaimsBdxReport, short userPrivilegeHkAppointmentBookingReport, short userPrivilegeHkLetterLabelPrintReport, short userPrivilegeHkMembershipCardPrintReport, short userPrivilegeHkPpmClaimLettersReport, short userPrivilegeHkPpmControlFileReport, short userPrivilegeHkPruInptClaimRefReport, short userPrivilegeHkPruInptPendingFileReport, short userPrivilegeCnUnitedEfileReport, short userPrivilegeCnStudentCareInptClaimBdxReport, short userPrivilegeThKtaxaPaymentBankReport, short userPrivilegeThAgiPaymentBankReport, short userPrivilegeThKtaxaEmailSmsReport, short userPrivilegeThKtaxaActuarial1report, short userPrivilegeThKtaxaActuarial2report, short userPrivilegeThKtaxaChequeAutoRefundReport, short userPrivilegeThKtaxaSlaPreFaxReport, short userPrivilegeThKtaxaSlaDirectReport, short userPrivilegeThKtaxaSmsMonthlyFeeReport, short userPrivilegeThKtaxaClaimPaymentReport, short userPrivilegeThKtaxaActuarialPaymentDailyReport, short userPrivilegeThKtaxaPaymentOutstandingReport, short userPrivilegeThKtaxaCdbPolicyMasterReport, short userPrivilegeThKtaxaCdbInsuredDetailsReport, short userPrivilegeThKtaxaCdbServiceProviderEnReport, short userPrivilegeThKtaxaCdbServiceProviderThReport, short userPrivilegeThKtaxaCdbClaimStatusReport, short userPrivilegeThKtaxaCdbBenefitCodeMappingReport, short userPrivilegeThKtaxaCdbBenefitMasterReport, short userPrivilegeThKtaxaCdbClaimHeaderReport, short userPrivilegeThKtaxaCdbClaimDetailDecisionReport, short userPrivilegeThKtaxaCdbClaimDetailPaymentReport, short userPrivilegeThKtaxaCdbPaymentDetailsReport, short userPrivilegeThKtaxaCdbProductMasterReport, short userPrivilegeThAgiClaimHistoryForRenewalReport, short userPrivilegeThAgiSlaFaxClaimReport, short userPrivilegeThAgiSlaCreditDirectClaimReport, short userPrivilegeThAgiInptDetailsReport, short userPrivilegeThAgiReceivedDateReport, short userPrivilegeThAgiClaimPaymentReport, short userPrivilegeThAgiClaimRepaymentReport, short userPrivilegeThAgiFaxClaimSummaryReport, short userPrivilegeThAathSlaFaxClaimReport, short userPrivilegeThAathSlaPreCerRegisterReport, short userPrivilegeThAathC1ieReport, short userPrivilegeFnAlimTextFileReport, short userPrivilegeApiReqToken, short userPrivilegeApiChgPw, short userPrivilegeApiLostPw, short userPrivilegeApiSignUp, short userPrivilegeApiMemberInit, short userPrivilegeApiReqInptPlan, short userPrivilegeApiReqInptCase, short userPrivilegeApiReqInptCases, short userPrivilegeApiCreateInptCase, short userPrivilegeApiReqOutptPlan, short userPrivilegeApiReqOutptClaim, short userPrivilegeApiReqOutptClaims, short userPrivilegeApiMemberValidate, short userPrivilegeApiClaimSubmit, short userPrivilegeApiCreateOutptClaimDraft, short userPrivilegeApiSearchProvider, short userPrivilegeApiQrSearchProvider, short userPrivilegeApiReqCountry, short userPrivilegeApiSubmitFeedback, short userPrivilegeApiReqHafStat, short userPrivilegeApiReqLog, short userPrivilegeApiReqImpp, short userPrivilegeBencomKey, short userPrivilegeBencom, short userPrivilegeEclaimDocUpload, Set<User> users) {
//    this.userPrivilegeCreatedBy = userPrivilegeCreatedBy;
//    this.userPrivilegeCreatedDate = userPrivilegeCreatedDate;
//    this.userPrivilegeLastEdittedBy = userPrivilegeLastEdittedBy;
//    this.userPrivilegeLastEdittedDate = userPrivilegeLastEdittedDate;
//    this.userPrivilegeName = userPrivilegeName;
//    this.userPrivilegeDescription = userPrivilegeDescription;
//    this.userPrivilegeInptCase = userPrivilegeInptCase;
//    this.userPrivilegeInptCaseMm = userPrivilegeInptCaseMm;
//    this.userPrivilegeInptCaseProp = userPrivilegeInptCaseProp;
//    this.userPrivilegeInptCaseHistory = userPrivilegeInptCaseHistory;
//    this.userPrivilegeInptCasePlanNotes = userPrivilegeInptCasePlanNotes;
//    this.userPrivilegeInptCasePolMvnt = userPrivilegeInptCasePolMvnt;
//    this.userPrivilegeInptCaseAdm = userPrivilegeInptCaseAdm;
//    this.userPrivilegeInptCaseDisc = userPrivilegeInptCaseDisc;
//    this.userPrivilegeInptCaseCalcs = userPrivilegeInptCaseCalcs;
//    this.userPrivilegeInptCaseWs = userPrivilegeInptCaseWs;
//    this.userPrivilegeInptCasePhLog = userPrivilegeInptCasePhLog;
//    this.userPrivilegeInptCaseDoc = userPrivilegeInptCaseDoc;
//    this.userPrivilegeInptCaseAppv = userPrivilegeInptCaseAppv;
//    this.userPrivilegeInptCaseImg = userPrivilegeInptCaseImg;
//    this.userPrivilegeInptCaseCostCu = userPrivilegeInptCaseCostCu;
//    this.userPrivilegeInptCaseCaseNote = userPrivilegeInptCaseCaseNote;
//    this.userPrivilegeInptCaseAcc = userPrivilegeInptCaseAcc;
//    this.userPrivilegeInptCaseReminder = userPrivilegeInptCaseReminder;
//    this.userPrivilegeInptCaseTodo = userPrivilegeInptCaseTodo;
//    this.userPrivilegeInptCaseExt = userPrivilegeInptCaseExt;
//    this.userPrivilegeInptCaseTriage = userPrivilegeInptCaseTriage;
//    this.userPrivilegeCcmCase = userPrivilegeCcmCase;
//    this.userPrivilegeCcmCaseInpt = userPrivilegeCcmCaseInpt;
//    this.userPrivilegeCcmCaseOutpt = userPrivilegeCcmCaseOutpt;
//    this.userPrivilegeAnnounce = userPrivilegeAnnounce;
//    this.userPrivilegeClient = userPrivilegeClient;
//    this.userPrivilegeBank = userPrivilegeBank;
//    this.userPrivilegeServices = userPrivilegeServices;
//    this.userPrivilegeProgram = userPrivilegeProgram;
//    this.userPrivilegeBillingProfile = userPrivilegeBillingProfile;
//    this.userPrivilegeAccountProfile = userPrivilegeAccountProfile;
//    this.userPrivilegeInptPlan = userPrivilegeInptPlan;
//    this.userPrivilegeInptPolicy = userPrivilegeInptPolicy;
//    this.userPrivilegeMedPrv = userPrivilegeMedPrv;
//    this.userPrivilegeMedPrvPanel = userPrivilegeMedPrvPanel;
//    this.userPrivilegeWsCat = userPrivilegeWsCat;
//    this.userPrivilegeWsTemp = userPrivilegeWsTemp;
//    this.userPrivilegeWsItems = userPrivilegeWsItems;
//    this.userPrivilegeDr = userPrivilegeDr;
//    this.userPrivilegeDrSpec = userPrivilegeDrSpec;
//    this.userPrivilegeMember = userPrivilegeMember;
//    this.userPrivilegeMemberInpt = userPrivilegeMemberInpt;
//    this.userPrivilegeMemberOutpt = userPrivilegeMemberOutpt;
//    this.userPrivilegeDiagnosis = userPrivilegeDiagnosis;
//    this.userPrivilegeDrug = userPrivilegeDrug;
//    this.userPrivilegeSymptom = userPrivilegeSymptom;
//    this.userPrivilegeDashboard = userPrivilegeDashboard;
//    this.userPrivilegeSurgSchedule = userPrivilegeSurgSchedule;
//    this.userPrivilegeDocTemp = userPrivilegeDocTemp;
//    this.userPrivilegeBdx = userPrivilegeBdx;
//    this.userPrivilegeImport = userPrivilegeImport;
//    this.userPrivilegeAppointmentBooking = userPrivilegeAppointmentBooking;
//    this.userPrivilegeUser = userPrivilegeUser;
//    this.userPrivilegeUserPrivilege = userPrivilegeUserPrivilege;
//    this.userPrivilegeUserApiPrivilege = userPrivilegeUserApiPrivilege;
//    this.userPrivilegeUserClient = userPrivilegeUserClient;
//    this.userPrivilegeUserDept = userPrivilegeUserDept;
//    this.userPrivilegeUserHospital = userPrivilegeUserHospital;
//    this.userPrivilegeUserApi = userPrivilegeUserApi;
//    this.userPrivilegeDocSpeAutho = userPrivilegeDocSpeAutho;
//    this.userPrivilegeIftttRule = userPrivilegeIftttRule;
//    this.userPrivilegeIftttField = userPrivilegeIftttField;
//    this.userPrivilegeCsuCases = userPrivilegeCsuCases;
//    this.userPrivilegeClaimGuidelines = userPrivilegeClaimGuidelines;
//    this.userPrivilegePolicyJacket = userPrivilegePolicyJacket;
//    this.userPrivilegeInptBillRegistration = userPrivilegeInptBillRegistration;
//    this.userPrivilegeOutptBillRegistration = userPrivilegeOutptBillRegistration;
//    this.userPrivilegeWorksheet = userPrivilegeWorksheet;
//    this.userPrivilegeIpWhitelist = userPrivilegeIpWhitelist;
//    this.userPrivilegeInptCaseType = userPrivilegeInptCaseType;
//    this.userPrivilegeInptCaseRejectType = userPrivilegeInptCaseRejectType;
//    this.userPrivilegeOutptBenefit = userPrivilegeOutptBenefit;
//    this.userPrivilegeOutptItem = userPrivilegeOutptItem;
//    this.userPrivilegeOutptPlan = userPrivilegeOutptPlan;
//    this.userPrivilegeOutptMember = userPrivilegeOutptMember;
//    this.userPrivilegeOutptClaim = userPrivilegeOutptClaim;
//    this.userPrivilegeOutptClaimLog = userPrivilegeOutptClaimLog;
//    this.userPrivilegeOutptClaimDoc = userPrivilegeOutptClaimDoc;
//    this.userPrivilegeOutptClaimImg = userPrivilegeOutptClaimImg;
//    this.userPrivilegeOutptClaimReminders = userPrivilegeOutptClaimReminders;
//    this.userPrivilegeOutptClaimCba = userPrivilegeOutptClaimCba;
//    this.userPrivilegeOutptClaimHistory = userPrivilegeOutptClaimHistory;
//    this.userPrivilegeOutptClaimFwa = userPrivilegeOutptClaimFwa;
//    this.userPrivilegeOutptClaimGeneralAdmin = userPrivilegeOutptClaimGeneralAdmin;
//    this.userPrivilegeOutptClaimPayAdv = userPrivilegeOutptClaimPayAdv;
//    this.userPrivilegeOutptClaimTriage = userPrivilegeOutptClaimTriage;
//    this.userPrivilegeOutptStatus = userPrivilegeOutptStatus;
//    this.userPrivilegeOutptAutoAdj = userPrivilegeOutptAutoAdj;
//    this.userPrivilegeOutptBdx = userPrivilegeOutptBdx;
//    this.userPrivilegeOutptPayAdv = userPrivilegeOutptPayAdv;
//    this.userPrivilegeOutptInvestigation = userPrivilegeOutptInvestigation;
//    this.userPrivilegeFileRepo = userPrivilegeFileRepo;
//    this.userPrivilegeEaDashboard = userPrivilegeEaDashboard;
//    this.userPrivilegeEaMember = userPrivilegeEaMember;
//    this.userPrivilegeEaCases = userPrivilegeEaCases;
//    this.userPrivilegeEaAnnounce = userPrivilegeEaAnnounce;
//    this.userPrivilegeEclientAllowImpersonation = userPrivilegeEclientAllowImpersonation;
//    this.userPrivilegeEclientDashboard = userPrivilegeEclientDashboard;
//    this.userPrivilegeEclientInptCase = userPrivilegeEclientInptCase;
//    this.userPrivilegeEclientInptIncludeOutpt = userPrivilegeEclientInptIncludeOutpt;
//    this.userPrivilegeEclientInptShowMedicalInfo = userPrivilegeEclientInptShowMedicalInfo;
//    this.userPrivilegeEclientInptShowPruPlan = userPrivilegeEclientInptShowPruPlan;
//    this.userPrivilegeEclientInptExternalCase = userPrivilegeEclientInptExternalCase;
//    this.userPrivilegeEclientInptMember = userPrivilegeEclientInptMember;
//    this.userPrivilegeEclientInptUtilReport = userPrivilegeEclientInptUtilReport;
//    this.userPrivilegeEclientInptCaseAdm = userPrivilegeEclientInptCaseAdm;
//    this.userPrivilegeEclientInptCaseMember = userPrivilegeEclientInptCaseMember;
//    this.userPrivilegeEclientInptCaseDisc = userPrivilegeEclientInptCaseDisc;
//    this.userPrivilegeEclientInptCaseCalc = userPrivilegeEclientInptCaseCalc;
//    this.userPrivilegeEclientInptCaseWorksheet = userPrivilegeEclientInptCaseWorksheet;
//    this.userPrivilegeEclientInptCaseDoc = userPrivilegeEclientInptCaseDoc;
//    this.userPrivilegeEclientInptCaseLogs = userPrivilegeEclientInptCaseLogs;
//    this.userPrivilegeEclientInptCaseApproval = userPrivilegeEclientInptCaseApproval;
//    this.userPrivilegeEclientInptCaseImage = userPrivilegeEclientInptCaseImage;
//    this.userPrivilegeEclientInptCasePingbox = userPrivilegeEclientInptCasePingbox;
//    this.userPrivilegeEclientInptCaseInptCsuCase = userPrivilegeEclientInptCaseInptCsuCase;
//    this.userPrivilegeEclientInptCsuCase = userPrivilegeEclientInptCsuCase;
//    this.userPrivilegeEclientInptCsuCaseAdm = userPrivilegeEclientInptCsuCaseAdm;
//    this.userPrivilegeEclientInptCsuCaseDisc = userPrivilegeEclientInptCsuCaseDisc;
//    this.userPrivilegeEclientInptCsuCaseWorksheet = userPrivilegeEclientInptCsuCaseWorksheet;
//    this.userPrivilegeEclientInptCsuCaseDoc = userPrivilegeEclientInptCsuCaseDoc;
//    this.userPrivilegeEclientInptCsuCaseImage = userPrivilegeEclientInptCsuCaseImage;
//    this.userPrivilegeEclientInOutOutptCase = userPrivilegeEclientInOutOutptCase;
//    this.userPrivilegeEclientInOutInptCase = userPrivilegeEclientInOutInptCase;
//    this.userPrivilegeEclientInOutShowMedicalInfo = userPrivilegeEclientInOutShowMedicalInfo;
//    this.userPrivilegeEclientInOutDocs = userPrivilegeEclientInOutDocs;
//    this.userPrivilegeEclientInOutLogs = userPrivilegeEclientInOutLogs;
//    this.userPrivilegeEclientInOutApproval = userPrivilegeEclientInOutApproval;
//    this.userPrivilegeEclientInOutImage = userPrivilegeEclientInOutImage;
//    this.userPrivilegeEclientInOutMember = userPrivilegeEclientInOutMember;
//    this.userPrivilegeEclientPingbox = userPrivilegeEclientPingbox;
//    this.userPrivilegeEclientInvestigation = userPrivilegeEclientInvestigation;
//    this.userPrivilegeEclientReport = userPrivilegeEclientReport;
//    this.userPrivilegeEclientMySetting = userPrivilegeEclientMySetting;
//    this.userPrivilegeEclaimAllowImpersonation = userPrivilegeEclaimAllowImpersonation;
//    this.userPrivilegeEclaimInptCases = userPrivilegeEclaimInptCases;
//    this.userPrivilegeEclaimInptIncludeOutpt = userPrivilegeEclaimInptIncludeOutpt;
//    this.userPrivilegeEclaimInptMember = userPrivilegeEclaimInptMember;
//    this.userPrivilegeEclaimInptDocUpload = userPrivilegeEclaimInptDocUpload;
//    this.userPrivilegeEclaimInOutOpdCases = userPrivilegeEclaimInOutOpdCases;
//    this.userPrivilegeEclaimInOutMember = userPrivilegeEclaimInOutMember;
//    this.userPrivilegeEclaimInOutIpdMember = userPrivilegeEclaimInOutIpdMember;
//    this.userPrivilegeEclaimInOutOpdMember = userPrivilegeEclaimInOutOpdMember;
//    this.userPrivilegeEclaimInOutIpdCases = userPrivilegeEclaimInOutIpdCases;
//    this.userPrivilegeEclaimInOutOpdPayAdv = userPrivilegeEclaimInOutOpdPayAdv;
//    this.userPrivilegeEclaimQr = userPrivilegeEclaimQr;
//    this.userPrivilegeEclaimMySetting = userPrivilegeEclaimMySetting;
//    this.userPrivilegeEclaimContactUs = userPrivilegeEclaimContactUs;
//    this.userPrivilegeEclaimMyForm = userPrivilegeEclaimMyForm;
//    this.userPrivilegeEclaimSgForm = userPrivilegeEclaimSgForm;
//    this.userPrivilegeEclaimThForm = userPrivilegeEclaimThForm;
//    this.userPrivilegeEclaimDocumentCentral = userPrivilegeEclaimDocumentCentral;
//    this.userPrivilegeAllInptMmCountReport = userPrivilegeAllInptMmCountReport;
//    this.userPrivilegeAllMemberUuidReport = userPrivilegeAllMemberUuidReport;
//    this.userPrivilegeAllCcmReport = userPrivilegeAllCcmReport;
//    this.userPrivilegeAllInptReminderReport = userPrivilegeAllInptReminderReport;
//    this.userPrivilegeAllInptCaseTodoReport = userPrivilegeAllInptCaseTodoReport;
//    this.userPrivilegeMyInptAccountingReport = userPrivilegeMyInptAccountingReport;
//    this.userPrivilegeMyInptB2bReport = userPrivilegeMyInptB2bReport;
//    this.userPrivilegeMyInptBordTempReport = userPrivilegeMyInptBordTempReport;
//    this.userPrivilegeMyInptHccReport = userPrivilegeMyInptHccReport;
//    this.userPrivilegeMyInptMarketingReport = userPrivilegeMyInptMarketingReport;
//    this.userPrivilegeMyInptMasterFileTempReport = userPrivilegeMyInptMasterFileTempReport;
//    this.userPrivilegeMyInptNoObAgingReport = userPrivilegeMyInptNoObAgingReport;
//    this.userPrivilegeMyInptOutstandingReport = userPrivilegeMyInptOutstandingReport;
//    this.userPrivilegeMyInptPaymentReport = userPrivilegeMyInptPaymentReport;
//    this.userPrivilegeMyInptUtilReport = userPrivilegeMyInptUtilReport;
//    this.userPrivilegeMyInptImportPurchaseReport = userPrivilegeMyInptImportPurchaseReport;
//    this.userPrivilegeMyInptBillRegReport = userPrivilegeMyInptBillRegReport;
//    this.userPrivilegeMyInptHoldPaymentReport = userPrivilegeMyInptHoldPaymentReport;
//    this.userPrivilegeMyInptReleasePaymentReport = userPrivilegeMyInptReleasePaymentReport;
//    this.userPrivilegeMyInptCaseTriageReport = userPrivilegeMyInptCaseTriageReport;
//    this.userPrivilegeMyInptHeadCountReport = userPrivilegeMyInptHeadCountReport;
//    this.userPrivilegeMyInptBordMyobReport = userPrivilegeMyInptBordMyobReport;
//    this.userPrivilegeMyInptPaymentForMyobReport = userPrivilegeMyInptPaymentForMyobReport;
//    this.userPrivilegeMyInptMemberNoClaimReport = userPrivilegeMyInptMemberNoClaimReport;
//    this.userPrivilegeMyAccPacArReport = userPrivilegeMyAccPacArReport;
//    this.userPrivilegeMyAccPacApReport = userPrivilegeMyAccPacApReport;
//    this.userPrivilegeMyAccPacReport = userPrivilegeMyAccPacReport;
//    this.userPrivilegeMyAccPayableReport = userPrivilegeMyAccPayableReport;
//    this.userPrivilegeMyAccReceivableReport = userPrivilegeMyAccReceivableReport;
//    this.userPrivilegeMyBsiInptTextFileReport = userPrivilegeMyBsiInptTextFileReport;
//    this.userPrivilegeMyAmmetlifeTxtReport = userPrivilegeMyAmmetlifeTxtReport;
//    this.userPrivilegeMyBsiPostTextFileReport = userPrivilegeMyBsiPostTextFileReport;
//    this.userPrivilegeMyAlimIndReport = userPrivilegeMyAlimIndReport;
//    this.userPrivilegeMyAlimGrpReport = userPrivilegeMyAlimGrpReport;
//    this.userPrivilegeMyHlaTxtReport = userPrivilegeMyHlaTxtReport;
//    this.userPrivilegeMyAxaTxtReport = userPrivilegeMyAxaTxtReport;
//    this.userPrivilegeMyLonpacTxtReport = userPrivilegeMyLonpacTxtReport;
//    this.userPrivilegeMyLonpacDcaTxtReport = userPrivilegeMyLonpacDcaTxtReport;
//    this.userPrivilegeMyMcisGrpTxtReport = userPrivilegeMyMcisGrpTxtReport;
//    this.userPrivilegeMyMcisIndTxtReport = userPrivilegeMyMcisIndTxtReport;
//    this.userPrivilegeMyMpiMseTxtReport = userPrivilegeMyMpiMseTxtReport;
//    this.userPrivilegeMyMpiPtgTxtReport = userPrivilegeMyMpiPtgTxtReport;
//    this.userPrivilegeMyStmbTxtReport = userPrivilegeMyStmbTxtReport;
//    this.userPrivilegeMyStmbRbTxtReport = userPrivilegeMyStmbRbTxtReport;
//    this.userPrivilegeMyStmbCashTxtReport = userPrivilegeMyStmbCashTxtReport;
//    this.userPrivilegeMyTisbTxtReport = userPrivilegeMyTisbTxtReport;
//    this.userPrivilegeMyTokioMarineTxtReport = userPrivilegeMyTokioMarineTxtReport;
//    this.userPrivilegeMySpikpaTxtReport = userPrivilegeMySpikpaTxtReport;
//    this.userPrivilegeMyEtiqaMcsTxtReport = userPrivilegeMyEtiqaMcsTxtReport;
//    this.userPrivilegeMyMbasTextFileReport = userPrivilegeMyMbasTextFileReport;
//    this.userPrivilegeAsiaInptClaimsBdxReport = userPrivilegeAsiaInptClaimsBdxReport;
//    this.userPrivilegeAsiaInptMasterReport = userPrivilegeAsiaInptMasterReport;
//    this.userPrivilegeAsiaInptClaimsReturnReport = userPrivilegeAsiaInptClaimsReturnReport;
//    this.userPrivilegeAsiaInptSettlementReport = userPrivilegeAsiaInptSettlementReport;
//    this.userPrivilegeAsiaDailyInptCasesReport = userPrivilegeAsiaDailyInptCasesReport;
//    this.userPrivilegeAsiaInptUtilReport = userPrivilegeAsiaInptUtilReport;
//    this.userPrivilegeAsiaInptCostContainmentReport = userPrivilegeAsiaInptCostContainmentReport;
//    this.userPrivilegeAsiaInptPostAuditReport = userPrivilegeAsiaInptPostAuditReport;
//    this.userPrivilegeAsiaInptPaymentAdvReport = userPrivilegeAsiaInptPaymentAdvReport;
//    this.userPrivilegeAsiaInptDailyImagingReport = userPrivilegeAsiaInptDailyImagingReport;
//    this.userPrivilegeAsiInptaMedicalFeeReport = userPrivilegeAsiInptaMedicalFeeReport;
//    this.userPrivilegeAsiaInptAccountPaymentReport = userPrivilegeAsiaInptAccountPaymentReport;
//    this.userPrivilegeAsiaInptSummarySettleReport = userPrivilegeAsiaInptSummarySettleReport;
//    this.userPrivilegeAsiaInptMedicalFeeReport = userPrivilegeAsiaInptMedicalFeeReport;
//    this.userPrivilegePhAxaHcpReport = userPrivilegePhAxaHcpReport;
//    this.userPrivilegePhInptClaimBdxReport = userPrivilegePhInptClaimBdxReport;
//    this.userPrivilegePhMabiFileReport = userPrivilegePhMabiFileReport;
//    this.userPrivilegePhSmsFileReport = userPrivilegePhSmsFileReport;
//    this.userPrivilegePhSmsFileGroupReport = userPrivilegePhSmsFileGroupReport;
//    this.userPrivilegePhGhaClaimsReturnReport = userPrivilegePhGhaClaimsReturnReport;
//    this.userPrivilegeSgAxaHcpReport = userPrivilegeSgAxaHcpReport;
//    this.userPrivilegeSgAhmStarhubSmsReport = userPrivilegeSgAhmStarhubSmsReport;
//    this.userPrivilegeSgAgiIndonAdmedikaReport = userPrivilegeSgAgiIndonAdmedikaReport;
//    this.userPrivilegeHkAhmPaReport = userPrivilegeHkAhmPaReport;
//    this.userPrivilegeHkInptPendingReport = userPrivilegeHkInptPendingReport;
//    this.userPrivilegeHkPruMmCountReport = userPrivilegeHkPruMmCountReport;
//    this.userPrivilegeHkPruMemReport = userPrivilegeHkPruMemReport;
//    this.userPrivilegeHkPruClaimReturnReport = userPrivilegeHkPruClaimReturnReport;
//    this.userPrivilegeHkPruInptPhoneLogReport = userPrivilegeHkPruInptPhoneLogReport;
//    this.userPrivilegeHkAceLifeDailyReport = userPrivilegeHkAceLifeDailyReport;
//    this.userPrivilegeHkWempClaimReport = userPrivilegeHkWempClaimReport;
//    this.userPrivilegeHkWempG400report = userPrivilegeHkWempG400report;
//    this.userPrivilegeHkSunLifeReport = userPrivilegeHkSunLifeReport;
//    this.userPrivilegeHkPruOwsClaimPpmReport = userPrivilegeHkPruOwsClaimPpmReport;
//    this.userPrivilegeHkInptClaimsBdxReport = userPrivilegeHkInptClaimsBdxReport;
//    this.userPrivilegeHkAppointmentBookingReport = userPrivilegeHkAppointmentBookingReport;
//    this.userPrivilegeHkLetterLabelPrintReport = userPrivilegeHkLetterLabelPrintReport;
//    this.userPrivilegeHkMembershipCardPrintReport = userPrivilegeHkMembershipCardPrintReport;
//    this.userPrivilegeHkPpmClaimLettersReport = userPrivilegeHkPpmClaimLettersReport;
//    this.userPrivilegeHkPpmControlFileReport = userPrivilegeHkPpmControlFileReport;
//    this.userPrivilegeHkPruInptClaimRefReport = userPrivilegeHkPruInptClaimRefReport;
//    this.userPrivilegeHkPruInptPendingFileReport = userPrivilegeHkPruInptPendingFileReport;
//    this.userPrivilegeCnUnitedEfileReport = userPrivilegeCnUnitedEfileReport;
//    this.userPrivilegeCnStudentCareInptClaimBdxReport = userPrivilegeCnStudentCareInptClaimBdxReport;
//    this.userPrivilegeThKtaxaPaymentBankReport = userPrivilegeThKtaxaPaymentBankReport;
//    this.userPrivilegeThAgiPaymentBankReport = userPrivilegeThAgiPaymentBankReport;
//    this.userPrivilegeThKtaxaEmailSmsReport = userPrivilegeThKtaxaEmailSmsReport;
//    this.userPrivilegeThKtaxaActuarial1report = userPrivilegeThKtaxaActuarial1report;
//    this.userPrivilegeThKtaxaActuarial2report = userPrivilegeThKtaxaActuarial2report;
//    this.userPrivilegeThKtaxaChequeAutoRefundReport = userPrivilegeThKtaxaChequeAutoRefundReport;
//    this.userPrivilegeThKtaxaSlaPreFaxReport = userPrivilegeThKtaxaSlaPreFaxReport;
//    this.userPrivilegeThKtaxaSlaDirectReport = userPrivilegeThKtaxaSlaDirectReport;
//    this.userPrivilegeThKtaxaSmsMonthlyFeeReport = userPrivilegeThKtaxaSmsMonthlyFeeReport;
//    this.userPrivilegeThKtaxaClaimPaymentReport = userPrivilegeThKtaxaClaimPaymentReport;
//    this.userPrivilegeThKtaxaActuarialPaymentDailyReport = userPrivilegeThKtaxaActuarialPaymentDailyReport;
//    this.userPrivilegeThKtaxaPaymentOutstandingReport = userPrivilegeThKtaxaPaymentOutstandingReport;
//    this.userPrivilegeThKtaxaCdbPolicyMasterReport = userPrivilegeThKtaxaCdbPolicyMasterReport;
//    this.userPrivilegeThKtaxaCdbInsuredDetailsReport = userPrivilegeThKtaxaCdbInsuredDetailsReport;
//    this.userPrivilegeThKtaxaCdbServiceProviderEnReport = userPrivilegeThKtaxaCdbServiceProviderEnReport;
//    this.userPrivilegeThKtaxaCdbServiceProviderThReport = userPrivilegeThKtaxaCdbServiceProviderThReport;
//    this.userPrivilegeThKtaxaCdbClaimStatusReport = userPrivilegeThKtaxaCdbClaimStatusReport;
//    this.userPrivilegeThKtaxaCdbBenefitCodeMappingReport = userPrivilegeThKtaxaCdbBenefitCodeMappingReport;
//    this.userPrivilegeThKtaxaCdbBenefitMasterReport = userPrivilegeThKtaxaCdbBenefitMasterReport;
//    this.userPrivilegeThKtaxaCdbClaimHeaderReport = userPrivilegeThKtaxaCdbClaimHeaderReport;
//    this.userPrivilegeThKtaxaCdbClaimDetailDecisionReport = userPrivilegeThKtaxaCdbClaimDetailDecisionReport;
//    this.userPrivilegeThKtaxaCdbClaimDetailPaymentReport = userPrivilegeThKtaxaCdbClaimDetailPaymentReport;
//    this.userPrivilegeThKtaxaCdbPaymentDetailsReport = userPrivilegeThKtaxaCdbPaymentDetailsReport;
//    this.userPrivilegeThKtaxaCdbProductMasterReport = userPrivilegeThKtaxaCdbProductMasterReport;
//    this.userPrivilegeThAgiClaimHistoryForRenewalReport = userPrivilegeThAgiClaimHistoryForRenewalReport;
//    this.userPrivilegeThAgiSlaFaxClaimReport = userPrivilegeThAgiSlaFaxClaimReport;
//    this.userPrivilegeThAgiSlaCreditDirectClaimReport = userPrivilegeThAgiSlaCreditDirectClaimReport;
//    this.userPrivilegeThAgiInptDetailsReport = userPrivilegeThAgiInptDetailsReport;
//    this.userPrivilegeThAgiReceivedDateReport = userPrivilegeThAgiReceivedDateReport;
//    this.userPrivilegeThAgiClaimPaymentReport = userPrivilegeThAgiClaimPaymentReport;
//    this.userPrivilegeThAgiClaimRepaymentReport = userPrivilegeThAgiClaimRepaymentReport;
//    this.userPrivilegeThAgiFaxClaimSummaryReport = userPrivilegeThAgiFaxClaimSummaryReport;
//    this.userPrivilegeThAathSlaFaxClaimReport = userPrivilegeThAathSlaFaxClaimReport;
//    this.userPrivilegeThAathSlaPreCerRegisterReport = userPrivilegeThAathSlaPreCerRegisterReport;
//    this.userPrivilegeThAathC1ieReport = userPrivilegeThAathC1ieReport;
//    this.userPrivilegeFnAlimTextFileReport = userPrivilegeFnAlimTextFileReport;
//    this.userPrivilegeApiReqToken = userPrivilegeApiReqToken;
//    this.userPrivilegeApiChgPw = userPrivilegeApiChgPw;
//    this.userPrivilegeApiLostPw = userPrivilegeApiLostPw;
//    this.userPrivilegeApiSignUp = userPrivilegeApiSignUp;
//    this.userPrivilegeApiMemberInit = userPrivilegeApiMemberInit;
//    this.userPrivilegeApiReqInptPlan = userPrivilegeApiReqInptPlan;
//    this.userPrivilegeApiReqInptCase = userPrivilegeApiReqInptCase;
//    this.userPrivilegeApiReqInptCases = userPrivilegeApiReqInptCases;
//    this.userPrivilegeApiCreateInptCase = userPrivilegeApiCreateInptCase;
//    this.userPrivilegeApiReqOutptPlan = userPrivilegeApiReqOutptPlan;
//    this.userPrivilegeApiReqOutptClaim = userPrivilegeApiReqOutptClaim;
//    this.userPrivilegeApiReqOutptClaims = userPrivilegeApiReqOutptClaims;
//    this.userPrivilegeApiMemberValidate = userPrivilegeApiMemberValidate;
//    this.userPrivilegeApiClaimSubmit = userPrivilegeApiClaimSubmit;
//    this.userPrivilegeApiCreateOutptClaimDraft = userPrivilegeApiCreateOutptClaimDraft;
//    this.userPrivilegeApiSearchProvider = userPrivilegeApiSearchProvider;
//    this.userPrivilegeApiQrSearchProvider = userPrivilegeApiQrSearchProvider;
//    this.userPrivilegeApiReqCountry = userPrivilegeApiReqCountry;
//    this.userPrivilegeApiSubmitFeedback = userPrivilegeApiSubmitFeedback;
//    this.userPrivilegeApiReqHafStat = userPrivilegeApiReqHafStat;
//    this.userPrivilegeApiReqLog = userPrivilegeApiReqLog;
//    this.userPrivilegeApiReqImpp = userPrivilegeApiReqImpp;
//    this.userPrivilegeBencomKey = userPrivilegeBencomKey;
//    this.userPrivilegeBencom = userPrivilegeBencom;
//    this.userPrivilegeEclaimDocUpload = userPrivilegeEclaimDocUpload;
//    this.users = users;
// }
//
 @Id
 @GeneratedValue(strategy = IDENTITY)

 @Column(name = "userPrivilegeId", unique = true, nullable = false)
 public Integer getUserPrivilegeId() {
     return this.userPrivilegeId;
 }

 public void setUserPrivilegeId(Integer userPrivilegeId) {
     this.userPrivilegeId = userPrivilegeId;
 }

 @Column(name = "userPrivilegeCreatedBy")
 public Integer getUserPrivilegeCreatedBy() {
     return this.userPrivilegeCreatedBy;
 }

 public void setUserPrivilegeCreatedBy(Integer userPrivilegeCreatedBy) {
     this.userPrivilegeCreatedBy = userPrivilegeCreatedBy;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "userPrivilegeCreatedDate", length = 10)
 public Date getUserPrivilegeCreatedDate() {
     return this.userPrivilegeCreatedDate;
 }

 public void setUserPrivilegeCreatedDate(Date userPrivilegeCreatedDate) {
     this.userPrivilegeCreatedDate = userPrivilegeCreatedDate;
 }

 @Column(name = "userPrivilegeLastEdittedBy")
 public Integer getUserPrivilegeLastEdittedBy() {
     return this.userPrivilegeLastEdittedBy;
 }

 public void setUserPrivilegeLastEdittedBy(Integer userPrivilegeLastEdittedBy) {
     this.userPrivilegeLastEdittedBy = userPrivilegeLastEdittedBy;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "userPrivilegeLastEdittedDate", length = 10)
 public Date getUserPrivilegeLastEdittedDate() {
     return this.userPrivilegeLastEdittedDate;
 }

 public void setUserPrivilegeLastEdittedDate(Date userPrivilegeLastEdittedDate) {
     this.userPrivilegeLastEdittedDate = userPrivilegeLastEdittedDate;
 }

 @Column(name = "userPrivilegeName", length = 50)
 public String getUserPrivilegeName() {
     return this.userPrivilegeName;
 }

 public void setUserPrivilegeName(String userPrivilegeName) {
     this.userPrivilegeName = userPrivilegeName;
 }

 @Column(name = "userPrivilegeDescription", length = 250)
 public String getUserPrivilegeDescription() {
     return this.userPrivilegeDescription;
 }

 public void setUserPrivilegeDescription(String userPrivilegeDescription) {
     this.userPrivilegeDescription = userPrivilegeDescription;
 }

 @Column(name = "userPrivilegeInptCase")
 public Short getUserPrivilegeInptCase() {
     return this.userPrivilegeInptCase;
 }

 public void setUserPrivilegeInptCase(Short userPrivilegeInptCase) {
     this.userPrivilegeInptCase = userPrivilegeInptCase;
 }

 @Column(name = "userPrivilegeInptCaseMm", nullable = false)
 public short getUserPrivilegeInptCaseMm() {
     return this.userPrivilegeInptCaseMm;
 }

 public void setUserPrivilegeInptCaseMm(short userPrivilegeInptCaseMm) {
     this.userPrivilegeInptCaseMm = userPrivilegeInptCaseMm;
 }

 @Column(name = "userPrivilegeInptCaseProp", nullable = false)
 public short getUserPrivilegeInptCaseProp() {
     return this.userPrivilegeInptCaseProp;
 }

 public void setUserPrivilegeInptCaseProp(short userPrivilegeInptCaseProp) {
     this.userPrivilegeInptCaseProp = userPrivilegeInptCaseProp;
 }

 @Column(name = "userPrivilegeInptCaseHistory", nullable = false)
 public short getUserPrivilegeInptCaseHistory() {
     return this.userPrivilegeInptCaseHistory;
 }

 public void setUserPrivilegeInptCaseHistory(short userPrivilegeInptCaseHistory) {
     this.userPrivilegeInptCaseHistory = userPrivilegeInptCaseHistory;
 }

 @Column(name = "userPrivilegeInptCasePlanNotes", nullable = false)
 public short getUserPrivilegeInptCasePlanNotes() {
     return this.userPrivilegeInptCasePlanNotes;
 }

 public void setUserPrivilegeInptCasePlanNotes(short userPrivilegeInptCasePlanNotes) {
     this.userPrivilegeInptCasePlanNotes = userPrivilegeInptCasePlanNotes;
 }

 @Column(name = "userPrivilegeInptCasePolMvnt", nullable = false)
 public short getUserPrivilegeInptCasePolMvnt() {
     return this.userPrivilegeInptCasePolMvnt;
 }

 public void setUserPrivilegeInptCasePolMvnt(short userPrivilegeInptCasePolMvnt) {
     this.userPrivilegeInptCasePolMvnt = userPrivilegeInptCasePolMvnt;
 }

 @Column(name = "userPrivilegeInptCaseAdm", nullable = false)
 public short getUserPrivilegeInptCaseAdm() {
     return this.userPrivilegeInptCaseAdm;
 }

 public void setUserPrivilegeInptCaseAdm(short userPrivilegeInptCaseAdm) {
     this.userPrivilegeInptCaseAdm = userPrivilegeInptCaseAdm;
 }

 @Column(name = "userPrivilegeInptCaseDisc", nullable = false)
 public short getUserPrivilegeInptCaseDisc() {
     return this.userPrivilegeInptCaseDisc;
 }

 public void setUserPrivilegeInptCaseDisc(short userPrivilegeInptCaseDisc) {
     this.userPrivilegeInptCaseDisc = userPrivilegeInptCaseDisc;
 }

 @Column(name = "userPrivilegeInptCaseCalcs", nullable = false)
 public short getUserPrivilegeInptCaseCalcs() {
     return this.userPrivilegeInptCaseCalcs;
 }

 public void setUserPrivilegeInptCaseCalcs(short userPrivilegeInptCaseCalcs) {
     this.userPrivilegeInptCaseCalcs = userPrivilegeInptCaseCalcs;
 }

 @Column(name = "userPrivilegeInptCaseWs", nullable = false)
 public short getUserPrivilegeInptCaseWs() {
     return this.userPrivilegeInptCaseWs;
 }

 public void setUserPrivilegeInptCaseWs(short userPrivilegeInptCaseWs) {
     this.userPrivilegeInptCaseWs = userPrivilegeInptCaseWs;
 }

 @Column(name = "userPrivilegeInptCasePhLog", nullable = false)
 public short getUserPrivilegeInptCasePhLog() {
     return this.userPrivilegeInptCasePhLog;
 }

 public void setUserPrivilegeInptCasePhLog(short userPrivilegeInptCasePhLog) {
     this.userPrivilegeInptCasePhLog = userPrivilegeInptCasePhLog;
 }

 @Column(name = "userPrivilegeInptCaseDoc", nullable = false)
 public short getUserPrivilegeInptCaseDoc() {
     return this.userPrivilegeInptCaseDoc;
 }

 public void setUserPrivilegeInptCaseDoc(short userPrivilegeInptCaseDoc) {
     this.userPrivilegeInptCaseDoc = userPrivilegeInptCaseDoc;
 }

 @Column(name = "userPrivilegeInptCaseAppv", nullable = false)
 public short getUserPrivilegeInptCaseAppv() {
     return this.userPrivilegeInptCaseAppv;
 }

 public void setUserPrivilegeInptCaseAppv(short userPrivilegeInptCaseAppv) {
     this.userPrivilegeInptCaseAppv = userPrivilegeInptCaseAppv;
 }

 @Column(name = "userPrivilegeInptCaseImg", nullable = false)
 public short getUserPrivilegeInptCaseImg() {
     return this.userPrivilegeInptCaseImg;
 }

 public void setUserPrivilegeInptCaseImg(short userPrivilegeInptCaseImg) {
     this.userPrivilegeInptCaseImg = userPrivilegeInptCaseImg;
 }

 @Column(name = "userPrivilegeInptCaseCostCU", nullable = false)
 public short getUserPrivilegeInptCaseCostCu() {
     return this.userPrivilegeInptCaseCostCu;
 }

 public void setUserPrivilegeInptCaseCostCu(short userPrivilegeInptCaseCostCu) {
     this.userPrivilegeInptCaseCostCu = userPrivilegeInptCaseCostCu;
 }

 @Column(name = "userPrivilegeInptCaseCaseNote", nullable = false)
 public short getUserPrivilegeInptCaseCaseNote() {
     return this.userPrivilegeInptCaseCaseNote;
 }

 public void setUserPrivilegeInptCaseCaseNote(short userPrivilegeInptCaseCaseNote) {
     this.userPrivilegeInptCaseCaseNote = userPrivilegeInptCaseCaseNote;
 }

 @Column(name = "userPrivilegeInptCaseAcc", nullable = false)
 public short getUserPrivilegeInptCaseAcc() {
     return this.userPrivilegeInptCaseAcc;
 }

 public void setUserPrivilegeInptCaseAcc(short userPrivilegeInptCaseAcc) {
     this.userPrivilegeInptCaseAcc = userPrivilegeInptCaseAcc;
 }

 @Column(name = "userPrivilegeInptCaseReminder", nullable = false)
 public short getUserPrivilegeInptCaseReminder() {
     return this.userPrivilegeInptCaseReminder;
 }

 public void setUserPrivilegeInptCaseReminder(short userPrivilegeInptCaseReminder) {
     this.userPrivilegeInptCaseReminder = userPrivilegeInptCaseReminder;
 }

 @Column(name = "userPrivilegeInptCaseTodo", nullable = false)
 public short getUserPrivilegeInptCaseTodo() {
     return this.userPrivilegeInptCaseTodo;
 }

 public void setUserPrivilegeInptCaseTodo(short userPrivilegeInptCaseTodo) {
     this.userPrivilegeInptCaseTodo = userPrivilegeInptCaseTodo;
 }

 @Column(name = "userPrivilegeInptCaseExt")
 public Short getUserPrivilegeInptCaseExt() {
     return this.userPrivilegeInptCaseExt;
 }

 public void setUserPrivilegeInptCaseExt(Short userPrivilegeInptCaseExt) {
     this.userPrivilegeInptCaseExt = userPrivilegeInptCaseExt;
 }

 @Column(name = "userPrivilegeInptCaseTriage", nullable = false)
 public short getUserPrivilegeInptCaseTriage() {
     return this.userPrivilegeInptCaseTriage;
 }

 public void setUserPrivilegeInptCaseTriage(short userPrivilegeInptCaseTriage) {
     this.userPrivilegeInptCaseTriage = userPrivilegeInptCaseTriage;
 }

 @Column(name = "userPrivilegeCcmCase", nullable = false)
 public short getUserPrivilegeCcmCase() {
     return this.userPrivilegeCcmCase;
 }

 public void setUserPrivilegeCcmCase(short userPrivilegeCcmCase) {
     this.userPrivilegeCcmCase = userPrivilegeCcmCase;
 }

 @Column(name = "userPrivilegeCcmCaseInpt", nullable = false)
 public short getUserPrivilegeCcmCaseInpt() {
     return this.userPrivilegeCcmCaseInpt;
 }

 public void setUserPrivilegeCcmCaseInpt(short userPrivilegeCcmCaseInpt) {
     this.userPrivilegeCcmCaseInpt = userPrivilegeCcmCaseInpt;
 }

 @Column(name = "userPrivilegeCcmCaseOutpt", nullable = false)
 public short getUserPrivilegeCcmCaseOutpt() {
     return this.userPrivilegeCcmCaseOutpt;
 }

 public void setUserPrivilegeCcmCaseOutpt(short userPrivilegeCcmCaseOutpt) {
     this.userPrivilegeCcmCaseOutpt = userPrivilegeCcmCaseOutpt;
 }

 @Column(name = "userPrivilegeAnnounce")
 public Short getUserPrivilegeAnnounce() {
     return this.userPrivilegeAnnounce;
 }

 public void setUserPrivilegeAnnounce(Short userPrivilegeAnnounce) {
     this.userPrivilegeAnnounce = userPrivilegeAnnounce;
 }

 @Column(name = "userPrivilegeClient", nullable = false)
 public short getUserPrivilegeClient() {
     return this.userPrivilegeClient;
 }

 public void setUserPrivilegeClient(short userPrivilegeClient) {
     this.userPrivilegeClient = userPrivilegeClient;
 }

 @Column(name = "userPrivilegeBank", nullable = false)
 public short getUserPrivilegeBank() {
     return this.userPrivilegeBank;
 }

 public void setUserPrivilegeBank(short userPrivilegeBank) {
     this.userPrivilegeBank = userPrivilegeBank;
 }

 @Column(name = "userPrivilegeServices", nullable = false)
 public short getUserPrivilegeServices() {
     return this.userPrivilegeServices;
 }

 public void setUserPrivilegeServices(short userPrivilegeServices) {
     this.userPrivilegeServices = userPrivilegeServices;
 }

 @Column(name = "userPrivilegeProgram", nullable = false)
 public short getUserPrivilegeProgram() {
     return this.userPrivilegeProgram;
 }

 public void setUserPrivilegeProgram(short userPrivilegeProgram) {
     this.userPrivilegeProgram = userPrivilegeProgram;
 }

 @Column(name = "userPrivilegeBillingProfile", nullable = false)
 public short getUserPrivilegeBillingProfile() {
     return this.userPrivilegeBillingProfile;
 }

 public void setUserPrivilegeBillingProfile(short userPrivilegeBillingProfile) {
     this.userPrivilegeBillingProfile = userPrivilegeBillingProfile;
 }

 @Column(name = "userPrivilegeAccountProfile", nullable = false)
 public short getUserPrivilegeAccountProfile() {
     return this.userPrivilegeAccountProfile;
 }

 public void setUserPrivilegeAccountProfile(short userPrivilegeAccountProfile) {
     this.userPrivilegeAccountProfile = userPrivilegeAccountProfile;
 }

 @Column(name = "userPrivilegeInptPlan", nullable = false)
 public short getUserPrivilegeInptPlan() {
     return this.userPrivilegeInptPlan;
 }

 public void setUserPrivilegeInptPlan(short userPrivilegeInptPlan) {
     this.userPrivilegeInptPlan = userPrivilegeInptPlan;
 }

 @Column(name = "userPrivilegeInptPolicy", nullable = false)
 public short getUserPrivilegeInptPolicy() {
     return this.userPrivilegeInptPolicy;
 }

 public void setUserPrivilegeInptPolicy(short userPrivilegeInptPolicy) {
     this.userPrivilegeInptPolicy = userPrivilegeInptPolicy;
 }

 @Column(name = "userPrivilegeMedPrv", nullable = false)
 public short getUserPrivilegeMedPrv() {
     return this.userPrivilegeMedPrv;
 }

 public void setUserPrivilegeMedPrv(short userPrivilegeMedPrv) {
     this.userPrivilegeMedPrv = userPrivilegeMedPrv;
 }

 @Column(name = "userPrivilegeMedPrvPanel", nullable = false)
 public short getUserPrivilegeMedPrvPanel() {
     return this.userPrivilegeMedPrvPanel;
 }

 public void setUserPrivilegeMedPrvPanel(short userPrivilegeMedPrvPanel) {
     this.userPrivilegeMedPrvPanel = userPrivilegeMedPrvPanel;
 }

 @Column(name = "userPrivilegeWsCat", nullable = false)
 public short getUserPrivilegeWsCat() {
     return this.userPrivilegeWsCat;
 }

 public void setUserPrivilegeWsCat(short userPrivilegeWsCat) {
     this.userPrivilegeWsCat = userPrivilegeWsCat;
 }

 @Column(name = "userPrivilegeWsTemp", nullable = false)
 public short getUserPrivilegeWsTemp() {
     return this.userPrivilegeWsTemp;
 }

 public void setUserPrivilegeWsTemp(short userPrivilegeWsTemp) {
     this.userPrivilegeWsTemp = userPrivilegeWsTemp;
 }

 @Column(name = "userPrivilegeWsItems", nullable = false)
 public short getUserPrivilegeWsItems() {
     return this.userPrivilegeWsItems;
 }

 public void setUserPrivilegeWsItems(short userPrivilegeWsItems) {
     this.userPrivilegeWsItems = userPrivilegeWsItems;
 }

 @Column(name = "userPrivilegeDr", nullable = false)
 public short getUserPrivilegeDr() {
     return this.userPrivilegeDr;
 }

 public void setUserPrivilegeDr(short userPrivilegeDr) {
     this.userPrivilegeDr = userPrivilegeDr;
 }

 @Column(name = "userPrivilegeDrSpec", nullable = false)
 public short getUserPrivilegeDrSpec() {
     return this.userPrivilegeDrSpec;
 }

 public void setUserPrivilegeDrSpec(short userPrivilegeDrSpec) {
     this.userPrivilegeDrSpec = userPrivilegeDrSpec;
 }

 @Column(name = "userPrivilegeMemberInvitationRoot", nullable = false)
 public short getUserPrivilegeMemberInvitationRoot() {
     return this.userPrivilegeMemberInvitationRoot;
 }

 public void setUserPrivilegeMemberInvitationRoot(short userPrivilegeMemberInvitationRoot) {
     this.userPrivilegeMemberInvitationRoot = userPrivilegeMemberInvitationRoot;
 }

 @Column(name = "userPrivilegeMemberInvitationAdmin", nullable = false)
 public short getUserPrivilegeMemberInvitationAdmin() {
     return this.userPrivilegeMemberInvitationAdmin;
 }

 public void setUserPrivilegeMemberInvitationAdmin(short userPrivilegeMemberInvitationAdmin) {
     this.userPrivilegeMemberInvitationAdmin = userPrivilegeMemberInvitationAdmin;
 }

 @Column(name = "userPrivilegeMember", nullable = false)
 public short getUserPrivilegeMember() {
     return this.userPrivilegeMember;
 }

 public void setUserPrivilegeMember(short userPrivilegeMember) {
     this.userPrivilegeMember = userPrivilegeMember;
 }

 @Column(name = "userPrivilegeMemberInpt", nullable = false)
 public short getUserPrivilegeMemberInpt() {
     return this.userPrivilegeMemberInpt;
 }

 public void setUserPrivilegeMemberInpt(short userPrivilegeMemberInpt) {
     this.userPrivilegeMemberInpt = userPrivilegeMemberInpt;
 }

 @Column(name = "userPrivilegeMemberOutpt", nullable = false)
 public short getUserPrivilegeMemberOutpt() {
     return this.userPrivilegeMemberOutpt;
 }

 public void setUserPrivilegeMemberOutpt(short userPrivilegeMemberOutpt) {
     this.userPrivilegeMemberOutpt = userPrivilegeMemberOutpt;
 }

 @Column(name = "userPrivilegeDiagnosis", nullable = false)
 public short getUserPrivilegeDiagnosis() {
     return this.userPrivilegeDiagnosis;
 }

 public void setUserPrivilegeDiagnosis(short userPrivilegeDiagnosis) {
     this.userPrivilegeDiagnosis = userPrivilegeDiagnosis;
 }

 @Column(name = "userPrivilegeDrug", nullable = false)
 public short getUserPrivilegeDrug() {
     return this.userPrivilegeDrug;
 }

 public void setUserPrivilegeDrug(short userPrivilegeDrug) {
     this.userPrivilegeDrug = userPrivilegeDrug;
 }

 @Column(name = "userPrivilegeSymptom", nullable = false)
 public short getUserPrivilegeSymptom() {
     return this.userPrivilegeSymptom;
 }

 public void setUserPrivilegeSymptom(short userPrivilegeSymptom) {
     this.userPrivilegeSymptom = userPrivilegeSymptom;
 }

 @Column(name = "userPrivilegeDashboard", nullable = false)
 public short getUserPrivilegeDashboard() {
     return this.userPrivilegeDashboard;
 }

 public void setUserPrivilegeDashboard(short userPrivilegeDashboard) {
     this.userPrivilegeDashboard = userPrivilegeDashboard;
 }

 @Column(name = "userPrivilegeSurgSchedule", nullable = false)
 public short getUserPrivilegeSurgSchedule() {
     return this.userPrivilegeSurgSchedule;
 }

 public void setUserPrivilegeSurgSchedule(short userPrivilegeSurgSchedule) {
     this.userPrivilegeSurgSchedule = userPrivilegeSurgSchedule;
 }

 @Column(name = "userPrivilegeDocTemp", nullable = false)
 public short getUserPrivilegeDocTemp() {
     return this.userPrivilegeDocTemp;
 }

 public void setUserPrivilegeDocTemp(short userPrivilegeDocTemp) {
     this.userPrivilegeDocTemp = userPrivilegeDocTemp;
 }

 @Column(name = "userPrivilegeBdx", nullable = false)
 public short getUserPrivilegeBdx() {
     return this.userPrivilegeBdx;
 }

 public void setUserPrivilegeBdx(short userPrivilegeBdx) {
     this.userPrivilegeBdx = userPrivilegeBdx;
 }

 @Column(name = "userPrivilegeImport", nullable = false)
 public short getUserPrivilegeImport() {
     return this.userPrivilegeImport;
 }

 public void setUserPrivilegeImport(short userPrivilegeImport) {
     this.userPrivilegeImport = userPrivilegeImport;
 }

 @Column(name = "userPrivilegeAppointmentBooking", nullable = false)
 public short getUserPrivilegeAppointmentBooking() {
     return this.userPrivilegeAppointmentBooking;
 }

 public void setUserPrivilegeAppointmentBooking(short userPrivilegeAppointmentBooking) {
     this.userPrivilegeAppointmentBooking = userPrivilegeAppointmentBooking;
 }

 @Column(name = "userPrivilegeUser", nullable = false)
 public short getUserPrivilegeUser() {
     return this.userPrivilegeUser;
 }

 public void setUserPrivilegeUser(short userPrivilegeUser) {
     this.userPrivilegeUser = userPrivilegeUser;
 }

 @Column(name = "userPrivilegeUserPrivilege", nullable = false)
 public short getUserPrivilegeUserPrivilege() {
     return this.userPrivilegeUserPrivilege;
 }

 public void setUserPrivilegeUserPrivilege(short userPrivilegeUserPrivilege) {
     this.userPrivilegeUserPrivilege = userPrivilegeUserPrivilege;
 }

 @Column(name = "userPrivilegeUserApiPrivilege", nullable = false)
 public short getUserPrivilegeUserApiPrivilege() {
     return this.userPrivilegeUserApiPrivilege;
 }

 public void setUserPrivilegeUserApiPrivilege(short userPrivilegeUserApiPrivilege) {
     this.userPrivilegeUserApiPrivilege = userPrivilegeUserApiPrivilege;
 }

 @Column(name = "userPrivilegeUserClient", nullable = false)
 public short getUserPrivilegeUserClient() {
     return this.userPrivilegeUserClient;
 }

 public void setUserPrivilegeUserClient(short userPrivilegeUserClient) {
     this.userPrivilegeUserClient = userPrivilegeUserClient;
 }

 @Column(name = "userPrivilegeUserDept", nullable = false)
 public short getUserPrivilegeUserDept() {
     return this.userPrivilegeUserDept;
 }

 public void setUserPrivilegeUserDept(short userPrivilegeUserDept) {
     this.userPrivilegeUserDept = userPrivilegeUserDept;
 }

 @Column(name = "userPrivilegeUserHospital", nullable = false)
 public short getUserPrivilegeUserHospital() {
     return this.userPrivilegeUserHospital;
 }

 public void setUserPrivilegeUserHospital(short userPrivilegeUserHospital) {
     this.userPrivilegeUserHospital = userPrivilegeUserHospital;
 }

 @Column(name = "userPrivilegeUserApi", nullable = false)
 public short getUserPrivilegeUserApi() {
     return this.userPrivilegeUserApi;
 }

 public void setUserPrivilegeUserApi(short userPrivilegeUserApi) {
     this.userPrivilegeUserApi = userPrivilegeUserApi;
 }

 @Column(name = "userPrivilegeDocSpeAutho", nullable = false)
 public short getUserPrivilegeDocSpeAutho() {
     return this.userPrivilegeDocSpeAutho;
 }

 public void setUserPrivilegeDocSpeAutho(short userPrivilegeDocSpeAutho) {
     this.userPrivilegeDocSpeAutho = userPrivilegeDocSpeAutho;
 }

 @Column(name = "userPrivilegeIftttRule", nullable = false)
 public short getUserPrivilegeIftttRule() {
     return this.userPrivilegeIftttRule;
 }

 public void setUserPrivilegeIftttRule(short userPrivilegeIftttRule) {
     this.userPrivilegeIftttRule = userPrivilegeIftttRule;
 }

 @Column(name = "userPrivilegeIftttField", nullable = false)
 public short getUserPrivilegeIftttField() {
     return this.userPrivilegeIftttField;
 }

 public void setUserPrivilegeIftttField(short userPrivilegeIftttField) {
     this.userPrivilegeIftttField = userPrivilegeIftttField;
 }

 @Column(name = "userPrivilegeCsuCases", nullable = false)
 public short getUserPrivilegeCsuCases() {
     return this.userPrivilegeCsuCases;
 }

 public void setUserPrivilegeCsuCases(short userPrivilegeCsuCases) {
     this.userPrivilegeCsuCases = userPrivilegeCsuCases;
 }

 @Column(name = "userPrivilegeClaimGuidelines", nullable = false)
 public short getUserPrivilegeClaimGuidelines() {
     return this.userPrivilegeClaimGuidelines;
 }

 public void setUserPrivilegeClaimGuidelines(short userPrivilegeClaimGuidelines) {
     this.userPrivilegeClaimGuidelines = userPrivilegeClaimGuidelines;
 }

 @Column(name = "userPrivilegePolicyJacket", nullable = false)
 public short getUserPrivilegePolicyJacket() {
     return this.userPrivilegePolicyJacket;
 }

 public void setUserPrivilegePolicyJacket(short userPrivilegePolicyJacket) {
     this.userPrivilegePolicyJacket = userPrivilegePolicyJacket;
 }

 @Column(name = "userPrivilegeInptBillRegistration", nullable = false)
 public short getUserPrivilegeInptBillRegistration() {
     return this.userPrivilegeInptBillRegistration;
 }

 public void setUserPrivilegeInptBillRegistration(short userPrivilegeInptBillRegistration) {
     this.userPrivilegeInptBillRegistration = userPrivilegeInptBillRegistration;
 }

 @Column(name = "userPrivilegeOutptBillRegistration", nullable = false)
 public short getUserPrivilegeOutptBillRegistration() {
     return this.userPrivilegeOutptBillRegistration;
 }

 public void setUserPrivilegeOutptBillRegistration(short userPrivilegeOutptBillRegistration) {
     this.userPrivilegeOutptBillRegistration = userPrivilegeOutptBillRegistration;
 }

 @Column(name = "userPrivilegeWorksheet", nullable = false)
 public short getUserPrivilegeWorksheet() {
     return this.userPrivilegeWorksheet;
 }

 public void setUserPrivilegeWorksheet(short userPrivilegeWorksheet) {
     this.userPrivilegeWorksheet = userPrivilegeWorksheet;
 }

 @Column(name = "userPrivilegeIpWhitelist", nullable = false)
 public short getUserPrivilegeIpWhitelist() {
     return this.userPrivilegeIpWhitelist;
 }

 public void setUserPrivilegeIpWhitelist(short userPrivilegeIpWhitelist) {
     this.userPrivilegeIpWhitelist = userPrivilegeIpWhitelist;
 }

 @Column(name = "userPrivilegeInptCaseType", nullable = false)
 public short getUserPrivilegeInptCaseType() {
     return this.userPrivilegeInptCaseType;
 }

 public void setUserPrivilegeInptCaseType(short userPrivilegeInptCaseType) {
     this.userPrivilegeInptCaseType = userPrivilegeInptCaseType;
 }

 @Column(name = "userPrivilegeInptCaseRejectType", nullable = false)
 public short getUserPrivilegeInptCaseRejectType() {
     return this.userPrivilegeInptCaseRejectType;
 }

 public void setUserPrivilegeInptCaseRejectType(short userPrivilegeInptCaseRejectType) {
     this.userPrivilegeInptCaseRejectType = userPrivilegeInptCaseRejectType;
 }

 @Column(name = "userPrivilegeOutptBenefit", nullable = false)
 public short getUserPrivilegeOutptBenefit() {
     return this.userPrivilegeOutptBenefit;
 }

 public void setUserPrivilegeOutptBenefit(short userPrivilegeOutptBenefit) {
     this.userPrivilegeOutptBenefit = userPrivilegeOutptBenefit;
 }

 @Column(name = "userPrivilegeOutptItem", nullable = false)
 public short getUserPrivilegeOutptItem() {
     return this.userPrivilegeOutptItem;
 }

 public void setUserPrivilegeOutptItem(short userPrivilegeOutptItem) {
     this.userPrivilegeOutptItem = userPrivilegeOutptItem;
 }

 @Column(name = "userPrivilegeOutptPlan", nullable = false)
 public short getUserPrivilegeOutptPlan() {
     return this.userPrivilegeOutptPlan;
 }

 public void setUserPrivilegeOutptPlan(short userPrivilegeOutptPlan) {
     this.userPrivilegeOutptPlan = userPrivilegeOutptPlan;
 }

 @Column(name = "userPrivilegeOutptMember", nullable = false)
 public short getUserPrivilegeOutptMember() {
     return this.userPrivilegeOutptMember;
 }

 public void setUserPrivilegeOutptMember(short userPrivilegeOutptMember) {
     this.userPrivilegeOutptMember = userPrivilegeOutptMember;
 }

 @Column(name = "userPrivilegeOutptClaim", nullable = false)
 public short getUserPrivilegeOutptClaim() {
     return this.userPrivilegeOutptClaim;
 }

 public void setUserPrivilegeOutptClaim(short userPrivilegeOutptClaim) {
     this.userPrivilegeOutptClaim = userPrivilegeOutptClaim;
 }

 @Column(name = "userPrivilegeOutptClaimLog", nullable = false)
 public short getUserPrivilegeOutptClaimLog() {
     return this.userPrivilegeOutptClaimLog;
 }

 public void setUserPrivilegeOutptClaimLog(short userPrivilegeOutptClaimLog) {
     this.userPrivilegeOutptClaimLog = userPrivilegeOutptClaimLog;
 }

 @Column(name = "userPrivilegeOutptClaimDoc", nullable = false)
 public short getUserPrivilegeOutptClaimDoc() {
     return this.userPrivilegeOutptClaimDoc;
 }

 public void setUserPrivilegeOutptClaimDoc(short userPrivilegeOutptClaimDoc) {
     this.userPrivilegeOutptClaimDoc = userPrivilegeOutptClaimDoc;
 }

 @Column(name = "userPrivilegeOutptClaimImg", nullable = false)
 public short getUserPrivilegeOutptClaimImg() {
     return this.userPrivilegeOutptClaimImg;
 }

 public void setUserPrivilegeOutptClaimImg(short userPrivilegeOutptClaimImg) {
     this.userPrivilegeOutptClaimImg = userPrivilegeOutptClaimImg;
 }

 @Column(name = "userPrivilegeOutptClaimReminders", nullable = false)
 public short getUserPrivilegeOutptClaimReminders() {
     return this.userPrivilegeOutptClaimReminders;
 }

 public void setUserPrivilegeOutptClaimReminders(short userPrivilegeOutptClaimReminders) {
     this.userPrivilegeOutptClaimReminders = userPrivilegeOutptClaimReminders;
 }

 @Column(name = "userPrivilegeOutptClaimCba", nullable = false)
 public short getUserPrivilegeOutptClaimCba() {
     return this.userPrivilegeOutptClaimCba;
 }

 public void setUserPrivilegeOutptClaimCba(short userPrivilegeOutptClaimCba) {
     this.userPrivilegeOutptClaimCba = userPrivilegeOutptClaimCba;
 }

 @Column(name = "userPrivilegeOutptClaimHistory", nullable = false)
 public short getUserPrivilegeOutptClaimHistory() {
     return this.userPrivilegeOutptClaimHistory;
 }

 public void setUserPrivilegeOutptClaimHistory(short userPrivilegeOutptClaimHistory) {
     this.userPrivilegeOutptClaimHistory = userPrivilegeOutptClaimHistory;
 }

 @Column(name = "userPrivilegeOutptClaimFwa", nullable = false)
 public short getUserPrivilegeOutptClaimFwa() {
     return this.userPrivilegeOutptClaimFwa;
 }

 public void setUserPrivilegeOutptClaimFwa(short userPrivilegeOutptClaimFwa) {
     this.userPrivilegeOutptClaimFwa = userPrivilegeOutptClaimFwa;
 }

 @Column(name = "userPrivilegeOutptClaimGeneralAdmin", nullable = false)
 public short getUserPrivilegeOutptClaimGeneralAdmin() {
     return this.userPrivilegeOutptClaimGeneralAdmin;
 }

 public void setUserPrivilegeOutptClaimGeneralAdmin(short userPrivilegeOutptClaimGeneralAdmin) {
     this.userPrivilegeOutptClaimGeneralAdmin = userPrivilegeOutptClaimGeneralAdmin;
 }

 @Column(name = "userPrivilegeOutptClaimPayAdv", nullable = false)
 public short getUserPrivilegeOutptClaimPayAdv() {
     return this.userPrivilegeOutptClaimPayAdv;
 }

 public void setUserPrivilegeOutptClaimPayAdv(short userPrivilegeOutptClaimPayAdv) {
     this.userPrivilegeOutptClaimPayAdv = userPrivilegeOutptClaimPayAdv;
 }

 @Column(name = "userPrivilegeOutptClaimTriage", nullable = false)
 public short getUserPrivilegeOutptClaimTriage() {
     return this.userPrivilegeOutptClaimTriage;
 }

 public void setUserPrivilegeOutptClaimTriage(short userPrivilegeOutptClaimTriage) {
     this.userPrivilegeOutptClaimTriage = userPrivilegeOutptClaimTriage;
 }

 @Column(name = "userPrivilegeOutptStatus", nullable = false)
 public short getUserPrivilegeOutptStatus() {
     return this.userPrivilegeOutptStatus;
 }

 public void setUserPrivilegeOutptStatus(short userPrivilegeOutptStatus) {
     this.userPrivilegeOutptStatus = userPrivilegeOutptStatus;
 }

 @Column(name = "userPrivilegeOutptAutoAdj", nullable = false)
 public short getUserPrivilegeOutptAutoAdj() {
     return this.userPrivilegeOutptAutoAdj;
 }

 public void setUserPrivilegeOutptAutoAdj(short userPrivilegeOutptAutoAdj) {
     this.userPrivilegeOutptAutoAdj = userPrivilegeOutptAutoAdj;
 }

 @Column(name = "userPrivilegeOutptBdx", nullable = false)
 public short getUserPrivilegeOutptBdx() {
     return this.userPrivilegeOutptBdx;
 }

 public void setUserPrivilegeOutptBdx(short userPrivilegeOutptBdx) {
     this.userPrivilegeOutptBdx = userPrivilegeOutptBdx;
 }

 @Column(name = "userPrivilegeOutptPayAdv", nullable = false)
 public short getUserPrivilegeOutptPayAdv() {
     return this.userPrivilegeOutptPayAdv;
 }

 public void setUserPrivilegeOutptPayAdv(short userPrivilegeOutptPayAdv) {
     this.userPrivilegeOutptPayAdv = userPrivilegeOutptPayAdv;
 }

 @Column(name = "userPrivilegeOutptInvestigation", nullable = false)
 public short getUserPrivilegeOutptInvestigation() {
     return this.userPrivilegeOutptInvestigation;
 }

 public void setUserPrivilegeOutptInvestigation(short userPrivilegeOutptInvestigation) {
     this.userPrivilegeOutptInvestigation = userPrivilegeOutptInvestigation;
 }

 @Column(name = "userPrivilegeFileRepo", nullable = false)
 public short getUserPrivilegeFileRepo() {
     return this.userPrivilegeFileRepo;
 }

 public void setUserPrivilegeFileRepo(short userPrivilegeFileRepo) {
     this.userPrivilegeFileRepo = userPrivilegeFileRepo;
 }

 @Column(name = "userPrivilegeEaDashboard", nullable = false)
 public short getUserPrivilegeEaDashboard() {
     return this.userPrivilegeEaDashboard;
 }

 public void setUserPrivilegeEaDashboard(short userPrivilegeEaDashboard) {
     this.userPrivilegeEaDashboard = userPrivilegeEaDashboard;
 }

 @Column(name = "userPrivilegeEaMember", nullable = false)
 public short getUserPrivilegeEaMember() {
     return this.userPrivilegeEaMember;
 }

 public void setUserPrivilegeEaMember(short userPrivilegeEaMember) {
     this.userPrivilegeEaMember = userPrivilegeEaMember;
 }

 @Column(name = "userPrivilegeEaCases", nullable = false)
 public short getUserPrivilegeEaCases() {
     return this.userPrivilegeEaCases;
 }

 public void setUserPrivilegeEaCases(short userPrivilegeEaCases) {
     this.userPrivilegeEaCases = userPrivilegeEaCases;
 }

 @Column(name = "userPrivilegeEaAnnounce", nullable = false)
 public short getUserPrivilegeEaAnnounce() {
     return this.userPrivilegeEaAnnounce;
 }

 public void setUserPrivilegeEaAnnounce(short userPrivilegeEaAnnounce) {
     this.userPrivilegeEaAnnounce = userPrivilegeEaAnnounce;
 }

 @Column(name = "userPrivilegeEclientAllowImpersonation", nullable = false)
 public short getUserPrivilegeEclientAllowImpersonation() {
     return this.userPrivilegeEclientAllowImpersonation;
 }

 public void setUserPrivilegeEclientAllowImpersonation(short userPrivilegeEclientAllowImpersonation) {
     this.userPrivilegeEclientAllowImpersonation = userPrivilegeEclientAllowImpersonation;
 }

 @Column(name = "userPrivilegeEclientDashboard", nullable = false)
 public short getUserPrivilegeEclientDashboard() {
     return this.userPrivilegeEclientDashboard;
 }

 public void setUserPrivilegeEclientDashboard(short userPrivilegeEclientDashboard) {
     this.userPrivilegeEclientDashboard = userPrivilegeEclientDashboard;
 }

 @Column(name = "userPrivilegeEclientInptCase", nullable = false)
 public short getUserPrivilegeEclientInptCase() {
     return this.userPrivilegeEclientInptCase;
 }

 public void setUserPrivilegeEclientInptCase(short userPrivilegeEclientInptCase) {
     this.userPrivilegeEclientInptCase = userPrivilegeEclientInptCase;
 }

 @Column(name = "userPrivilegeEclientInptIncludeOutpt", nullable = false)
 public short getUserPrivilegeEclientInptIncludeOutpt() {
     return this.userPrivilegeEclientInptIncludeOutpt;
 }

 public void setUserPrivilegeEclientInptIncludeOutpt(short userPrivilegeEclientInptIncludeOutpt) {
     this.userPrivilegeEclientInptIncludeOutpt = userPrivilegeEclientInptIncludeOutpt;
 }

 @Column(name = "userPrivilegeEclientInptShowMedicalInfo", nullable = false)
 public short getUserPrivilegeEclientInptShowMedicalInfo() {
     return this.userPrivilegeEclientInptShowMedicalInfo;
 }

 public void setUserPrivilegeEclientInptShowMedicalInfo(short userPrivilegeEclientInptShowMedicalInfo) {
     this.userPrivilegeEclientInptShowMedicalInfo = userPrivilegeEclientInptShowMedicalInfo;
 }

 @Column(name = "userPrivilegeEclientInptShowPruPlan", nullable = false)
 public short getUserPrivilegeEclientInptShowPruPlan() {
     return this.userPrivilegeEclientInptShowPruPlan;
 }

 public void setUserPrivilegeEclientInptShowPruPlan(short userPrivilegeEclientInptShowPruPlan) {
     this.userPrivilegeEclientInptShowPruPlan = userPrivilegeEclientInptShowPruPlan;
 }

 @Column(name = "userPrivilegeEclientInptExternalCase", nullable = false)
 public short getUserPrivilegeEclientInptExternalCase() {
     return this.userPrivilegeEclientInptExternalCase;
 }

 public void setUserPrivilegeEclientInptExternalCase(short userPrivilegeEclientInptExternalCase) {
     this.userPrivilegeEclientInptExternalCase = userPrivilegeEclientInptExternalCase;
 }

 @Column(name = "userPrivilegeEclientInptMember", nullable = false)
 public short getUserPrivilegeEclientInptMember() {
     return this.userPrivilegeEclientInptMember;
 }

 public void setUserPrivilegeEclientInptMember(short userPrivilegeEclientInptMember) {
     this.userPrivilegeEclientInptMember = userPrivilegeEclientInptMember;
 }

 @Column(name = "userPrivilegeEclientInptUtilReport", nullable = false)
 public short getUserPrivilegeEclientInptUtilReport() {
     return this.userPrivilegeEclientInptUtilReport;
 }

 public void setUserPrivilegeEclientInptUtilReport(short userPrivilegeEclientInptUtilReport) {
     this.userPrivilegeEclientInptUtilReport = userPrivilegeEclientInptUtilReport;
 }

 @Column(name = "userPrivilegeEclientInptCaseAdm", nullable = false)
 public short getUserPrivilegeEclientInptCaseAdm() {
     return this.userPrivilegeEclientInptCaseAdm;
 }

 public void setUserPrivilegeEclientInptCaseAdm(short userPrivilegeEclientInptCaseAdm) {
     this.userPrivilegeEclientInptCaseAdm = userPrivilegeEclientInptCaseAdm;
 }

 @Column(name = "userPrivilegeEclientInptCaseMember", nullable = false)
 public short getUserPrivilegeEclientInptCaseMember() {
     return this.userPrivilegeEclientInptCaseMember;
 }

 public void setUserPrivilegeEclientInptCaseMember(short userPrivilegeEclientInptCaseMember) {
     this.userPrivilegeEclientInptCaseMember = userPrivilegeEclientInptCaseMember;
 }

 @Column(name = "userPrivilegeEclientInptCaseDisc", nullable = false)
 public short getUserPrivilegeEclientInptCaseDisc() {
     return this.userPrivilegeEclientInptCaseDisc;
 }

 public void setUserPrivilegeEclientInptCaseDisc(short userPrivilegeEclientInptCaseDisc) {
     this.userPrivilegeEclientInptCaseDisc = userPrivilegeEclientInptCaseDisc;
 }

 @Column(name = "userPrivilegeEclientInptCaseCalc", nullable = false)
 public short getUserPrivilegeEclientInptCaseCalc() {
     return this.userPrivilegeEclientInptCaseCalc;
 }

 public void setUserPrivilegeEclientInptCaseCalc(short userPrivilegeEclientInptCaseCalc) {
     this.userPrivilegeEclientInptCaseCalc = userPrivilegeEclientInptCaseCalc;
 }

 @Column(name = "userPrivilegeEclientInptCaseWorksheet", nullable = false)
 public short getUserPrivilegeEclientInptCaseWorksheet() {
     return this.userPrivilegeEclientInptCaseWorksheet;
 }

 public void setUserPrivilegeEclientInptCaseWorksheet(short userPrivilegeEclientInptCaseWorksheet) {
     this.userPrivilegeEclientInptCaseWorksheet = userPrivilegeEclientInptCaseWorksheet;
 }

 @Column(name = "userPrivilegeEclientInptCaseDoc", nullable = false)
 public short getUserPrivilegeEclientInptCaseDoc() {
     return this.userPrivilegeEclientInptCaseDoc;
 }

 public void setUserPrivilegeEclientInptCaseDoc(short userPrivilegeEclientInptCaseDoc) {
     this.userPrivilegeEclientInptCaseDoc = userPrivilegeEclientInptCaseDoc;
 }

 @Column(name = "userPrivilegeEclientInptCaseLogs", nullable = false)
 public short getUserPrivilegeEclientInptCaseLogs() {
     return this.userPrivilegeEclientInptCaseLogs;
 }

 public void setUserPrivilegeEclientInptCaseLogs(short userPrivilegeEclientInptCaseLogs) {
     this.userPrivilegeEclientInptCaseLogs = userPrivilegeEclientInptCaseLogs;
 }

 @Column(name = "userPrivilegeEclientInptCaseApproval", nullable = false)
 public short getUserPrivilegeEclientInptCaseApproval() {
     return this.userPrivilegeEclientInptCaseApproval;
 }

 public void setUserPrivilegeEclientInptCaseApproval(short userPrivilegeEclientInptCaseApproval) {
     this.userPrivilegeEclientInptCaseApproval = userPrivilegeEclientInptCaseApproval;
 }

 @Column(name = "userPrivilegeEclientInptCaseImage", nullable = false)
 public short getUserPrivilegeEclientInptCaseImage() {
     return this.userPrivilegeEclientInptCaseImage;
 }

 public void setUserPrivilegeEclientInptCaseImage(short userPrivilegeEclientInptCaseImage) {
     this.userPrivilegeEclientInptCaseImage = userPrivilegeEclientInptCaseImage;
 }

 @Column(name = "userPrivilegeEclientInptCasePingbox", nullable = false)
 public short getUserPrivilegeEclientInptCasePingbox() {
     return this.userPrivilegeEclientInptCasePingbox;
 }

 public void setUserPrivilegeEclientInptCasePingbox(short userPrivilegeEclientInptCasePingbox) {
     this.userPrivilegeEclientInptCasePingbox = userPrivilegeEclientInptCasePingbox;
 }

 @Column(name = "userPrivilegeEclientInptCaseInptCsuCase", nullable = false)
 public short getUserPrivilegeEclientInptCaseInptCsuCase() {
     return this.userPrivilegeEclientInptCaseInptCsuCase;
 }

 public void setUserPrivilegeEclientInptCaseInptCsuCase(short userPrivilegeEclientInptCaseInptCsuCase) {
     this.userPrivilegeEclientInptCaseInptCsuCase = userPrivilegeEclientInptCaseInptCsuCase;
 }

 @Column(name = "userPrivilegeEclientInptCsuCase", nullable = false)
 public short getUserPrivilegeEclientInptCsuCase() {
     return this.userPrivilegeEclientInptCsuCase;
 }

 public void setUserPrivilegeEclientInptCsuCase(short userPrivilegeEclientInptCsuCase) {
     this.userPrivilegeEclientInptCsuCase = userPrivilegeEclientInptCsuCase;
 }

 @Column(name = "userPrivilegeEclientInptCsuCaseAdm", nullable = false)
 public short getUserPrivilegeEclientInptCsuCaseAdm() {
     return this.userPrivilegeEclientInptCsuCaseAdm;
 }

 public void setUserPrivilegeEclientInptCsuCaseAdm(short userPrivilegeEclientInptCsuCaseAdm) {
     this.userPrivilegeEclientInptCsuCaseAdm = userPrivilegeEclientInptCsuCaseAdm;
 }

 @Column(name = "userPrivilegeEclientInptCsuCaseDisc", nullable = false)
 public short getUserPrivilegeEclientInptCsuCaseDisc() {
     return this.userPrivilegeEclientInptCsuCaseDisc;
 }

 public void setUserPrivilegeEclientInptCsuCaseDisc(short userPrivilegeEclientInptCsuCaseDisc) {
     this.userPrivilegeEclientInptCsuCaseDisc = userPrivilegeEclientInptCsuCaseDisc;
 }

 @Column(name = "userPrivilegeEclientInptCsuCaseWorksheet", nullable = false)
 public short getUserPrivilegeEclientInptCsuCaseWorksheet() {
     return this.userPrivilegeEclientInptCsuCaseWorksheet;
 }

 public void setUserPrivilegeEclientInptCsuCaseWorksheet(short userPrivilegeEclientInptCsuCaseWorksheet) {
     this.userPrivilegeEclientInptCsuCaseWorksheet = userPrivilegeEclientInptCsuCaseWorksheet;
 }

 @Column(name = "userPrivilegeEclientInptCsuCaseDoc", nullable = false)
 public short getUserPrivilegeEclientInptCsuCaseDoc() {
     return this.userPrivilegeEclientInptCsuCaseDoc;
 }

 public void setUserPrivilegeEclientInptCsuCaseDoc(short userPrivilegeEclientInptCsuCaseDoc) {
     this.userPrivilegeEclientInptCsuCaseDoc = userPrivilegeEclientInptCsuCaseDoc;
 }

 @Column(name = "userPrivilegeEclientInptCsuCaseImage", nullable = false)
 public short getUserPrivilegeEclientInptCsuCaseImage() {
     return this.userPrivilegeEclientInptCsuCaseImage;
 }

 public void setUserPrivilegeEclientInptCsuCaseImage(short userPrivilegeEclientInptCsuCaseImage) {
     this.userPrivilegeEclientInptCsuCaseImage = userPrivilegeEclientInptCsuCaseImage;
 }

 @Column(name = "userPrivilegeEclientInOutOutptCase", nullable = false)
 public short getUserPrivilegeEclientInOutOutptCase() {
     return this.userPrivilegeEclientInOutOutptCase;
 }

 public void setUserPrivilegeEclientInOutOutptCase(short userPrivilegeEclientInOutOutptCase) {
     this.userPrivilegeEclientInOutOutptCase = userPrivilegeEclientInOutOutptCase;
 }

 @Column(name = "userPrivilegeEclientInOutInptCase", nullable = false)
 public short getUserPrivilegeEclientInOutInptCase() {
     return this.userPrivilegeEclientInOutInptCase;
 }

 public void setUserPrivilegeEclientInOutInptCase(short userPrivilegeEclientInOutInptCase) {
     this.userPrivilegeEclientInOutInptCase = userPrivilegeEclientInOutInptCase;
 }

 @Column(name = "userPrivilegeEclientInOutShowMedicalInfo", nullable = false)
 public short getUserPrivilegeEclientInOutShowMedicalInfo() {
     return this.userPrivilegeEclientInOutShowMedicalInfo;
 }

 public void setUserPrivilegeEclientInOutShowMedicalInfo(short userPrivilegeEclientInOutShowMedicalInfo) {
     this.userPrivilegeEclientInOutShowMedicalInfo = userPrivilegeEclientInOutShowMedicalInfo;
 }

 @Column(name = "userPrivilegeEclientInOutDocs", nullable = false)
 public short getUserPrivilegeEclientInOutDocs() {
     return this.userPrivilegeEclientInOutDocs;
 }

 public void setUserPrivilegeEclientInOutDocs(short userPrivilegeEclientInOutDocs) {
     this.userPrivilegeEclientInOutDocs = userPrivilegeEclientInOutDocs;
 }

 @Column(name = "userPrivilegeEclientInOutLogs", nullable = false)
 public short getUserPrivilegeEclientInOutLogs() {
     return this.userPrivilegeEclientInOutLogs;
 }

 public void setUserPrivilegeEclientInOutLogs(short userPrivilegeEclientInOutLogs) {
     this.userPrivilegeEclientInOutLogs = userPrivilegeEclientInOutLogs;
 }

 @Column(name = "userPrivilegeEclientInOutApproval", nullable = false)
 public short getUserPrivilegeEclientInOutApproval() {
     return this.userPrivilegeEclientInOutApproval;
 }

 public void setUserPrivilegeEclientInOutApproval(short userPrivilegeEclientInOutApproval) {
     this.userPrivilegeEclientInOutApproval = userPrivilegeEclientInOutApproval;
 }

 @Column(name = "userPrivilegeEclientInOutImage", nullable = false)
 public short getUserPrivilegeEclientInOutImage() {
     return this.userPrivilegeEclientInOutImage;
 }

 public void setUserPrivilegeEclientInOutImage(short userPrivilegeEclientInOutImage) {
     this.userPrivilegeEclientInOutImage = userPrivilegeEclientInOutImage;
 }

 @Column(name = "userPrivilegeEclientInOutMember", nullable = false)
 public short getUserPrivilegeEclientInOutMember() {
     return this.userPrivilegeEclientInOutMember;
 }

 public void setUserPrivilegeEclientInOutMember(short userPrivilegeEclientInOutMember) {
     this.userPrivilegeEclientInOutMember = userPrivilegeEclientInOutMember;
 }

 @Column(name = "userPrivilegeEclientPingbox", nullable = false)
 public short getUserPrivilegeEclientPingbox() {
     return this.userPrivilegeEclientPingbox;
 }

 public void setUserPrivilegeEclientPingbox(short userPrivilegeEclientPingbox) {
     this.userPrivilegeEclientPingbox = userPrivilegeEclientPingbox;
 }

 @Column(name = "userPrivilegeEclientInvestigation", nullable = false)
 public short getUserPrivilegeEclientInvestigation() {
     return this.userPrivilegeEclientInvestigation;
 }

 public void setUserPrivilegeEclientInvestigation(short userPrivilegeEclientInvestigation) {
     this.userPrivilegeEclientInvestigation = userPrivilegeEclientInvestigation;
 }

 @Column(name = "userPrivilegeEclientReport", nullable = false)
 public short getUserPrivilegeEclientReport() {
     return this.userPrivilegeEclientReport;
 }

 public void setUserPrivilegeEclientReport(short userPrivilegeEclientReport) {
     this.userPrivilegeEclientReport = userPrivilegeEclientReport;
 }

 @Column(name = "userPrivilegeEclientMySetting", nullable = false)
 public short getUserPrivilegeEclientMySetting() {
     return this.userPrivilegeEclientMySetting;
 }

 public void setUserPrivilegeEclientMySetting(short userPrivilegeEclientMySetting) {
     this.userPrivilegeEclientMySetting = userPrivilegeEclientMySetting;
 }

 @Column(name = "userPrivilegeEclaimAllowImpersonation", nullable = false)
 public short getUserPrivilegeEclaimAllowImpersonation() {
     return this.userPrivilegeEclaimAllowImpersonation;
 }

 public void setUserPrivilegeEclaimAllowImpersonation(short userPrivilegeEclaimAllowImpersonation) {
     this.userPrivilegeEclaimAllowImpersonation = userPrivilegeEclaimAllowImpersonation;
 }

 @Column(name = "userPrivilegeEclaimInptCases", nullable = false)
 public short getUserPrivilegeEclaimInptCases() {
     return this.userPrivilegeEclaimInptCases;
 }

 public void setUserPrivilegeEclaimInptCases(short userPrivilegeEclaimInptCases) {
     this.userPrivilegeEclaimInptCases = userPrivilegeEclaimInptCases;
 }

 @Column(name = "userPrivilegeEclaimInptIncludeOutpt", nullable = false)
 public short getUserPrivilegeEclaimInptIncludeOutpt() {
     return this.userPrivilegeEclaimInptIncludeOutpt;
 }

 public void setUserPrivilegeEclaimInptIncludeOutpt(short userPrivilegeEclaimInptIncludeOutpt) {
     this.userPrivilegeEclaimInptIncludeOutpt = userPrivilegeEclaimInptIncludeOutpt;
 }

 @Column(name = "userPrivilegeEclaimInptMember", nullable = false)
 public short getUserPrivilegeEclaimInptMember() {
     return this.userPrivilegeEclaimInptMember;
 }

 public void setUserPrivilegeEclaimInptMember(short userPrivilegeEclaimInptMember) {
     this.userPrivilegeEclaimInptMember = userPrivilegeEclaimInptMember;
 }

 @Column(name = "userPrivilegeEclaimInptDocUpload", nullable = false)
 public short getUserPrivilegeEclaimInptDocUpload() {
     return this.userPrivilegeEclaimInptDocUpload;
 }

 public void setUserPrivilegeEclaimInptDocUpload(short userPrivilegeEclaimInptDocUpload) {
     this.userPrivilegeEclaimInptDocUpload = userPrivilegeEclaimInptDocUpload;
 }

 @Column(name = "userPrivilegeEclaimInOutOpdCases", nullable = false)
 public short getUserPrivilegeEclaimInOutOpdCases() {
     return this.userPrivilegeEclaimInOutOpdCases;
 }

 public void setUserPrivilegeEclaimInOutOpdCases(short userPrivilegeEclaimInOutOpdCases) {
     this.userPrivilegeEclaimInOutOpdCases = userPrivilegeEclaimInOutOpdCases;
 }

 @Column(name = "userPrivilegeEclaimInOutMember", nullable = false)
 public short getUserPrivilegeEclaimInOutMember() {
     return this.userPrivilegeEclaimInOutMember;
 }

 public void setUserPrivilegeEclaimInOutMember(short userPrivilegeEclaimInOutMember) {
     this.userPrivilegeEclaimInOutMember = userPrivilegeEclaimInOutMember;
 }

 @Column(name = "userPrivilegeEclaimInOutIpdMember", nullable = false)
 public short getUserPrivilegeEclaimInOutIpdMember() {
     return this.userPrivilegeEclaimInOutIpdMember;
 }

 public void setUserPrivilegeEclaimInOutIpdMember(short userPrivilegeEclaimInOutIpdMember) {
     this.userPrivilegeEclaimInOutIpdMember = userPrivilegeEclaimInOutIpdMember;
 }

 @Column(name = "userPrivilegeEclaimInOutOpdMember", nullable = false)
 public short getUserPrivilegeEclaimInOutOpdMember() {
     return this.userPrivilegeEclaimInOutOpdMember;
 }

 public void setUserPrivilegeEclaimInOutOpdMember(short userPrivilegeEclaimInOutOpdMember) {
     this.userPrivilegeEclaimInOutOpdMember = userPrivilegeEclaimInOutOpdMember;
 }

 @Column(name = "userPrivilegeEclaimInOutIpdCases", nullable = false)
 public short getUserPrivilegeEclaimInOutIpdCases() {
     return this.userPrivilegeEclaimInOutIpdCases;
 }

 public void setUserPrivilegeEclaimInOutIpdCases(short userPrivilegeEclaimInOutIpdCases) {
     this.userPrivilegeEclaimInOutIpdCases = userPrivilegeEclaimInOutIpdCases;
 }

 @Column(name = "userPrivilegeEclaimInOutOpdPayAdv", nullable = false)
 public short getUserPrivilegeEclaimInOutOpdPayAdv() {
     return this.userPrivilegeEclaimInOutOpdPayAdv;
 }

 public void setUserPrivilegeEclaimInOutOpdPayAdv(short userPrivilegeEclaimInOutOpdPayAdv) {
     this.userPrivilegeEclaimInOutOpdPayAdv = userPrivilegeEclaimInOutOpdPayAdv;
 }

 @Column(name = "userPrivilegeEclaimQr", nullable = false)
 public short getUserPrivilegeEclaimQr() {
     return this.userPrivilegeEclaimQr;
 }

 public void setUserPrivilegeEclaimQr(short userPrivilegeEclaimQr) {
     this.userPrivilegeEclaimQr = userPrivilegeEclaimQr;
 }

 @Column(name = "userPrivilegeEclaimMySetting", nullable = false)
 public short getUserPrivilegeEclaimMySetting() {
     return this.userPrivilegeEclaimMySetting;
 }

 public void setUserPrivilegeEclaimMySetting(short userPrivilegeEclaimMySetting) {
     this.userPrivilegeEclaimMySetting = userPrivilegeEclaimMySetting;
 }

 @Column(name = "userPrivilegeEclaimContactUs", nullable = false)
 public short getUserPrivilegeEclaimContactUs() {
     return this.userPrivilegeEclaimContactUs;
 }

 public void setUserPrivilegeEclaimContactUs(short userPrivilegeEclaimContactUs) {
     this.userPrivilegeEclaimContactUs = userPrivilegeEclaimContactUs;
 }

 @Column(name = "userPrivilegeEclaimMyForm", nullable = false)
 public short getUserPrivilegeEclaimMyForm() {
     return this.userPrivilegeEclaimMyForm;
 }

 public void setUserPrivilegeEclaimMyForm(short userPrivilegeEclaimMyForm) {
     this.userPrivilegeEclaimMyForm = userPrivilegeEclaimMyForm;
 }

 @Column(name = "userPrivilegeEclaimSgForm", nullable = false)
 public short getUserPrivilegeEclaimSgForm() {
     return this.userPrivilegeEclaimSgForm;
 }

 public void setUserPrivilegeEclaimSgForm(short userPrivilegeEclaimSgForm) {
     this.userPrivilegeEclaimSgForm = userPrivilegeEclaimSgForm;
 }

 @Column(name = "userPrivilegeEclaimThForm", nullable = false)
 public short getUserPrivilegeEclaimThForm() {
     return this.userPrivilegeEclaimThForm;
 }

 public void setUserPrivilegeEclaimThForm(short userPrivilegeEclaimThForm) {
     this.userPrivilegeEclaimThForm = userPrivilegeEclaimThForm;
 }

 @Column(name = "userPrivilegeEclaimDocumentCentral", nullable = false)
 public short getUserPrivilegeEclaimDocumentCentral() {
     return this.userPrivilegeEclaimDocumentCentral;
 }

 public void setUserPrivilegeEclaimDocumentCentral(short userPrivilegeEclaimDocumentCentral) {
     this.userPrivilegeEclaimDocumentCentral = userPrivilegeEclaimDocumentCentral;
 }

 @Column(name = "userPrivilegeAllInptMmCountReport", nullable = false)
 public short getUserPrivilegeAllInptMmCountReport() {
     return this.userPrivilegeAllInptMmCountReport;
 }

 public void setUserPrivilegeAllInptMmCountReport(short userPrivilegeAllInptMmCountReport) {
     this.userPrivilegeAllInptMmCountReport = userPrivilegeAllInptMmCountReport;
 }

 @Column(name = "userPrivilegeAllMemberUuidReport", nullable = false)
 public short getUserPrivilegeAllMemberUuidReport() {
     return this.userPrivilegeAllMemberUuidReport;
 }

 public void setUserPrivilegeAllMemberUuidReport(short userPrivilegeAllMemberUuidReport) {
     this.userPrivilegeAllMemberUuidReport = userPrivilegeAllMemberUuidReport;
 }

 @Column(name = "userPrivilegeAllCcmReport", nullable = false)
 public short getUserPrivilegeAllCcmReport() {
     return this.userPrivilegeAllCcmReport;
 }

 public void setUserPrivilegeAllCcmReport(short userPrivilegeAllCcmReport) {
     this.userPrivilegeAllCcmReport = userPrivilegeAllCcmReport;
 }

 @Column(name = "userPrivilegeAllInptReminderReport", nullable = false)
 public short getUserPrivilegeAllInptReminderReport() {
     return this.userPrivilegeAllInptReminderReport;
 }

 public void setUserPrivilegeAllInptReminderReport(short userPrivilegeAllInptReminderReport) {
     this.userPrivilegeAllInptReminderReport = userPrivilegeAllInptReminderReport;
 }

 @Column(name = "userPrivilegeAllInptCaseTodoReport", nullable = false)
 public short getUserPrivilegeAllInptCaseTodoReport() {
     return this.userPrivilegeAllInptCaseTodoReport;
 }

 public void setUserPrivilegeAllInptCaseTodoReport(short userPrivilegeAllInptCaseTodoReport) {
     this.userPrivilegeAllInptCaseTodoReport = userPrivilegeAllInptCaseTodoReport;
 }

 @Column(name = "userPrivilegeMyInptAccountingReport", nullable = false)
 public short getUserPrivilegeMyInptAccountingReport() {
     return this.userPrivilegeMyInptAccountingReport;
 }

 public void setUserPrivilegeMyInptAccountingReport(short userPrivilegeMyInptAccountingReport) {
     this.userPrivilegeMyInptAccountingReport = userPrivilegeMyInptAccountingReport;
 }

 @Column(name = "userPrivilegeMyInptB2bReport", nullable = false)
 public short getUserPrivilegeMyInptB2bReport() {
     return this.userPrivilegeMyInptB2bReport;
 }

 public void setUserPrivilegeMyInptB2bReport(short userPrivilegeMyInptB2bReport) {
     this.userPrivilegeMyInptB2bReport = userPrivilegeMyInptB2bReport;
 }

 @Column(name = "userPrivilegeMyInptBordTempReport", nullable = false)
 public short getUserPrivilegeMyInptBordTempReport() {
     return this.userPrivilegeMyInptBordTempReport;
 }

 public void setUserPrivilegeMyInptBordTempReport(short userPrivilegeMyInptBordTempReport) {
     this.userPrivilegeMyInptBordTempReport = userPrivilegeMyInptBordTempReport;
 }

 @Column(name = "userPrivilegeMyInptHccReport", nullable = false)
 public short getUserPrivilegeMyInptHccReport() {
     return this.userPrivilegeMyInptHccReport;
 }

 public void setUserPrivilegeMyInptHccReport(short userPrivilegeMyInptHccReport) {
     this.userPrivilegeMyInptHccReport = userPrivilegeMyInptHccReport;
 }

 @Column(name = "userPrivilegeMyInptMarketingReport", nullable = false)
 public short getUserPrivilegeMyInptMarketingReport() {
     return this.userPrivilegeMyInptMarketingReport;
 }

 public void setUserPrivilegeMyInptMarketingReport(short userPrivilegeMyInptMarketingReport) {
     this.userPrivilegeMyInptMarketingReport = userPrivilegeMyInptMarketingReport;
 }

 @Column(name = "userPrivilegeMyInptMasterFileTempReport", nullable = false)
 public short getUserPrivilegeMyInptMasterFileTempReport() {
     return this.userPrivilegeMyInptMasterFileTempReport;
 }

 public void setUserPrivilegeMyInptMasterFileTempReport(short userPrivilegeMyInptMasterFileTempReport) {
     this.userPrivilegeMyInptMasterFileTempReport = userPrivilegeMyInptMasterFileTempReport;
 }

 @Column(name = "userPrivilegeMyInptNoObAgingReport", nullable = false)
 public short getUserPrivilegeMyInptNoObAgingReport() {
     return this.userPrivilegeMyInptNoObAgingReport;
 }

 public void setUserPrivilegeMyInptNoObAgingReport(short userPrivilegeMyInptNoObAgingReport) {
     this.userPrivilegeMyInptNoObAgingReport = userPrivilegeMyInptNoObAgingReport;
 }

 @Column(name = "userPrivilegeMyInptOutstandingReport", nullable = false)
 public short getUserPrivilegeMyInptOutstandingReport() {
     return this.userPrivilegeMyInptOutstandingReport;
 }

 public void setUserPrivilegeMyInptOutstandingReport(short userPrivilegeMyInptOutstandingReport) {
     this.userPrivilegeMyInptOutstandingReport = userPrivilegeMyInptOutstandingReport;
 }

 @Column(name = "userPrivilegeMyInptPaymentReport", nullable = false)
 public short getUserPrivilegeMyInptPaymentReport() {
     return this.userPrivilegeMyInptPaymentReport;
 }

 public void setUserPrivilegeMyInptPaymentReport(short userPrivilegeMyInptPaymentReport) {
     this.userPrivilegeMyInptPaymentReport = userPrivilegeMyInptPaymentReport;
 }

 @Column(name = "userPrivilegeMyInptUtilReport", nullable = false)
 public short getUserPrivilegeMyInptUtilReport() {
     return this.userPrivilegeMyInptUtilReport;
 }

 public void setUserPrivilegeMyInptUtilReport(short userPrivilegeMyInptUtilReport) {
     this.userPrivilegeMyInptUtilReport = userPrivilegeMyInptUtilReport;
 }

 @Column(name = "userPrivilegeMyInptImportPurchaseReport", nullable = false)
 public short getUserPrivilegeMyInptImportPurchaseReport() {
     return this.userPrivilegeMyInptImportPurchaseReport;
 }

 public void setUserPrivilegeMyInptImportPurchaseReport(short userPrivilegeMyInptImportPurchaseReport) {
     this.userPrivilegeMyInptImportPurchaseReport = userPrivilegeMyInptImportPurchaseReport;
 }

 @Column(name = "userPrivilegeMyInptBillRegReport", nullable = false)
 public short getUserPrivilegeMyInptBillRegReport() {
     return this.userPrivilegeMyInptBillRegReport;
 }

 public void setUserPrivilegeMyInptBillRegReport(short userPrivilegeMyInptBillRegReport) {
     this.userPrivilegeMyInptBillRegReport = userPrivilegeMyInptBillRegReport;
 }

 @Column(name = "userPrivilegeMyInptHoldPaymentReport", nullable = false)
 public short getUserPrivilegeMyInptHoldPaymentReport() {
     return this.userPrivilegeMyInptHoldPaymentReport;
 }

 public void setUserPrivilegeMyInptHoldPaymentReport(short userPrivilegeMyInptHoldPaymentReport) {
     this.userPrivilegeMyInptHoldPaymentReport = userPrivilegeMyInptHoldPaymentReport;
 }

 @Column(name = "userPrivilegeMyInptReleasePaymentReport", nullable = false)
 public short getUserPrivilegeMyInptReleasePaymentReport() {
     return this.userPrivilegeMyInptReleasePaymentReport;
 }

 public void setUserPrivilegeMyInptReleasePaymentReport(short userPrivilegeMyInptReleasePaymentReport) {
     this.userPrivilegeMyInptReleasePaymentReport = userPrivilegeMyInptReleasePaymentReport;
 }

 @Column(name = "userPrivilegeMyInptCaseTriageReport", nullable = false)
 public short getUserPrivilegeMyInptCaseTriageReport() {
     return this.userPrivilegeMyInptCaseTriageReport;
 }

 public void setUserPrivilegeMyInptCaseTriageReport(short userPrivilegeMyInptCaseTriageReport) {
     this.userPrivilegeMyInptCaseTriageReport = userPrivilegeMyInptCaseTriageReport;
 }

 @Column(name = "userPrivilegeMyInptHeadCountReport", nullable = false)
 public short getUserPrivilegeMyInptHeadCountReport() {
     return this.userPrivilegeMyInptHeadCountReport;
 }

 public void setUserPrivilegeMyInptHeadCountReport(short userPrivilegeMyInptHeadCountReport) {
     this.userPrivilegeMyInptHeadCountReport = userPrivilegeMyInptHeadCountReport;
 }

 @Column(name = "userPrivilegeMyInptBordMyobReport", nullable = false)
 public short getUserPrivilegeMyInptBordMyobReport() {
     return this.userPrivilegeMyInptBordMyobReport;
 }

 public void setUserPrivilegeMyInptBordMyobReport(short userPrivilegeMyInptBordMyobReport) {
     this.userPrivilegeMyInptBordMyobReport = userPrivilegeMyInptBordMyobReport;
 }

 @Column(name = "userPrivilegeMyInptPaymentForMyobReport", nullable = false)
 public short getUserPrivilegeMyInptPaymentForMyobReport() {
     return this.userPrivilegeMyInptPaymentForMyobReport;
 }

 public void setUserPrivilegeMyInptPaymentForMyobReport(short userPrivilegeMyInptPaymentForMyobReport) {
     this.userPrivilegeMyInptPaymentForMyobReport = userPrivilegeMyInptPaymentForMyobReport;
 }

 @Column(name = "userPrivilegeMyInptMemberNoClaimReport", nullable = false)
 public short getUserPrivilegeMyInptMemberNoClaimReport() {
     return this.userPrivilegeMyInptMemberNoClaimReport;
 }

 public void setUserPrivilegeMyInptMemberNoClaimReport(short userPrivilegeMyInptMemberNoClaimReport) {
     this.userPrivilegeMyInptMemberNoClaimReport = userPrivilegeMyInptMemberNoClaimReport;
 }

 @Column(name = "userPrivilegeMyAccPacArReport", nullable = false)
 public short getUserPrivilegeMyAccPacArReport() {
     return this.userPrivilegeMyAccPacArReport;
 }

 public void setUserPrivilegeMyAccPacArReport(short userPrivilegeMyAccPacArReport) {
     this.userPrivilegeMyAccPacArReport = userPrivilegeMyAccPacArReport;
 }

 @Column(name = "userPrivilegeMyAccPacApReport", nullable = false)
 public short getUserPrivilegeMyAccPacApReport() {
     return this.userPrivilegeMyAccPacApReport;
 }

 public void setUserPrivilegeMyAccPacApReport(short userPrivilegeMyAccPacApReport) {
     this.userPrivilegeMyAccPacApReport = userPrivilegeMyAccPacApReport;
 }

 @Column(name = "userPrivilegeMyAccPacReport", nullable = false)
 public short getUserPrivilegeMyAccPacReport() {
     return this.userPrivilegeMyAccPacReport;
 }

 public void setUserPrivilegeMyAccPacReport(short userPrivilegeMyAccPacReport) {
     this.userPrivilegeMyAccPacReport = userPrivilegeMyAccPacReport;
 }

 @Column(name = "userPrivilegeMyAccPayableReport", nullable = false)
 public short getUserPrivilegeMyAccPayableReport() {
     return this.userPrivilegeMyAccPayableReport;
 }

 public void setUserPrivilegeMyAccPayableReport(short userPrivilegeMyAccPayableReport) {
     this.userPrivilegeMyAccPayableReport = userPrivilegeMyAccPayableReport;
 }

 @Column(name = "userPrivilegeMyAccReceivableReport", nullable = false)
 public short getUserPrivilegeMyAccReceivableReport() {
     return this.userPrivilegeMyAccReceivableReport;
 }
 
 public void setUserPrivilegeMyAccReceivableReport(short userPrivilegeMyAccReceivableReport) {
     this.userPrivilegeMyAccReceivableReport = userPrivilegeMyAccReceivableReport;
 }
 
 @Column(name = "userPrivilegeMyAxaTextFileGPReport", nullable = false)
 public short getUserPrivilegeMyAxaTextFileGPReport() {
     return userPrivilegeMyAxaTextFileGPReport;
 }

 public void setUserPrivilegeMyAxaTextFileGPReport(short userPrivilegeMyAxaTextFileGPReport) {
     this.userPrivilegeMyAxaTextFileGPReport = userPrivilegeMyAxaTextFileGPReport;
 }

 
 @Column(name = "userPrivilegeMyBsiInptTextFileReport", nullable = false)
 public short getUserPrivilegeMyBsiInptTextFileReport() {
     return this.userPrivilegeMyBsiInptTextFileReport;
 }

 public void setUserPrivilegeMyBsiInptTextFileReport(short userPrivilegeMyBsiInptTextFileReport) {
     this.userPrivilegeMyBsiInptTextFileReport = userPrivilegeMyBsiInptTextFileReport;
 }

 @Column(name = "userPrivilegeMyAmmetlifeTxtReport", nullable = false)
 public short getUserPrivilegeMyAmmetlifeTxtReport() {
     return this.userPrivilegeMyAmmetlifeTxtReport;
 }

 public void setUserPrivilegeMyAmmetlifeTxtReport(short userPrivilegeMyAmmetlifeTxtReport) {
     this.userPrivilegeMyAmmetlifeTxtReport = userPrivilegeMyAmmetlifeTxtReport;
 }

 @Column(name = "userPrivilegeMyBsiPostTextFileReport", nullable = false)
 public short getUserPrivilegeMyBsiPostTextFileReport() {
     return this.userPrivilegeMyBsiPostTextFileReport;
 }

 public void setUserPrivilegeMyBsiPostTextFileReport(short userPrivilegeMyBsiPostTextFileReport) {
     this.userPrivilegeMyBsiPostTextFileReport = userPrivilegeMyBsiPostTextFileReport;
 }

 @Column(name = "userPrivilegeMyAlimIndReport", nullable = false)
 public short getUserPrivilegeMyAlimIndReport() {
     return this.userPrivilegeMyAlimIndReport;
 }

 public void setUserPrivilegeMyAlimIndReport(short userPrivilegeMyAlimIndReport) {
     this.userPrivilegeMyAlimIndReport = userPrivilegeMyAlimIndReport;
 }

 @Column(name = "userPrivilegeMyAlimGrpReport", nullable = false)
 public short getUserPrivilegeMyAlimGrpReport() {
     return this.userPrivilegeMyAlimGrpReport;
 }

 public void setUserPrivilegeMyAlimGrpReport(short userPrivilegeMyAlimGrpReport) {
     this.userPrivilegeMyAlimGrpReport = userPrivilegeMyAlimGrpReport;
 }

 @Column(name = "userPrivilegeMyHlaTxtReport", nullable = false)
 public short getUserPrivilegeMyHlaTxtReport() {
     return this.userPrivilegeMyHlaTxtReport;
 }

 public void setUserPrivilegeMyHlaTxtReport(short userPrivilegeMyHlaTxtReport) {
     this.userPrivilegeMyHlaTxtReport = userPrivilegeMyHlaTxtReport;
 }

 @Column(name = "userPrivilegeMyAxaTxtReport", nullable = false)
 public short getUserPrivilegeMyAxaTxtReport() {
     return this.userPrivilegeMyAxaTxtReport;
 }

 public void setUserPrivilegeMyAxaTxtReport(short userPrivilegeMyAxaTxtReport) {
     this.userPrivilegeMyAxaTxtReport = userPrivilegeMyAxaTxtReport;
 }

 @Column(name = "userPrivilegeMyLonpacTxtReport", nullable = false)
 public short getUserPrivilegeMyLonpacTxtReport() {
     return this.userPrivilegeMyLonpacTxtReport;
 }

 public void setUserPrivilegeMyLonpacTxtReport(short userPrivilegeMyLonpacTxtReport) {
     this.userPrivilegeMyLonpacTxtReport = userPrivilegeMyLonpacTxtReport;
 }

 @Column(name = "userPrivilegeMyLonpacDcaTxtReport", nullable = false)
 public short getUserPrivilegeMyLonpacDcaTxtReport() {
     return this.userPrivilegeMyLonpacDcaTxtReport;
 }

 public void setUserPrivilegeMyLonpacDcaTxtReport(short userPrivilegeMyLonpacDcaTxtReport) {
     this.userPrivilegeMyLonpacDcaTxtReport = userPrivilegeMyLonpacDcaTxtReport;
 }

 @Column(name = "userPrivilegeMyMcisGrpTxtReport", nullable = false)
 public short getUserPrivilegeMyMcisGrpTxtReport() {
     return this.userPrivilegeMyMcisGrpTxtReport;
 }

 public void setUserPrivilegeMyMcisGrpTxtReport(short userPrivilegeMyMcisGrpTxtReport) {
     this.userPrivilegeMyMcisGrpTxtReport = userPrivilegeMyMcisGrpTxtReport;
 }

 @Column(name = "userPrivilegeMyMcisIndTxtReport", nullable = false)
 public short getUserPrivilegeMyMcisIndTxtReport() {
     return this.userPrivilegeMyMcisIndTxtReport;
 }

 public void setUserPrivilegeMyMcisIndTxtReport(short userPrivilegeMyMcisIndTxtReport) {
     this.userPrivilegeMyMcisIndTxtReport = userPrivilegeMyMcisIndTxtReport;
 }

 @Column(name = "userPrivilegeMyMpiMseTxtReport", nullable = false)
 public short getUserPrivilegeMyMpiMseTxtReport() {
     return this.userPrivilegeMyMpiMseTxtReport;
 }

 public void setUserPrivilegeMyMpiMseTxtReport(short userPrivilegeMyMpiMseTxtReport) {
     this.userPrivilegeMyMpiMseTxtReport = userPrivilegeMyMpiMseTxtReport;
 }

 @Column(name = "userPrivilegeMyMpiPtgTxtReport", nullable = false)
 public short getUserPrivilegeMyMpiPtgTxtReport() {
     return this.userPrivilegeMyMpiPtgTxtReport;
 }

 public void setUserPrivilegeMyMpiPtgTxtReport(short userPrivilegeMyMpiPtgTxtReport) {
     this.userPrivilegeMyMpiPtgTxtReport = userPrivilegeMyMpiPtgTxtReport;
 }

 @Column(name = "userPrivilegeMyStmbTxtReport", nullable = false)
 public short getUserPrivilegeMyStmbTxtReport() {
     return this.userPrivilegeMyStmbTxtReport;
 }

 public void setUserPrivilegeMyStmbTxtReport(short userPrivilegeMyStmbTxtReport) {
     this.userPrivilegeMyStmbTxtReport = userPrivilegeMyStmbTxtReport;
 }

 @Column(name = "userPrivilegeMyStmbRbTxtReport", nullable = false)
 public short getUserPrivilegeMyStmbRbTxtReport() {
     return this.userPrivilegeMyStmbRbTxtReport;
 }

 public void setUserPrivilegeMyStmbRbTxtReport(short userPrivilegeMyStmbRbTxtReport) {
     this.userPrivilegeMyStmbRbTxtReport = userPrivilegeMyStmbRbTxtReport;
 }

 @Column(name = "userPrivilegeMyStmbCashTxtReport", nullable = false)
 public short getUserPrivilegeMyStmbCashTxtReport() {
     return this.userPrivilegeMyStmbCashTxtReport;
 }

 public void setUserPrivilegeMyStmbCashTxtReport(short userPrivilegeMyStmbCashTxtReport) {
     this.userPrivilegeMyStmbCashTxtReport = userPrivilegeMyStmbCashTxtReport;
 }

 @Column(name = "userPrivilegeMyTisbTxtReport", nullable = false)
 public short getUserPrivilegeMyTisbTxtReport() {
     return this.userPrivilegeMyTisbTxtReport;
 }

 public void setUserPrivilegeMyTisbTxtReport(short userPrivilegeMyTisbTxtReport) {
     this.userPrivilegeMyTisbTxtReport = userPrivilegeMyTisbTxtReport;
 }

 @Column(name = "userPrivilegeMyTokioMarineTxtReport", nullable = false)
 public short getUserPrivilegeMyTokioMarineTxtReport() {
     return this.userPrivilegeMyTokioMarineTxtReport;
 }

 public void setUserPrivilegeMyTokioMarineTxtReport(short userPrivilegeMyTokioMarineTxtReport) {
     this.userPrivilegeMyTokioMarineTxtReport = userPrivilegeMyTokioMarineTxtReport;
 }

 @Column(name = "userPrivilegeMySpikpaTxtReport", nullable = false)
 public short getUserPrivilegeMySpikpaTxtReport() {
     return this.userPrivilegeMySpikpaTxtReport;
 }

 public void setUserPrivilegeMySpikpaTxtReport(short userPrivilegeMySpikpaTxtReport) {
     this.userPrivilegeMySpikpaTxtReport = userPrivilegeMySpikpaTxtReport;
 }

 @Column(name = "userPrivilegeMyEtiqaMcsTxtReport", nullable = false)
 public short getUserPrivilegeMyEtiqaMcsTxtReport() {
     return this.userPrivilegeMyEtiqaMcsTxtReport;
 }

 public void setUserPrivilegeMyEtiqaMcsTxtReport(short userPrivilegeMyEtiqaMcsTxtReport) {
     this.userPrivilegeMyEtiqaMcsTxtReport = userPrivilegeMyEtiqaMcsTxtReport;
 }
 
 @Column(name = "userPrivilegeMyMbasTextFileReport", nullable = false)
 public short getUserPrivilegeMyMbasTextFileReport() {
     return this.userPrivilegeMyMbasTextFileReport;
 }

 public void setUserPrivilegeMyMbasTextFileReport(short userPrivilegeMyMbasTextFileReport) {
     this.userPrivilegeMyMbasTextFileReport = userPrivilegeMyMbasTextFileReport;
 }
 
 @Column(name = "userPrivilegeAsiaInptClaimsBdxReport", nullable = false)
 public short getUserPrivilegeAsiaInptClaimsBdxReport() {
     return this.userPrivilegeAsiaInptClaimsBdxReport;
 }

 public void setUserPrivilegeAsiaInptClaimsBdxReport(short userPrivilegeAsiaInptClaimsBdxReport) {
     this.userPrivilegeAsiaInptClaimsBdxReport = userPrivilegeAsiaInptClaimsBdxReport;
 }

 @Column(name = "userPrivilegeAsiaInptMasterReport", nullable = false)
 public short getUserPrivilegeAsiaInptMasterReport() {
     return this.userPrivilegeAsiaInptMasterReport;
 }

 public void setUserPrivilegeAsiaInptMasterReport(short userPrivilegeAsiaInptMasterReport) {
     this.userPrivilegeAsiaInptMasterReport = userPrivilegeAsiaInptMasterReport;
 }

 @Column(name = "userPrivilegeAsiaInptClaimsReturnReport", nullable = false)
 public short getUserPrivilegeAsiaInptClaimsReturnReport() {
     return this.userPrivilegeAsiaInptClaimsReturnReport;
 }

 public void setUserPrivilegeAsiaInptClaimsReturnReport(short userPrivilegeAsiaInptClaimsReturnReport) {
     this.userPrivilegeAsiaInptClaimsReturnReport = userPrivilegeAsiaInptClaimsReturnReport;
 }

 @Column(name = "userPrivilegeAsiaInptSettlementReport", nullable = false)
 public short getUserPrivilegeAsiaInptSettlementReport() {
     return this.userPrivilegeAsiaInptSettlementReport;
 }

 public void setUserPrivilegeAsiaInptSettlementReport(short userPrivilegeAsiaInptSettlementReport) {
     this.userPrivilegeAsiaInptSettlementReport = userPrivilegeAsiaInptSettlementReport;
 }

 @Column(name = "userPrivilegeAsiaDailyInptCasesReport", nullable = false)
 public short getUserPrivilegeAsiaDailyInptCasesReport() {
     return this.userPrivilegeAsiaDailyInptCasesReport;
 }

 public void setUserPrivilegeAsiaDailyInptCasesReport(short userPrivilegeAsiaDailyInptCasesReport) {
     this.userPrivilegeAsiaDailyInptCasesReport = userPrivilegeAsiaDailyInptCasesReport;
 }

 @Column(name = "userPrivilegeAsiaInptUtilReport", nullable = false)
 public short getUserPrivilegeAsiaInptUtilReport() {
     return this.userPrivilegeAsiaInptUtilReport;
 }

 public void setUserPrivilegeAsiaInptUtilReport(short userPrivilegeAsiaInptUtilReport) {
     this.userPrivilegeAsiaInptUtilReport = userPrivilegeAsiaInptUtilReport;
 }

 @Column(name = "userPrivilegeAsiaInptCostContainmentReport", nullable = false)
 public short getUserPrivilegeAsiaInptCostContainmentReport() {
     return this.userPrivilegeAsiaInptCostContainmentReport;
 }

 public void setUserPrivilegeAsiaInptCostContainmentReport(short userPrivilegeAsiaInptCostContainmentReport) {
     this.userPrivilegeAsiaInptCostContainmentReport = userPrivilegeAsiaInptCostContainmentReport;
 }

 @Column(name = "userPrivilegeAsiaInptPostAuditReport", nullable = false)
 public short getUserPrivilegeAsiaInptPostAuditReport() {
     return this.userPrivilegeAsiaInptPostAuditReport;
 }

 public void setUserPrivilegeAsiaInptPostAuditReport(short userPrivilegeAsiaInptPostAuditReport) {
     this.userPrivilegeAsiaInptPostAuditReport = userPrivilegeAsiaInptPostAuditReport;
 }

 @Column(name = "userPrivilegeAsiaInptPaymentAdvReport", nullable = false)
 public short getUserPrivilegeAsiaInptPaymentAdvReport() {
     return this.userPrivilegeAsiaInptPaymentAdvReport;
 }

 public void setUserPrivilegeAsiaInptPaymentAdvReport(short userPrivilegeAsiaInptPaymentAdvReport) {
     this.userPrivilegeAsiaInptPaymentAdvReport = userPrivilegeAsiaInptPaymentAdvReport;
 }

 @Column(name = "userPrivilegeAsiaInptDailyImagingReport", nullable = false)
 public short getUserPrivilegeAsiaInptDailyImagingReport() {
     return this.userPrivilegeAsiaInptDailyImagingReport;
 }

 public void setUserPrivilegeAsiaInptDailyImagingReport(short userPrivilegeAsiaInptDailyImagingReport) {
     this.userPrivilegeAsiaInptDailyImagingReport = userPrivilegeAsiaInptDailyImagingReport;
 }

 @Column(name = "userPrivilegeAsiInptaMedicalFeeReport", nullable = false)
 public short getUserPrivilegeAsiInptaMedicalFeeReport() {
     return this.userPrivilegeAsiInptaMedicalFeeReport;
 }

 public void setUserPrivilegeAsiInptaMedicalFeeReport(short userPrivilegeAsiInptaMedicalFeeReport) {
     this.userPrivilegeAsiInptaMedicalFeeReport = userPrivilegeAsiInptaMedicalFeeReport;
 }

 @Column(name = "userPrivilegeAsiaInptAccountPaymentReport", nullable = false)
 public short getUserPrivilegeAsiaInptAccountPaymentReport() {
     return this.userPrivilegeAsiaInptAccountPaymentReport;
 }

 public void setUserPrivilegeAsiaInptAccountPaymentReport(short userPrivilegeAsiaInptAccountPaymentReport) {
     this.userPrivilegeAsiaInptAccountPaymentReport = userPrivilegeAsiaInptAccountPaymentReport;
 }

 @Column(name = "userPrivilegeAsiaInptSummarySettleReport", nullable = false)
 public short getUserPrivilegeAsiaInptSummarySettleReport() {
     return this.userPrivilegeAsiaInptSummarySettleReport;
 }

 public void setUserPrivilegeAsiaInptSummarySettleReport(short userPrivilegeAsiaInptSummarySettleReport) {
     this.userPrivilegeAsiaInptSummarySettleReport = userPrivilegeAsiaInptSummarySettleReport;
 }

 @Column(name = "userPrivilegeAsiaInptMedicalFeeReport", nullable = false)
 public short getUserPrivilegeAsiaInptMedicalFeeReport() {
     return this.userPrivilegeAsiaInptMedicalFeeReport;
 }

 public void setUserPrivilegeAsiaInptMedicalFeeReport(short userPrivilegeAsiaInptMedicalFeeReport) {
     this.userPrivilegeAsiaInptMedicalFeeReport = userPrivilegeAsiaInptMedicalFeeReport;
 }

 @Column(name = "userPrivilegePhAxaHcpReport", nullable = false)
 public short getUserPrivilegePhAxaHcpReport() {
     return this.userPrivilegePhAxaHcpReport;
 }

 public void setUserPrivilegePhAxaHcpReport(short userPrivilegePhAxaHcpReport) {
     this.userPrivilegePhAxaHcpReport = userPrivilegePhAxaHcpReport;
 }

 @Column(name = "userPrivilegePhInptClaimBdxReport", nullable = false)
 public short getUserPrivilegePhInptClaimBdxReport() {
     return this.userPrivilegePhInptClaimBdxReport;
 }

 public void setUserPrivilegePhInptClaimBdxReport(short userPrivilegePhInptClaimBdxReport) {
     this.userPrivilegePhInptClaimBdxReport = userPrivilegePhInptClaimBdxReport;
 }

 @Column(name = "userPrivilegePhMabiFileReport", nullable = false)
 public short getUserPrivilegePhMabiFileReport() {
     return this.userPrivilegePhMabiFileReport;
 }

 public void setUserPrivilegePhMabiFileReport(short userPrivilegePhMabiFileReport) {
     this.userPrivilegePhMabiFileReport = userPrivilegePhMabiFileReport;
 }

 @Column(name = "userPrivilegePhSmsFileReport", nullable = false)
 public short getUserPrivilegePhSmsFileReport() {
     return this.userPrivilegePhSmsFileReport;
 }

 public void setUserPrivilegePhSmsFileReport(short userPrivilegePhSmsFileReport) {
     this.userPrivilegePhSmsFileReport = userPrivilegePhSmsFileReport;
 }

 @Column(name = "userPrivilegePhSmsFileGroupReport", nullable = false)
 public short getUserPrivilegePhSmsFileGroupReport() {
     return this.userPrivilegePhSmsFileGroupReport;
 }

 public void setUserPrivilegePhSmsFileGroupReport(short userPrivilegePhSmsFileGroupReport) {
     this.userPrivilegePhSmsFileGroupReport = userPrivilegePhSmsFileGroupReport;
 }

 @Column(name = "userPrivilegePhGhaClaimsReturnReport", nullable = false)
 public short getUserPrivilegePhGhaClaimsReturnReport() {
     return this.userPrivilegePhGhaClaimsReturnReport;
 }

 public void setUserPrivilegePhGhaClaimsReturnReport(short userPrivilegePhGhaClaimsReturnReport) {
     this.userPrivilegePhGhaClaimsReturnReport = userPrivilegePhGhaClaimsReturnReport;
 }

 @Column(name = "userPrivilegeSgAxaHcpReport", nullable = false)
 public short getUserPrivilegeSgAxaHcpReport() {
     return this.userPrivilegeSgAxaHcpReport;
 }

 public void setUserPrivilegeSgAxaHcpReport(short userPrivilegeSgAxaHcpReport) {
     this.userPrivilegeSgAxaHcpReport = userPrivilegeSgAxaHcpReport;
 }

 @Column(name = "userPrivilegeSgAhmStarhubSmsReport", nullable = false)
 public short getUserPrivilegeSgAhmStarhubSmsReport() {
     return this.userPrivilegeSgAhmStarhubSmsReport;
 }

 public void setUserPrivilegeSgAhmStarhubSmsReport(short userPrivilegeSgAhmStarhubSmsReport) {
     this.userPrivilegeSgAhmStarhubSmsReport = userPrivilegeSgAhmStarhubSmsReport;
 }

 @Column(name = "userPrivilegeSgAgiIndonAdmedikaReport", nullable = false)
 public short getUserPrivilegeSgAgiIndonAdmedikaReport() {
     return this.userPrivilegeSgAgiIndonAdmedikaReport;
 }

 public void setUserPrivilegeSgAgiIndonAdmedikaReport(short userPrivilegeSgAgiIndonAdmedikaReport) {
     this.userPrivilegeSgAgiIndonAdmedikaReport = userPrivilegeSgAgiIndonAdmedikaReport;
 }

 @Column(name = "userPrivilegeHkAhmPaReport", nullable = false)
 public short getUserPrivilegeHkAhmPaReport() {
     return this.userPrivilegeHkAhmPaReport;
 }

 public void setUserPrivilegeHkAhmPaReport(short userPrivilegeHkAhmPaReport) {
     this.userPrivilegeHkAhmPaReport = userPrivilegeHkAhmPaReport;
 }

 @Column(name = "userPrivilegeHkInptPendingReport", nullable = false)
 public short getUserPrivilegeHkInptPendingReport() {
     return this.userPrivilegeHkInptPendingReport;
 }

 public void setUserPrivilegeHkInptPendingReport(short userPrivilegeHkInptPendingReport) {
     this.userPrivilegeHkInptPendingReport = userPrivilegeHkInptPendingReport;
 }

 @Column(name = "userPrivilegeHkPruMmCountReport", nullable = false)
 public short getUserPrivilegeHkPruMmCountReport() {
     return this.userPrivilegeHkPruMmCountReport;
 }

 public void setUserPrivilegeHkPruMmCountReport(short userPrivilegeHkPruMmCountReport) {
     this.userPrivilegeHkPruMmCountReport = userPrivilegeHkPruMmCountReport;
 }

 @Column(name = "userPrivilegeHkPruMemReport", nullable = false)
 public short getUserPrivilegeHkPruMemReport() {
     return this.userPrivilegeHkPruMemReport;
 }

 public void setUserPrivilegeHkPruMemReport(short userPrivilegeHkPruMemReport) {
     this.userPrivilegeHkPruMemReport = userPrivilegeHkPruMemReport;
 }

 @Column(name = "userPrivilegeHkPruClaimReturnReport", nullable = false)
 public short getUserPrivilegeHkPruClaimReturnReport() {
     return this.userPrivilegeHkPruClaimReturnReport;
 }

 public void setUserPrivilegeHkPruClaimReturnReport(short userPrivilegeHkPruClaimReturnReport) {
     this.userPrivilegeHkPruClaimReturnReport = userPrivilegeHkPruClaimReturnReport;
 }

 @Column(name = "userPrivilegeHkPruInptPhoneLogReport", nullable = false)
 public short getUserPrivilegeHkPruInptPhoneLogReport() {
     return this.userPrivilegeHkPruInptPhoneLogReport;
 }

 public void setUserPrivilegeHkPruInptPhoneLogReport(short userPrivilegeHkPruInptPhoneLogReport) {
     this.userPrivilegeHkPruInptPhoneLogReport = userPrivilegeHkPruInptPhoneLogReport;
 }

 @Column(name = "userPrivilegeHkAceLifeDailyReport", nullable = false)
 public short getUserPrivilegeHkAceLifeDailyReport() {
     return this.userPrivilegeHkAceLifeDailyReport;
 }

 public void setUserPrivilegeHkAceLifeDailyReport(short userPrivilegeHkAceLifeDailyReport) {
     this.userPrivilegeHkAceLifeDailyReport = userPrivilegeHkAceLifeDailyReport;
 }

 @Column(name = "userPrivilegeHkWempClaimReport", nullable = false)
 public short getUserPrivilegeHkWempClaimReport() {
     return this.userPrivilegeHkWempClaimReport;
 }

 public void setUserPrivilegeHkWempClaimReport(short userPrivilegeHkWempClaimReport) {
     this.userPrivilegeHkWempClaimReport = userPrivilegeHkWempClaimReport;
 }

 @Column(name = "userPrivilegeHkWempG400Report", nullable = false)
 public short getUserPrivilegeHkWempG400report() {
     return this.userPrivilegeHkWempG400report;
 }

 public void setUserPrivilegeHkWempG400report(short userPrivilegeHkWempG400report) {
     this.userPrivilegeHkWempG400report = userPrivilegeHkWempG400report;
 }

 @Column(name = "userPrivilegeHkSunLifeReport", nullable = false)
 public short getUserPrivilegeHkSunLifeReport() {
     return this.userPrivilegeHkSunLifeReport;
 }

 public void setUserPrivilegeHkSunLifeReport(short userPrivilegeHkSunLifeReport) {
     this.userPrivilegeHkSunLifeReport = userPrivilegeHkSunLifeReport;
 }

 @Column(name = "userPrivilegeHkPruOwsClaimPpmReport", nullable = false)
 public short getUserPrivilegeHkPruOwsClaimPpmReport() {
     return this.userPrivilegeHkPruOwsClaimPpmReport;
 }

 public void setUserPrivilegeHkPruOwsClaimPpmReport(short userPrivilegeHkPruOwsClaimPpmReport) {
     this.userPrivilegeHkPruOwsClaimPpmReport = userPrivilegeHkPruOwsClaimPpmReport;
 }

 @Column(name = "userPrivilegeHkInptClaimsBdxReport", nullable = false)
 public short getUserPrivilegeHkInptClaimsBdxReport() {
     return this.userPrivilegeHkInptClaimsBdxReport;
 }

 public void setUserPrivilegeHkInptClaimsBdxReport(short userPrivilegeHkInptClaimsBdxReport) {
     this.userPrivilegeHkInptClaimsBdxReport = userPrivilegeHkInptClaimsBdxReport;
 }

 @Column(name = "userPrivilegeHkAppointmentBookingReport", nullable = false)
 public short getUserPrivilegeHkAppointmentBookingReport() {
     return this.userPrivilegeHkAppointmentBookingReport;
 }

 public void setUserPrivilegeHkAppointmentBookingReport(short userPrivilegeHkAppointmentBookingReport) {
     this.userPrivilegeHkAppointmentBookingReport = userPrivilegeHkAppointmentBookingReport;
 }

 @Column(name = "userPrivilegeHkLetterLabelPrintReport", nullable = false)
 public short getUserPrivilegeHkLetterLabelPrintReport() {
     return this.userPrivilegeHkLetterLabelPrintReport;
 }

 public void setUserPrivilegeHkLetterLabelPrintReport(short userPrivilegeHkLetterLabelPrintReport) {
     this.userPrivilegeHkLetterLabelPrintReport = userPrivilegeHkLetterLabelPrintReport;
 }

 @Column(name = "userPrivilegeHkMembershipCardPrintReport", nullable = false)
 public short getUserPrivilegeHkMembershipCardPrintReport() {
     return this.userPrivilegeHkMembershipCardPrintReport;
 }

 public void setUserPrivilegeHkMembershipCardPrintReport(short userPrivilegeHkMembershipCardPrintReport) {
     this.userPrivilegeHkMembershipCardPrintReport = userPrivilegeHkMembershipCardPrintReport;
 }

 @Column(name = "userPrivilegeHkPpmClaimLettersReport", nullable = false)
 public short getUserPrivilegeHkPpmClaimLettersReport() {
     return this.userPrivilegeHkPpmClaimLettersReport;
 }

 public void setUserPrivilegeHkPpmClaimLettersReport(short userPrivilegeHkPpmClaimLettersReport) {
     this.userPrivilegeHkPpmClaimLettersReport = userPrivilegeHkPpmClaimLettersReport;
 }

 @Column(name = "userPrivilegeHkPpmControlFileReport", nullable = false)
 public short getUserPrivilegeHkPpmControlFileReport() {
     return this.userPrivilegeHkPpmControlFileReport;
 }

 public void setUserPrivilegeHkPpmControlFileReport(short userPrivilegeHkPpmControlFileReport) {
     this.userPrivilegeHkPpmControlFileReport = userPrivilegeHkPpmControlFileReport;
 }

 @Column(name = "userPrivilegeHkPruInptClaimRefReport", nullable = false)
 public short getUserPrivilegeHkPruInptClaimRefReport() {
     return this.userPrivilegeHkPruInptClaimRefReport;
 }

 public void setUserPrivilegeHkPruInptClaimRefReport(short userPrivilegeHkPruInptClaimRefReport) {
     this.userPrivilegeHkPruInptClaimRefReport = userPrivilegeHkPruInptClaimRefReport;
 }

 @Column(name = "userPrivilegeHkPruInptPendingFileReport", nullable = false)
 public short getUserPrivilegeHkPruInptPendingFileReport() {
     return this.userPrivilegeHkPruInptPendingFileReport;
 }

 public void setUserPrivilegeHkPruInptPendingFileReport(short userPrivilegeHkPruInptPendingFileReport) {
     this.userPrivilegeHkPruInptPendingFileReport = userPrivilegeHkPruInptPendingFileReport;
 }

 @Column(name = "userPrivilegeCnUnitedEfileReport", nullable = false)
 public short getUserPrivilegeCnUnitedEfileReport() {
     return this.userPrivilegeCnUnitedEfileReport;
 }

 public void setUserPrivilegeCnUnitedEfileReport(short userPrivilegeCnUnitedEfileReport) {
     this.userPrivilegeCnUnitedEfileReport = userPrivilegeCnUnitedEfileReport;
 }

 @Column(name = "userPrivilegeCnStudentCareInptClaimBdxReport", nullable = false)
 public short getUserPrivilegeCnStudentCareInptClaimBdxReport() {
     return this.userPrivilegeCnStudentCareInptClaimBdxReport;
 }

 public void setUserPrivilegeCnStudentCareInptClaimBdxReport(short userPrivilegeCnStudentCareInptClaimBdxReport) {
     this.userPrivilegeCnStudentCareInptClaimBdxReport = userPrivilegeCnStudentCareInptClaimBdxReport;
 }

 @Column(name = "userPrivilegeThKtaxaPaymentBankReport", nullable = false)
 public short getUserPrivilegeThKtaxaPaymentBankReport() {
     return this.userPrivilegeThKtaxaPaymentBankReport;
 }

 public void setUserPrivilegeThKtaxaPaymentBankReport(short userPrivilegeThKtaxaPaymentBankReport) {
     this.userPrivilegeThKtaxaPaymentBankReport = userPrivilegeThKtaxaPaymentBankReport;
 }

 @Column(name = "userPrivilegeThAgiPaymentBankReport", nullable = false)
 public short getUserPrivilegeThAgiPaymentBankReport() {
     return this.userPrivilegeThAgiPaymentBankReport;
 }

 public void setUserPrivilegeThAgiPaymentBankReport(short userPrivilegeThAgiPaymentBankReport) {
     this.userPrivilegeThAgiPaymentBankReport = userPrivilegeThAgiPaymentBankReport;
 }

 @Column(name = "userPrivilegeThKtaxaEmailSmsReport", nullable = false)
 public short getUserPrivilegeThKtaxaEmailSmsReport() {
     return this.userPrivilegeThKtaxaEmailSmsReport;
 }

 public void setUserPrivilegeThKtaxaEmailSmsReport(short userPrivilegeThKtaxaEmailSmsReport) {
     this.userPrivilegeThKtaxaEmailSmsReport = userPrivilegeThKtaxaEmailSmsReport;
 }

 @Column(name = "userPrivilegeThKtaxaActuarial1Report", nullable = false)
 public short getUserPrivilegeThKtaxaActuarial1report() {
     return this.userPrivilegeThKtaxaActuarial1report;
 }

 public void setUserPrivilegeThKtaxaActuarial1report(short userPrivilegeThKtaxaActuarial1report) {
     this.userPrivilegeThKtaxaActuarial1report = userPrivilegeThKtaxaActuarial1report;
 }

 @Column(name = "userPrivilegeThKtaxaActuarial2Report", nullable = false)
 public short getUserPrivilegeThKtaxaActuarial2report() {
     return this.userPrivilegeThKtaxaActuarial2report;
 }

 public void setUserPrivilegeThKtaxaActuarial2report(short userPrivilegeThKtaxaActuarial2report) {
     this.userPrivilegeThKtaxaActuarial2report = userPrivilegeThKtaxaActuarial2report;
 }

 @Column(name = "userPrivilegeThKtaxaChequeAutoRefundReport", nullable = false)
 public short getUserPrivilegeThKtaxaChequeAutoRefundReport() {
     return this.userPrivilegeThKtaxaChequeAutoRefundReport;
 }

 public void setUserPrivilegeThKtaxaChequeAutoRefundReport(short userPrivilegeThKtaxaChequeAutoRefundReport) {
     this.userPrivilegeThKtaxaChequeAutoRefundReport = userPrivilegeThKtaxaChequeAutoRefundReport;
 }

 @Column(name = "userPrivilegeThKtaxaSlaPreFaxReport", nullable = false)
 public short getUserPrivilegeThKtaxaSlaPreFaxReport() {
     return this.userPrivilegeThKtaxaSlaPreFaxReport;
 }

 public void setUserPrivilegeThKtaxaSlaPreFaxReport(short userPrivilegeThKtaxaSlaPreFaxReport) {
     this.userPrivilegeThKtaxaSlaPreFaxReport = userPrivilegeThKtaxaSlaPreFaxReport;
 }

 @Column(name = "userPrivilegeThKtaxaSlaDirectReport", nullable = false)
 public short getUserPrivilegeThKtaxaSlaDirectReport() {
     return this.userPrivilegeThKtaxaSlaDirectReport;
 }

 public void setUserPrivilegeThKtaxaSlaDirectReport(short userPrivilegeThKtaxaSlaDirectReport) {
     this.userPrivilegeThKtaxaSlaDirectReport = userPrivilegeThKtaxaSlaDirectReport;
 }

 @Column(name = "userPrivilegeThKtaxaSmsMonthlyFeeReport", nullable = false)
 public short getUserPrivilegeThKtaxaSmsMonthlyFeeReport() {
     return this.userPrivilegeThKtaxaSmsMonthlyFeeReport;
 }

 public void setUserPrivilegeThKtaxaSmsMonthlyFeeReport(short userPrivilegeThKtaxaSmsMonthlyFeeReport) {
     this.userPrivilegeThKtaxaSmsMonthlyFeeReport = userPrivilegeThKtaxaSmsMonthlyFeeReport;
 }

 @Column(name = "userPrivilegeThKtaxaClaimPaymentReport", nullable = false)
 public short getUserPrivilegeThKtaxaClaimPaymentReport() {
     return this.userPrivilegeThKtaxaClaimPaymentReport;
 }

 public void setUserPrivilegeThKtaxaClaimPaymentReport(short userPrivilegeThKtaxaClaimPaymentReport) {
     this.userPrivilegeThKtaxaClaimPaymentReport = userPrivilegeThKtaxaClaimPaymentReport;
 }

 @Column(name = "userPrivilegeThKtaxaActuarialPaymentDailyReport", nullable = false)
 public short getUserPrivilegeThKtaxaActuarialPaymentDailyReport() {
     return this.userPrivilegeThKtaxaActuarialPaymentDailyReport;
 }

 public void setUserPrivilegeThKtaxaActuarialPaymentDailyReport(short userPrivilegeThKtaxaActuarialPaymentDailyReport) {
     this.userPrivilegeThKtaxaActuarialPaymentDailyReport = userPrivilegeThKtaxaActuarialPaymentDailyReport;
 }

 @Column(name = "userPrivilegeThKtaxaPaymentOutstandingReport", nullable = false)
 public short getUserPrivilegeThKtaxaPaymentOutstandingReport() {
     return this.userPrivilegeThKtaxaPaymentOutstandingReport;
 }

 public void setUserPrivilegeThKtaxaPaymentOutstandingReport(short userPrivilegeThKtaxaPaymentOutstandingReport) {
     this.userPrivilegeThKtaxaPaymentOutstandingReport = userPrivilegeThKtaxaPaymentOutstandingReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbPolicyMasterReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbPolicyMasterReport() {
     return this.userPrivilegeThKtaxaCdbPolicyMasterReport;
 }

 public void setUserPrivilegeThKtaxaCdbPolicyMasterReport(short userPrivilegeThKtaxaCdbPolicyMasterReport) {
     this.userPrivilegeThKtaxaCdbPolicyMasterReport = userPrivilegeThKtaxaCdbPolicyMasterReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbInsuredDetailsReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbInsuredDetailsReport() {
     return this.userPrivilegeThKtaxaCdbInsuredDetailsReport;
 }

 public void setUserPrivilegeThKtaxaCdbInsuredDetailsReport(short userPrivilegeThKtaxaCdbInsuredDetailsReport) {
     this.userPrivilegeThKtaxaCdbInsuredDetailsReport = userPrivilegeThKtaxaCdbInsuredDetailsReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbServiceProviderEnReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbServiceProviderEnReport() {
     return this.userPrivilegeThKtaxaCdbServiceProviderEnReport;
 }

 public void setUserPrivilegeThKtaxaCdbServiceProviderEnReport(short userPrivilegeThKtaxaCdbServiceProviderEnReport) {
     this.userPrivilegeThKtaxaCdbServiceProviderEnReport = userPrivilegeThKtaxaCdbServiceProviderEnReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbServiceProviderThReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbServiceProviderThReport() {
     return this.userPrivilegeThKtaxaCdbServiceProviderThReport;
 }

 public void setUserPrivilegeThKtaxaCdbServiceProviderThReport(short userPrivilegeThKtaxaCdbServiceProviderThReport) {
     this.userPrivilegeThKtaxaCdbServiceProviderThReport = userPrivilegeThKtaxaCdbServiceProviderThReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbClaimStatusReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbClaimStatusReport() {
     return this.userPrivilegeThKtaxaCdbClaimStatusReport;
 }

 public void setUserPrivilegeThKtaxaCdbClaimStatusReport(short userPrivilegeThKtaxaCdbClaimStatusReport) {
     this.userPrivilegeThKtaxaCdbClaimStatusReport = userPrivilegeThKtaxaCdbClaimStatusReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbBenefitCodeMappingReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbBenefitCodeMappingReport() {
     return this.userPrivilegeThKtaxaCdbBenefitCodeMappingReport;
 }

 public void setUserPrivilegeThKtaxaCdbBenefitCodeMappingReport(short userPrivilegeThKtaxaCdbBenefitCodeMappingReport) {
     this.userPrivilegeThKtaxaCdbBenefitCodeMappingReport = userPrivilegeThKtaxaCdbBenefitCodeMappingReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbBenefitMasterReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbBenefitMasterReport() {
     return this.userPrivilegeThKtaxaCdbBenefitMasterReport;
 }

 public void setUserPrivilegeThKtaxaCdbBenefitMasterReport(short userPrivilegeThKtaxaCdbBenefitMasterReport) {
     this.userPrivilegeThKtaxaCdbBenefitMasterReport = userPrivilegeThKtaxaCdbBenefitMasterReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbClaimHeaderReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbClaimHeaderReport() {
     return this.userPrivilegeThKtaxaCdbClaimHeaderReport;
 }

 public void setUserPrivilegeThKtaxaCdbClaimHeaderReport(short userPrivilegeThKtaxaCdbClaimHeaderReport) {
     this.userPrivilegeThKtaxaCdbClaimHeaderReport = userPrivilegeThKtaxaCdbClaimHeaderReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbClaimDetailDecisionReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbClaimDetailDecisionReport() {
     return this.userPrivilegeThKtaxaCdbClaimDetailDecisionReport;
 }

 public void setUserPrivilegeThKtaxaCdbClaimDetailDecisionReport(short userPrivilegeThKtaxaCdbClaimDetailDecisionReport) {
     this.userPrivilegeThKtaxaCdbClaimDetailDecisionReport = userPrivilegeThKtaxaCdbClaimDetailDecisionReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbClaimDetailPaymentReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbClaimDetailPaymentReport() {
     return this.userPrivilegeThKtaxaCdbClaimDetailPaymentReport;
 }

 public void setUserPrivilegeThKtaxaCdbClaimDetailPaymentReport(short userPrivilegeThKtaxaCdbClaimDetailPaymentReport) {
     this.userPrivilegeThKtaxaCdbClaimDetailPaymentReport = userPrivilegeThKtaxaCdbClaimDetailPaymentReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbPaymentDetailsReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbPaymentDetailsReport() {
     return this.userPrivilegeThKtaxaCdbPaymentDetailsReport;
 }

 public void setUserPrivilegeThKtaxaCdbPaymentDetailsReport(short userPrivilegeThKtaxaCdbPaymentDetailsReport) {
     this.userPrivilegeThKtaxaCdbPaymentDetailsReport = userPrivilegeThKtaxaCdbPaymentDetailsReport;
 }

 @Column(name = "userPrivilegeThKtaxaCdbProductMasterReport", nullable = false)
 public short getUserPrivilegeThKtaxaCdbProductMasterReport() {
     return this.userPrivilegeThKtaxaCdbProductMasterReport;
 }

 public void setUserPrivilegeThKtaxaCdbProductMasterReport(short userPrivilegeThKtaxaCdbProductMasterReport) {
     this.userPrivilegeThKtaxaCdbProductMasterReport = userPrivilegeThKtaxaCdbProductMasterReport;
 }

 @Column(name = "userPrivilegeThAgiClaimHistoryForRenewalReport", nullable = false)
 public short getUserPrivilegeThAgiClaimHistoryForRenewalReport() {
     return this.userPrivilegeThAgiClaimHistoryForRenewalReport;
 }

 public void setUserPrivilegeThAgiClaimHistoryForRenewalReport(short userPrivilegeThAgiClaimHistoryForRenewalReport) {
     this.userPrivilegeThAgiClaimHistoryForRenewalReport = userPrivilegeThAgiClaimHistoryForRenewalReport;
 }

 @Column(name = "userPrivilegeThAgiSlaFaxClaimReport", nullable = false)
 public short getUserPrivilegeThAgiSlaFaxClaimReport() {
     return this.userPrivilegeThAgiSlaFaxClaimReport;
 }

 public void setUserPrivilegeThAgiSlaFaxClaimReport(short userPrivilegeThAgiSlaFaxClaimReport) {
     this.userPrivilegeThAgiSlaFaxClaimReport = userPrivilegeThAgiSlaFaxClaimReport;
 }

 @Column(name = "userPrivilegeThAgiSlaCreditDirectClaimReport", nullable = false)
 public short getUserPrivilegeThAgiSlaCreditDirectClaimReport() {
     return this.userPrivilegeThAgiSlaCreditDirectClaimReport;
 }

 public void setUserPrivilegeThAgiSlaCreditDirectClaimReport(short userPrivilegeThAgiSlaCreditDirectClaimReport) {
     this.userPrivilegeThAgiSlaCreditDirectClaimReport = userPrivilegeThAgiSlaCreditDirectClaimReport;
 }

 @Column(name = "userPrivilegeThAgiInptDetailsReport", nullable = false)
 public short getUserPrivilegeThAgiInptDetailsReport() {
     return this.userPrivilegeThAgiInptDetailsReport;
 }

 public void setUserPrivilegeThAgiInptDetailsReport(short userPrivilegeThAgiInptDetailsReport) {
     this.userPrivilegeThAgiInptDetailsReport = userPrivilegeThAgiInptDetailsReport;
 }

 @Column(name = "userPrivilegeThAgiReceivedDateReport", nullable = false)
 public short getUserPrivilegeThAgiReceivedDateReport() {
     return this.userPrivilegeThAgiReceivedDateReport;
 }

 public void setUserPrivilegeThAgiReceivedDateReport(short userPrivilegeThAgiReceivedDateReport) {
     this.userPrivilegeThAgiReceivedDateReport = userPrivilegeThAgiReceivedDateReport;
 }

 @Column(name = "userPrivilegeThAgiClaimPaymentReport", nullable = false)
 public short getUserPrivilegeThAgiClaimPaymentReport() {
     return this.userPrivilegeThAgiClaimPaymentReport;
 }

 public void setUserPrivilegeThAgiClaimPaymentReport(short userPrivilegeThAgiClaimPaymentReport) {
     this.userPrivilegeThAgiClaimPaymentReport = userPrivilegeThAgiClaimPaymentReport;
 }

 @Column(name = "userPrivilegeThAgiClaimRepaymentReport", nullable = false)
 public short getUserPrivilegeThAgiClaimRepaymentReport() {
     return this.userPrivilegeThAgiClaimRepaymentReport;
 }

 public void setUserPrivilegeThAgiClaimRepaymentReport(short userPrivilegeThAgiClaimRepaymentReport) {
     this.userPrivilegeThAgiClaimRepaymentReport = userPrivilegeThAgiClaimRepaymentReport;
 }

 @Column(name = "userPrivilegeThAgiFaxClaimSummaryReport", nullable = false)
 public short getUserPrivilegeThAgiFaxClaimSummaryReport() {
     return this.userPrivilegeThAgiFaxClaimSummaryReport;
 }

 public void setUserPrivilegeThAgiFaxClaimSummaryReport(short userPrivilegeThAgiFaxClaimSummaryReport) {
     this.userPrivilegeThAgiFaxClaimSummaryReport = userPrivilegeThAgiFaxClaimSummaryReport;
 }

 @Column(name = "userPrivilegeThAathSlaFaxClaimReport", nullable = false)
 public short getUserPrivilegeThAathSlaFaxClaimReport() {
     return this.userPrivilegeThAathSlaFaxClaimReport;
 }

 public void setUserPrivilegeThAathSlaFaxClaimReport(short userPrivilegeThAathSlaFaxClaimReport) {
     this.userPrivilegeThAathSlaFaxClaimReport = userPrivilegeThAathSlaFaxClaimReport;
 }

 @Column(name = "userPrivilegeThAathSlaPreCerRegisterReport", nullable = false)
 public short getUserPrivilegeThAathSlaPreCerRegisterReport() {
     return this.userPrivilegeThAathSlaPreCerRegisterReport;
 }

 public void setUserPrivilegeThAathSlaPreCerRegisterReport(short userPrivilegeThAathSlaPreCerRegisterReport) {
     this.userPrivilegeThAathSlaPreCerRegisterReport = userPrivilegeThAathSlaPreCerRegisterReport;
 }

 @Column(name = "userPrivilegeThAathC1IeReport", nullable = false)
 public short getUserPrivilegeThAathC1ieReport() {
     return this.userPrivilegeThAathC1ieReport;
 }

 public void setUserPrivilegeThAathC1ieReport(short userPrivilegeThAathC1ieReport) {
     this.userPrivilegeThAathC1ieReport = userPrivilegeThAathC1ieReport;
 }
 
 @Column(name = "userPrivilegeFnAlimTextFileReport", nullable = false)
 public short getUserPrivilegeFnAlimTextFileReport() {
     return this.userPrivilegeFnAlimTextFileReport;
 }

 public void setUserPrivilegeFnAlimTextFileReport(short userPrivilegeFnAlimTextFileReport) {
     this.userPrivilegeFnAlimTextFileReport = userPrivilegeFnAlimTextFileReport;
 }

 @Column(name = "userPrivilegeApiReqToken", nullable = false)
 public short getUserPrivilegeApiReqToken() {
     return this.userPrivilegeApiReqToken;
 }

 public void setUserPrivilegeApiReqToken(short userPrivilegeApiReqToken) {
     this.userPrivilegeApiReqToken = userPrivilegeApiReqToken;
 }

 @Column(name = "userPrivilegeApiChgPw", nullable = false)
 public short getUserPrivilegeApiChgPw() {
     return this.userPrivilegeApiChgPw;
 }

 public void setUserPrivilegeApiChgPw(short userPrivilegeApiChgPw) {
     this.userPrivilegeApiChgPw = userPrivilegeApiChgPw;
 }

 @Column(name = "userPrivilegeApiLostPw", nullable = false)
 public short getUserPrivilegeApiLostPw() {
     return this.userPrivilegeApiLostPw;
 }

 public void setUserPrivilegeApiLostPw(short userPrivilegeApiLostPw) {
     this.userPrivilegeApiLostPw = userPrivilegeApiLostPw;
 }

 @Column(name = "userPrivilegeApiSignUp", nullable = false)
 public short getUserPrivilegeApiSignUp() {
     return this.userPrivilegeApiSignUp;
 }

 public void setUserPrivilegeApiSignUp(short userPrivilegeApiSignUp) {
     this.userPrivilegeApiSignUp = userPrivilegeApiSignUp;
 }

 @Column(name = "userPrivilegeApiMemberInit", nullable = false)
 public short getUserPrivilegeApiMemberInit() {
     return this.userPrivilegeApiMemberInit;
 }

 public void setUserPrivilegeApiMemberInit(short userPrivilegeApiMemberInit) {
     this.userPrivilegeApiMemberInit = userPrivilegeApiMemberInit;
 }

 @Column(name = "userPrivilegeApiReqInptPlan", nullable = false)
 public short getUserPrivilegeApiReqInptPlan() {
     return this.userPrivilegeApiReqInptPlan;
 }

 public void setUserPrivilegeApiReqInptPlan(short userPrivilegeApiReqInptPlan) {
     this.userPrivilegeApiReqInptPlan = userPrivilegeApiReqInptPlan;
 }

 @Column(name = "userPrivilegeApiReqInptCase", nullable = false)
 public short getUserPrivilegeApiReqInptCase() {
     return this.userPrivilegeApiReqInptCase;
 }

 public void setUserPrivilegeApiReqInptCase(short userPrivilegeApiReqInptCase) {
     this.userPrivilegeApiReqInptCase = userPrivilegeApiReqInptCase;
 }

 @Column(name = "userPrivilegeApiReqInptCases", nullable = false)
 public short getUserPrivilegeApiReqInptCases() {
     return this.userPrivilegeApiReqInptCases;
 }

 public void setUserPrivilegeApiReqInptCases(short userPrivilegeApiReqInptCases) {
     this.userPrivilegeApiReqInptCases = userPrivilegeApiReqInptCases;
 }

 @Column(name = "userPrivilegeApiCreateInptCase", nullable = false)
 public short getUserPrivilegeApiCreateInptCase() {
     return this.userPrivilegeApiCreateInptCase;
 }

 public void setUserPrivilegeApiCreateInptCase(short userPrivilegeApiCreateInptCase) {
     this.userPrivilegeApiCreateInptCase = userPrivilegeApiCreateInptCase;
 }

 @Column(name = "userPrivilegeApiReqOutptPlan", nullable = false)
 public short getUserPrivilegeApiReqOutptPlan() {
     return this.userPrivilegeApiReqOutptPlan;
 }

 public void setUserPrivilegeApiReqOutptPlan(short userPrivilegeApiReqOutptPlan) {
     this.userPrivilegeApiReqOutptPlan = userPrivilegeApiReqOutptPlan;
 }

 @Column(name = "userPrivilegeApiReqOutptClaim", nullable = false)
 public short getUserPrivilegeApiReqOutptClaim() {
     return this.userPrivilegeApiReqOutptClaim;
 }

 public void setUserPrivilegeApiReqOutptClaim(short userPrivilegeApiReqOutptClaim) {
     this.userPrivilegeApiReqOutptClaim = userPrivilegeApiReqOutptClaim;
 }

 @Column(name = "userPrivilegeApiReqOutptClaims", nullable = false)
 public short getUserPrivilegeApiReqOutptClaims() {
     return this.userPrivilegeApiReqOutptClaims;
 }

 public void setUserPrivilegeApiReqOutptClaims(short userPrivilegeApiReqOutptClaims) {
     this.userPrivilegeApiReqOutptClaims = userPrivilegeApiReqOutptClaims;
 }

 @Column(name = "userPrivilegeApiMemberValidate", nullable = false)
 public short getUserPrivilegeApiMemberValidate() {
     return this.userPrivilegeApiMemberValidate;
 }

 public void setUserPrivilegeApiMemberValidate(short userPrivilegeApiMemberValidate) {
     this.userPrivilegeApiMemberValidate = userPrivilegeApiMemberValidate;
 }

 @Column(name = "userPrivilegeApiClaimSubmit", nullable = false)
 public short getUserPrivilegeApiClaimSubmit() {
     return this.userPrivilegeApiClaimSubmit;
 }

 public void setUserPrivilegeApiClaimSubmit(short userPrivilegeApiClaimSubmit) {
     this.userPrivilegeApiClaimSubmit = userPrivilegeApiClaimSubmit;
 }

 @Column(name = "userPrivilegeApiCreateOutptClaimDraft", nullable = false)
 public short getUserPrivilegeApiCreateOutptClaimDraft() {
     return this.userPrivilegeApiCreateOutptClaimDraft;
 }

 public void setUserPrivilegeApiCreateOutptClaimDraft(short userPrivilegeApiCreateOutptClaimDraft) {
     this.userPrivilegeApiCreateOutptClaimDraft = userPrivilegeApiCreateOutptClaimDraft;
 }

 @Column(name = "userPrivilegeApiSearchProvider", nullable = false)
 public short getUserPrivilegeApiSearchProvider() {
     return this.userPrivilegeApiSearchProvider;
 }

 public void setUserPrivilegeApiSearchProvider(short userPrivilegeApiSearchProvider) {
     this.userPrivilegeApiSearchProvider = userPrivilegeApiSearchProvider;
 }

 @Column(name = "userPrivilegeApiQrSearchProvider", nullable = false)
 public short getUserPrivilegeApiQrSearchProvider() {
     return this.userPrivilegeApiQrSearchProvider;
 }

 public void setUserPrivilegeApiQrSearchProvider(short userPrivilegeApiQrSearchProvider) {
     this.userPrivilegeApiQrSearchProvider = userPrivilegeApiQrSearchProvider;
 }

 @Column(name = "userPrivilegeApiReqCountry", nullable = false)
 public short getUserPrivilegeApiReqCountry() {
     return this.userPrivilegeApiReqCountry;
 }

 public void setUserPrivilegeApiReqCountry(short userPrivilegeApiReqCountry) {
     this.userPrivilegeApiReqCountry = userPrivilegeApiReqCountry;
 }

 @Column(name = "userPrivilegeApiSubmitFeedback", nullable = false)
 public short getUserPrivilegeApiSubmitFeedback() {
     return this.userPrivilegeApiSubmitFeedback;
 }

 public void setUserPrivilegeApiSubmitFeedback(short userPrivilegeApiSubmitFeedback) {
     this.userPrivilegeApiSubmitFeedback = userPrivilegeApiSubmitFeedback;
 }

 @Column(name = "userPrivilegeApiReqHafStat", nullable = false)
 public short getUserPrivilegeApiReqHafStat() {
     return this.userPrivilegeApiReqHafStat;
 }

 public void setUserPrivilegeApiReqHafStat(short userPrivilegeApiReqHafStat) {
     this.userPrivilegeApiReqHafStat = userPrivilegeApiReqHafStat;
 }

 @Column(name = "userPrivilegeApiReqLog", nullable = false)
 public short getUserPrivilegeApiReqLog() {
     return this.userPrivilegeApiReqLog;
 }

 public void setUserPrivilegeApiReqLog(short userPrivilegeApiReqLog) {
     this.userPrivilegeApiReqLog = userPrivilegeApiReqLog;
 }

 @Column(name = "userPrivilegeApiReqImpp", nullable = false)
 public short getUserPrivilegeApiReqImpp() {
     return this.userPrivilegeApiReqImpp;
 }

 public void setUserPrivilegeApiReqImpp(short userPrivilegeApiReqImpp) {
     this.userPrivilegeApiReqImpp = userPrivilegeApiReqImpp;
 }

 @Column(name = "userPrivilegeBencomKey", nullable = false)
 public short getUserPrivilegeBencomKey() {
     return this.userPrivilegeBencomKey;
 }

 public void setUserPrivilegeBencomKey(short userPrivilegeBencomKey) {
     this.userPrivilegeBencomKey = userPrivilegeBencomKey;
 }

 @Column(name = "userPrivilegeBencom", nullable = false)
 public short getUserPrivilegeBencom() {
     return this.userPrivilegeBencom;
 }

 public void setUserPrivilegeBencom(short userPrivilegeBencom) {
     this.userPrivilegeBencom = userPrivilegeBencom;
 }

 @Column(name = "userPrivilegeEclaimDocUpload", nullable = false)
 public short getUserPrivilegeEclaimDocUpload() {
     return this.userPrivilegeEclaimDocUpload;
 }

 public void setUserPrivilegeEclaimDocUpload(short userPrivilegeEclaimDocUpload) {
     this.userPrivilegeEclaimDocUpload = userPrivilegeEclaimDocUpload;
 }
 
 @Column(name = "userPrivilegeMyOutptStmbTxtReport", nullable = false)
 public short getUserPrivilegeMyOutptStmbTxtReport() {
     return this.userPrivilegeMyOutptStmbTxtReport;
 }

 public void setUserPrivilegeMyOutptStmbTxtReport(short userPrivilegeMyOutptStmbTxtReport) {
     this.userPrivilegeMyOutptStmbTxtReport = userPrivilegeMyOutptStmbTxtReport;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "userPrivilege")
 public Set<User> getUsers() {
     return this.users;
 }

 public void setUsers(Set<User> users) {
     this.users = users;
 }

}
