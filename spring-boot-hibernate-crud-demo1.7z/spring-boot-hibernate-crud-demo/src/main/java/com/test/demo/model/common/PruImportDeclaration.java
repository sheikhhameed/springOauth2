package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.inpt.InptPolicy;

/**
 * This is pruImportDeclaration class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="pru_import_declaration"
 ,catalog="marcmy"
)
public class PruImportDeclaration  implements java.io.Serializable {


  private Integer pruImpDecId;
  private InptPolicy inptPolicy;
  private Integer pruImpDecCreatedBy;
  private Date pruImpDecCreatedDate;
  private Integer pruImpDecLastEdittedBy;
  private Date pruImpDecLastEdittedDate;
  private String pruImpDecRecordType;
  private String pruImpDecPolicyNum;
  private String pruImpDecMovementCode;
  private String pruImpDecBenefitCode;
  private Date pruImpDecMovementEffDate;
  private Date pruImpDecRegDate;
  private Date pruImpDecStatChangeDate;
  private String pruImpDecMovementStat;
  private String pruImpDecMovementMsg;
  private String pruImpDecRecordEnd;

 public PruImportDeclaration() {
 }

	
 public PruImportDeclaration(String pruImpDecRecordType, String pruImpDecMovementCode, Date pruImpDecMovementEffDate, Date pruImpDecRegDate, Date pruImpDecStatChangeDate, String pruImpDecMovementStat, String pruImpDecRecordEnd) {
     this.pruImpDecRecordType = pruImpDecRecordType;
     this.pruImpDecMovementCode = pruImpDecMovementCode;
     this.pruImpDecMovementEffDate = pruImpDecMovementEffDate;
     this.pruImpDecRegDate = pruImpDecRegDate;
     this.pruImpDecStatChangeDate = pruImpDecStatChangeDate;
     this.pruImpDecMovementStat = pruImpDecMovementStat;
     this.pruImpDecRecordEnd = pruImpDecRecordEnd;
 }
 public PruImportDeclaration(InptPolicy inptPolicy, Integer pruImpDecCreatedBy, Date pruImpDecCreatedDate, Integer pruImpDecLastEdittedBy, Date pruImpDecLastEdittedDate, String pruImpDecRecordType, String pruImpDecPolicyNum, String pruImpDecMovementCode, String pruImpDecBenefitCode, Date pruImpDecMovementEffDate, Date pruImpDecRegDate, Date pruImpDecStatChangeDate, String pruImpDecMovementStat, String pruImpDecMovementMsg, String pruImpDecRecordEnd) {
    this.inptPolicy = inptPolicy;
    this.pruImpDecCreatedBy = pruImpDecCreatedBy;
    this.pruImpDecCreatedDate = pruImpDecCreatedDate;
    this.pruImpDecLastEdittedBy = pruImpDecLastEdittedBy;
    this.pruImpDecLastEdittedDate = pruImpDecLastEdittedDate;
    this.pruImpDecRecordType = pruImpDecRecordType;
    this.pruImpDecPolicyNum = pruImpDecPolicyNum;
    this.pruImpDecMovementCode = pruImpDecMovementCode;
    this.pruImpDecBenefitCode = pruImpDecBenefitCode;
    this.pruImpDecMovementEffDate = pruImpDecMovementEffDate;
    this.pruImpDecRegDate = pruImpDecRegDate;
    this.pruImpDecStatChangeDate = pruImpDecStatChangeDate;
    this.pruImpDecMovementStat = pruImpDecMovementStat;
    this.pruImpDecMovementMsg = pruImpDecMovementMsg;
    this.pruImpDecRecordEnd = pruImpDecRecordEnd;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="pruImpDecId", unique=true, nullable=false)
 public Integer getPruImpDecId() {
     return this.pruImpDecId;
 }
 
 public void setPruImpDecId(Integer pruImpDecId) {
     this.pruImpDecId = pruImpDecId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="pruImpDecInptPolicyId")
 public InptPolicy getInptPolicy() {
     return this.inptPolicy;
 }
 
 public void setInptPolicy(InptPolicy inptPolicy) {
     this.inptPolicy = inptPolicy;
 }

 
 @Column(name="pruImpDecCreatedBy")
 public Integer getPruImpDecCreatedBy() {
     return this.pruImpDecCreatedBy;
 }
 
 public void setPruImpDecCreatedBy(Integer pruImpDecCreatedBy) {
     this.pruImpDecCreatedBy = pruImpDecCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="pruImpDecCreatedDate", length=19)
 public Date getPruImpDecCreatedDate() {
     return this.pruImpDecCreatedDate;
 }
 
 public void setPruImpDecCreatedDate(Date pruImpDecCreatedDate) {
     this.pruImpDecCreatedDate = pruImpDecCreatedDate;
 }

 
 @Column(name="pruImpDecLastEdittedBy")
 public Integer getPruImpDecLastEdittedBy() {
     return this.pruImpDecLastEdittedBy;
 }
 
 public void setPruImpDecLastEdittedBy(Integer pruImpDecLastEdittedBy) {
     this.pruImpDecLastEdittedBy = pruImpDecLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="pruImpDecLastEdittedDate", length=19)
 public Date getPruImpDecLastEdittedDate() {
     return this.pruImpDecLastEdittedDate;
 }
 
 public void setPruImpDecLastEdittedDate(Date pruImpDecLastEdittedDate) {
     this.pruImpDecLastEdittedDate = pruImpDecLastEdittedDate;
 }

 
 @Column(name="pruImpDecRecordType", nullable=false, length=1)
 public String getPruImpDecRecordType() {
     return this.pruImpDecRecordType;
 }
 
 public void setPruImpDecRecordType(String pruImpDecRecordType) {
     this.pruImpDecRecordType = pruImpDecRecordType;
 }

 
 @Column(name="pruImpDecPolicyNum", length=12)
 public String getPruImpDecPolicyNum() {
     return this.pruImpDecPolicyNum;
 }
 
 public void setPruImpDecPolicyNum(String pruImpDecPolicyNum) {
     this.pruImpDecPolicyNum = pruImpDecPolicyNum;
 }

 
 @Column(name="pruImpDecMovementCode", nullable=false, length=200)
 public String getPruImpDecMovementCode() {
     return this.pruImpDecMovementCode;
 }
 
 public void setPruImpDecMovementCode(String pruImpDecMovementCode) {
     this.pruImpDecMovementCode = pruImpDecMovementCode;
 }

 
 @Column(name="pruImpDecBenefitCode", length=8)
 public String getPruImpDecBenefitCode() {
     return this.pruImpDecBenefitCode;
 }
 
 public void setPruImpDecBenefitCode(String pruImpDecBenefitCode) {
     this.pruImpDecBenefitCode = pruImpDecBenefitCode;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="pruImpDecMovementEffDate", nullable=false, length=10)
 public Date getPruImpDecMovementEffDate() {
     return this.pruImpDecMovementEffDate;
 }
 
 public void setPruImpDecMovementEffDate(Date pruImpDecMovementEffDate) {
     this.pruImpDecMovementEffDate = pruImpDecMovementEffDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="pruImpDecRegDate", nullable=false, length=10)
 public Date getPruImpDecRegDate() {
     return this.pruImpDecRegDate;
 }
 
 public void setPruImpDecRegDate(Date pruImpDecRegDate) {
     this.pruImpDecRegDate = pruImpDecRegDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="pruImpDecStatChangeDate", nullable=false, length=10)
 public Date getPruImpDecStatChangeDate() {
     return this.pruImpDecStatChangeDate;
 }
 
 public void setPruImpDecStatChangeDate(Date pruImpDecStatChangeDate) {
     this.pruImpDecStatChangeDate = pruImpDecStatChangeDate;
 }

 
 @Column(name="pruImpDecMovementStat", nullable=false, length=1)
 public String getPruImpDecMovementStat() {
     return this.pruImpDecMovementStat;
 }
 
 public void setPruImpDecMovementStat(String pruImpDecMovementStat) {
     this.pruImpDecMovementStat = pruImpDecMovementStat;
 }

 
 @Column(name="pruImpDecMovementMsg", length=40)
 public String getPruImpDecMovementMsg() {
     return this.pruImpDecMovementMsg;
 }
 
 public void setPruImpDecMovementMsg(String pruImpDecMovementMsg) {
     this.pruImpDecMovementMsg = pruImpDecMovementMsg;
 }

 
 @Column(name="pruImpDecRecordEnd", nullable=false, length=1)
 public String getPruImpDecRecordEnd() {
     return this.pruImpDecRecordEnd;
 }
 
 public void setPruImpDecRecordEnd(String pruImpDecRecordEnd) {
     this.pruImpDecRecordEnd = pruImpDecRecordEnd;
 }




}


