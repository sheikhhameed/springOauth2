package com.test.demo.service;

import java.util.List;

import com.test.demo.model.common.EmployeeEntity;
import com.test.demo.model.outpt.OutptClaim;
/**
 * This interface is to list of service of the interface
 * 
 * @author smannan
 *
 */
public interface OutptCaseService {

	List<EmployeeEntity> getAllEmployees();

	EmployeeEntity createOrUpdateEmployee(EmployeeEntity employee);

	EmployeeEntity getEmployeeById(Long id);

	void deleteEmployeeById(Long id);

	OutptClaim getOutptClaim(int claimId);

}
