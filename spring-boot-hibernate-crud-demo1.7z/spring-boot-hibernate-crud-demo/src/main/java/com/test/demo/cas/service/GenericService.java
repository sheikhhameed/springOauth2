//package com.test.demo.cas.service;
//
//public interface GenericService {
//
//}
