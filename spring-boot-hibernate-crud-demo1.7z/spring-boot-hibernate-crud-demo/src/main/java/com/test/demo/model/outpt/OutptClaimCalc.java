package com.test.demo.model.outpt;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This is outptClaimCalc class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_calc"
 ,catalog="marcmy"
)
public class OutptClaimCalc  implements java.io.Serializable {


  private Integer id;
  private OutptClaim outptClaim;
  private Integer outptPlanId;
  private Integer outptPlanBenefitGroupId;
  private String outptPlanBenefitGroupTypeName;
  private Integer outptPlanBenefitId;
  private Integer outptBenefitId;
  private String outptBenefitName;
  private Integer outptPlanBenefitItemId;
  private Integer outptItemCategoryId;
  private String outptItemCategoryLocalName;
  private String outptItemCategoryName;
  private String remark;
  private BigDecimal invoiceAmt;
  private BigDecimal invoiceDiscountAmt;
  private BigDecimal invoiceGstAmt;
  private BigDecimal invoiceExcessAmt;
  private BigDecimal lineTotal;
  private BigDecimal excessNonCoverAmt;
  private BigDecimal excessCoInsuranceAmt;
  private BigDecimal excessPrvCoInsuranceAmt;
  private BigDecimal excessCoPayAmt;
  private String excessCoPayAmtType;
  private boolean excessCoPayApply;
  private BigDecimal excessDeductAmt;
  private BigDecimal excessPerVisitLimitAmt;
  private BigDecimal excessAnnLimitAmt;
  private BigDecimal excessAnnVisitAmt;
  private BigDecimal excessLifetimeLimitAmt;
  private BigDecimal insAmt;
  private BigDecimal exgratiaAmt;
  private BigDecimal ptAmt;
  private BigDecimal asoAmt;
  private BigDecimal numOfVisit;
  private BigDecimal startAvailableLimit;
  private BigDecimal startAvailableVisit;
  private BigDecimal endAvailableLimit;
  private BigDecimal endAvailableVisit;

 public OutptClaimCalc() {
 }

	
 public OutptClaimCalc(OutptClaim outptClaim, boolean excessCoPayApply) {
     this.outptClaim = outptClaim;
     this.excessCoPayApply = excessCoPayApply;
 }
 public OutptClaimCalc(OutptClaim outptClaim, Integer outptPlanId, Integer outptPlanBenefitGroupId, String outptPlanBenefitGroupTypeName, Integer outptPlanBenefitId, Integer outptBenefitId, String outptBenefitName, Integer outptPlanBenefitItemId, Integer outptItemCategoryId, String outptItemCategoryLocalName, String outptItemCategoryName, String remark, BigDecimal invoiceAmt, BigDecimal invoiceDiscountAmt, BigDecimal invoiceGstAmt, BigDecimal invoiceExcessAmt, BigDecimal lineTotal, BigDecimal excessNonCoverAmt, BigDecimal excessCoInsuranceAmt, BigDecimal excessPrvCoInsuranceAmt, BigDecimal excessCoPayAmt, String excessCoPayAmtType, boolean excessCoPayApply, BigDecimal excessDeductAmt, BigDecimal excessPerVisitLimitAmt, BigDecimal excessAnnLimitAmt, BigDecimal excessAnnVisitAmt, BigDecimal excessLifetimeLimitAmt, BigDecimal insAmt, BigDecimal exgratiaAmt, BigDecimal ptAmt, BigDecimal asoAmt, BigDecimal numOfVisit, BigDecimal startAvailableLimit, BigDecimal startAvailableVisit, BigDecimal endAvailableLimit, BigDecimal endAvailableVisit) {
    this.outptClaim = outptClaim;
    this.outptPlanId = outptPlanId;
    this.outptPlanBenefitGroupId = outptPlanBenefitGroupId;
    this.outptPlanBenefitGroupTypeName = outptPlanBenefitGroupTypeName;
    this.outptPlanBenefitId = outptPlanBenefitId;
    this.outptBenefitId = outptBenefitId;
    this.outptBenefitName = outptBenefitName;
    this.outptPlanBenefitItemId = outptPlanBenefitItemId;
    this.outptItemCategoryId = outptItemCategoryId;
    this.outptItemCategoryLocalName = outptItemCategoryLocalName;
    this.outptItemCategoryName = outptItemCategoryName;
    this.remark = remark;
    this.invoiceAmt = invoiceAmt;
    this.invoiceDiscountAmt = invoiceDiscountAmt;
    this.invoiceGstAmt = invoiceGstAmt;
    this.invoiceExcessAmt = invoiceExcessAmt;
    this.lineTotal = lineTotal;
    this.excessNonCoverAmt = excessNonCoverAmt;
    this.excessCoInsuranceAmt = excessCoInsuranceAmt;
    this.excessPrvCoInsuranceAmt = excessPrvCoInsuranceAmt;
    this.excessCoPayAmt = excessCoPayAmt;
    this.excessCoPayAmtType = excessCoPayAmtType;
    this.excessCoPayApply = excessCoPayApply;
    this.excessDeductAmt = excessDeductAmt;
    this.excessPerVisitLimitAmt = excessPerVisitLimitAmt;
    this.excessAnnLimitAmt = excessAnnLimitAmt;
    this.excessAnnVisitAmt = excessAnnVisitAmt;
    this.excessLifetimeLimitAmt = excessLifetimeLimitAmt;
    this.insAmt = insAmt;
    this.exgratiaAmt = exgratiaAmt;
    this.ptAmt = ptAmt;
    this.asoAmt = asoAmt;
    this.numOfVisit = numOfVisit;
    this.startAvailableLimit = startAvailableLimit;
    this.startAvailableVisit = startAvailableVisit;
    this.endAvailableLimit = endAvailableLimit;
    this.endAvailableVisit = endAvailableVisit;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="id", unique=true, nullable=false)
 public Integer getId() {
     return this.id;
 }
 
 public void setId(Integer id) {
     this.id = id;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="outptPlanId")
 public Integer getOutptPlanId() {
     return this.outptPlanId;
 }
 
 public void setOutptPlanId(Integer outptPlanId) {
     this.outptPlanId = outptPlanId;
 }

 
 @Column(name="outptPlanBenefitGroupId")
 public Integer getOutptPlanBenefitGroupId() {
     return this.outptPlanBenefitGroupId;
 }
 
 public void setOutptPlanBenefitGroupId(Integer outptPlanBenefitGroupId) {
     this.outptPlanBenefitGroupId = outptPlanBenefitGroupId;
 }

 
 @Column(name="outptPlanBenefitGroupTypeName", length=100)
 public String getOutptPlanBenefitGroupTypeName() {
     return this.outptPlanBenefitGroupTypeName;
 }
 
 public void setOutptPlanBenefitGroupTypeName(String outptPlanBenefitGroupTypeName) {
     this.outptPlanBenefitGroupTypeName = outptPlanBenefitGroupTypeName;
 }

 
 @Column(name="outptPlanBenefitId")
 public Integer getOutptPlanBenefitId() {
     return this.outptPlanBenefitId;
 }
 
 public void setOutptPlanBenefitId(Integer outptPlanBenefitId) {
     this.outptPlanBenefitId = outptPlanBenefitId;
 }

 
 @Column(name="outptBenefitId")
 public Integer getOutptBenefitId() {
     return this.outptBenefitId;
 }
 
 public void setOutptBenefitId(Integer outptBenefitId) {
     this.outptBenefitId = outptBenefitId;
 }

 
 @Column(name="outptBenefitName", length=250)
 public String getOutptBenefitName() {
     return this.outptBenefitName;
 }
 
 public void setOutptBenefitName(String outptBenefitName) {
     this.outptBenefitName = outptBenefitName;
 }

 
 @Column(name="outptPlanBenefitItemId")
 public Integer getOutptPlanBenefitItemId() {
     return this.outptPlanBenefitItemId;
 }
 
 public void setOutptPlanBenefitItemId(Integer outptPlanBenefitItemId) {
     this.outptPlanBenefitItemId = outptPlanBenefitItemId;
 }

 
 @Column(name="outptItemCategoryId")
 public Integer getOutptItemCategoryId() {
     return this.outptItemCategoryId;
 }
 
 public void setOutptItemCategoryId(Integer outptItemCategoryId) {
     this.outptItemCategoryId = outptItemCategoryId;
 }

 
 @Column(name="outptItemCategoryLocalName", length=50)
 public String getOutptItemCategoryLocalName() {
     return this.outptItemCategoryLocalName;
 }
 
 public void setOutptItemCategoryLocalName(String outptItemCategoryLocalName) {
     this.outptItemCategoryLocalName = outptItemCategoryLocalName;
 }

 
 @Column(name="outptItemCategoryName", length=50)
 public String getOutptItemCategoryName() {
     return this.outptItemCategoryName;
 }
 
 public void setOutptItemCategoryName(String outptItemCategoryName) {
     this.outptItemCategoryName = outptItemCategoryName;
 }

 
 @Column(name="remark", length=65535)
 public String getRemark() {
     return this.remark;
 }
 
 public void setRemark(String remark) {
     this.remark = remark;
 }

 
 @Column(name="invoiceAmt", precision=16)
 public BigDecimal getInvoiceAmt() {
     return this.invoiceAmt;
 }
 
 public void setInvoiceAmt(BigDecimal invoiceAmt) {
     this.invoiceAmt = invoiceAmt;
 }

 
 @Column(name="invoiceDiscountAmt", precision=16)
 public BigDecimal getInvoiceDiscountAmt() {
     return this.invoiceDiscountAmt;
 }
 
 public void setInvoiceDiscountAmt(BigDecimal invoiceDiscountAmt) {
     this.invoiceDiscountAmt = invoiceDiscountAmt;
 }

 
 @Column(name="invoiceGstAmt", precision=16)
 public BigDecimal getInvoiceGstAmt() {
     return this.invoiceGstAmt;
 }
 
 public void setInvoiceGstAmt(BigDecimal invoiceGstAmt) {
     this.invoiceGstAmt = invoiceGstAmt;
 }

 
 @Column(name="invoiceExcessAmt", precision=16)
 public BigDecimal getInvoiceExcessAmt() {
     return this.invoiceExcessAmt;
 }
 
 public void setInvoiceExcessAmt(BigDecimal invoiceExcessAmt) {
     this.invoiceExcessAmt = invoiceExcessAmt;
 }

 
 @Column(name="lineTotal", precision=16)
 public BigDecimal getLineTotal() {
     return this.lineTotal;
 }
 
 public void setLineTotal(BigDecimal lineTotal) {
     this.lineTotal = lineTotal;
 }

 
 @Column(name="excessNonCoverAmt", precision=16)
 public BigDecimal getExcessNonCoverAmt() {
     return this.excessNonCoverAmt;
 }
 
 public void setExcessNonCoverAmt(BigDecimal excessNonCoverAmt) {
     this.excessNonCoverAmt = excessNonCoverAmt;
 }

 
 @Column(name="excessCoInsuranceAmt", precision=16)
 public BigDecimal getExcessCoInsuranceAmt() {
     return this.excessCoInsuranceAmt;
 }
 
 public void setExcessCoInsuranceAmt(BigDecimal excessCoInsuranceAmt) {
     this.excessCoInsuranceAmt = excessCoInsuranceAmt;
 }

 
 @Column(name="excessPrvCoInsuranceAmt", precision=16)
 public BigDecimal getExcessPrvCoInsuranceAmt() {
     return this.excessPrvCoInsuranceAmt;
 }
 
 public void setExcessPrvCoInsuranceAmt(BigDecimal excessPrvCoInsuranceAmt) {
     this.excessPrvCoInsuranceAmt = excessPrvCoInsuranceAmt;
 }

 
 @Column(name="excessCoPayAmt", precision=16)
 public BigDecimal getExcessCoPayAmt() {
     return this.excessCoPayAmt;
 }
 
 public void setExcessCoPayAmt(BigDecimal excessCoPayAmt) {
     this.excessCoPayAmt = excessCoPayAmt;
 }

 
 @Column(name="excessCoPayAmtType", length=1)
 public String getExcessCoPayAmtType() {
     return this.excessCoPayAmtType;
 }
 
 public void setExcessCoPayAmtType(String excessCoPayAmtType) {
     this.excessCoPayAmtType = excessCoPayAmtType;
 }

 
 @Column(name="excessCoPayApply", nullable=false)
 public boolean isExcessCoPayApply() {
     return this.excessCoPayApply;
 }
 
 public void setExcessCoPayApply(boolean excessCoPayApply) {
     this.excessCoPayApply = excessCoPayApply;
 }

 
 @Column(name="excessDeductAmt", precision=16)
 public BigDecimal getExcessDeductAmt() {
     return this.excessDeductAmt;
 }
 
 public void setExcessDeductAmt(BigDecimal excessDeductAmt) {
     this.excessDeductAmt = excessDeductAmt;
 }

 
 @Column(name="excessPerVisitLimitAmt", precision=16)
 public BigDecimal getExcessPerVisitLimitAmt() {
     return this.excessPerVisitLimitAmt;
 }
 
 public void setExcessPerVisitLimitAmt(BigDecimal excessPerVisitLimitAmt) {
     this.excessPerVisitLimitAmt = excessPerVisitLimitAmt;
 }

 
 @Column(name="excessAnnLimitAmt", precision=16)
 public BigDecimal getExcessAnnLimitAmt() {
     return this.excessAnnLimitAmt;
 }
 
 public void setExcessAnnLimitAmt(BigDecimal excessAnnLimitAmt) {
     this.excessAnnLimitAmt = excessAnnLimitAmt;
 }

 
 @Column(name="excessAnnVisitAmt", precision=16)
 public BigDecimal getExcessAnnVisitAmt() {
     return this.excessAnnVisitAmt;
 }
 
 public void setExcessAnnVisitAmt(BigDecimal excessAnnVisitAmt) {
     this.excessAnnVisitAmt = excessAnnVisitAmt;
 }

 
 @Column(name="excessLifetimeLimitAmt", precision=16)
 public BigDecimal getExcessLifetimeLimitAmt() {
     return this.excessLifetimeLimitAmt;
 }
 
 public void setExcessLifetimeLimitAmt(BigDecimal excessLifetimeLimitAmt) {
     this.excessLifetimeLimitAmt = excessLifetimeLimitAmt;
 }

 
 @Column(name="insAmt", precision=16)
 public BigDecimal getInsAmt() {
     return this.insAmt;
 }
 
 public void setInsAmt(BigDecimal insAmt) {
     this.insAmt = insAmt;
 }

 
 @Column(name="exgratiaAmt", precision=16)
 public BigDecimal getExgratiaAmt() {
     return this.exgratiaAmt;
 }
 
 public void setExgratiaAmt(BigDecimal exgratiaAmt) {
     this.exgratiaAmt = exgratiaAmt;
 }

 
 @Column(name="ptAmt", precision=16)
 public BigDecimal getPtAmt() {
     return this.ptAmt;
 }
 
 public void setPtAmt(BigDecimal ptAmt) {
     this.ptAmt = ptAmt;
 }

 
 @Column(name="asoAmt", precision=16)
 public BigDecimal getAsoAmt() {
     return this.asoAmt;
 }
 
 public void setAsoAmt(BigDecimal asoAmt) {
     this.asoAmt = asoAmt;
 }

 
 @Column(name="numOfVisit", precision=4, scale=1)
 public BigDecimal getNumOfVisit() {
     return this.numOfVisit;
 }
 
 public void setNumOfVisit(BigDecimal numOfVisit) {
     this.numOfVisit = numOfVisit;
 }

 
 @Column(name="startAvailableLimit", precision=16)
 public BigDecimal getStartAvailableLimit() {
     return this.startAvailableLimit;
 }
 
 public void setStartAvailableLimit(BigDecimal startAvailableLimit) {
     this.startAvailableLimit = startAvailableLimit;
 }

 
 @Column(name="startAvailableVisit", precision=4, scale=1)
 public BigDecimal getStartAvailableVisit() {
     return this.startAvailableVisit;
 }
 
 public void setStartAvailableVisit(BigDecimal startAvailableVisit) {
     this.startAvailableVisit = startAvailableVisit;
 }

 
 @Column(name="endAvailableLimit", precision=16)
 public BigDecimal getEndAvailableLimit() {
     return this.endAvailableLimit;
 }
 
 public void setEndAvailableLimit(BigDecimal endAvailableLimit) {
     this.endAvailableLimit = endAvailableLimit;
 }

 
 @Column(name="endAvailableVisit", precision=16)
 public BigDecimal getEndAvailableVisit() {
     return this.endAvailableVisit;
 }
 
 public void setEndAvailableVisit(BigDecimal endAvailableVisit) {
     this.endAvailableVisit = endAvailableVisit;
 }




}


