package com.test.demo.model.common;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * This is userDepartment class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="user_department"
 ,catalog="marcmy"
 , uniqueConstraints = @UniqueConstraint(columnNames="userDeptName") 
)
public class UserDepartment  implements java.io.Serializable {


  private Integer userDeptId;
  private String userDeptName;
  private String userDeptEmail;
  private Boolean userDeptShowToClient;
  private Set<User> users = new HashSet<User>(0);

 public UserDepartment() {
 }

	
 public UserDepartment(String userDeptName) {
     this.userDeptName = userDeptName;
 }
 public UserDepartment(String userDeptName, String userDeptEmail, Boolean userDeptShowToClient, Set<User> users) {
    this.userDeptName = userDeptName;
    this.userDeptEmail = userDeptEmail;
    this.userDeptShowToClient = userDeptShowToClient;
    this.users = users;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="userDeptId", unique=true, nullable=false)
 public Integer getUserDeptId() {
     return this.userDeptId;
 }
 
 public void setUserDeptId(Integer userDeptId) {
     this.userDeptId = userDeptId;
 }

 
 @Column(name="userDeptName", unique=true, nullable=false, length=150)
 public String getUserDeptName() {
     return this.userDeptName;
 }
 
 public void setUserDeptName(String userDeptName) {
     this.userDeptName = userDeptName;
 }

 
 @Column(name="userDeptEmail", length=250)
 public String getUserDeptEmail() {
     return this.userDeptEmail;
 }
 
 public void setUserDeptEmail(String userDeptEmail) {
     this.userDeptEmail = userDeptEmail;
 }

 
 @Column(name="userDeptShowToClient")
 public Boolean getUserDeptShowToClient() {
     return this.userDeptShowToClient;
 }
 
 public void setUserDeptShowToClient(Boolean userDeptShowToClient) {
     this.userDeptShowToClient = userDeptShowToClient;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="userDepartment")
 public Set<User> getUsers() {
     return this.users;
 }
 
 public void setUsers(Set<User> users) {
     this.users = users;
 }




}


