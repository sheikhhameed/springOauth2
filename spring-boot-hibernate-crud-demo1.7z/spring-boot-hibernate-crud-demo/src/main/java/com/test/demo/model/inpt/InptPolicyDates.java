package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptPolicyDates class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_policy_dates"
 ,catalog="marcmy"
)
public class InptPolicyDates  implements java.io.Serializable {


  private Integer ipdId;
  private InptPolicy inptPolicy;
  private Boolean ipdEnabled;
  private Integer ipdCreatedBy;
  private Date ipdCreatedDate;
  private Integer ipdLastEdittedBy;
  private Date ipdLastEdittedDate;
  private Date ipdStartDate;
  private Date ipdEndDate;
  private String ipdType;
  private Boolean ipdActive;
  private String ipdRemarks;

 public InptPolicyDates() {
 }

	
 public InptPolicyDates(InptPolicy inptPolicy) {
     this.inptPolicy = inptPolicy;
 }
 public InptPolicyDates(InptPolicy inptPolicy, Boolean ipdEnabled, Integer ipdCreatedBy, Date ipdCreatedDate, Integer ipdLastEdittedBy, Date ipdLastEdittedDate, Date ipdStartDate, Date ipdEndDate, String ipdType, Boolean ipdActive, String ipdRemarks) {
    this.inptPolicy = inptPolicy;
    this.ipdEnabled = ipdEnabled;
    this.ipdCreatedBy = ipdCreatedBy;
    this.ipdCreatedDate = ipdCreatedDate;
    this.ipdLastEdittedBy = ipdLastEdittedBy;
    this.ipdLastEdittedDate = ipdLastEdittedDate;
    this.ipdStartDate = ipdStartDate;
    this.ipdEndDate = ipdEndDate;
    this.ipdType = ipdType;
    this.ipdActive = ipdActive;
    this.ipdRemarks = ipdRemarks;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ipdId", unique=true, nullable=false)
 public Integer getIpdId() {
     return this.ipdId;
 }
 
 public void setIpdId(Integer ipdId) {
     this.ipdId = ipdId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ipdInptPolicyId", nullable=false)
 public InptPolicy getInptPolicy() {
     return this.inptPolicy;
 }
 
 public void setInptPolicy(InptPolicy inptPolicy) {
     this.inptPolicy = inptPolicy;
 }

 
 @Column(name="ipdEnabled")
 public Boolean getIpdEnabled() {
     return this.ipdEnabled;
 }
 
 public void setIpdEnabled(Boolean ipdEnabled) {
     this.ipdEnabled = ipdEnabled;
 }

 
 @Column(name="ipdCreatedBy")
 public Integer getIpdCreatedBy() {
     return this.ipdCreatedBy;
 }
 
 public void setIpdCreatedBy(Integer ipdCreatedBy) {
     this.ipdCreatedBy = ipdCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ipdCreatedDate", length=19)
 public Date getIpdCreatedDate() {
     return this.ipdCreatedDate;
 }
 
 public void setIpdCreatedDate(Date ipdCreatedDate) {
     this.ipdCreatedDate = ipdCreatedDate;
 }

 
 @Column(name="ipdLastEdittedBy")
 public Integer getIpdLastEdittedBy() {
     return this.ipdLastEdittedBy;
 }
 
 public void setIpdLastEdittedBy(Integer ipdLastEdittedBy) {
     this.ipdLastEdittedBy = ipdLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ipdLastEdittedDate", length=19)
 public Date getIpdLastEdittedDate() {
     return this.ipdLastEdittedDate;
 }
 
 public void setIpdLastEdittedDate(Date ipdLastEdittedDate) {
     this.ipdLastEdittedDate = ipdLastEdittedDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ipdStartDate", length=10)
 public Date getIpdStartDate() {
     return this.ipdStartDate;
 }
 
 public void setIpdStartDate(Date ipdStartDate) {
     this.ipdStartDate = ipdStartDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ipdEndDate", length=10)
 public Date getIpdEndDate() {
     return this.ipdEndDate;
 }
 
 public void setIpdEndDate(Date ipdEndDate) {
     this.ipdEndDate = ipdEndDate;
 }

 
 @Column(name="ipdType", length=1)
 public String getIpdType() {
     return this.ipdType;
 }
 
 public void setIpdType(String ipdType) {
     this.ipdType = ipdType;
 }

 
 @Column(name="ipdActive")
 public Boolean getIpdActive() {
     return this.ipdActive;
 }
 
 public void setIpdActive(Boolean ipdActive) {
     this.ipdActive = ipdActive;
 }

 
 @Column(name="ipdRemarks", length=250)
 public String getIpdRemarks() {
     return this.ipdRemarks;
 }
 
 public void setIpdRemarks(String ipdRemarks) {
     this.ipdRemarks = ipdRemarks;
 }




}


