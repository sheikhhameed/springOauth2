package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptClaimFwaResult class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_fwa_result"
 ,catalog="marcmy"
)
public class OutptClaimFwaResult  implements java.io.Serializable {


  private Integer id;
  private OutptClaim outptClaim;
  private Date createdDate;
  private String createdByAbbvName;
  private Date approvalDate;
  private String approvalByAbbvName;
  private String ruleType;
  private String ruleName;
  private String ruleFlag;
  private String ruleRemark;
  private String ruleRemark2;
  private boolean ruleManual;
  private String approverRemark;

 public OutptClaimFwaResult() {
 }

	
 public OutptClaimFwaResult(OutptClaim outptClaim, String ruleType, String ruleName, String ruleFlag, boolean ruleManual) {
     this.outptClaim = outptClaim;
     this.ruleType = ruleType;
     this.ruleName = ruleName;
     this.ruleFlag = ruleFlag;
     this.ruleManual = ruleManual;
 }
 public OutptClaimFwaResult(OutptClaim outptClaim, Date createdDate, String createdByAbbvName, Date approvalDate, String approvalByAbbvName, String ruleType, String ruleName, String ruleFlag, String ruleRemark, String ruleRemark2, boolean ruleManual, String approverRemark) {
    this.outptClaim = outptClaim;
    this.createdDate = createdDate;
    this.createdByAbbvName = createdByAbbvName;
    this.approvalDate = approvalDate;
    this.approvalByAbbvName = approvalByAbbvName;
    this.ruleType = ruleType;
    this.ruleName = ruleName;
    this.ruleFlag = ruleFlag;
    this.ruleRemark = ruleRemark;
    this.ruleRemark2 = ruleRemark2;
    this.ruleManual = ruleManual;
    this.approverRemark = approverRemark;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="id", unique=true, nullable=false)
 public Integer getId() {
     return this.id;
 }
 
 public void setId(Integer id) {
     this.id = id;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="createdDate", length=19)
 public Date getCreatedDate() {
     return this.createdDate;
 }
 
 public void setCreatedDate(Date createdDate) {
     this.createdDate = createdDate;
 }

 
 @Column(name="createdByAbbvName", length=16)
 public String getCreatedByAbbvName() {
     return this.createdByAbbvName;
 }
 
 public void setCreatedByAbbvName(String createdByAbbvName) {
     this.createdByAbbvName = createdByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="approvalDate", length=19)
 public Date getApprovalDate() {
     return this.approvalDate;
 }
 
 public void setApprovalDate(Date approvalDate) {
     this.approvalDate = approvalDate;
 }

 
 @Column(name="approvalByAbbvName", length=16)
 public String getApprovalByAbbvName() {
     return this.approvalByAbbvName;
 }
 
 public void setApprovalByAbbvName(String approvalByAbbvName) {
     this.approvalByAbbvName = approvalByAbbvName;
 }

 
 @Column(name="ruleType", nullable=false, length=1)
 public String getRuleType() {
     return this.ruleType;
 }
 
 public void setRuleType(String ruleType) {
     this.ruleType = ruleType;
 }

 
 @Column(name="ruleName", nullable=false, length=30)
 public String getRuleName() {
     return this.ruleName;
 }
 
 public void setRuleName(String ruleName) {
     this.ruleName = ruleName;
 }

 
 @Column(name="ruleFlag", nullable=false, length=2)
 public String getRuleFlag() {
     return this.ruleFlag;
 }
 
 public void setRuleFlag(String ruleFlag) {
     this.ruleFlag = ruleFlag;
 }

 
 @Column(name="ruleRemark", length=150)
 public String getRuleRemark() {
     return this.ruleRemark;
 }
 
 public void setRuleRemark(String ruleRemark) {
     this.ruleRemark = ruleRemark;
 }

 
 @Column(name="ruleRemark2", length=250)
 public String getRuleRemark2() {
     return this.ruleRemark2;
 }
 
 public void setRuleRemark2(String ruleRemark2) {
     this.ruleRemark2 = ruleRemark2;
 }

 
 @Column(name="ruleManual", nullable=false)
 public boolean isRuleManual() {
     return this.ruleManual;
 }
 
 public void setRuleManual(boolean ruleManual) {
     this.ruleManual = ruleManual;
 }

 
 @Column(name="approverRemark", length=250)
 public String getApproverRemark() {
     return this.approverRemark;
 }
 
 public void setApproverRemark(String approverRemark) {
     this.approverRemark = approverRemark;
 }




}


