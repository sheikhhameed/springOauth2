package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.PruImportDeclaration;

/**
 * This is inptPolicy class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_policy"
 ,catalog="marcmy"
)
public class InptPolicy  implements java.io.Serializable {


  private Integer inptPolId;
  private Boolean inptPolEnabled;
  private Integer inptPolCreatedBy;
  private Date inptPolCreatedDate;
  private Integer inptPolLastEdittedBy;
  private Date inptPolLastEdittedDate;
  private String inptPolExtInsCode;
  private String inptPolExtPolUniqId;
  private String inptPolPolicyNum;
  private Integer inptPolTtlNoOfFw;
  private BigDecimal inptPolTtlGrsPremium;
  private BigDecimal inptPolTtlTpcaFees;
  private String inptPolOwner;
  private String inptPolOwnerChinese;
  private String inptPolOwnerNationalId;
  private Character inptPolOwnerGender;
  private String inptPolOwnerEmail;
  private Boolean inptPolOwnerIdRec;
  private Date inptPolEffectiveDate;
  private Date inptPolExpiryDate;
  private Date inptPolExtensionExpiryDate;
  private Date inptPolCancelDate;
  private Date inptPolLgSuspensionDate;
  private Date inptPolPaidToDate;
  private Date inptPolReinstatementDate;
  private Character inptPolPolicyCreationType;
  private String inptPolInsurerBranch;
  private String inptPolInsurerAgencyName;
  private String inptPolInsurerAgencyChineseName;
  private String inptPolInsurerAgencyCode;
  private String inptPolInsurerAgencyTel;
  private String inptPolInsurerAgencyEmail;
  private String inptPolInsurerAgencyLocation;
  private String inptPolPrevPolicyNum;
  private Integer inptPolPrevPolicyId;
  private String inptPolRemark;
  private String inptPolSuspendFlag;
  private String inptPolTermination;
  private Set<InptPolicyPlan> inptPolicyPlans = new HashSet<InptPolicyPlan>(0);
  private Set<PruImportDeclaration> pruImportDeclarations = new HashSet<PruImportDeclaration>(0);
  private Set<InptPolicyDates> inptPolicyDateses = new HashSet<InptPolicyDates>(0);

 public InptPolicy() {
 }

 public InptPolicy(Boolean inptPolEnabled, Integer inptPolCreatedBy, Date inptPolCreatedDate, Integer inptPolLastEdittedBy, Date inptPolLastEdittedDate, String inptPolExtInsCode, String inptPolExtPolUniqId, String inptPolPolicyNum, Integer inptPolTtlNoOfFw, BigDecimal inptPolTtlGrsPremium, BigDecimal inptPolTtlTpcaFees, String inptPolOwner, String inptPolOwnerChinese, String inptPolOwnerNationalId, Character inptPolOwnerGender, String inptPolOwnerEmail, Boolean inptPolOwnerIdRec, Date inptPolEffectiveDate, Date inptPolExpiryDate, Date inptPolExtensionExpiryDate, Date inptPolCancelDate, Date inptPolLgSuspensionDate, Date inptPolPaidToDate, Date inptPolReinstatementDate, Character inptPolPolicyCreationType, String inptPolInsurerBranch, String inptPolInsurerAgencyName, String inptPolInsurerAgencyChineseName, String inptPolInsurerAgencyCode, String inptPolInsurerAgencyTel, String inptPolInsurerAgencyEmail, String inptPolInsurerAgencyLocation, String inptPolPrevPolicyNum, Integer inptPolPrevPolicyId, String inptPolRemark, String inptPolSuspendFlag, String inptPolTermination, Set<InptPolicyPlan> inptPolicyPlans, Set<PruImportDeclaration> pruImportDeclarations, Set<InptPolicyDates> inptPolicyDateses) {
    this.inptPolEnabled = inptPolEnabled;
    this.inptPolCreatedBy = inptPolCreatedBy;
    this.inptPolCreatedDate = inptPolCreatedDate;
    this.inptPolLastEdittedBy = inptPolLastEdittedBy;
    this.inptPolLastEdittedDate = inptPolLastEdittedDate;
    this.inptPolExtInsCode = inptPolExtInsCode;
    this.inptPolExtPolUniqId = inptPolExtPolUniqId;
    this.inptPolPolicyNum = inptPolPolicyNum;
    this.inptPolTtlNoOfFw = inptPolTtlNoOfFw;
    this.inptPolTtlGrsPremium = inptPolTtlGrsPremium;
    this.inptPolTtlTpcaFees = inptPolTtlTpcaFees;
    this.inptPolOwner = inptPolOwner;
    this.inptPolOwnerChinese = inptPolOwnerChinese;
    this.inptPolOwnerNationalId = inptPolOwnerNationalId;
    this.inptPolOwnerGender = inptPolOwnerGender;
    this.inptPolOwnerEmail = inptPolOwnerEmail;
    this.inptPolOwnerIdRec = inptPolOwnerIdRec;
    this.inptPolEffectiveDate = inptPolEffectiveDate;
    this.inptPolExpiryDate = inptPolExpiryDate;
    this.inptPolExtensionExpiryDate = inptPolExtensionExpiryDate;
    this.inptPolCancelDate = inptPolCancelDate;
    this.inptPolLgSuspensionDate = inptPolLgSuspensionDate;
    this.inptPolPaidToDate = inptPolPaidToDate;
    this.inptPolReinstatementDate = inptPolReinstatementDate;
    this.inptPolPolicyCreationType = inptPolPolicyCreationType;
    this.inptPolInsurerBranch = inptPolInsurerBranch;
    this.inptPolInsurerAgencyName = inptPolInsurerAgencyName;
    this.inptPolInsurerAgencyChineseName = inptPolInsurerAgencyChineseName;
    this.inptPolInsurerAgencyCode = inptPolInsurerAgencyCode;
    this.inptPolInsurerAgencyTel = inptPolInsurerAgencyTel;
    this.inptPolInsurerAgencyEmail = inptPolInsurerAgencyEmail;
    this.inptPolInsurerAgencyLocation = inptPolInsurerAgencyLocation;
    this.inptPolPrevPolicyNum = inptPolPrevPolicyNum;
    this.inptPolPrevPolicyId = inptPolPrevPolicyId;
    this.inptPolRemark = inptPolRemark;
    this.inptPolSuspendFlag = inptPolSuspendFlag;
    this.inptPolTermination = inptPolTermination;
    this.inptPolicyPlans = inptPolicyPlans;
    this.pruImportDeclarations = pruImportDeclarations;
    this.inptPolicyDateses = inptPolicyDateses;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptPolId", unique=true, nullable=false)
 public Integer getInptPolId() {
     return this.inptPolId;
 }
 
 public void setInptPolId(Integer inptPolId) {
     this.inptPolId = inptPolId;
 }

 
 @Column(name="inptPolEnabled")
 public Boolean getInptPolEnabled() {
     return this.inptPolEnabled;
 }
 
 public void setInptPolEnabled(Boolean inptPolEnabled) {
     this.inptPolEnabled = inptPolEnabled;
 }

 
 @Column(name="inptPolCreatedBy")
 public Integer getInptPolCreatedBy() {
     return this.inptPolCreatedBy;
 }
 
 public void setInptPolCreatedBy(Integer inptPolCreatedBy) {
     this.inptPolCreatedBy = inptPolCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptPolCreatedDate", length=19)
 public Date getInptPolCreatedDate() {
     return this.inptPolCreatedDate;
 }
 
 public void setInptPolCreatedDate(Date inptPolCreatedDate) {
     this.inptPolCreatedDate = inptPolCreatedDate;
 }

 
 @Column(name="inptPolLastEdittedBy")
 public Integer getInptPolLastEdittedBy() {
     return this.inptPolLastEdittedBy;
 }
 
 public void setInptPolLastEdittedBy(Integer inptPolLastEdittedBy) {
     this.inptPolLastEdittedBy = inptPolLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptPolLastEdittedDate", length=19)
 public Date getInptPolLastEdittedDate() {
     return this.inptPolLastEdittedDate;
 }
 
 public void setInptPolLastEdittedDate(Date inptPolLastEdittedDate) {
     this.inptPolLastEdittedDate = inptPolLastEdittedDate;
 }

 
 @Column(name="inptPolExtInsCode", length=10)
 public String getInptPolExtInsCode() {
     return this.inptPolExtInsCode;
 }
 
 public void setInptPolExtInsCode(String inptPolExtInsCode) {
     this.inptPolExtInsCode = inptPolExtInsCode;
 }

 
 @Column(name="inptPolExtPolUniqId", length=50)
 public String getInptPolExtPolUniqId() {
     return this.inptPolExtPolUniqId;
 }
 
 public void setInptPolExtPolUniqId(String inptPolExtPolUniqId) {
     this.inptPolExtPolUniqId = inptPolExtPolUniqId;
 }

 
 @Column(name="inptPolPolicyNum", length=25)
 public String getInptPolPolicyNum() {
     return this.inptPolPolicyNum;
 }
 
 public void setInptPolPolicyNum(String inptPolPolicyNum) {
     this.inptPolPolicyNum = inptPolPolicyNum;
 }

 
 @Column(name="inptPolTtlNoOfFw")
 public Integer getInptPolTtlNoOfFw() {
     return this.inptPolTtlNoOfFw;
 }
 
 public void setInptPolTtlNoOfFw(Integer inptPolTtlNoOfFw) {
     this.inptPolTtlNoOfFw = inptPolTtlNoOfFw;
 }

 
 @Column(name="inptPolTtlGrsPremium", precision=9)
 public BigDecimal getInptPolTtlGrsPremium() {
     return this.inptPolTtlGrsPremium;
 }
 
 public void setInptPolTtlGrsPremium(BigDecimal inptPolTtlGrsPremium) {
     this.inptPolTtlGrsPremium = inptPolTtlGrsPremium;
 }

 
 @Column(name="inptPolTtlTpcaFees", precision=9)
 public BigDecimal getInptPolTtlTpcaFees() {
     return this.inptPolTtlTpcaFees;
 }
 
 public void setInptPolTtlTpcaFees(BigDecimal inptPolTtlTpcaFees) {
     this.inptPolTtlTpcaFees = inptPolTtlTpcaFees;
 }

 
 @Column(name="inptPolOwner", length=150)
 public String getInptPolOwner() {
     return this.inptPolOwner;
 }
 
 public void setInptPolOwner(String inptPolOwner) {
     this.inptPolOwner = inptPolOwner;
 }

 
 @Column(name="inptPolOwnerChinese", length=150)
 public String getInptPolOwnerChinese() {
     return this.inptPolOwnerChinese;
 }
 
 public void setInptPolOwnerChinese(String inptPolOwnerChinese) {
     this.inptPolOwnerChinese = inptPolOwnerChinese;
 }

 
 @Column(name="inptPolOwnerNationalId", length=30)
 public String getInptPolOwnerNationalId() {
     return this.inptPolOwnerNationalId;
 }
 
 public void setInptPolOwnerNationalId(String inptPolOwnerNationalId) {
     this.inptPolOwnerNationalId = inptPolOwnerNationalId;
 }

 
 @Column(name="inptPolOwnerGender", length=1)
 public Character getInptPolOwnerGender() {
     return this.inptPolOwnerGender;
 }
 
 public void setInptPolOwnerGender(Character inptPolOwnerGender) {
     this.inptPolOwnerGender = inptPolOwnerGender;
 }

 
 @Column(name="inptPolOwnerEmail", length=16777215)
 public String getInptPolOwnerEmail() {
     return this.inptPolOwnerEmail;
 }
 
 public void setInptPolOwnerEmail(String inptPolOwnerEmail) {
     this.inptPolOwnerEmail = inptPolOwnerEmail;
 }

 
 @Column(name="inptPolOwnerIdRec")
 public Boolean getInptPolOwnerIdRec() {
     return this.inptPolOwnerIdRec;
 }
 
 public void setInptPolOwnerIdRec(Boolean inptPolOwnerIdRec) {
     this.inptPolOwnerIdRec = inptPolOwnerIdRec;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolEffectiveDate", length=10)
 public Date getInptPolEffectiveDate() {
     return this.inptPolEffectiveDate;
 }
 
 public void setInptPolEffectiveDate(Date inptPolEffectiveDate) {
     this.inptPolEffectiveDate = inptPolEffectiveDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolExpiryDate", length=10)
 public Date getInptPolExpiryDate() {
     return this.inptPolExpiryDate;
 }
 
 public void setInptPolExpiryDate(Date inptPolExpiryDate) {
     this.inptPolExpiryDate = inptPolExpiryDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolExtensionExpiryDate", length=10)
 public Date getInptPolExtensionExpiryDate() {
     return this.inptPolExtensionExpiryDate;
 }
 
 public void setInptPolExtensionExpiryDate(Date inptPolExtensionExpiryDate) {
     this.inptPolExtensionExpiryDate = inptPolExtensionExpiryDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolCancelDate", length=10)
 public Date getInptPolCancelDate() {
     return this.inptPolCancelDate;
 }
 
 public void setInptPolCancelDate(Date inptPolCancelDate) {
     this.inptPolCancelDate = inptPolCancelDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolLgSuspensionDate", length=10)
 public Date getInptPolLgSuspensionDate() {
     return this.inptPolLgSuspensionDate;
 }
 
 public void setInptPolLgSuspensionDate(Date inptPolLgSuspensionDate) {
     this.inptPolLgSuspensionDate = inptPolLgSuspensionDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolPaidToDate", length=10)
 public Date getInptPolPaidToDate() {
     return this.inptPolPaidToDate;
 }
 
 public void setInptPolPaidToDate(Date inptPolPaidToDate) {
     this.inptPolPaidToDate = inptPolPaidToDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptPolReinstatementDate", length=10)
 public Date getInptPolReinstatementDate() {
     return this.inptPolReinstatementDate;
 }
 
 public void setInptPolReinstatementDate(Date inptPolReinstatementDate) {
     this.inptPolReinstatementDate = inptPolReinstatementDate;
 }

 
 @Column(name="inptPolPolicyCreationType", length=1)
 public Character getInptPolPolicyCreationType() {
     return this.inptPolPolicyCreationType;
 }
 
 public void setInptPolPolicyCreationType(Character inptPolPolicyCreationType) {
     this.inptPolPolicyCreationType = inptPolPolicyCreationType;
 }

 
 @Column(name="inptPolInsurerBranch", length=100)
 public String getInptPolInsurerBranch() {
     return this.inptPolInsurerBranch;
 }
 
 public void setInptPolInsurerBranch(String inptPolInsurerBranch) {
     this.inptPolInsurerBranch = inptPolInsurerBranch;
 }

 
 @Column(name="inptPolInsurerAgencyName", length=100)
 public String getInptPolInsurerAgencyName() {
     return this.inptPolInsurerAgencyName;
 }
 
 public void setInptPolInsurerAgencyName(String inptPolInsurerAgencyName) {
     this.inptPolInsurerAgencyName = inptPolInsurerAgencyName;
 }

 
 @Column(name="inptPolInsurerAgencyChineseName", length=100)
 public String getInptPolInsurerAgencyChineseName() {
     return this.inptPolInsurerAgencyChineseName;
 }
 
 public void setInptPolInsurerAgencyChineseName(String inptPolInsurerAgencyChineseName) {
     this.inptPolInsurerAgencyChineseName = inptPolInsurerAgencyChineseName;
 }

 
 @Column(name="inptPolInsurerAgencyCode", length=100)
 public String getInptPolInsurerAgencyCode() {
     return this.inptPolInsurerAgencyCode;
 }
 
 public void setInptPolInsurerAgencyCode(String inptPolInsurerAgencyCode) {
     this.inptPolInsurerAgencyCode = inptPolInsurerAgencyCode;
 }

 
 @Column(name="inptPolInsurerAgencyTel", length=20)
 public String getInptPolInsurerAgencyTel() {
     return this.inptPolInsurerAgencyTel;
 }
 
 public void setInptPolInsurerAgencyTel(String inptPolInsurerAgencyTel) {
     this.inptPolInsurerAgencyTel = inptPolInsurerAgencyTel;
 }

 
 @Column(name="inptPolInsurerAgencyEmail", length=250)
 public String getInptPolInsurerAgencyEmail() {
     return this.inptPolInsurerAgencyEmail;
 }
 
 public void setInptPolInsurerAgencyEmail(String inptPolInsurerAgencyEmail) {
     this.inptPolInsurerAgencyEmail = inptPolInsurerAgencyEmail;
 }

 
 @Column(name="inptPolInsurerAgencyLocation", length=100)
 public String getInptPolInsurerAgencyLocation() {
     return this.inptPolInsurerAgencyLocation;
 }
 
 public void setInptPolInsurerAgencyLocation(String inptPolInsurerAgencyLocation) {
     this.inptPolInsurerAgencyLocation = inptPolInsurerAgencyLocation;
 }

 
 @Column(name="inptPolPrevPolicyNum", length=25)
 public String getInptPolPrevPolicyNum() {
     return this.inptPolPrevPolicyNum;
 }
 
 public void setInptPolPrevPolicyNum(String inptPolPrevPolicyNum) {
     this.inptPolPrevPolicyNum = inptPolPrevPolicyNum;
 }

 
 @Column(name="inptPolPrevPolicyId")
 public Integer getInptPolPrevPolicyId() {
     return this.inptPolPrevPolicyId;
 }
 
 public void setInptPolPrevPolicyId(Integer inptPolPrevPolicyId) {
     this.inptPolPrevPolicyId = inptPolPrevPolicyId;
 }

 
 @Column(name="inptPolRemark", length=16777215)
 public String getInptPolRemark() {
     return this.inptPolRemark;
 }
 
 public void setInptPolRemark(String inptPolRemark) {
     this.inptPolRemark = inptPolRemark;
 }

 
 @Column(name="inptPolSuspendFlag", length=5)
 public String getInptPolSuspendFlag() {
     return this.inptPolSuspendFlag;
 }
 
 public void setInptPolSuspendFlag(String inptPolSuspendFlag) {
     this.inptPolSuspendFlag = inptPolSuspendFlag;
 }

 
 @Column(name="inptPolTermination", length=50)
 public String getInptPolTermination() {
     return this.inptPolTermination;
 }
 
 public void setInptPolTermination(String inptPolTermination) {
     this.inptPolTermination = inptPolTermination;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPolicy")
 public Set<InptPolicyPlan> getInptPolicyPlans() {
     return this.inptPolicyPlans;
 }
 
 public void setInptPolicyPlans(Set<InptPolicyPlan> inptPolicyPlans) {
     this.inptPolicyPlans = inptPolicyPlans;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPolicy")
 public Set<PruImportDeclaration> getPruImportDeclarations() {
     return this.pruImportDeclarations;
 }
 
 public void setPruImportDeclarations(Set<PruImportDeclaration> pruImportDeclarations) {
     this.pruImportDeclarations = pruImportDeclarations;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPolicy")
 public Set<InptPolicyDates> getInptPolicyDateses() {
     return this.inptPolicyDateses;
 }
 
 public void setInptPolicyDateses(Set<InptPolicyDates> inptPolicyDateses) {
     this.inptPolicyDateses = inptPolicyDateses;
 }




}


