package com.test.demo.model.common;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This is providerType class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="provider_type"
 ,catalog="marcmy"
)
public class ProviderType  implements java.io.Serializable {


  private Integer prvTypeId;
  private boolean prvTypeEnabled;
  private String prvTypeName;
  private String prvTypeLocalName;
  private boolean prvTypeIsClinic;
  private boolean prvTypeShowAtEmember;
  private Set<MedicalProvider> medicalProviders = new HashSet<MedicalProvider>(0);

 public ProviderType() {
 }

	
 public ProviderType(boolean prvTypeEnabled, String prvTypeName, boolean prvTypeIsClinic, boolean prvTypeShowAtEmember) {
     this.prvTypeEnabled = prvTypeEnabled;
     this.prvTypeName = prvTypeName;
     this.prvTypeIsClinic = prvTypeIsClinic;
     this.prvTypeShowAtEmember = prvTypeShowAtEmember;
 }
 public ProviderType(boolean prvTypeEnabled, String prvTypeName, String prvTypeLocalName, boolean prvTypeIsClinic, boolean prvTypeShowAtEmember, Set<MedicalProvider> medicalProviders) {
    this.prvTypeEnabled = prvTypeEnabled;
    this.prvTypeName = prvTypeName;
    this.prvTypeLocalName = prvTypeLocalName;
    this.prvTypeIsClinic = prvTypeIsClinic;
    this.prvTypeShowAtEmember = prvTypeShowAtEmember;
    this.medicalProviders = medicalProviders;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="prvTypeId", unique=true, nullable=false)
 public Integer getPrvTypeId() {
     return this.prvTypeId;
 }
 
 public void setPrvTypeId(Integer prvTypeId) {
     this.prvTypeId = prvTypeId;
 }

 
 @Column(name="prvTypeEnabled", nullable=false)
 public boolean isPrvTypeEnabled() {
     return this.prvTypeEnabled;
 }
 
 public void setPrvTypeEnabled(boolean prvTypeEnabled) {
     this.prvTypeEnabled = prvTypeEnabled;
 }

 
 @Column(name="prvTypeName", nullable=false, length=50)
 public String getPrvTypeName() {
     return this.prvTypeName;
 }
 
 public void setPrvTypeName(String prvTypeName) {
     this.prvTypeName = prvTypeName;
 }

 
 @Column(name="prvTypeLocalName", length=50)
 public String getPrvTypeLocalName() {
     return this.prvTypeLocalName;
 }
 
 public void setPrvTypeLocalName(String prvTypeLocalName) {
     this.prvTypeLocalName = prvTypeLocalName;
 }

 
 @Column(name="prvTypeIsClinic", nullable=false)
 public boolean isPrvTypeIsClinic() {
     return this.prvTypeIsClinic;
 }
 
 public void setPrvTypeIsClinic(boolean prvTypeIsClinic) {
     this.prvTypeIsClinic = prvTypeIsClinic;
 }

 
 @Column(name="prvTypeShowAtEmember", nullable=false)
 public boolean isPrvTypeShowAtEmember() {
     return this.prvTypeShowAtEmember;
 }
 
 public void setPrvTypeShowAtEmember(boolean prvTypeShowAtEmember) {
     this.prvTypeShowAtEmember = prvTypeShowAtEmember;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="providerType")
 public Set<MedicalProvider> getMedicalProviders() {
     return this.medicalProviders;
 }
 
 public void setMedicalProviders(Set<MedicalProvider> medicalProviders) {
     this.medicalProviders = medicalProviders;
 }




}


