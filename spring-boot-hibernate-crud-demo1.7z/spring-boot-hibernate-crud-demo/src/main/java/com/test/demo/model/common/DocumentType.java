package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.inpt.InptCaseCsuDoc;
import com.test.demo.model.inpt.InptCaseDoc;
import com.test.demo.model.outpt.OutptCaseDoc;

/**
 * This is DocumentType class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="document_type"
 ,catalog="marcmy"
)
public class DocumentType  implements java.io.Serializable {


  private Integer docTypeId;
  private Boolean docTypeEnabled;
  private Integer docTypeCreatedBy;
  private Date docTypeCreatedDate;
  private Integer docTypeLastEdittedBy;
  private Date docTypeLastEdittedDate;
  private String docTypeName;
  private Boolean docTypeSendAsNone;
  private Boolean docTypeSendAsSms;
  private Boolean docTypeSendAsEmail;
  private Boolean docTypeSendAsFax;
  private Boolean docTypeAttnTypeClient;
  private Boolean docTypeAttnTypeInsurer;
  private Boolean docTypeAttnTypeHospital;
  private Boolean docTypeAttnTypePatient;
  private Boolean docTypeAttnTypeAgent;
  private Boolean docTypeAttnTypeInternal;
  private Boolean docTypeAttnTypeOthers;
  private Set<InptCaseCsuDoc> inptCaseCsuDocs = new HashSet<InptCaseCsuDoc>(0);
  private Set<OutptCaseDoc> outptCaseDocs = new HashSet<OutptCaseDoc>(0);
  private Set<DocumentTemplate> documentTemplates = new HashSet<DocumentTemplate>(0);
  private Set<InptCaseDoc> inptCaseDocs = new HashSet<InptCaseDoc>(0);

 public DocumentType() {
 }

 public DocumentType(Boolean docTypeEnabled, Integer docTypeCreatedBy, Date docTypeCreatedDate, Integer docTypeLastEdittedBy, Date docTypeLastEdittedDate, String docTypeName, Boolean docTypeSendAsNone, Boolean docTypeSendAsSms, Boolean docTypeSendAsEmail, Boolean docTypeSendAsFax, Boolean docTypeAttnTypeClient, Boolean docTypeAttnTypeInsurer, Boolean docTypeAttnTypeHospital, Boolean docTypeAttnTypePatient, Boolean docTypeAttnTypeAgent, Boolean docTypeAttnTypeInternal, Boolean docTypeAttnTypeOthers, Set<InptCaseCsuDoc> inptCaseCsuDocs, Set<OutptCaseDoc> outptCaseDocs, Set<DocumentTemplate> documentTemplates, Set<InptCaseDoc> inptCaseDocs) {
    this.docTypeEnabled = docTypeEnabled;
    this.docTypeCreatedBy = docTypeCreatedBy;
    this.docTypeCreatedDate = docTypeCreatedDate;
    this.docTypeLastEdittedBy = docTypeLastEdittedBy;
    this.docTypeLastEdittedDate = docTypeLastEdittedDate;
    this.docTypeName = docTypeName;
    this.docTypeSendAsNone = docTypeSendAsNone;
    this.docTypeSendAsSms = docTypeSendAsSms;
    this.docTypeSendAsEmail = docTypeSendAsEmail;
    this.docTypeSendAsFax = docTypeSendAsFax;
    this.docTypeAttnTypeClient = docTypeAttnTypeClient;
    this.docTypeAttnTypeInsurer = docTypeAttnTypeInsurer;
    this.docTypeAttnTypeHospital = docTypeAttnTypeHospital;
    this.docTypeAttnTypePatient = docTypeAttnTypePatient;
    this.docTypeAttnTypeAgent = docTypeAttnTypeAgent;
    this.docTypeAttnTypeInternal = docTypeAttnTypeInternal;
    this.docTypeAttnTypeOthers = docTypeAttnTypeOthers;
    this.inptCaseCsuDocs = inptCaseCsuDocs;
    this.outptCaseDocs = outptCaseDocs;
    this.documentTemplates = documentTemplates;
    this.inptCaseDocs = inptCaseDocs;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="docTypeId", unique=true, nullable=false)
 public Integer getDocTypeId() {
     return this.docTypeId;
 }
 
 public void setDocTypeId(Integer docTypeId) {
     this.docTypeId = docTypeId;
 }

 
 @Column(name="docTypeEnabled")
 public Boolean getDocTypeEnabled() {
     return this.docTypeEnabled;
 }
 
 public void setDocTypeEnabled(Boolean docTypeEnabled) {
     this.docTypeEnabled = docTypeEnabled;
 }

 
 @Column(name="docTypeCreatedBy")
 public Integer getDocTypeCreatedBy() {
     return this.docTypeCreatedBy;
 }
 
 public void setDocTypeCreatedBy(Integer docTypeCreatedBy) {
     this.docTypeCreatedBy = docTypeCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="docTypeCreatedDate", length=19)
 public Date getDocTypeCreatedDate() {
     return this.docTypeCreatedDate;
 }
 
 public void setDocTypeCreatedDate(Date docTypeCreatedDate) {
     this.docTypeCreatedDate = docTypeCreatedDate;
 }

 
 @Column(name="docTypeLastEdittedBy")
 public Integer getDocTypeLastEdittedBy() {
     return this.docTypeLastEdittedBy;
 }
 
 public void setDocTypeLastEdittedBy(Integer docTypeLastEdittedBy) {
     this.docTypeLastEdittedBy = docTypeLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="docTypeLastEdittedDate", length=19)
 public Date getDocTypeLastEdittedDate() {
     return this.docTypeLastEdittedDate;
 }
 
 public void setDocTypeLastEdittedDate(Date docTypeLastEdittedDate) {
     this.docTypeLastEdittedDate = docTypeLastEdittedDate;
 }

 
 @Column(name="docTypeName", length=25)
 public String getDocTypeName() {
     return this.docTypeName;
 }
 
 public void setDocTypeName(String docTypeName) {
     this.docTypeName = docTypeName;
 }

 
 @Column(name="docTypeSendAsNone")
 public Boolean getDocTypeSendAsNone() {
     return this.docTypeSendAsNone;
 }
 
 public void setDocTypeSendAsNone(Boolean docTypeSendAsNone) {
     this.docTypeSendAsNone = docTypeSendAsNone;
 }

 
 @Column(name="docTypeSendAsSMS")
 public Boolean getDocTypeSendAsSms() {
     return this.docTypeSendAsSms;
 }
 
 public void setDocTypeSendAsSms(Boolean docTypeSendAsSms) {
     this.docTypeSendAsSms = docTypeSendAsSms;
 }

 
 @Column(name="docTypeSendAsEmail")
 public Boolean getDocTypeSendAsEmail() {
     return this.docTypeSendAsEmail;
 }
 
 public void setDocTypeSendAsEmail(Boolean docTypeSendAsEmail) {
     this.docTypeSendAsEmail = docTypeSendAsEmail;
 }

 
 @Column(name="docTypeSendAsFax")
 public Boolean getDocTypeSendAsFax() {
     return this.docTypeSendAsFax;
 }
 
 public void setDocTypeSendAsFax(Boolean docTypeSendAsFax) {
     this.docTypeSendAsFax = docTypeSendAsFax;
 }

 
 @Column(name="docTypeAttnTypeClient")
 public Boolean getDocTypeAttnTypeClient() {
     return this.docTypeAttnTypeClient;
 }
 
 public void setDocTypeAttnTypeClient(Boolean docTypeAttnTypeClient) {
     this.docTypeAttnTypeClient = docTypeAttnTypeClient;
 }

 
 @Column(name="docTypeAttnTypeInsurer")
 public Boolean getDocTypeAttnTypeInsurer() {
     return this.docTypeAttnTypeInsurer;
 }
 
 public void setDocTypeAttnTypeInsurer(Boolean docTypeAttnTypeInsurer) {
     this.docTypeAttnTypeInsurer = docTypeAttnTypeInsurer;
 }

 
 @Column(name="docTypeAttnTypeHospital")
 public Boolean getDocTypeAttnTypeHospital() {
     return this.docTypeAttnTypeHospital;
 }
 
 public void setDocTypeAttnTypeHospital(Boolean docTypeAttnTypeHospital) {
     this.docTypeAttnTypeHospital = docTypeAttnTypeHospital;
 }

 
 @Column(name="docTypeAttnTypePatient")
 public Boolean getDocTypeAttnTypePatient() {
     return this.docTypeAttnTypePatient;
 }
 
 public void setDocTypeAttnTypePatient(Boolean docTypeAttnTypePatient) {
     this.docTypeAttnTypePatient = docTypeAttnTypePatient;
 }

 
 @Column(name="docTypeAttnTypeAgent")
 public Boolean getDocTypeAttnTypeAgent() {
     return this.docTypeAttnTypeAgent;
 }
 
 public void setDocTypeAttnTypeAgent(Boolean docTypeAttnTypeAgent) {
     this.docTypeAttnTypeAgent = docTypeAttnTypeAgent;
 }

 
 @Column(name="docTypeAttnTypeInternal")
 public Boolean getDocTypeAttnTypeInternal() {
     return this.docTypeAttnTypeInternal;
 }
 
 public void setDocTypeAttnTypeInternal(Boolean docTypeAttnTypeInternal) {
     this.docTypeAttnTypeInternal = docTypeAttnTypeInternal;
 }

 
 @Column(name="docTypeAttnTypeOthers")
 public Boolean getDocTypeAttnTypeOthers() {
     return this.docTypeAttnTypeOthers;
 }
 
 public void setDocTypeAttnTypeOthers(Boolean docTypeAttnTypeOthers) {
     this.docTypeAttnTypeOthers = docTypeAttnTypeOthers;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="documentType")
 public Set<InptCaseCsuDoc> getInptCaseCsuDocs() {
     return this.inptCaseCsuDocs;
 }
 
 public void setInptCaseCsuDocs(Set<InptCaseCsuDoc> inptCaseCsuDocs) {
     this.inptCaseCsuDocs = inptCaseCsuDocs;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="documentType")
 public Set<OutptCaseDoc> getOutptCaseDocs() {
     return this.outptCaseDocs;
 }
 
 public void setOutptCaseDocs(Set<OutptCaseDoc> outptCaseDocs) {
     this.outptCaseDocs = outptCaseDocs;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="documentType")
 public Set<DocumentTemplate> getDocumentTemplates() {
     return this.documentTemplates;
 }
 
 public void setDocumentTemplates(Set<DocumentTemplate> documentTemplates) {
     this.documentTemplates = documentTemplates;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="documentType")
 public Set<InptCaseDoc> getInptCaseDocs() {
     return this.inptCaseDocs;
 }
 
 public void setInptCaseDocs(Set<InptCaseDoc> inptCaseDocs) {
     this.inptCaseDocs = inptCaseDocs;
 }




}


