package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * OutptCaseAdmin class 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_case_admin"
 ,catalog="marcmy"
)
public class OutptCaseAdmin  implements java.io.Serializable {


  private Integer outptCaseAdminId;
  private OutptCase outptCase;
  private OutptClaim outptClaim;
  private Integer outptCaseAdminCreatedBy;
  private String outptCaseAdminCreatedByAbbvName;
  private Date outptCaseAdminCreatedDate;
  private Integer outptCaseAdminLastEdittedBy;
  private String outptCaseAdminLastEdittedByAbbvName;
  private Date outptCaseAdminLastEdittedDate;
  private String outptCaseAdminDocumentSentTo;
  private String outptCaseAdminRecipientName;
  private String outptCaseAdminAddress1;
  private String outptCaseAdminAddress2;
  private String outptCaseAdminAddress3;
  private String outptCaseAdminAddress4;
  private String outptCaseAdminPostalCode;
  private String outptCaseAdminCountry;
  private String outptCaseAdminCourierType;
  private String outptCaseAdminCourierTrackingNo;
  private Date outptCaseAdminDocSendDate;
  private String outptCaseAdminDocIndexNo;
  private boolean outptCaseAdminSentReceipt;
  private boolean outptCaseAdminSentCtcReceipt;
  private boolean outptCaseAdminSentSettlementLetter;
  private boolean outptCaseAdminSentOpdMedicalCert;
  private boolean outptCaseAdminSentIpdMedicalCert;
  private boolean outptCaseAdminSentInvoice;
  private boolean outptCaseAdminSentClaimDocs;
  private String outptCaseAdminSentRemarks;
  private boolean outptCaseAdminSentCheque;

 public OutptCaseAdmin() {
 }

	
 public OutptCaseAdmin(boolean outptCaseAdminSentReceipt, boolean outptCaseAdminSentCtcReceipt, boolean outptCaseAdminSentSettlementLetter, boolean outptCaseAdminSentOpdMedicalCert, boolean outptCaseAdminSentIpdMedicalCert, boolean outptCaseAdminSentInvoice, boolean outptCaseAdminSentClaimDocs, boolean outptCaseAdminSentCheque) {
     this.outptCaseAdminSentReceipt = outptCaseAdminSentReceipt;
     this.outptCaseAdminSentCtcReceipt = outptCaseAdminSentCtcReceipt;
     this.outptCaseAdminSentSettlementLetter = outptCaseAdminSentSettlementLetter;
     this.outptCaseAdminSentOpdMedicalCert = outptCaseAdminSentOpdMedicalCert;
     this.outptCaseAdminSentIpdMedicalCert = outptCaseAdminSentIpdMedicalCert;
     this.outptCaseAdminSentInvoice = outptCaseAdminSentInvoice;
     this.outptCaseAdminSentClaimDocs = outptCaseAdminSentClaimDocs;
     this.outptCaseAdminSentCheque = outptCaseAdminSentCheque;
 }

 public OutptCaseAdmin(OutptCase outptCase, OutptClaim outptClaim, Integer outptCaseAdminCreatedBy, String outptCaseAdminCreatedByAbbvName, Date outptCaseAdminCreatedDate, Integer outptCaseAdminLastEdittedBy, String outptCaseAdminLastEdittedByAbbvName, Date outptCaseAdminLastEdittedDate, String outptCaseAdminDocumentSentTo, String outptCaseAdminRecipientName, String outptCaseAdminAddress1, String outptCaseAdminAddress2, String outptCaseAdminAddress3, String outptCaseAdminAddress4, String outptCaseAdminPostalCode, String outptCaseAdminCountry, String outptCaseAdminCourierType, String outptCaseAdminCourierTrackingNo, Date outptCaseAdminDocSendDate, String outptCaseAdminDocIndexNo, boolean outptCaseAdminSentReceipt, boolean outptCaseAdminSentCtcReceipt, boolean outptCaseAdminSentSettlementLetter, boolean outptCaseAdminSentOpdMedicalCert, boolean outptCaseAdminSentIpdMedicalCert, boolean outptCaseAdminSentInvoice, boolean outptCaseAdminSentClaimDocs, String outptCaseAdminSentRemarks, boolean outptCaseAdminSentCheque) {
    this.outptCase = outptCase;
    this.outptClaim = outptClaim;
    this.outptCaseAdminCreatedBy = outptCaseAdminCreatedBy;
    this.outptCaseAdminCreatedByAbbvName = outptCaseAdminCreatedByAbbvName;
    this.outptCaseAdminCreatedDate = outptCaseAdminCreatedDate;
    this.outptCaseAdminLastEdittedBy = outptCaseAdminLastEdittedBy;
    this.outptCaseAdminLastEdittedByAbbvName = outptCaseAdminLastEdittedByAbbvName;
    this.outptCaseAdminLastEdittedDate = outptCaseAdminLastEdittedDate;
    this.outptCaseAdminDocumentSentTo = outptCaseAdminDocumentSentTo;
    this.outptCaseAdminRecipientName = outptCaseAdminRecipientName;
    this.outptCaseAdminAddress1 = outptCaseAdminAddress1;
    this.outptCaseAdminAddress2 = outptCaseAdminAddress2;
    this.outptCaseAdminAddress3 = outptCaseAdminAddress3;
    this.outptCaseAdminAddress4 = outptCaseAdminAddress4;
    this.outptCaseAdminPostalCode = outptCaseAdminPostalCode;
    this.outptCaseAdminCountry = outptCaseAdminCountry;
    this.outptCaseAdminCourierType = outptCaseAdminCourierType;
    this.outptCaseAdminCourierTrackingNo = outptCaseAdminCourierTrackingNo;
    this.outptCaseAdminDocSendDate = outptCaseAdminDocSendDate;
    this.outptCaseAdminDocIndexNo = outptCaseAdminDocIndexNo;
    this.outptCaseAdminSentReceipt = outptCaseAdminSentReceipt;
    this.outptCaseAdminSentCtcReceipt = outptCaseAdminSentCtcReceipt;
    this.outptCaseAdminSentSettlementLetter = outptCaseAdminSentSettlementLetter;
    this.outptCaseAdminSentOpdMedicalCert = outptCaseAdminSentOpdMedicalCert;
    this.outptCaseAdminSentIpdMedicalCert = outptCaseAdminSentIpdMedicalCert;
    this.outptCaseAdminSentInvoice = outptCaseAdminSentInvoice;
    this.outptCaseAdminSentClaimDocs = outptCaseAdminSentClaimDocs;
    this.outptCaseAdminSentRemarks = outptCaseAdminSentRemarks;
    this.outptCaseAdminSentCheque = outptCaseAdminSentCheque;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptCaseAdminId", unique=true, nullable=false)
 public Integer getOutptCaseAdminId() {
     return this.outptCaseAdminId;
 }
 
 public void setOutptCaseAdminId(Integer outptCaseAdminId) {
     this.outptCaseAdminId = outptCaseAdminId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptCaseAdminCaseId")
 public OutptCase getOutptCase() {
     return this.outptCase;
 }
 
 public void setOutptCase(OutptCase outptCase) {
     this.outptCase = outptCase;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptCaseAdminClaimId")
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="outptCaseAdminCreatedBy")
 public Integer getOutptCaseAdminCreatedBy() {
     return this.outptCaseAdminCreatedBy;
 }
 
 public void setOutptCaseAdminCreatedBy(Integer outptCaseAdminCreatedBy) {
     this.outptCaseAdminCreatedBy = outptCaseAdminCreatedBy;
 }

 
 @Column(name="outptCaseAdminCreatedByAbbvName", length=8)
 public String getOutptCaseAdminCreatedByAbbvName() {
     return this.outptCaseAdminCreatedByAbbvName;
 }
 
 public void setOutptCaseAdminCreatedByAbbvName(String outptCaseAdminCreatedByAbbvName) {
     this.outptCaseAdminCreatedByAbbvName = outptCaseAdminCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptCaseAdminCreatedDate", length=19)
 public Date getOutptCaseAdminCreatedDate() {
     return this.outptCaseAdminCreatedDate;
 }
 
 public void setOutptCaseAdminCreatedDate(Date outptCaseAdminCreatedDate) {
     this.outptCaseAdminCreatedDate = outptCaseAdminCreatedDate;
 }

 
 @Column(name="outptCaseAdminLastEdittedBy")
 public Integer getOutptCaseAdminLastEdittedBy() {
     return this.outptCaseAdminLastEdittedBy;
 }
 
 public void setOutptCaseAdminLastEdittedBy(Integer outptCaseAdminLastEdittedBy) {
     this.outptCaseAdminLastEdittedBy = outptCaseAdminLastEdittedBy;
 }

 
 @Column(name="outptCaseAdminLastEdittedByAbbvName", length=8)
 public String getOutptCaseAdminLastEdittedByAbbvName() {
     return this.outptCaseAdminLastEdittedByAbbvName;
 }
 
 public void setOutptCaseAdminLastEdittedByAbbvName(String outptCaseAdminLastEdittedByAbbvName) {
     this.outptCaseAdminLastEdittedByAbbvName = outptCaseAdminLastEdittedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptCaseAdminLastEdittedDate", length=19)
 public Date getOutptCaseAdminLastEdittedDate() {
     return this.outptCaseAdminLastEdittedDate;
 }
 
 public void setOutptCaseAdminLastEdittedDate(Date outptCaseAdminLastEdittedDate) {
     this.outptCaseAdminLastEdittedDate = outptCaseAdminLastEdittedDate;
 }

 
 @Column(name="outptCaseAdminDocumentSentTo", length=150)
 public String getOutptCaseAdminDocumentSentTo() {
     return this.outptCaseAdminDocumentSentTo;
 }
 
 public void setOutptCaseAdminDocumentSentTo(String outptCaseAdminDocumentSentTo) {
     this.outptCaseAdminDocumentSentTo = outptCaseAdminDocumentSentTo;
 }

 
 @Column(name="outptCaseAdminRecipientName", length=50)
 public String getOutptCaseAdminRecipientName() {
     return this.outptCaseAdminRecipientName;
 }
 
 public void setOutptCaseAdminRecipientName(String outptCaseAdminRecipientName) {
     this.outptCaseAdminRecipientName = outptCaseAdminRecipientName;
 }

 
 @Column(name="outptCaseAdminAddress1", length=250)
 public String getOutptCaseAdminAddress1() {
     return this.outptCaseAdminAddress1;
 }
 
 public void setOutptCaseAdminAddress1(String outptCaseAdminAddress1) {
     this.outptCaseAdminAddress1 = outptCaseAdminAddress1;
 }

 
 @Column(name="outptCaseAdminAddress2", length=250)
 public String getOutptCaseAdminAddress2() {
     return this.outptCaseAdminAddress2;
 }
 
 public void setOutptCaseAdminAddress2(String outptCaseAdminAddress2) {
     this.outptCaseAdminAddress2 = outptCaseAdminAddress2;
 }

 
 @Column(name="outptCaseAdminAddress3", length=250)
 public String getOutptCaseAdminAddress3() {
     return this.outptCaseAdminAddress3;
 }
 
 public void setOutptCaseAdminAddress3(String outptCaseAdminAddress3) {
     this.outptCaseAdminAddress3 = outptCaseAdminAddress3;
 }

 
 @Column(name="outptCaseAdminAddress4", length=250)
 public String getOutptCaseAdminAddress4() {
     return this.outptCaseAdminAddress4;
 }
 
 public void setOutptCaseAdminAddress4(String outptCaseAdminAddress4) {
     this.outptCaseAdminAddress4 = outptCaseAdminAddress4;
 }

 
 @Column(name="outptCaseAdminPostalCode", length=20)
 public String getOutptCaseAdminPostalCode() {
     return this.outptCaseAdminPostalCode;
 }
 
 public void setOutptCaseAdminPostalCode(String outptCaseAdminPostalCode) {
     this.outptCaseAdminPostalCode = outptCaseAdminPostalCode;
 }

 
 @Column(name="outptCaseAdminCountry", length=80)
 public String getOutptCaseAdminCountry() {
     return this.outptCaseAdminCountry;
 }
 
 public void setOutptCaseAdminCountry(String outptCaseAdminCountry) {
     this.outptCaseAdminCountry = outptCaseAdminCountry;
 }

 
 @Column(name="outptCaseAdminCourierType", length=20)
 public String getOutptCaseAdminCourierType() {
     return this.outptCaseAdminCourierType;
 }
 
 public void setOutptCaseAdminCourierType(String outptCaseAdminCourierType) {
     this.outptCaseAdminCourierType = outptCaseAdminCourierType;
 }

 
 @Column(name="outptCaseAdminCourierTrackingNo", length=20)
 public String getOutptCaseAdminCourierTrackingNo() {
     return this.outptCaseAdminCourierTrackingNo;
 }
 
 public void setOutptCaseAdminCourierTrackingNo(String outptCaseAdminCourierTrackingNo) {
     this.outptCaseAdminCourierTrackingNo = outptCaseAdminCourierTrackingNo;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptCaseAdminDocSendDate", length=19)
 public Date getOutptCaseAdminDocSendDate() {
     return this.outptCaseAdminDocSendDate;
 }
 
 public void setOutptCaseAdminDocSendDate(Date outptCaseAdminDocSendDate) {
     this.outptCaseAdminDocSendDate = outptCaseAdminDocSendDate;
 }

 
 @Column(name="outptCaseAdminDocIndexNo", length=20)
 public String getOutptCaseAdminDocIndexNo() {
     return this.outptCaseAdminDocIndexNo;
 }
 
 public void setOutptCaseAdminDocIndexNo(String outptCaseAdminDocIndexNo) {
     this.outptCaseAdminDocIndexNo = outptCaseAdminDocIndexNo;
 }

 
 @Column(name="outptCaseAdminSentReceipt", nullable=false)
 public boolean isOutptCaseAdminSentReceipt() {
     return this.outptCaseAdminSentReceipt;
 }
 
 public void setOutptCaseAdminSentReceipt(boolean outptCaseAdminSentReceipt) {
     this.outptCaseAdminSentReceipt = outptCaseAdminSentReceipt;
 }

 
 @Column(name="outptCaseAdminSentCtcReceipt", nullable=false)
 public boolean isOutptCaseAdminSentCtcReceipt() {
     return this.outptCaseAdminSentCtcReceipt;
 }
 
 public void setOutptCaseAdminSentCtcReceipt(boolean outptCaseAdminSentCtcReceipt) {
     this.outptCaseAdminSentCtcReceipt = outptCaseAdminSentCtcReceipt;
 }

 
 @Column(name="outptCaseAdminSentSettlementLetter", nullable=false)
 public boolean isOutptCaseAdminSentSettlementLetter() {
     return this.outptCaseAdminSentSettlementLetter;
 }
 
 public void setOutptCaseAdminSentSettlementLetter(boolean outptCaseAdminSentSettlementLetter) {
     this.outptCaseAdminSentSettlementLetter = outptCaseAdminSentSettlementLetter;
 }

 
 @Column(name="outptCaseAdminSentOpdMedicalCert", nullable=false)
 public boolean isOutptCaseAdminSentOpdMedicalCert() {
     return this.outptCaseAdminSentOpdMedicalCert;
 }
 
 public void setOutptCaseAdminSentOpdMedicalCert(boolean outptCaseAdminSentOpdMedicalCert) {
     this.outptCaseAdminSentOpdMedicalCert = outptCaseAdminSentOpdMedicalCert;
 }

 
 @Column(name="outptCaseAdminSentIpdMedicalCert", nullable=false)
 public boolean isOutptCaseAdminSentIpdMedicalCert() {
     return this.outptCaseAdminSentIpdMedicalCert;
 }
 
 public void setOutptCaseAdminSentIpdMedicalCert(boolean outptCaseAdminSentIpdMedicalCert) {
     this.outptCaseAdminSentIpdMedicalCert = outptCaseAdminSentIpdMedicalCert;
 }

 
 @Column(name="outptCaseAdminSentInvoice", nullable=false)
 public boolean isOutptCaseAdminSentInvoice() {
     return this.outptCaseAdminSentInvoice;
 }
 
 public void setOutptCaseAdminSentInvoice(boolean outptCaseAdminSentInvoice) {
     this.outptCaseAdminSentInvoice = outptCaseAdminSentInvoice;
 }

 
 @Column(name="outptCaseAdminSentClaimDocs", nullable=false)
 public boolean isOutptCaseAdminSentClaimDocs() {
     return this.outptCaseAdminSentClaimDocs;
 }
 
 public void setOutptCaseAdminSentClaimDocs(boolean outptCaseAdminSentClaimDocs) {
     this.outptCaseAdminSentClaimDocs = outptCaseAdminSentClaimDocs;
 }

 
 @Column(name="outptCaseAdminSentRemarks", length=65535)
 public String getOutptCaseAdminSentRemarks() {
     return this.outptCaseAdminSentRemarks;
 }
 
 public void setOutptCaseAdminSentRemarks(String outptCaseAdminSentRemarks) {
     this.outptCaseAdminSentRemarks = outptCaseAdminSentRemarks;
 }

 
 @Column(name="outptCaseAdminSentCheque", nullable=false)
 public boolean isOutptCaseAdminSentCheque() {
     return this.outptCaseAdminSentCheque;
 }
 
 public void setOutptCaseAdminSentCheque(boolean outptCaseAdminSentCheque) {
     this.outptCaseAdminSentCheque = outptCaseAdminSentCheque;
 }




}


