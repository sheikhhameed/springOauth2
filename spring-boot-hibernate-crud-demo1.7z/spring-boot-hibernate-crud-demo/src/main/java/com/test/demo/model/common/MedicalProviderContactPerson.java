package com.test.demo.model.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This is medicalProviderContactPerson class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="medical_provider_contact_person"
 ,catalog="marcmy"
)
public class MedicalProviderContactPerson  implements java.io.Serializable {


  private Integer medCntctPersonId;
  private MedicalProvider medicalProvider;
  private String medCntctPersonName;
  private String medCntctPersonDepartment;
  private String medCntctPersonTelNo;
  private String medCntctPersonPosition;
  private String medCntctPersonEmail;
  private String medCntctPersonFax;

 public MedicalProviderContactPerson() {
 }

 public MedicalProviderContactPerson(MedicalProvider medicalProvider, String medCntctPersonName, String medCntctPersonDepartment, String medCntctPersonTelNo, String medCntctPersonPosition, String medCntctPersonEmail, String medCntctPersonFax) {
    this.medicalProvider = medicalProvider;
    this.medCntctPersonName = medCntctPersonName;
    this.medCntctPersonDepartment = medCntctPersonDepartment;
    this.medCntctPersonTelNo = medCntctPersonTelNo;
    this.medCntctPersonPosition = medCntctPersonPosition;
    this.medCntctPersonEmail = medCntctPersonEmail;
    this.medCntctPersonFax = medCntctPersonFax;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="medCntctPersonId", unique=true, nullable=false)
 public Integer getMedCntctPersonId() {
     return this.medCntctPersonId;
 }
 
 public void setMedCntctPersonId(Integer medCntctPersonId) {
     this.medCntctPersonId = medCntctPersonId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medCntctPersonMedPrvId")
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }
 
 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }

 
 @Column(name="medCntctPersonName", length=250)
 public String getMedCntctPersonName() {
     return this.medCntctPersonName;
 }
 
 public void setMedCntctPersonName(String medCntctPersonName) {
     this.medCntctPersonName = medCntctPersonName;
 }

 
 @Column(name="medCntctPersonDepartment", length=50)
 public String getMedCntctPersonDepartment() {
     return this.medCntctPersonDepartment;
 }
 
 public void setMedCntctPersonDepartment(String medCntctPersonDepartment) {
     this.medCntctPersonDepartment = medCntctPersonDepartment;
 }

 
 @Column(name="medCntctPersonTelNo", length=50)
 public String getMedCntctPersonTelNo() {
     return this.medCntctPersonTelNo;
 }
 
 public void setMedCntctPersonTelNo(String medCntctPersonTelNo) {
     this.medCntctPersonTelNo = medCntctPersonTelNo;
 }

 
 @Column(name="medCntctPersonPosition", length=50)
 public String getMedCntctPersonPosition() {
     return this.medCntctPersonPosition;
 }
 
 public void setMedCntctPersonPosition(String medCntctPersonPosition) {
     this.medCntctPersonPosition = medCntctPersonPosition;
 }

 
 @Column(name="medCntctPersonEmail", length=50)
 public String getMedCntctPersonEmail() {
     return this.medCntctPersonEmail;
 }
 
 public void setMedCntctPersonEmail(String medCntctPersonEmail) {
     this.medCntctPersonEmail = medCntctPersonEmail;
 }

 
 @Column(name="medCntctPersonFax", length=51)
 public String getMedCntctPersonFax() {
     return this.medCntctPersonFax;
 }
 
 public void setMedCntctPersonFax(String medCntctPersonFax) {
     this.medCntctPersonFax = medCntctPersonFax;
 }




}


