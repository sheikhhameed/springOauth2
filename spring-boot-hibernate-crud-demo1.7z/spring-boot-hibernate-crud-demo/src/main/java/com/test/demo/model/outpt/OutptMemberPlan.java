package com.test.demo.model.outpt;

import static javax.persistence.GenerationType.IDENTITY;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Member;

/**
 * This is outptMemberPlan class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_member_plan"
 ,catalog="marcmy"
)
public class OutptMemberPlan  implements java.io.Serializable {


  private Integer ompId;
  private Member member;
  private Boolean ompEnabled;
  private Integer ompCreatedBy;
  private String ompCreatedByAbbvName;
  private Date ompReinstateDate;
  private Date ompCreatedDate;
  private Integer ompLastEdittedBy;
  private String ompLastEdittedByAbbvName;
  private Date ompLastEdittedDate;
  private String ompPolicyNum;
  private String ompExternalRefId;
  private String ompEmployeeId;
  private Date ompFirstJoinDate;
  private Date ompPlanEffDate;
  private Date ompPlanExpDate;
  private Date ompPlanCancelDate;
  private String ompAddress1;
  private String ompAddress2;
  private String ompAddress3;
  private String ompAddress4;
  private String ompPostal;
  private String ompCity;
  private String ompCountry;
  private String ompEmail;
  private String ompTel;
  private Boolean ompVip;
  private String ompDepNum;
  private String ompRelationship;
  private Integer ompPrincipalOmpId;
  private String ompSpecCond;
  private String ompExclusion;
  private String ompSchoolName;
  private String ompSchoolState;
  private String ompPolicyOwnerName;
  private String ompPolicyOwnerChineseName;
  private Character ompPolicyGender;
  private Date ompPolicyDob;
  private String ompAgencyBranch;
  private String ompAgencyName;
  private String ompAgencyChineseName;
  private String ompAgencyCode;
  private String ompAgencyEmail;
  private String ompAgencyTel;
  private String ompAgentName;
  private String ompAgentFaxTel;
  private String ompAgentTel;
  private String ompAgentCode;
  private String ompAgentRemarks;
  private String ompAgentAddress1;
  private String ompAgentAddress2;
  private String ompAgentAddress3;
  private String ompAgentAddress4;
  private String ompAgentCountry;
  private Integer ompAnnMaxVisitUtilCf;
  private String ompAgentAddress5;
  private String ompAgentPostal;
  private String ompAgentState;
  private BigDecimal ompAnnUtilCf;
  private BigDecimal ompLtUtilCf;
  private String ompSubsidiaryCompany;
  private Integer ompImppId;
  private String ompSubsidiaryNo;
  private String ompFamilyNo;
  private String ompPersonCertNo;
  private String ompJobPosition;
  private String ompMemberBand;
  private String ompBankName;
  private String ompBankAccountNumber;
  private String ompBankBranchName;
  private String ompBankCode;
  private Date ompPaidToDate;
  private BigDecimal ompNetPremium;
  private String ompFrequencyOfPaymentMode;
  private Integer ompNoOfMainPolicyYear;
  private Integer ompNoOfHealthPolicyYear;
  private String ompInsBranchCode;
  private String ompInsBranchName;
  private String ompRemarks;
  private String ompDepartment;
  private Integer ompImportBatchId;
  private String ompDivision;
  private String ompCostCentre;
  private String ompBranch;
  private String ompGrade;
  private String ompEmail2;
  private Set<OutptPlanMovement> outptPlanMovements = new HashSet<OutptPlanMovement>(0);

 public OutptMemberPlan() {
 }

	
 public OutptMemberPlan(Member member) {
     this.member = member;
 }
 public OutptMemberPlan(Member member, Boolean ompEnabled, Integer ompCreatedBy, String ompCreatedByAbbvName, Date ompReinstateDate, Date ompCreatedDate, Integer ompLastEdittedBy, String ompLastEdittedByAbbvName, Date ompLastEdittedDate, String ompPolicyNum, String ompExternalRefId, String ompEmployeeId, Date ompFirstJoinDate, Date ompPlanEffDate, Date ompPlanExpDate, Date ompPlanCancelDate, String ompAddress1, String ompAddress2, String ompAddress3, String ompAddress4, String ompPostal, String ompCity, String ompCountry, String ompEmail, String ompTel, Boolean ompVip, String ompDepNum, String ompRelationship, Integer ompPrincipalOmpId, String ompSpecCond, String ompExclusion, String ompSchoolName, String ompSchoolState, String ompPolicyOwnerName, String ompPolicyOwnerChineseName, Character ompPolicyGender, Date ompPolicyDob, String ompAgencyBranch, String ompAgencyName, String ompAgencyChineseName, String ompAgencyCode, String ompAgencyEmail, String ompAgencyTel, String ompAgentName, String ompAgentFaxTel, String ompAgentTel, String ompAgentCode, String ompAgentRemarks, String ompAgentAddress1, String ompAgentAddress2, String ompAgentAddress3, String ompAgentAddress4, String ompAgentCountry, Integer ompAnnMaxVisitUtilCf, String ompAgentAddress5, String ompAgentPostal, String ompAgentState, BigDecimal ompAnnUtilCf, BigDecimal ompLtUtilCf, String ompSubsidiaryCompany, Integer ompImppId, String ompSubsidiaryNo, String ompFamilyNo, String ompPersonCertNo, String ompJobPosition, String ompMemberBand, String ompBankName, String ompBankAccountNumber, String ompBankBranchName, String ompBankCode, Date ompPaidToDate, BigDecimal ompNetPremium, String ompFrequencyOfPaymentMode, Integer ompNoOfMainPolicyYear, Integer ompNoOfHealthPolicyYear, String ompInsBranchCode, String ompInsBranchName, String ompRemarks, String ompDepartment, Integer ompImportBatchId, String ompDivision, String ompCostCentre, String ompBranch, String ompGrade, String ompEmail2, Set<OutptPlanMovement> outptPlanMovements) {
    this.member = member;
    this.ompEnabled = ompEnabled;
    this.ompCreatedBy = ompCreatedBy;
    this.ompCreatedByAbbvName = ompCreatedByAbbvName;
    this.ompReinstateDate = ompReinstateDate;
    this.ompCreatedDate = ompCreatedDate;
    this.ompLastEdittedBy = ompLastEdittedBy;
    this.ompLastEdittedByAbbvName = ompLastEdittedByAbbvName;
    this.ompLastEdittedDate = ompLastEdittedDate;
    this.ompPolicyNum = ompPolicyNum;
    this.ompExternalRefId = ompExternalRefId;
    this.ompEmployeeId = ompEmployeeId;
    this.ompFirstJoinDate = ompFirstJoinDate;
    this.ompPlanEffDate = ompPlanEffDate;
    this.ompPlanExpDate = ompPlanExpDate;
    this.ompPlanCancelDate = ompPlanCancelDate;
    this.ompAddress1 = ompAddress1;
    this.ompAddress2 = ompAddress2;
    this.ompAddress3 = ompAddress3;
    this.ompAddress4 = ompAddress4;
    this.ompPostal = ompPostal;
    this.ompCity = ompCity;
    this.ompCountry = ompCountry;
    this.ompEmail = ompEmail;
    this.ompTel = ompTel;
    this.ompVip = ompVip;
    this.ompDepNum = ompDepNum;
    this.ompRelationship = ompRelationship;
    this.ompPrincipalOmpId = ompPrincipalOmpId;
    this.ompSpecCond = ompSpecCond;
    this.ompExclusion = ompExclusion;
    this.ompSchoolName = ompSchoolName;
    this.ompSchoolState = ompSchoolState;
    this.ompPolicyOwnerName = ompPolicyOwnerName;
    this.ompPolicyOwnerChineseName = ompPolicyOwnerChineseName;
    this.ompPolicyGender = ompPolicyGender;
    this.ompPolicyDob = ompPolicyDob;
    this.ompAgencyBranch = ompAgencyBranch;
    this.ompAgencyName = ompAgencyName;
    this.ompAgencyChineseName = ompAgencyChineseName;
    this.ompAgencyCode = ompAgencyCode;
    this.ompAgencyEmail = ompAgencyEmail;
    this.ompAgencyTel = ompAgencyTel;
    this.ompAgentName = ompAgentName;
    this.ompAgentFaxTel = ompAgentFaxTel;
    this.ompAgentTel = ompAgentTel;
    this.ompAgentCode = ompAgentCode;
    this.ompAgentRemarks = ompAgentRemarks;
    this.ompAgentAddress1 = ompAgentAddress1;
    this.ompAgentAddress2 = ompAgentAddress2;
    this.ompAgentAddress3 = ompAgentAddress3;
    this.ompAgentAddress4 = ompAgentAddress4;
    this.ompAgentCountry = ompAgentCountry;
    this.ompAnnMaxVisitUtilCf = ompAnnMaxVisitUtilCf;
    this.ompAgentAddress5 = ompAgentAddress5;
    this.ompAgentPostal = ompAgentPostal;
    this.ompAgentState = ompAgentState;
    this.ompAnnUtilCf = ompAnnUtilCf;
    this.ompLtUtilCf = ompLtUtilCf;
    this.ompSubsidiaryCompany = ompSubsidiaryCompany;
    this.ompImppId = ompImppId;
    this.ompSubsidiaryNo = ompSubsidiaryNo;
    this.ompFamilyNo = ompFamilyNo;
    this.ompPersonCertNo = ompPersonCertNo;
    this.ompJobPosition = ompJobPosition;
    this.ompMemberBand = ompMemberBand;
    this.ompBankName = ompBankName;
    this.ompBankAccountNumber = ompBankAccountNumber;
    this.ompBankBranchName = ompBankBranchName;
    this.ompBankCode = ompBankCode;
    this.ompPaidToDate = ompPaidToDate;
    this.ompNetPremium = ompNetPremium;
    this.ompFrequencyOfPaymentMode = ompFrequencyOfPaymentMode;
    this.ompNoOfMainPolicyYear = ompNoOfMainPolicyYear;
    this.ompNoOfHealthPolicyYear = ompNoOfHealthPolicyYear;
    this.ompInsBranchCode = ompInsBranchCode;
    this.ompInsBranchName = ompInsBranchName;
    this.ompRemarks = ompRemarks;
    this.ompDepartment = ompDepartment;
    this.ompImportBatchId = ompImportBatchId;
    this.ompDivision = ompDivision;
    this.ompCostCentre = ompCostCentre;
    this.ompBranch = ompBranch;
    this.ompGrade = ompGrade;
    this.ompEmail2 = ompEmail2;
    this.outptPlanMovements = outptPlanMovements;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ompId", unique=true, nullable=false)
 public Integer getOmpId() {
     return this.ompId;
 }
 
 public void setOmpId(Integer ompId) {
     this.ompId = ompId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ompMemberId", nullable=false)
 public Member getMember() {
     return this.member;
 }
 
 public void setMember(Member member) {
     this.member = member;
 }

 
 @Column(name="ompEnabled")
 public Boolean getOmpEnabled() {
     return this.ompEnabled;
 }
 
 public void setOmpEnabled(Boolean ompEnabled) {
     this.ompEnabled = ompEnabled;
 }

 
 @Column(name="ompCreatedBy")
 public Integer getOmpCreatedBy() {
     return this.ompCreatedBy;
 }
 
 public void setOmpCreatedBy(Integer ompCreatedBy) {
     this.ompCreatedBy = ompCreatedBy;
 }

 
 @Column(name="ompCreatedByAbbvName", length=8)
 public String getOmpCreatedByAbbvName() {
     return this.ompCreatedByAbbvName;
 }
 
 public void setOmpCreatedByAbbvName(String ompCreatedByAbbvName) {
     this.ompCreatedByAbbvName = ompCreatedByAbbvName;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompReinstateDate", length=10)
 public Date getOmpReinstateDate() {
     return this.ompReinstateDate;
 }
 
 public void setOmpReinstateDate(Date ompReinstateDate) {
     this.ompReinstateDate = ompReinstateDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ompCreatedDate", length=19)
 public Date getOmpCreatedDate() {
     return this.ompCreatedDate;
 }
 
 public void setOmpCreatedDate(Date ompCreatedDate) {
     this.ompCreatedDate = ompCreatedDate;
 }

 
 @Column(name="ompLastEdittedBy")
 public Integer getOmpLastEdittedBy() {
     return this.ompLastEdittedBy;
 }
 
 public void setOmpLastEdittedBy(Integer ompLastEdittedBy) {
     this.ompLastEdittedBy = ompLastEdittedBy;
 }

 
 @Column(name="ompLastEdittedByAbbvName", length=8)
 public String getOmpLastEdittedByAbbvName() {
     return this.ompLastEdittedByAbbvName;
 }
 
 public void setOmpLastEdittedByAbbvName(String ompLastEdittedByAbbvName) {
     this.ompLastEdittedByAbbvName = ompLastEdittedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ompLastEdittedDate", length=19)
 public Date getOmpLastEdittedDate() {
     return this.ompLastEdittedDate;
 }
 
 public void setOmpLastEdittedDate(Date ompLastEdittedDate) {
     this.ompLastEdittedDate = ompLastEdittedDate;
 }

 
 @Column(name="ompPolicyNum", length=50)
 public String getOmpPolicyNum() {
     return this.ompPolicyNum;
 }
 
 public void setOmpPolicyNum(String ompPolicyNum) {
     this.ompPolicyNum = ompPolicyNum;
 }

 
 @Column(name="ompExternalRefId", length=50)
 public String getOmpExternalRefId() {
     return this.ompExternalRefId;
 }
 
 public void setOmpExternalRefId(String ompExternalRefId) {
     this.ompExternalRefId = ompExternalRefId;
 }

 
 @Column(name="ompEmployeeId", length=15)
 public String getOmpEmployeeId() {
     return this.ompEmployeeId;
 }
 
 public void setOmpEmployeeId(String ompEmployeeId) {
     this.ompEmployeeId = ompEmployeeId;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompFirstJoinDate", length=10)
 public Date getOmpFirstJoinDate() {
     return this.ompFirstJoinDate;
 }
 
 public void setOmpFirstJoinDate(Date ompFirstJoinDate) {
     this.ompFirstJoinDate = ompFirstJoinDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompPlanEffDate", length=10)
 public Date getOmpPlanEffDate() {
     return this.ompPlanEffDate;
 }
 
 public void setOmpPlanEffDate(Date ompPlanEffDate) {
     this.ompPlanEffDate = ompPlanEffDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompPlanExpDate", length=10)
 public Date getOmpPlanExpDate() {
     return this.ompPlanExpDate;
 }
 
 public void setOmpPlanExpDate(Date ompPlanExpDate) {
     this.ompPlanExpDate = ompPlanExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompPlanCancelDate", length=10)
 public Date getOmpPlanCancelDate() {
     return this.ompPlanCancelDate;
 }
 
 public void setOmpPlanCancelDate(Date ompPlanCancelDate) {
     this.ompPlanCancelDate = ompPlanCancelDate;
 }

 
 @Column(name="ompAddress1", length=250)
 public String getOmpAddress1() {
     return this.ompAddress1;
 }
 
 public void setOmpAddress1(String ompAddress1) {
     this.ompAddress1 = ompAddress1;
 }

 
 @Column(name="ompAddress2", length=250)
 public String getOmpAddress2() {
     return this.ompAddress2;
 }
 
 public void setOmpAddress2(String ompAddress2) {
     this.ompAddress2 = ompAddress2;
 }

 
 @Column(name="ompAddress3", length=250)
 public String getOmpAddress3() {
     return this.ompAddress3;
 }
 
 public void setOmpAddress3(String ompAddress3) {
     this.ompAddress3 = ompAddress3;
 }

 
 @Column(name="ompAddress4", length=250)
 public String getOmpAddress4() {
     return this.ompAddress4;
 }
 
 public void setOmpAddress4(String ompAddress4) {
     this.ompAddress4 = ompAddress4;
 }

 
 @Column(name="ompPostal", length=10)
 public String getOmpPostal() {
     return this.ompPostal;
 }
 
 public void setOmpPostal(String ompPostal) {
     this.ompPostal = ompPostal;
 }

 
 @Column(name="ompCity", length=60)
 public String getOmpCity() {
     return this.ompCity;
 }
 
 public void setOmpCity(String ompCity) {
     this.ompCity = ompCity;
 }

 
 @Column(name="ompCountry", length=80)
 public String getOmpCountry() {
     return this.ompCountry;
 }
 
 public void setOmpCountry(String ompCountry) {
     this.ompCountry = ompCountry;
 }

 
 @Column(name="ompEmail", length=250)
 public String getOmpEmail() {
     return this.ompEmail;
 }
 
 public void setOmpEmail(String ompEmail) {
     this.ompEmail = ompEmail;
 }

 
 @Column(name="ompTel", length=20)
 public String getOmpTel() {
     return this.ompTel;
 }
 
 public void setOmpTel(String ompTel) {
     this.ompTel = ompTel;
 }

 
 @Column(name="ompVip")
 public Boolean getOmpVip() {
     return this.ompVip;
 }
 
 public void setOmpVip(Boolean ompVip) {
     this.ompVip = ompVip;
 }

 
 @Column(name="ompDepNum", length=30)
 public String getOmpDepNum() {
     return this.ompDepNum;
 }
 
 public void setOmpDepNum(String ompDepNum) {
     this.ompDepNum = ompDepNum;
 }

 
 @Column(name="ompRelationship", length=1)
 public String getOmpRelationship() {
     return this.ompRelationship;
 }
 
 public void setOmpRelationship(String ompRelationship) {
     this.ompRelationship = ompRelationship;
 }

 
 @Column(name="ompPrincipalOmpId")
 public Integer getOmpPrincipalOmpId() {
     return this.ompPrincipalOmpId;
 }
 
 public void setOmpPrincipalOmpId(Integer ompPrincipalOmpId) {
     this.ompPrincipalOmpId = ompPrincipalOmpId;
 }

 
 @Column(name="ompSpecCond", length=65535)
 public String getOmpSpecCond() {
     return this.ompSpecCond;
 }
 
 public void setOmpSpecCond(String ompSpecCond) {
     this.ompSpecCond = ompSpecCond;
 }

 
 @Column(name="ompExclusion", length=65535)
 public String getOmpExclusion() {
     return this.ompExclusion;
 }
 
 public void setOmpExclusion(String ompExclusion) {
     this.ompExclusion = ompExclusion;
 }

 
 @Column(name="ompSchoolName", length=100)
 public String getOmpSchoolName() {
     return this.ompSchoolName;
 }
 
 public void setOmpSchoolName(String ompSchoolName) {
     this.ompSchoolName = ompSchoolName;
 }

 
 @Column(name="ompSchoolState", length=80)
 public String getOmpSchoolState() {
     return this.ompSchoolState;
 }
 
 public void setOmpSchoolState(String ompSchoolState) {
     this.ompSchoolState = ompSchoolState;
 }

 
 @Column(name="ompPolicyOwnerName", length=150)
 public String getOmpPolicyOwnerName() {
     return this.ompPolicyOwnerName;
 }
 
 public void setOmpPolicyOwnerName(String ompPolicyOwnerName) {
     this.ompPolicyOwnerName = ompPolicyOwnerName;
 }

 
 @Column(name="ompPolicyOwnerChineseName", length=30)
 public String getOmpPolicyOwnerChineseName() {
     return this.ompPolicyOwnerChineseName;
 }
 
 public void setOmpPolicyOwnerChineseName(String ompPolicyOwnerChineseName) {
     this.ompPolicyOwnerChineseName = ompPolicyOwnerChineseName;
 }

 
 @Column(name="ompPolicyGender", length=1)
 public Character getOmpPolicyGender() {
     return this.ompPolicyGender;
 }
 
 public void setOmpPolicyGender(Character ompPolicyGender) {
     this.ompPolicyGender = ompPolicyGender;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompPolicyDOB", length=10)
 public Date getOmpPolicyDob() {
     return this.ompPolicyDob;
 }
 
 public void setOmpPolicyDob(Date ompPolicyDob) {
     this.ompPolicyDob = ompPolicyDob;
 }

 
 @Column(name="ompAgencyBranch", length=100)
 public String getOmpAgencyBranch() {
     return this.ompAgencyBranch;
 }
 
 public void setOmpAgencyBranch(String ompAgencyBranch) {
     this.ompAgencyBranch = ompAgencyBranch;
 }

 
 @Column(name="ompAgencyName", length=150)
 public String getOmpAgencyName() {
     return this.ompAgencyName;
 }
 
 public void setOmpAgencyName(String ompAgencyName) {
     this.ompAgencyName = ompAgencyName;
 }

 
 @Column(name="ompAgencyChineseName", length=30)
 public String getOmpAgencyChineseName() {
     return this.ompAgencyChineseName;
 }
 
 public void setOmpAgencyChineseName(String ompAgencyChineseName) {
     this.ompAgencyChineseName = ompAgencyChineseName;
 }

 
 @Column(name="ompAgencyCode", length=20)
 public String getOmpAgencyCode() {
     return this.ompAgencyCode;
 }
 
 public void setOmpAgencyCode(String ompAgencyCode) {
     this.ompAgencyCode = ompAgencyCode;
 }

 
 @Column(name="ompAgencyEmail", length=250)
 public String getOmpAgencyEmail() {
     return this.ompAgencyEmail;
 }
 
 public void setOmpAgencyEmail(String ompAgencyEmail) {
     this.ompAgencyEmail = ompAgencyEmail;
 }

 
 @Column(name="ompAgencyTel", length=20)
 public String getOmpAgencyTel() {
     return this.ompAgencyTel;
 }
 
 public void setOmpAgencyTel(String ompAgencyTel) {
     this.ompAgencyTel = ompAgencyTel;
 }

 
 @Column(name="ompAgentName", length=100)
 public String getOmpAgentName() {
     return this.ompAgentName;
 }
 
 public void setOmpAgentName(String ompAgentName) {
     this.ompAgentName = ompAgentName;
 }

 
 @Column(name="ompAgentFaxTel", length=20)
 public String getOmpAgentFaxTel() {
     return this.ompAgentFaxTel;
 }
 
 public void setOmpAgentFaxTel(String ompAgentFaxTel) {
     this.ompAgentFaxTel = ompAgentFaxTel;
 }

 
 @Column(name="ompAgentTel", length=20)
 public String getOmpAgentTel() {
     return this.ompAgentTel;
 }
 
 public void setOmpAgentTel(String ompAgentTel) {
     this.ompAgentTel = ompAgentTel;
 }

 
 @Column(name="ompAgentCode", length=20)
 public String getOmpAgentCode() {
     return this.ompAgentCode;
 }
 
 public void setOmpAgentCode(String ompAgentCode) {
     this.ompAgentCode = ompAgentCode;
 }

 
 @Column(name="ompAgentRemarks", length=65535)
 public String getOmpAgentRemarks() {
     return this.ompAgentRemarks;
 }
 
 public void setOmpAgentRemarks(String ompAgentRemarks) {
     this.ompAgentRemarks = ompAgentRemarks;
 }

 
 @Column(name="ompAgentAddress1", length=250)
 public String getOmpAgentAddress1() {
     return this.ompAgentAddress1;
 }
 
 public void setOmpAgentAddress1(String ompAgentAddress1) {
     this.ompAgentAddress1 = ompAgentAddress1;
 }

 
 @Column(name="ompAgentAddress2", length=250)
 public String getOmpAgentAddress2() {
     return this.ompAgentAddress2;
 }
 
 public void setOmpAgentAddress2(String ompAgentAddress2) {
     this.ompAgentAddress2 = ompAgentAddress2;
 }

 
 @Column(name="ompAgentAddress3", length=250)
 public String getOmpAgentAddress3() {
     return this.ompAgentAddress3;
 }
 
 public void setOmpAgentAddress3(String ompAgentAddress3) {
     this.ompAgentAddress3 = ompAgentAddress3;
 }

 
 @Column(name="ompAgentAddress4", length=250)
 public String getOmpAgentAddress4() {
     return this.ompAgentAddress4;
 }
 
 public void setOmpAgentAddress4(String ompAgentAddress4) {
     this.ompAgentAddress4 = ompAgentAddress4;
 }

 
 @Column(name="ompAgentCountry", length=80)
 public String getOmpAgentCountry() {
     return this.ompAgentCountry;
 }
 
 public void setOmpAgentCountry(String ompAgentCountry) {
     this.ompAgentCountry = ompAgentCountry;
 }

 
 @Column(name="ompAnnMaxVisitUtilCf")
 public Integer getOmpAnnMaxVisitUtilCf() {
     return this.ompAnnMaxVisitUtilCf;
 }
 
 public void setOmpAnnMaxVisitUtilCf(Integer ompAnnMaxVisitUtilCf) {
     this.ompAnnMaxVisitUtilCf = ompAnnMaxVisitUtilCf;
 }

 
 @Column(name="ompAgentAddress5", length=250)
 public String getOmpAgentAddress5() {
     return this.ompAgentAddress5;
 }
 
 public void setOmpAgentAddress5(String ompAgentAddress5) {
     this.ompAgentAddress5 = ompAgentAddress5;
 }

 
 @Column(name="ompAgentPostal", length=20)
 public String getOmpAgentPostal() {
     return this.ompAgentPostal;
 }
 
 public void setOmpAgentPostal(String ompAgentPostal) {
     this.ompAgentPostal = ompAgentPostal;
 }

 
 @Column(name="ompAgentState", length=250)
 public String getOmpAgentState() {
     return this.ompAgentState;
 }
 
 public void setOmpAgentState(String ompAgentState) {
     this.ompAgentState = ompAgentState;
 }

 
 @Column(name="ompAnnUtilCf", precision=16)
 public BigDecimal getOmpAnnUtilCf() {
     return this.ompAnnUtilCf;
 }
 
 public void setOmpAnnUtilCf(BigDecimal ompAnnUtilCf) {
     this.ompAnnUtilCf = ompAnnUtilCf;
 }

 
 @Column(name="ompLtUtilCf", precision=16)
 public BigDecimal getOmpLtUtilCf() {
     return this.ompLtUtilCf;
 }
 
 public void setOmpLtUtilCf(BigDecimal ompLtUtilCf) {
     this.ompLtUtilCf = ompLtUtilCf;
 }

 
 @Column(name="ompSubsidiaryCompany", length=20)
 public String getOmpSubsidiaryCompany() {
     return this.ompSubsidiaryCompany;
 }
 
 public void setOmpSubsidiaryCompany(String ompSubsidiaryCompany) {
     this.ompSubsidiaryCompany = ompSubsidiaryCompany;
 }

 
 @Column(name="ompImppId")
 public Integer getOmpImppId() {
     return this.ompImppId;
 }
 
 public void setOmpImppId(Integer ompImppId) {
     this.ompImppId = ompImppId;
 }

 
 @Column(name="ompSubsidiaryNo", length=100)
 public String getOmpSubsidiaryNo() {
     return this.ompSubsidiaryNo;
 }
 
 public void setOmpSubsidiaryNo(String ompSubsidiaryNo) {
     this.ompSubsidiaryNo = ompSubsidiaryNo;
 }

 
 @Column(name="ompFamilyNo", length=10)
 public String getOmpFamilyNo() {
     return this.ompFamilyNo;
 }
 
 public void setOmpFamilyNo(String ompFamilyNo) {
     this.ompFamilyNo = ompFamilyNo;
 }

 
 @Column(name="ompPersonCertNo", length=100)
 public String getOmpPersonCertNo() {
     return this.ompPersonCertNo;
 }
 
 public void setOmpPersonCertNo(String ompPersonCertNo) {
     this.ompPersonCertNo = ompPersonCertNo;
 }

 
 @Column(name="ompJobPosition", length=15)
 public String getOmpJobPosition() {
     return this.ompJobPosition;
 }
 
 public void setOmpJobPosition(String ompJobPosition) {
     this.ompJobPosition = ompJobPosition;
 }

 
 @Column(name="ompMemberBand", length=15)
 public String getOmpMemberBand() {
     return this.ompMemberBand;
 }
 
 public void setOmpMemberBand(String ompMemberBand) {
     this.ompMemberBand = ompMemberBand;
 }

 
 @Column(name="ompBankName", length=20)
 public String getOmpBankName() {
     return this.ompBankName;
 }
 
 public void setOmpBankName(String ompBankName) {
     this.ompBankName = ompBankName;
 }

 
 @Column(name="ompBankAccountNumber", length=50)
 public String getOmpBankAccountNumber() {
     return this.ompBankAccountNumber;
 }
 
 public void setOmpBankAccountNumber(String ompBankAccountNumber) {
     this.ompBankAccountNumber = ompBankAccountNumber;
 }

 
 @Column(name="ompBankBranchName", length=30)
 public String getOmpBankBranchName() {
     return this.ompBankBranchName;
 }
 
 public void setOmpBankBranchName(String ompBankBranchName) {
     this.ompBankBranchName = ompBankBranchName;
 }

 
 @Column(name="ompBankCode", length=30)
 public String getOmpBankCode() {
     return this.ompBankCode;
 }
 
 public void setOmpBankCode(String ompBankCode) {
     this.ompBankCode = ompBankCode;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="ompPaidToDate", length=10)
 public Date getOmpPaidToDate() {
     return this.ompPaidToDate;
 }
 
 public void setOmpPaidToDate(Date ompPaidToDate) {
     this.ompPaidToDate = ompPaidToDate;
 }

 
 @Column(name="ompNetPremium", precision=16)
 public BigDecimal getOmpNetPremium() {
     return this.ompNetPremium;
 }
 
 public void setOmpNetPremium(BigDecimal ompNetPremium) {
     this.ompNetPremium = ompNetPremium;
 }

 
 @Column(name="ompFrequencyOfPaymentMode", length=15)
 public String getOmpFrequencyOfPaymentMode() {
     return this.ompFrequencyOfPaymentMode;
 }
 
 public void setOmpFrequencyOfPaymentMode(String ompFrequencyOfPaymentMode) {
     this.ompFrequencyOfPaymentMode = ompFrequencyOfPaymentMode;
 }

 
 @Column(name="ompNoOfMainPolicyYear")
 public Integer getOmpNoOfMainPolicyYear() {
     return this.ompNoOfMainPolicyYear;
 }
 
 public void setOmpNoOfMainPolicyYear(Integer ompNoOfMainPolicyYear) {
     this.ompNoOfMainPolicyYear = ompNoOfMainPolicyYear;
 }

 
 @Column(name="ompNoOfHealthPolicyYear")
 public Integer getOmpNoOfHealthPolicyYear() {
     return this.ompNoOfHealthPolicyYear;
 }
 
 public void setOmpNoOfHealthPolicyYear(Integer ompNoOfHealthPolicyYear) {
     this.ompNoOfHealthPolicyYear = ompNoOfHealthPolicyYear;
 }

 
 @Column(name="ompInsBranchCode", length=20)
 public String getOmpInsBranchCode() {
     return this.ompInsBranchCode;
 }
 
 public void setOmpInsBranchCode(String ompInsBranchCode) {
     this.ompInsBranchCode = ompInsBranchCode;
 }

 
 @Column(name="ompInsBranchName", length=100)
 public String getOmpInsBranchName() {
     return this.ompInsBranchName;
 }
 
 public void setOmpInsBranchName(String ompInsBranchName) {
     this.ompInsBranchName = ompInsBranchName;
 }

 
 @Column(name="ompRemarks", length=65535)
 public String getOmpRemarks() {
     return this.ompRemarks;
 }
 
 public void setOmpRemarks(String ompRemarks) {
     this.ompRemarks = ompRemarks;
 }

 
 @Column(name="ompDepartment", length=8)
 public String getOmpDepartment() {
     return this.ompDepartment;
 }
 
 public void setOmpDepartment(String ompDepartment) {
     this.ompDepartment = ompDepartment;
 }

 
 @Column(name="ompImportBatchId")
 public Integer getOmpImportBatchId() {
     return this.ompImportBatchId;
 }
 
 public void setOmpImportBatchId(Integer ompImportBatchId) {
     this.ompImportBatchId = ompImportBatchId;
 }

 
 @Column(name="ompDivision", length=50)
 public String getOmpDivision() {
     return this.ompDivision;
 }
 
 public void setOmpDivision(String ompDivision) {
     this.ompDivision = ompDivision;
 }

 
 @Column(name="ompCostCentre", length=20)
 public String getOmpCostCentre() {
     return this.ompCostCentre;
 }
 
 public void setOmpCostCentre(String ompCostCentre) {
     this.ompCostCentre = ompCostCentre;
 }

 
 @Column(name="ompBranch", length=20)
 public String getOmpBranch() {
     return this.ompBranch;
 }
 
 public void setOmpBranch(String ompBranch) {
     this.ompBranch = ompBranch;
 }

 
 @Column(name="ompGrade", length=20)
 public String getOmpGrade() {
     return this.ompGrade;
 }
 
 public void setOmpGrade(String ompGrade) {
     this.ompGrade = ompGrade;
 }

 
 @Column(name="ompEmail2", length=250)
 public String getOmpEmail2() {
     return this.ompEmail2;
 }
 
 public void setOmpEmail2(String ompEmail2) {
     this.ompEmail2 = ompEmail2;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="outptMemberPlan")
 public Set<OutptPlanMovement> getOutptPlanMovements() {
     return this.outptPlanMovements;
 }
 
 public void setOutptPlanMovements(Set<OutptPlanMovement> outptPlanMovements) {
     this.outptPlanMovements = outptPlanMovements;
 }




}


