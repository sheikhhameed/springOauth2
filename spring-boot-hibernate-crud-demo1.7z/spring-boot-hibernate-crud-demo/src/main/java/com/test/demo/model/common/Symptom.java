package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.outpt.OutptClaimSymptom;

/**
 * This is Symptom class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="symptom"
 ,catalog="marcmy"
)
public class Symptom  implements java.io.Serializable {


  private Integer sxId;
  private Boolean sxEnabled;
  private Integer sxCreatedBy;
  private Date sxCreatedDate;
  private Integer sxLastEdittedBy;
  private Date sxLastEdittedDate;
  private String sxDescription;
  private String sxLocalDesc;
  private boolean sxSimple;
  private Set<IftttCondition> iftttConditions = new HashSet<IftttCondition>(0);
  private Set<OutptClaimSymptom> outptClaimSymptoms = new HashSet<OutptClaimSymptom>(0);

 public Symptom() {
 }

	
 public Symptom(boolean sxSimple) {
     this.sxSimple = sxSimple;
 }
 public Symptom(Boolean sxEnabled, Integer sxCreatedBy, Date sxCreatedDate, Integer sxLastEdittedBy, Date sxLastEdittedDate, String sxDescription, String sxLocalDesc, boolean sxSimple, Set<IftttCondition> iftttConditions, Set<OutptClaimSymptom> outptClaimSymptoms) {
    this.sxEnabled = sxEnabled;
    this.sxCreatedBy = sxCreatedBy;
    this.sxCreatedDate = sxCreatedDate;
    this.sxLastEdittedBy = sxLastEdittedBy;
    this.sxLastEdittedDate = sxLastEdittedDate;
    this.sxDescription = sxDescription;
    this.sxLocalDesc = sxLocalDesc;
    this.sxSimple = sxSimple;
    this.iftttConditions = iftttConditions;
    this.outptClaimSymptoms = outptClaimSymptoms;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="sxId", unique=true, nullable=false)
 public Integer getSxId() {
     return this.sxId;
 }
 
 public void setSxId(Integer sxId) {
     this.sxId = sxId;
 }

 
 @Column(name="sxEnabled")
 public Boolean getSxEnabled() {
     return this.sxEnabled;
 }
 
 public void setSxEnabled(Boolean sxEnabled) {
     this.sxEnabled = sxEnabled;
 }

 
 @Column(name="sxCreatedBy")
 public Integer getSxCreatedBy() {
     return this.sxCreatedBy;
 }
 
 public void setSxCreatedBy(Integer sxCreatedBy) {
     this.sxCreatedBy = sxCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="sxCreatedDate", length=19)
 public Date getSxCreatedDate() {
     return this.sxCreatedDate;
 }
 
 public void setSxCreatedDate(Date sxCreatedDate) {
     this.sxCreatedDate = sxCreatedDate;
 }

 
 @Column(name="sxLastEdittedBy")
 public Integer getSxLastEdittedBy() {
     return this.sxLastEdittedBy;
 }
 
 public void setSxLastEdittedBy(Integer sxLastEdittedBy) {
     this.sxLastEdittedBy = sxLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="sxLastEdittedDate", length=19)
 public Date getSxLastEdittedDate() {
     return this.sxLastEdittedDate;
 }
 
 public void setSxLastEdittedDate(Date sxLastEdittedDate) {
     this.sxLastEdittedDate = sxLastEdittedDate;
 }

 
 @Column(name="sxDescription", length=250)
 public String getSxDescription() {
     return this.sxDescription;
 }
 
 public void setSxDescription(String sxDescription) {
     this.sxDescription = sxDescription;
 }

 
 @Column(name="sxLocalDesc", length=250)
 public String getSxLocalDesc() {
     return this.sxLocalDesc;
 }
 
 public void setSxLocalDesc(String sxLocalDesc) {
     this.sxLocalDesc = sxLocalDesc;
 }

 
 @Column(name="sxSimple", nullable=false)
 public boolean isSxSimple() {
     return this.sxSimple;
 }
 
 public void setSxSimple(boolean sxSimple) {
     this.sxSimple = sxSimple;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="symptom")
 public Set<IftttCondition> getIftttConditions() {
     return this.iftttConditions;
 }
 
 public void setIftttConditions(Set<IftttCondition> iftttConditions) {
     this.iftttConditions = iftttConditions;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="symptom")
 public Set<OutptClaimSymptom> getOutptClaimSymptoms() {
     return this.outptClaimSymptoms;
 }
 
 public void setOutptClaimSymptoms(Set<OutptClaimSymptom> outptClaimSymptoms) {
     this.outptClaimSymptoms = outptClaimSymptoms;
 }




}


