package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is medicalPanelProviders class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="medical_panel_providers"
 ,catalog="marcmy"
)
public class MedicalPanelProviders  implements java.io.Serializable {


  private Integer mppId;
  private MedicalPanel medicalPanel;
  private MedicalProvider medicalProvider;
  private Boolean mppEnabled;
  private Integer mppCreatedBy;
  private Date mppCreatedDate;
  private Integer mppLastEdittedBy;
  private Date mppLastEdittedDate;

 public MedicalPanelProviders() {
 }

	
 public MedicalPanelProviders(MedicalPanel medicalPanel, MedicalProvider medicalProvider) {
     this.medicalPanel = medicalPanel;
     this.medicalProvider = medicalProvider;
 }
 public MedicalPanelProviders(MedicalPanel medicalPanel, MedicalProvider medicalProvider, Boolean mppEnabled, Integer mppCreatedBy, Date mppCreatedDate, Integer mppLastEdittedBy, Date mppLastEdittedDate) {
    this.medicalPanel = medicalPanel;
    this.medicalProvider = medicalProvider;
    this.mppEnabled = mppEnabled;
    this.mppCreatedBy = mppCreatedBy;
    this.mppCreatedDate = mppCreatedDate;
    this.mppLastEdittedBy = mppLastEdittedBy;
    this.mppLastEdittedDate = mppLastEdittedDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="mppId", unique=true, nullable=false)
 public Integer getMppId() {
     return this.mppId;
 }
 
 public void setMppId(Integer mppId) {
     this.mppId = mppId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="mppMedPanelId", nullable=false)
 public MedicalPanel getMedicalPanel() {
     return this.medicalPanel;
 }
 
 public void setMedicalPanel(MedicalPanel medicalPanel) {
     this.medicalPanel = medicalPanel;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="mppMedPrvId", nullable=false)
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }
 
 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }

 
 @Column(name="mppEnabled")
 public Boolean getMppEnabled() {
     return this.mppEnabled;
 }
 
 public void setMppEnabled(Boolean mppEnabled) {
     this.mppEnabled = mppEnabled;
 }

 
 @Column(name="mppCreatedBy")
 public Integer getMppCreatedBy() {
     return this.mppCreatedBy;
 }
 
 public void setMppCreatedBy(Integer mppCreatedBy) {
     this.mppCreatedBy = mppCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="mppCreatedDate", length=19)
 public Date getMppCreatedDate() {
     return this.mppCreatedDate;
 }
 
 public void setMppCreatedDate(Date mppCreatedDate) {
     this.mppCreatedDate = mppCreatedDate;
 }

 
 @Column(name="mppLastEdittedBy")
 public Integer getMppLastEdittedBy() {
     return this.mppLastEdittedBy;
 }
 
 public void setMppLastEdittedBy(Integer mppLastEdittedBy) {
     this.mppLastEdittedBy = mppLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="mppLastEdittedDate", length=19)
 public Date getMppLastEdittedDate() {
     return this.mppLastEdittedDate;
 }
 
 public void setMppLastEdittedDate(Date mppLastEdittedDate) {
     this.mppLastEdittedDate = mppLastEdittedDate;
 }




}


