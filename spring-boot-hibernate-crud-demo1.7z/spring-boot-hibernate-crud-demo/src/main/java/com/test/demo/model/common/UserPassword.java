package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is userPassword class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="user_password"
 ,catalog="marcmy"
)
public class UserPassword  implements java.io.Serializable {


  private Integer id;
  private User user;
  private Integer createdBy;
  private Date createdDate;
  private String pwd;
  private byte[] pwdSalt;
  private Date expiryDate;

 public UserPassword() {
 }

 public UserPassword(User user, Integer createdBy, Date createdDate, String pwd, byte[] pwdSalt, Date expiryDate) {
    this.user = user;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.pwd = pwd;
    this.pwdSalt = pwdSalt;
    this.expiryDate = expiryDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="id", unique=true, nullable=false)
 public Integer getId() {
     return this.id;
 }
 
 public void setId(Integer id) {
     this.id = id;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userId")
 public User getUser() {
     return this.user;
 }
 
 public void setUser(User user) {
     this.user = user;
 }

 
 @Column(name="createdBy")
 public Integer getCreatedBy() {
     return this.createdBy;
 }
 
 public void setCreatedBy(Integer createdBy) {
     this.createdBy = createdBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="createdDate", length=19)
 public Date getCreatedDate() {
     return this.createdDate;
 }
 
 public void setCreatedDate(Date createdDate) {
     this.createdDate = createdDate;
 }

 
 @Column(name="pwd", length=100)
 public String getPwd() {
     return this.pwd;
 }
 
 public void setPwd(String pwd) {
     this.pwd = pwd;
 }

 
 @Column(name="pwdSalt")
 public byte[] getPwdSalt() {
     return this.pwdSalt;
 }
 
 public void setPwdSalt(byte[] pwdSalt) {
     this.pwdSalt = pwdSalt;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="expiryDate", length=10)
 public Date getExpiryDate() {
     return this.expiryDate;
 }
 
 public void setExpiryDate(Date expiryDate) {
     this.expiryDate = expiryDate;
 }




}


