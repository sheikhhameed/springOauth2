//package com.test.demo.repository;
//
//import java.util.Optional;
//
//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
//import org.springframework.data.domain.Page;
//import org.springframework.data.repository.PagingAndSortingRepository;
//import org.springframework.security.core.userdetails.User;
//
//import com.test.demo.model.common.User1;
//
//public interface UserRepository extends PagingAndSortingRepository<User1, Long> {
//
//	 Optional<User1> findByEmail(String email);
//	    Page<User1> findByEmailContains(String email, Pageable pageable);
//	    Page<User1> findAllByEmail(String email, Pageable pageable);
//	    Page<User1> findAllByEmailContainsAndEmail(String email, String auth, Pageable pageable);
//
//	    Boolean existsByEmail(String email);
//		org.springframework.boot.autoconfigure.security.SecurityProperties.User findbyUsername(String username);
//
//}
