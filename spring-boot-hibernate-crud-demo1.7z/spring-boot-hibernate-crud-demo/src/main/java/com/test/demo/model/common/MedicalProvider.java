package com.test.demo.model.common;

import static javax.persistence.GenerationType.IDENTITY;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.outpt.OutptClaim;
import com.test.demo.model.outpt.OutptPaymentAdvice;

/**
 * This is MedicalProvider class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="medical_provider"
 ,catalog="marcmy"
)
public class MedicalProvider  implements java.io.Serializable {


	private Integer medPrvId;
	private DocumentTemplate documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId;
	private DocumentTemplate documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId;
	private ProviderType providerType;
	private Date medPrvEnabledDate;
	private Date medPrvDeletionDate;
	private Integer medPrvCreatedBy;
	private Date medPrvCreatedDate;
	private Integer medPrvLastEdittedBy;
	private Date medPrvLastEdittedDate;
	private String medPrvFullName;
	private String medPrvAbbvName;
	private String medPrvLocalName;
	private String medPrvAccountingName;
	private String medPrvAddress1;
	private String medPrvAddress2;
	private String medPrvAddress3;
	private String medPrvCity;
	private String medPrvState;
	private String medPrvPostcode;
	private String medPrvCountry;
	private Character medPrvOwnership;
	private String medPrvOwner;
	private String medPrvWebsite;
	private String medPrvGenTelOfcHrs;
	private String medPrvGenTelAftOfc;
	private String medPrvGenFaxOfcHrs;
	private String medPrvGenFaxAftOfc;
	private String medPrvGenEmail;
	private Boolean medPrv24hours;
	private String medPrvDesc;
	private Boolean medPrvCreditCardLg;
	private String medPrvGeHospCode;
	private String medPrvRegion;
	private Double medPrvLat;
	private Double medPrvLng;
	private Double medPrvCnLat;
	private Double medPrvCnLng;
	private String medPrvExternalHospCode;
	private String medPrvAlimHospCode;
	private String medPrvMpiHospCode;
	private String medPrvPruCode;
	private String medPrvSunLifeCode;
	private String medPrvLonpacMyCode;
	private String medPrvAxaAffinMyCode;
	private String medPrvEtiqaMcsMyCode;
	private String medPrvStmbMyCode;
	private String medPrvHlaMyCode;
	private String medPrvAgicMyCode;
	private String medPrv24hourHotline;
	private String medPrvVendorId;
	private String medPrvVendorIdOupt;
	private String medPrvBankName;
	private String medPrvBankAccountNum;
	private String medPrvBankBranch;
	private String medPrvBankCode;
	private String medPrvPaymentType;
	private String medPrvGstRegistrationNum;
	private String medPrvMohLicenseNum;
	private String medPrvClinicLicenseNum;
     private String medPrvPayeeEmailAddress;
     private String medPrvBillingName;
	private String medPrvDoctorPractisingCertNum;
	private String medPrvDefaultCurrency;
	private Boolean medPrvOutptGpClinic;
	private Boolean medPrvOutptSpClinic;
	private Boolean medPrvOutptDentalClinic;
	private Boolean medPrvOutptTcmClinic;
	private Boolean medPrvOutptMatClinic;
	private Boolean medPrvOutptHospital;
	private Boolean medPrvOutptAutoAdjudicate;
	private String medPrvOutptGstCalcType;
	private BigDecimal medPrvOutptGstPercent;
	private BigDecimal medPrvOutptPerVisitLimit;
	private String medPrvQrString;
	private String medPrvPicName;
	private String medPrvPicEmail;
	private String medPrvPicTel;
	private Boolean medPrvNotifyOutptFax;
	private String medPrvNotifyOutptFaxNum;
	private Boolean medPrvNotifyOutptEmail;
	private String medPrvNotifyOutptEmailToAddr;
	private String medPrvNotifyOutptEmailToCc;
	private String medPrvNotifyOutptEmailToBcc;
	private String medPrvNotifyOutptEmailSubject;
	private String medPrvNotifyOutptEmailContent;
	private Boolean medPrvNotifyInptFax;
	private String medPrvNotifyInptFaxNum;
	private Boolean medPrvNotifyInptEmail;
	private String medPrvNotifyInptEmailToAddr;
	private String medPrvNotifyInptEmailToCc;
	private String medPrvNotifyInptEmailToBcc;
	private String medPrvNotifyInptEmailSubject;
	private String medPrvNotifyInptEmailContent;
	private String medPrvClass;
	private String medPrvAccTaxId;
	private Double medPrvAccDiscRate;
	private Integer medPrvAccWhtPercentage;
	private Date medPrvAccWhtStartDate;
	private Date medPrvAccWhtEndDate;
	private String medPrvAccWhtExclude;
	private String medPrvAccTaxName;
	private String medPrvAccTaxAddress;
	private String medPrvAccTaxCity;
	private String medPrvAccTaxProvince;
	private String medPrvAccTaxPostcode;
	private String medPrvAccTaxType;
	private String medprvCreditTerm;
	private String medPrvTitle;
	private Boolean medPrvJciAccre;
	private Boolean medPrvLocalCre;
	private Boolean medPrvIsoAccre;
	private Boolean medPrvHospMalprac;
	private Boolean medPrvFullTimeDrMalprac;
	private Boolean medPrvPartTimeDrMalprac;
	private Date medPrvJciAccreExpDate;
	private Date medPrvLocalCreExpDate;
	private Date medPrvIsoAccreExpDate;
	private Date medPrvHospMalpracExpDate;
	private Date medPrvFullTimeDrMalpracExpDate;
	private Date medPrvPartTimeDrMalpracExpDate;
	private String medPrvCapacity;
	private Boolean medPrvSpecMedicine;
	private Boolean medPrvSpecPlastic;
	private Boolean medPrvSpecEar;
	private Boolean medPrvSpecCardiology;
	private Boolean medPrvSpecInfectious;
	private Boolean medPrvSpecGi;
	private Boolean medPrvSpecNutrition;
	private Boolean medPrvSpecPsychiatry;
	private Boolean medPrvSpecHypertension;
	private Boolean medPrvSpecBreast;
	private Boolean medPrvSpecCheckup;
	private Boolean medPrvSpecDental;
	private Boolean medPrvSpecNeurology;
	private Boolean medPrvSpecHygiene;
	private Boolean medPrvSpecNeuropathy;
	private Boolean medPrvSpecGynecology;
	private Boolean medPrvSpecEye;
	private Boolean medPrvSpecPediatrics;
	private Boolean medPrvSpecHematology;
	private Boolean medPrvSpecNephrology;
	private Boolean medPrvSpecOrthopaedic;
	private Boolean medPrvSpecArthritis;
	private Boolean medPrvSpecMedical;
	private Boolean medPrvSpecForensic;
	private Boolean medPrvSpecDiabetes;
	private Boolean medPrvSpecEmergency;
	private Boolean medPrvSpecDialysis;
	private Boolean medPrvSpecUrology;
	private Boolean medPrvSpecArthroplasty;
	private Boolean medPrvSpecDermatosis;
	private Boolean medPrvSpecOthers;
	private String medPrvSpecRemarks;
	private Boolean medPrvCommEnglish;
	private Boolean medPrvCommFrench;
	private Boolean medPrvCommSpanish;
	private Boolean medPrvCommJapanese;
	private Boolean medPrvCommGerman;
	private Boolean medPrvCommKorean;
	private Boolean medPrvCommRussian;
	private Boolean medPrvCommOthers;
	private String medPrvCommRemarks;
	private String medPrvGetsbcode;
	private BigDecimal medPrvRoomRate1bedded;
	private BigDecimal medPrvRoomRate2bedded;
	private BigDecimal medPrvRoomRate4bedded;
	private BigDecimal medPrvRoomRate8bedded;
	private BigDecimal medPrvRoomRate16bedded;
	private boolean medPrvIsWatchlist;
	private String medPrvGePayeeCode;
	private String medPrvOpenHours;
	private Set<InvestigationMedicalProvider> investigationMedicalProviders = new HashSet<InvestigationMedicalProvider>(
			0);
	private Set<MedicalPanelProviders> medicalPanelProviderses = new HashSet<MedicalPanelProviders>(0);
	private Set<MedicalProviderContactPerson> medicalProviderContactPersons = new HashSet<MedicalProviderContactPerson>(
			0);
	private Set<User> users = new HashSet<User>(0);
	private Set<OutptPaymentAdvice> outptPaymentAdvices = new HashSet<OutptPaymentAdvice>(0);
	private Set<IftttCondition> iftttConditions = new HashSet<IftttCondition>(0);
	private Set<MedicalProviderCoPay> medicalProviderCoPays = new HashSet<MedicalProviderCoPay>(0);
	private Set<OutptClaim> outptClaims = new HashSet<OutptClaim>(0);

 public MedicalProvider() {
 }

	public MedicalProvider(boolean medPrvIsWatchlist) {
		this.medPrvIsWatchlist = medPrvIsWatchlist;
	}

	public MedicalProvider(DocumentTemplate documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId,
			DocumentTemplate documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId, ProviderType providerType,
			Date medPrvEnabledDate, Date medPrvDeletionDate, Integer medPrvCreatedBy, Date medPrvCreatedDate,
			Integer medPrvLastEdittedBy, Date medPrvLastEdittedDate, String medPrvFullName, String medPrvAbbvName,
			String medPrvLocalName, String medPrvAccountingName, String medPrvAddress1, String medPrvAddress2,
			String medPrvAddress3, String medPrvCity, String medPrvState, String medPrvPostcode, String medPrvCountry,
			Character medPrvOwnership, String medPrvOwner, String medPrvWebsite, String medPrvGenTelOfcHrs,
			String medPrvGenTelAftOfc, String medPrvGenFaxOfcHrs, String medPrvGenFaxAftOfc, String medPrvGenEmail,
			Boolean medPrv24hours, String medPrvDesc, Boolean medPrvCreditCardLg, String medPrvGeHospCode,
			String medPrvRegion, Double medPrvLat, Double medPrvLng, Double medPrvCnLat, Double medPrvCnLng,
			String medPrvExternalHospCode, String medPrvAlimHospCode, String medPrvMpiHospCode, String medPrvPruCode,
			String medPrvSunLifeCode, String medPrvLonpacMyCode, String medPrvAxaAffinMyCode,
			String medPrvEtiqaMcsMyCode, String medPrvStmbMyCode, String medPrvHlaMyCode, String medPrvAgicMyCode,
			String medPrv24hourHotline, String medPrvVendorId, String medPrvVendorIdOupt, String medPrvBankName,
			String medPrvBankAccountNum, String medPrvBankBranch, String medPrvBankCode, String medPrvPaymentType,
			String medPrvGstRegistrationNum, String medPrvMohLicenseNum, String medPrvClinicLicenseNum, 
                     String medPrvPayeeEmailAddress, String medPrvBillingName, 
			String medPrvDoctorPracmedPrvPayeeEmailAddresstisingCertNum, String medPrvDefaultCurrency, Boolean medPrvOutptGpClinic,
			Boolean medPrvOutptSpClinic, Boolean medPrvOutptDentalClinic, Boolean medPrvOutptTcmClinic,
			Boolean medPrvOutptMatClinic, Boolean medPrvOutptHospital, Boolean medPrvOutptAutoAdjudicate,
			String medPrvOutptGstCalcType, BigDecimal medPrvOutptGstPercent, BigDecimal medPrvOutptPerVisitLimit,
			String medPrvQrString, String medPrvPicName, String medPrvPicEmail, String medPrvPicTel,
			Boolean medPrvNotifyOutptFax, String medPrvNotifyOutptFaxNum, Boolean medPrvNotifyOutptEmail,
			String medPrvNotifyOutptEmailToAddr, String medPrvNotifyOutptEmailToCc, String medPrvNotifyOutptEmailToBcc,
			String medPrvNotifyOutptEmailSubject, String medPrvNotifyOutptEmailContent, Boolean medPrvNotifyInptFax,
			String medPrvNotifyInptFaxNum, Boolean medPrvNotifyInptEmail, String medPrvNotifyInptEmailToAddr,
			String medPrvNotifyInptEmailToCc, String medPrvNotifyInptEmailToBcc, String medPrvNotifyInptEmailSubject,
			String medPrvNotifyInptEmailContent, String medPrvClass, String medPrvAccTaxId, Double medPrvAccDiscRate,
			Integer medPrvAccWhtPercentage, Date medPrvAccWhtStartDate, Date medPrvAccWhtEndDate,
			String medPrvAccWhtExclude, String medPrvAccTaxName, String medPrvAccTaxAddress, String medPrvAccTaxCity,
			String medPrvAccTaxProvince, String medPrvAccTaxPostcode, String medPrvAccTaxType, String medprvCreditTerm,
			String medPrvTitle, Boolean medPrvJciAccre, Boolean medPrvLocalCre, Boolean medPrvIsoAccre,
			Boolean medPrvHospMalprac, Boolean medPrvFullTimeDrMalprac, Boolean medPrvPartTimeDrMalprac,
			Date medPrvJciAccreExpDate, Date medPrvLocalCreExpDate, Date medPrvIsoAccreExpDate,
			Date medPrvHospMalpracExpDate, Date medPrvFullTimeDrMalpracExpDate, Date medPrvPartTimeDrMalpracExpDate,
			String medPrvCapacity, Boolean medPrvSpecMedicine, Boolean medPrvSpecPlastic, Boolean medPrvSpecEar,
			Boolean medPrvSpecCardiology, Boolean medPrvSpecInfectious, Boolean medPrvSpecGi,
			Boolean medPrvSpecNutrition, Boolean medPrvSpecPsychiatry, Boolean medPrvSpecHypertension,
			Boolean medPrvSpecBreast, Boolean medPrvSpecCheckup, Boolean medPrvSpecDental, Boolean medPrvSpecNeurology,
			Boolean medPrvSpecHygiene, Boolean medPrvSpecNeuropathy, Boolean medPrvSpecGynecology,
			Boolean medPrvSpecEye, Boolean medPrvSpecPediatrics, Boolean medPrvSpecHematology,
			Boolean medPrvSpecNephrology, Boolean medPrvSpecOrthopaedic, Boolean medPrvSpecArthritis,
			Boolean medPrvSpecMedical, Boolean medPrvSpecForensic, Boolean medPrvSpecDiabetes,
			Boolean medPrvSpecEmergency, Boolean medPrvSpecDialysis, Boolean medPrvSpecUrology,
			Boolean medPrvSpecArthroplasty, Boolean medPrvSpecDermatosis, Boolean medPrvSpecOthers,
			String medPrvSpecRemarks, Boolean medPrvCommEnglish, Boolean medPrvCommFrench, Boolean medPrvCommSpanish,
			Boolean medPrvCommJapanese, Boolean medPrvCommGerman, Boolean medPrvCommKorean, Boolean medPrvCommRussian,
			Boolean medPrvCommOthers, String medPrvCommRemarks, String medPrvGetsbcode,
			BigDecimal medPrvRoomRate1bedded, BigDecimal medPrvRoomRate2bedded, BigDecimal medPrvRoomRate4bedded,
			BigDecimal medPrvRoomRate8bedded, BigDecimal medPrvRoomRate16bedded, boolean medPrvIsWatchlist,
			String medPrvGePayeeCode, String medPrvOpenHours,
			Set<InvestigationMedicalProvider> investigationMedicalProviders,
			Set<MedicalPanelProviders> medicalPanelProviderses,
			Set<MedicalProviderContactPerson> medicalProviderContactPersons, Set<User> users,
			Set<OutptPaymentAdvice> outptPaymentAdvices, Set<IftttCondition> iftttConditions,
			Set<MedicalProviderCoPay> medicalProviderCoPays, Set<OutptClaim> outptClaims) {
		this.documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId = documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId;
		this.documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId = documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId;
		this.documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId = documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId;
		this.documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId = documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId;
		this.documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId = documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId;
		this.documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId = documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId;
		this.documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId = documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId;
		this.documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId = documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId;
		this.providerType = providerType;
		this.medPrvEnabledDate = medPrvEnabledDate;
		this.medPrvDeletionDate = medPrvDeletionDate;
		this.medPrvCreatedBy = medPrvCreatedBy;
		this.medPrvCreatedDate = medPrvCreatedDate;
		this.medPrvLastEdittedBy = medPrvLastEdittedBy;
		this.medPrvLastEdittedDate = medPrvLastEdittedDate;
		this.medPrvFullName = medPrvFullName;
		this.medPrvAbbvName = medPrvAbbvName;
		this.medPrvLocalName = medPrvLocalName;
		this.medPrvAccountingName = medPrvAccountingName;
		this.medPrvAddress1 = medPrvAddress1;
		this.medPrvAddress2 = medPrvAddress2;
		this.medPrvAddress3 = medPrvAddress3;
		this.medPrvCity = medPrvCity;
		this.medPrvState = medPrvState;
		this.medPrvPostcode = medPrvPostcode;
		this.medPrvCountry = medPrvCountry;
		this.medPrvOwnership = medPrvOwnership;
		this.medPrvOwner = medPrvOwner;
		this.medPrvWebsite = medPrvWebsite;
		this.medPrvGenTelOfcHrs = medPrvGenTelOfcHrs;
		this.medPrvGenTelAftOfc = medPrvGenTelAftOfc;
		this.medPrvGenFaxOfcHrs = medPrvGenFaxOfcHrs;
		this.medPrvGenFaxAftOfc = medPrvGenFaxAftOfc;
		this.medPrvGenEmail = medPrvGenEmail;
		this.medPrv24hours = medPrv24hours;
		this.medPrvDesc = medPrvDesc;
		this.medPrvCreditCardLg = medPrvCreditCardLg;
		this.medPrvGeHospCode = medPrvGeHospCode;
		this.medPrvRegion = medPrvRegion;
		this.medPrvLat = medPrvLat;
		this.medPrvLng = medPrvLng;
		this.medPrvCnLat = medPrvCnLat;
		this.medPrvCnLng = medPrvCnLng;
		this.medPrvExternalHospCode = medPrvExternalHospCode;
		this.medPrvAlimHospCode = medPrvAlimHospCode;
		this.medPrvMpiHospCode = medPrvMpiHospCode;
		this.medPrvPruCode = medPrvPruCode;
		this.medPrvSunLifeCode = medPrvSunLifeCode;
		this.medPrvLonpacMyCode = medPrvLonpacMyCode;
		this.medPrvAxaAffinMyCode = medPrvAxaAffinMyCode;
		this.medPrvEtiqaMcsMyCode = medPrvEtiqaMcsMyCode;
		this.medPrvStmbMyCode = medPrvStmbMyCode;
		this.medPrvHlaMyCode = medPrvHlaMyCode;
		this.medPrvAgicMyCode = medPrvAgicMyCode;
		this.medPrv24hourHotline = medPrv24hourHotline;
		this.medPrvVendorId = medPrvVendorId;
		this.medPrvVendorIdOupt = medPrvVendorIdOupt;
		this.medPrvBankName = medPrvBankName;
		this.medPrvBankAccountNum = medPrvBankAccountNum;
		this.medPrvBankBranch = medPrvBankBranch;
		this.medPrvBankCode = medPrvBankCode;
		this.medPrvPaymentType = medPrvPaymentType;
		this.medPrvGstRegistrationNum = medPrvGstRegistrationNum;
		this.medPrvMohLicenseNum = medPrvMohLicenseNum;
		this.medPrvClinicLicenseNum = medPrvClinicLicenseNum;
             this.medPrvPayeeEmailAddress = medPrvPayeeEmailAddress;
             this.medPrvBillingName = medPrvBillingName;
		this.medPrvDoctorPractisingCertNum = medPrvDoctorPractisingCertNum;
		this.medPrvDefaultCurrency = medPrvDefaultCurrency;
		this.medPrvOutptGpClinic = medPrvOutptGpClinic;
		this.medPrvOutptSpClinic = medPrvOutptSpClinic;
		this.medPrvOutptDentalClinic = medPrvOutptDentalClinic;
		this.medPrvOutptTcmClinic = medPrvOutptTcmClinic;
		this.medPrvOutptMatClinic = medPrvOutptMatClinic;
		this.medPrvOutptHospital = medPrvOutptHospital;
		this.medPrvOutptAutoAdjudicate = medPrvOutptAutoAdjudicate;
		this.medPrvOutptGstCalcType = medPrvOutptGstCalcType;
		this.medPrvOutptGstPercent = medPrvOutptGstPercent;
		this.medPrvOutptPerVisitLimit = medPrvOutptPerVisitLimit;
		this.medPrvQrString = medPrvQrString;
		this.medPrvPicName = medPrvPicName;
		this.medPrvPicEmail = medPrvPicEmail;
		this.medPrvPicTel = medPrvPicTel;
		this.medPrvNotifyOutptFax = medPrvNotifyOutptFax;
		this.medPrvNotifyOutptFaxNum = medPrvNotifyOutptFaxNum;
		this.medPrvNotifyOutptEmail = medPrvNotifyOutptEmail;
		this.medPrvNotifyOutptEmailToAddr = medPrvNotifyOutptEmailToAddr;
		this.medPrvNotifyOutptEmailToCc = medPrvNotifyOutptEmailToCc;
		this.medPrvNotifyOutptEmailToBcc = medPrvNotifyOutptEmailToBcc;
		this.medPrvNotifyOutptEmailSubject = medPrvNotifyOutptEmailSubject;
		this.medPrvNotifyOutptEmailContent = medPrvNotifyOutptEmailContent;
		this.medPrvNotifyInptFax = medPrvNotifyInptFax;
		this.medPrvNotifyInptFaxNum = medPrvNotifyInptFaxNum;
		this.medPrvNotifyInptEmail = medPrvNotifyInptEmail;
		this.medPrvNotifyInptEmailToAddr = medPrvNotifyInptEmailToAddr;
		this.medPrvNotifyInptEmailToCc = medPrvNotifyInptEmailToCc;
		this.medPrvNotifyInptEmailToBcc = medPrvNotifyInptEmailToBcc;
		this.medPrvNotifyInptEmailSubject = medPrvNotifyInptEmailSubject;
		this.medPrvNotifyInptEmailContent = medPrvNotifyInptEmailContent;
		this.medPrvClass = medPrvClass;
		this.medPrvAccTaxId = medPrvAccTaxId;
		this.medPrvAccDiscRate = medPrvAccDiscRate;
		this.medPrvAccWhtPercentage = medPrvAccWhtPercentage;
		this.medPrvAccWhtStartDate = medPrvAccWhtStartDate;
		this.medPrvAccWhtEndDate = medPrvAccWhtEndDate;
		this.medPrvAccWhtExclude = medPrvAccWhtExclude;
		this.medPrvAccTaxName = medPrvAccTaxName;
		this.medPrvAccTaxAddress = medPrvAccTaxAddress;
		this.medPrvAccTaxCity = medPrvAccTaxCity;
		this.medPrvAccTaxProvince = medPrvAccTaxProvince;
		this.medPrvAccTaxPostcode = medPrvAccTaxPostcode;
		this.medPrvAccTaxType = medPrvAccTaxType;
		this.medprvCreditTerm = medprvCreditTerm;
		this.medPrvTitle = medPrvTitle;
		this.medPrvJciAccre = medPrvJciAccre;
		this.medPrvLocalCre = medPrvLocalCre;
		this.medPrvIsoAccre = medPrvIsoAccre;
		this.medPrvHospMalprac = medPrvHospMalprac;
		this.medPrvFullTimeDrMalprac = medPrvFullTimeDrMalprac;
		this.medPrvPartTimeDrMalprac = medPrvPartTimeDrMalprac;
		this.medPrvJciAccreExpDate = medPrvJciAccreExpDate;
		this.medPrvLocalCreExpDate = medPrvLocalCreExpDate;
		this.medPrvIsoAccreExpDate = medPrvIsoAccreExpDate;
		this.medPrvHospMalpracExpDate = medPrvHospMalpracExpDate;
		this.medPrvFullTimeDrMalpracExpDate = medPrvFullTimeDrMalpracExpDate;
		this.medPrvPartTimeDrMalpracExpDate = medPrvPartTimeDrMalpracExpDate;
		this.medPrvCapacity = medPrvCapacity;
		this.medPrvSpecMedicine = medPrvSpecMedicine;
		this.medPrvSpecPlastic = medPrvSpecPlastic;
		this.medPrvSpecEar = medPrvSpecEar;
		this.medPrvSpecCardiology = medPrvSpecCardiology;
		this.medPrvSpecInfectious = medPrvSpecInfectious;
		this.medPrvSpecGi = medPrvSpecGi;
		this.medPrvSpecNutrition = medPrvSpecNutrition;
		this.medPrvSpecPsychiatry = medPrvSpecPsychiatry;
		this.medPrvSpecHypertension = medPrvSpecHypertension;
		this.medPrvSpecBreast = medPrvSpecBreast;
		this.medPrvSpecCheckup = medPrvSpecCheckup;
		this.medPrvSpecDental = medPrvSpecDental;
		this.medPrvSpecNeurology = medPrvSpecNeurology;
		this.medPrvSpecHygiene = medPrvSpecHygiene;
		this.medPrvSpecNeuropathy = medPrvSpecNeuropathy;
		this.medPrvSpecGynecology = medPrvSpecGynecology;
		this.medPrvSpecEye = medPrvSpecEye;
		this.medPrvSpecPediatrics = medPrvSpecPediatrics;
		this.medPrvSpecHematology = medPrvSpecHematology;
		this.medPrvSpecNephrology = medPrvSpecNephrology;
		this.medPrvSpecOrthopaedic = medPrvSpecOrthopaedic;
		this.medPrvSpecArthritis = medPrvSpecArthritis;
		this.medPrvSpecMedical = medPrvSpecMedical;
		this.medPrvSpecForensic = medPrvSpecForensic;
		this.medPrvSpecDiabetes = medPrvSpecDiabetes;
		this.medPrvSpecEmergency = medPrvSpecEmergency;
		this.medPrvSpecDialysis = medPrvSpecDialysis;
		this.medPrvSpecUrology = medPrvSpecUrology;
		this.medPrvSpecArthroplasty = medPrvSpecArthroplasty;
		this.medPrvSpecDermatosis = medPrvSpecDermatosis;
		this.medPrvSpecOthers = medPrvSpecOthers;
		this.medPrvSpecRemarks = medPrvSpecRemarks;
		this.medPrvCommEnglish = medPrvCommEnglish;
		this.medPrvCommFrench = medPrvCommFrench;
		this.medPrvCommSpanish = medPrvCommSpanish;
		this.medPrvCommJapanese = medPrvCommJapanese;
		this.medPrvCommGerman = medPrvCommGerman;
		this.medPrvCommKorean = medPrvCommKorean;
		this.medPrvCommRussian = medPrvCommRussian;
		this.medPrvCommOthers = medPrvCommOthers;
		this.medPrvCommRemarks = medPrvCommRemarks;
		this.medPrvGetsbcode = medPrvGetsbcode;
		this.medPrvRoomRate1bedded = medPrvRoomRate1bedded;
		this.medPrvRoomRate2bedded = medPrvRoomRate2bedded;
		this.medPrvRoomRate4bedded = medPrvRoomRate4bedded;
		this.medPrvRoomRate8bedded = medPrvRoomRate8bedded;
		this.medPrvRoomRate16bedded = medPrvRoomRate16bedded;
		this.medPrvIsWatchlist = medPrvIsWatchlist;
		this.medPrvGePayeeCode = medPrvGePayeeCode;
		this.medPrvOpenHours = medPrvOpenHours;
		this.investigationMedicalProviders = investigationMedicalProviders;
		this.medicalPanelProviderses = medicalPanelProviderses;
		this.medicalProviderContactPersons = medicalProviderContactPersons;
		this.users = users;
		this.outptPaymentAdvices = outptPaymentAdvices;
		this.iftttConditions = iftttConditions;
		this.medicalProviderCoPays = medicalProviderCoPays;
		this.outptClaims = outptClaims;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

 
 @Column(name="medPrvId", unique=true, nullable=false)
 public Integer getMedPrvId() {
     return this.medPrvId;
 }
 
 public void setMedPrvId(Integer medPrvId) {
     this.medPrvId = medPrvId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyInptFaxSuccessDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId() {
     return this.documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId) {
     this.documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId = documentTemplateByMedPrvNotifyInptFaxSuccessDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyOutptEmailSuccessDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId() {
     return this.documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId) {
     this.documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId = documentTemplateByMedPrvNotifyOutptEmailSuccessDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyOutptFaxSuccessDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId() {
     return this.documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId) {
     this.documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId = documentTemplateByMedPrvNotifyOutptFaxSuccessDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyInptFaxFailedDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyInptFaxFailedDocTmplId() {
     return this.documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyInptFaxFailedDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId) {
     this.documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId = documentTemplateByMedPrvNotifyInptFaxFailedDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyOutptEmailFailedDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId() {
     return this.documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId) {
     this.documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId = documentTemplateByMedPrvNotifyOutptEmailFailedDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyOutptFaxFailedDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId() {
     return this.documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId) {
     this.documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId = documentTemplateByMedPrvNotifyOutptFaxFailedDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyInptEmailSuccessDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId() {
     return this.documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId) {
     this.documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId = documentTemplateByMedPrvNotifyInptEmailSuccessDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvNotifyInptEmailFailedDocTmplId")
 public DocumentTemplate getDocumentTemplateByMedPrvNotifyInptEmailFailedDocTmplId() {
     return this.documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId;
 }
 
 public void setDocumentTemplateByMedPrvNotifyInptEmailFailedDocTmplId(DocumentTemplate documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId) {
     this.documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId = documentTemplateByMedPrvNotifyInptEmailFailedDocTmplId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="medPrvProviderTypeId")
 public ProviderType getProviderType() {
     return this.providerType;
 }
 
 public void setProviderType(ProviderType providerType) {
     this.providerType = providerType;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvEnabledDate", length=19)
 public Date getMedPrvEnabledDate() {
     return this.medPrvEnabledDate;
 }
 
 public void setMedPrvEnabledDate(Date medPrvEnabledDate) {
     this.medPrvEnabledDate = medPrvEnabledDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvDeletionDate", length=19)
 public Date getMedPrvDeletionDate() {
     return this.medPrvDeletionDate;
 }
 
 public void setMedPrvDeletionDate(Date medPrvDeletionDate) {
     this.medPrvDeletionDate = medPrvDeletionDate;
 }

 
 @Column(name="medPrvCreatedBy")
 public Integer getMedPrvCreatedBy() {
     return this.medPrvCreatedBy;
 }
 
 public void setMedPrvCreatedBy(Integer medPrvCreatedBy) {
     this.medPrvCreatedBy = medPrvCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvCreatedDate", length=19)
 public Date getMedPrvCreatedDate() {
     return this.medPrvCreatedDate;
 }
 
 public void setMedPrvCreatedDate(Date medPrvCreatedDate) {
     this.medPrvCreatedDate = medPrvCreatedDate;
 }

 
 @Column(name="medPrvLastEdittedBy")
 public Integer getMedPrvLastEdittedBy() {
     return this.medPrvLastEdittedBy;
 }
 
 public void setMedPrvLastEdittedBy(Integer medPrvLastEdittedBy) {
     this.medPrvLastEdittedBy = medPrvLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvLastEdittedDate", length=19)
 public Date getMedPrvLastEdittedDate() {
     return this.medPrvLastEdittedDate;
 }
 
 public void setMedPrvLastEdittedDate(Date medPrvLastEdittedDate) {
     this.medPrvLastEdittedDate = medPrvLastEdittedDate;
 }

 
 @Column(name="medPrvFullName", length=190)
 public String getMedPrvFullName() {
     return this.medPrvFullName;
 }
 
 public void setMedPrvFullName(String medPrvFullName) {
     this.medPrvFullName = medPrvFullName;
 }

 
 @Column(name="medPrvAbbvName", length=8)
 public String getMedPrvAbbvName() {
     return this.medPrvAbbvName;
 }
 
 public void setMedPrvAbbvName(String medPrvAbbvName) {
     this.medPrvAbbvName = medPrvAbbvName;
 }

 
 @Column(name="medPrvLocalName", length=250)
 public String getMedPrvLocalName() {
     return this.medPrvLocalName;
 }
 
 public void setMedPrvLocalName(String medPrvLocalName) {
     this.medPrvLocalName = medPrvLocalName;
 }

 
 @Column(name="medPrvAccountingName", length=190)
 public String getMedPrvAccountingName() {
     return this.medPrvAccountingName;
 }
 
 public void setMedPrvAccountingName(String medPrvAccountingName) {
     this.medPrvAccountingName = medPrvAccountingName;
 }

 
 @Column(name="medPrvAddress1", length=200)
 public String getMedPrvAddress1() {
     return this.medPrvAddress1;
 }
 
 public void setMedPrvAddress1(String medPrvAddress1) {
     this.medPrvAddress1 = medPrvAddress1;
 }

 
 @Column(name="medPrvAddress2", length=200)
 public String getMedPrvAddress2() {
     return this.medPrvAddress2;
 }
 
 public void setMedPrvAddress2(String medPrvAddress2) {
     this.medPrvAddress2 = medPrvAddress2;
 }

 
 @Column(name="medPrvAddress3", length=200)
 public String getMedPrvAddress3() {
     return this.medPrvAddress3;
 }
 
 public void setMedPrvAddress3(String medPrvAddress3) {
     this.medPrvAddress3 = medPrvAddress3;
 }

 
 @Column(name="medPrvCity", length=25)
 public String getMedPrvCity() {
     return this.medPrvCity;
 }
 
 public void setMedPrvCity(String medPrvCity) {
     this.medPrvCity = medPrvCity;
 }

 
 @Column(name="medPrvState", length=50)
 public String getMedPrvState() {
     return this.medPrvState;
 }
 
 public void setMedPrvState(String medPrvState) {
     this.medPrvState = medPrvState;
 }

 
 @Column(name="medPrvPostcode", length=20)
 public String getMedPrvPostcode() {
     return this.medPrvPostcode;
 }
 
 public void setMedPrvPostcode(String medPrvPostcode) {
     this.medPrvPostcode = medPrvPostcode;
 }

 
 @Column(name="medPrvCountry", length=50)
 public String getMedPrvCountry() {
     return this.medPrvCountry;
 }
 
 public void setMedPrvCountry(String medPrvCountry) {
     this.medPrvCountry = medPrvCountry;
 }

 
 @Column(name="medPrvOwnership", length=1)
 public Character getMedPrvOwnership() {
     return this.medPrvOwnership;
 }
 
 public void setMedPrvOwnership(Character medPrvOwnership) {
     this.medPrvOwnership = medPrvOwnership;
 }

 
 @Column(name="medPrvOwner", length=190)
 public String getMedPrvOwner() {
     return this.medPrvOwner;
 }
 
 public void setMedPrvOwner(String medPrvOwner) {
     this.medPrvOwner = medPrvOwner;
 }

 
 @Column(name="medPrvWebsite", length=190)
 public String getMedPrvWebsite() {
     return this.medPrvWebsite;
 }
 
 public void setMedPrvWebsite(String medPrvWebsite) {
     this.medPrvWebsite = medPrvWebsite;
 }

 
 @Column(name="medPrvGenTelOfcHrs", length=100)
 public String getMedPrvGenTelOfcHrs() {
     return this.medPrvGenTelOfcHrs;
 }
 
 public void setMedPrvGenTelOfcHrs(String medPrvGenTelOfcHrs) {
     this.medPrvGenTelOfcHrs = medPrvGenTelOfcHrs;
 }

 
 @Column(name="medPrvGenTelAftOfc", length=100)
 public String getMedPrvGenTelAftOfc() {
     return this.medPrvGenTelAftOfc;
 }
 
 public void setMedPrvGenTelAftOfc(String medPrvGenTelAftOfc) {
     this.medPrvGenTelAftOfc = medPrvGenTelAftOfc;
 }

 
 @Column(name="medPrvGenFaxOfcHrs", length=100)
 public String getMedPrvGenFaxOfcHrs() {
     return this.medPrvGenFaxOfcHrs;
 }
 
 public void setMedPrvGenFaxOfcHrs(String medPrvGenFaxOfcHrs) {
     this.medPrvGenFaxOfcHrs = medPrvGenFaxOfcHrs;
 }

 
 @Column(name="medPrvGenFaxAftOfc", length=100)
 public String getMedPrvGenFaxAftOfc() {
     return this.medPrvGenFaxAftOfc;
 }
 
 public void setMedPrvGenFaxAftOfc(String medPrvGenFaxAftOfc) {
     this.medPrvGenFaxAftOfc = medPrvGenFaxAftOfc;
 }

 
 @Column(name="medPrvGenEmail", length=190)
 public String getMedPrvGenEmail() {
     return this.medPrvGenEmail;
 }
 
 public void setMedPrvGenEmail(String medPrvGenEmail) {
     this.medPrvGenEmail = medPrvGenEmail;
 }

 
 @Column(name="medPrv24hours")
 public Boolean getMedPrv24hours() {
     return this.medPrv24hours;
 }
 
 public void setMedPrv24hours(Boolean medPrv24hours) {
     this.medPrv24hours = medPrv24hours;
 }

 
 @Column(name="medPrvDesc", length=16777215)
 public String getMedPrvDesc() {
     return this.medPrvDesc;
 }
 
 public void setMedPrvDesc(String medPrvDesc) {
     this.medPrvDesc = medPrvDesc;
 }

 
 @Column(name="medPrvCreditCardLg")
 public Boolean getMedPrvCreditCardLg() {
     return this.medPrvCreditCardLg;
 }
 
 public void setMedPrvCreditCardLg(Boolean medPrvCreditCardLg) {
     this.medPrvCreditCardLg = medPrvCreditCardLg;
 }

 
 @Column(name="medPrvGeHospCode", length=50)
 public String getMedPrvGeHospCode() {
     return this.medPrvGeHospCode;
 }
 
 public void setMedPrvGeHospCode(String medPrvGeHospCode) {
     this.medPrvGeHospCode = medPrvGeHospCode;
 }

 
 @Column(name="medPrvRegion", length=20)
 public String getMedPrvRegion() {
     return this.medPrvRegion;
 }
 
 public void setMedPrvRegion(String medPrvRegion) {
     this.medPrvRegion = medPrvRegion;
 }

 
 @Column(name="medPrvLat", precision=22, scale=0)
 public Double getMedPrvLat() {
     return this.medPrvLat;
 }
 
 public void setMedPrvLat(Double medPrvLat) {
     this.medPrvLat = medPrvLat;
 }

 
 @Column(name="medPrvLng", precision=22, scale=0)
 public Double getMedPrvLng() {
     return this.medPrvLng;
 }
 
 public void setMedPrvLng(Double medPrvLng) {
     this.medPrvLng = medPrvLng;
 }

 
 @Column(name="medPrvCnLat", precision=22, scale=0)
 public Double getMedPrvCnLat() {
     return this.medPrvCnLat;
 }
 
 public void setMedPrvCnLat(Double medPrvCnLat) {
     this.medPrvCnLat = medPrvCnLat;
 }

 
 @Column(name="medPrvCnLng", precision=22, scale=0)
 public Double getMedPrvCnLng() {
     return this.medPrvCnLng;
 }
 
 public void setMedPrvCnLng(Double medPrvCnLng) {
     this.medPrvCnLng = medPrvCnLng;
 }

 
 @Column(name="medPrvExternalHospCode", length=50)
 public String getMedPrvExternalHospCode() {
     return this.medPrvExternalHospCode;
 }
 
 public void setMedPrvExternalHospCode(String medPrvExternalHospCode) {
     this.medPrvExternalHospCode = medPrvExternalHospCode;
 }

 
 @Column(name="medPrvAlimHospCode", length=50)
 public String getMedPrvAlimHospCode() {
     return this.medPrvAlimHospCode;
 }
 
 public void setMedPrvAlimHospCode(String medPrvAlimHospCode) {
     this.medPrvAlimHospCode = medPrvAlimHospCode;
 }

 
 @Column(name="medPrvMpiHospCode", length=50)
 public String getMedPrvMpiHospCode() {
     return this.medPrvMpiHospCode;
 }
 
 public void setMedPrvMpiHospCode(String medPrvMpiHospCode) {
     this.medPrvMpiHospCode = medPrvMpiHospCode;
 }

 
 @Column(name="medPrvPruCode", length=15)
 public String getMedPrvPruCode() {
     return this.medPrvPruCode;
 }
 
 public void setMedPrvPruCode(String medPrvPruCode) {
     this.medPrvPruCode = medPrvPruCode;
 }

 
 @Column(name="medPrvSunLifeCode", length=50)
 public String getMedPrvSunLifeCode() {
     return this.medPrvSunLifeCode;
 }
 
 public void setMedPrvSunLifeCode(String medPrvSunLifeCode) {
     this.medPrvSunLifeCode = medPrvSunLifeCode;
 }

 
 @Column(name="medPrvLonpacMyCode", length=15)
 public String getMedPrvLonpacMyCode() {
     return this.medPrvLonpacMyCode;
 }
 
 public void setMedPrvLonpacMyCode(String medPrvLonpacMyCode) {
     this.medPrvLonpacMyCode = medPrvLonpacMyCode;
 }

 
 @Column(name="medPrvAxaAffinMyCode", length=15)
 public String getMedPrvAxaAffinMyCode() {
     return this.medPrvAxaAffinMyCode;
 }
 
 public void setMedPrvAxaAffinMyCode(String medPrvAxaAffinMyCode) {
     this.medPrvAxaAffinMyCode = medPrvAxaAffinMyCode;
 }

 
 @Column(name="medPrvEtiqaMcsMyCode", length=15)
 public String getMedPrvEtiqaMcsMyCode() {
     return this.medPrvEtiqaMcsMyCode;
 }
 
 public void setMedPrvEtiqaMcsMyCode(String medPrvEtiqaMcsMyCode) {
     this.medPrvEtiqaMcsMyCode = medPrvEtiqaMcsMyCode;
 }

 
 @Column(name="medPrvStmbMyCode", length=15)
 public String getMedPrvStmbMyCode() {
     return this.medPrvStmbMyCode;
 }
 
 public void setMedPrvStmbMyCode(String medPrvStmbMyCode) {
     this.medPrvStmbMyCode = medPrvStmbMyCode;
 }

 
 @Column(name="medPrvHlaMyCode", length=15)
 public String getMedPrvHlaMyCode() {
     return this.medPrvHlaMyCode;
 }
 
 public void setMedPrvHlaMyCode(String medPrvHlaMyCode) {
     this.medPrvHlaMyCode = medPrvHlaMyCode;
 }
 
 @Column(name="medPrvAgicMyCode", length=15)
 public String getMedPrvAgicMyCode() {
     return this.medPrvAgicMyCode;
 }
 
 public void setMedPrvAgicMyCode(String medPrvAgicMyCode) {
     this.medPrvAgicMyCode = medPrvAgicMyCode;
 }
 
 @Column(name="medPrv24hourHotline", length=100)
 public String getMedPrv24hourHotline() {
     return this.medPrv24hourHotline;
 }
 
 public void setMedPrv24hourHotline(String medPrv24hourHotline) {
     this.medPrv24hourHotline = medPrv24hourHotline;
 }

 
 @Column(name="medPrvVendorId", length=20)
 public String getMedPrvVendorId() {
     return this.medPrvVendorId;
 }
 
 public void setMedPrvVendorId(String medPrvVendorId) {
     this.medPrvVendorId = medPrvVendorId;
 }

 
 @Column(name="medPrvVendorIdOupt", length=20)
 public String getMedPrvVendorIdOupt() {
     return this.medPrvVendorIdOupt;
 }
 
 public void setMedPrvVendorIdOupt(String medPrvVendorIdOupt) {
     this.medPrvVendorIdOupt = medPrvVendorIdOupt;
 }

 
 @Column(name="medPrvBankName", length=150)
 public String getMedPrvBankName() {
     return this.medPrvBankName;
 }
 
 public void setMedPrvBankName(String medPrvBankName) {
     this.medPrvBankName = medPrvBankName;
 }

 
 @Column(name="medPrvBankAccountNum", length=50)
 public String getMedPrvBankAccountNum() {
     return this.medPrvBankAccountNum;
 }
 
 public void setMedPrvBankAccountNum(String medPrvBankAccountNum) {
     this.medPrvBankAccountNum = medPrvBankAccountNum;
 }

 
 @Column(name="medPrvBankBranch", length=100)
 public String getMedPrvBankBranch() {
     return this.medPrvBankBranch;
 }
 
 public void setMedPrvBankBranch(String medPrvBankBranch) {
     this.medPrvBankBranch = medPrvBankBranch;
 }

 
 @Column(name="medPrvBankCode", length=30)
 public String getMedPrvBankCode() {
     return this.medPrvBankCode;
 }
 
 public void setMedPrvBankCode(String medPrvBankCode) {
     this.medPrvBankCode = medPrvBankCode;
 }

 
 @Column(name="medPrvPaymentType", length=1)
 public String getMedPrvPaymentType() {
     return this.medPrvPaymentType;
 }
 
 public void setMedPrvPaymentType(String medPrvPaymentType) {
     this.medPrvPaymentType = medPrvPaymentType;
 }

 
 @Column(name="medPrvGstRegistrationNum", length=20)
 public String getMedPrvGstRegistrationNum() {
     return this.medPrvGstRegistrationNum;
 }
 
 public void setMedPrvGstRegistrationNum(String medPrvGstRegistrationNum) {
     this.medPrvGstRegistrationNum = medPrvGstRegistrationNum;
 }

 
 @Column(name="medPrvMohLicenseNum", length=20)
 public String getMedPrvMohLicenseNum() {
     return this.medPrvMohLicenseNum;
 }
 
 public void setMedPrvMohLicenseNum(String medPrvMohLicenseNum) {
     this.medPrvMohLicenseNum = medPrvMohLicenseNum;
 }

 
 @Column(name="medPrvClinicLicenseNum", length=20)
 public String getMedPrvClinicLicenseNum() {
     return this.medPrvClinicLicenseNum;
 }
 
 public void setMedPrvClinicLicenseNum(String medPrvClinicLicenseNum) {
     this.medPrvClinicLicenseNum = medPrvClinicLicenseNum;
 }
  
 @Column(name="medPrvPayeeEmailAddress", length=100)
 public String getMedPrvPayeeEmailAddress() {
     return this.medPrvPayeeEmailAddress;
 }
 
 public void setMedPrvPayeeEmailAddress(String medPrvPayeeEmailAddress) {
     this.medPrvPayeeEmailAddress = medPrvPayeeEmailAddress;
 }
  
 @Column(name="medPrvBillingName", length=100)
 public String getmedPrvBillingName() {
     return this.medPrvBillingName;
 }
 
 public void setmedPrvBillingName(String medPrvBillingName) {
     this.medPrvBillingName = medPrvBillingName;
 }
 
 @Column(name="medPrvDoctorPractisingCertNum", length=20)
 public String getMedPrvDoctorPractisingCertNum() {
     return this.medPrvDoctorPractisingCertNum;
 }
 
 public void setMedPrvDoctorPractisingCertNum(String medPrvDoctorPractisingCertNum) {
     this.medPrvDoctorPractisingCertNum = medPrvDoctorPractisingCertNum;
 }

 
 @Column(name="medPrvDefaultCurrency", length=3)
 public String getMedPrvDefaultCurrency() {
     return this.medPrvDefaultCurrency;
 }
 
 public void setMedPrvDefaultCurrency(String medPrvDefaultCurrency) {
     this.medPrvDefaultCurrency = medPrvDefaultCurrency;
 }

 
 @Column(name="medPrvOutptGpClinic")
 public Boolean getMedPrvOutptGpClinic() {
     return this.medPrvOutptGpClinic;
 }
 
 public void setMedPrvOutptGpClinic(Boolean medPrvOutptGpClinic) {
     this.medPrvOutptGpClinic = medPrvOutptGpClinic;
 }

 
 @Column(name="medPrvOutptSpClinic")
 public Boolean getMedPrvOutptSpClinic() {
     return this.medPrvOutptSpClinic;
 }
 
 public void setMedPrvOutptSpClinic(Boolean medPrvOutptSpClinic) {
     this.medPrvOutptSpClinic = medPrvOutptSpClinic;
 }

 
 @Column(name="medPrvOutptDentalClinic")
 public Boolean getMedPrvOutptDentalClinic() {
     return this.medPrvOutptDentalClinic;
 }
 
 public void setMedPrvOutptDentalClinic(Boolean medPrvOutptDentalClinic) {
     this.medPrvOutptDentalClinic = medPrvOutptDentalClinic;
 }

 
 @Column(name="medPrvOutptTcmClinic")
 public Boolean getMedPrvOutptTcmClinic() {
     return this.medPrvOutptTcmClinic;
 }
 
 public void setMedPrvOutptTcmClinic(Boolean medPrvOutptTcmClinic) {
     this.medPrvOutptTcmClinic = medPrvOutptTcmClinic;
 }

 
 @Column(name="medPrvOutptMatClinic")
 public Boolean getMedPrvOutptMatClinic() {
     return this.medPrvOutptMatClinic;
 }
 
 public void setMedPrvOutptMatClinic(Boolean medPrvOutptMatClinic) {
     this.medPrvOutptMatClinic = medPrvOutptMatClinic;
 }

 
 @Column(name="medPrvOutptHospital")
 public Boolean getMedPrvOutptHospital() {
     return this.medPrvOutptHospital;
 }
 
 public void setMedPrvOutptHospital(Boolean medPrvOutptHospital) {
     this.medPrvOutptHospital = medPrvOutptHospital;
 }

 
 @Column(name="medPrvOutptAutoAdjudicate")
 public Boolean getMedPrvOutptAutoAdjudicate() {
     return this.medPrvOutptAutoAdjudicate;
 }
 
 public void setMedPrvOutptAutoAdjudicate(Boolean medPrvOutptAutoAdjudicate) {
     this.medPrvOutptAutoAdjudicate = medPrvOutptAutoAdjudicate;
 }

 
 @Column(name="medPrvOutptGstCalcType", length=1)
 public String getMedPrvOutptGstCalcType() {
     return this.medPrvOutptGstCalcType;
 }
 
 public void setMedPrvOutptGstCalcType(String medPrvOutptGstCalcType) {
     this.medPrvOutptGstCalcType = medPrvOutptGstCalcType;
 }

 
 @Column(name="medPrvOutptGstPercent", precision=3, scale=1)
 public BigDecimal getMedPrvOutptGstPercent() {
     return this.medPrvOutptGstPercent;
 }
 
 public void setMedPrvOutptGstPercent(BigDecimal medPrvOutptGstPercent) {
     this.medPrvOutptGstPercent = medPrvOutptGstPercent;
 }

 
 @Column(name="medPrvOutptPerVisitLimit", length = 12)
 public BigDecimal getMedPrvOutptPerVisitLimit() {
     return this.medPrvOutptPerVisitLimit;
 }
 
 public void setMedPrvOutptPerVisitLimit(BigDecimal medPrvOutptPerVisitLimit) {
     this.medPrvOutptPerVisitLimit = medPrvOutptPerVisitLimit;
 }

 
 @Column(name="medPrvQrString", length=100)
 public String getMedPrvQrString() {
     return this.medPrvQrString;
 }
 
 public void setMedPrvQrString(String medPrvQrString) {
     this.medPrvQrString = medPrvQrString;
 }

 
 @Column(name="medPrvPicName", length=100)
 public String getMedPrvPicName() {
     return this.medPrvPicName;
 }
 
 public void setMedPrvPicName(String medPrvPicName) {
     this.medPrvPicName = medPrvPicName;
 }

 
 @Column(name="medPrvPicEmail", length=250)
 public String getMedPrvPicEmail() {
     return this.medPrvPicEmail;
 }
 
 public void setMedPrvPicEmail(String medPrvPicEmail) {
     this.medPrvPicEmail = medPrvPicEmail;
 }

 
 @Column(name="medPrvPicTel", length=50)
 public String getMedPrvPicTel() {
     return this.medPrvPicTel;
 }
 
 public void setMedPrvPicTel(String medPrvPicTel) {
     this.medPrvPicTel = medPrvPicTel;
 }

 
 @Column(name="medPrvNotifyOutptFax")
 public Boolean getMedPrvNotifyOutptFax() {
     return this.medPrvNotifyOutptFax;
 }
 
 public void setMedPrvNotifyOutptFax(Boolean medPrvNotifyOutptFax) {
     this.medPrvNotifyOutptFax = medPrvNotifyOutptFax;
 }

 
 @Column(name="medPrvNotifyOutptFaxNum", length=100)
 public String getMedPrvNotifyOutptFaxNum() {
     return this.medPrvNotifyOutptFaxNum;
 }
 
 public void setMedPrvNotifyOutptFaxNum(String medPrvNotifyOutptFaxNum) {
     this.medPrvNotifyOutptFaxNum = medPrvNotifyOutptFaxNum;
 }

 
 @Column(name="medPrvNotifyOutptEmail")
 public Boolean getMedPrvNotifyOutptEmail() {
     return this.medPrvNotifyOutptEmail;
 }
 
 public void setMedPrvNotifyOutptEmail(Boolean medPrvNotifyOutptEmail) {
     this.medPrvNotifyOutptEmail = medPrvNotifyOutptEmail;
 }

 
 @Column(name="medPrvNotifyOutptEmailToAddr", length=250)
 public String getMedPrvNotifyOutptEmailToAddr() {
     return this.medPrvNotifyOutptEmailToAddr;
 }
 
 public void setMedPrvNotifyOutptEmailToAddr(String medPrvNotifyOutptEmailToAddr) {
     this.medPrvNotifyOutptEmailToAddr = medPrvNotifyOutptEmailToAddr;
 }

 
 @Column(name="medPrvNotifyOutptEmailToCc", length=250)
 public String getMedPrvNotifyOutptEmailToCc() {
     return this.medPrvNotifyOutptEmailToCc;
 }
 
 public void setMedPrvNotifyOutptEmailToCc(String medPrvNotifyOutptEmailToCc) {
     this.medPrvNotifyOutptEmailToCc = medPrvNotifyOutptEmailToCc;
 }

 
 @Column(name="medPrvNotifyOutptEmailToBcc", length=250)
 public String getMedPrvNotifyOutptEmailToBcc() {
     return this.medPrvNotifyOutptEmailToBcc;
 }
 
 public void setMedPrvNotifyOutptEmailToBcc(String medPrvNotifyOutptEmailToBcc) {
     this.medPrvNotifyOutptEmailToBcc = medPrvNotifyOutptEmailToBcc;
 }

 
 @Column(name="medPrvNotifyOutptEmailSubject", length=250)
 public String getMedPrvNotifyOutptEmailSubject() {
     return this.medPrvNotifyOutptEmailSubject;
 }
 
 public void setMedPrvNotifyOutptEmailSubject(String medPrvNotifyOutptEmailSubject) {
     this.medPrvNotifyOutptEmailSubject = medPrvNotifyOutptEmailSubject;
 }

 
 @Column(name="medPrvNotifyOutptEmailContent", length=16777215)
 public String getMedPrvNotifyOutptEmailContent() {
     return this.medPrvNotifyOutptEmailContent;
 }
 
 public void setMedPrvNotifyOutptEmailContent(String medPrvNotifyOutptEmailContent) {
     this.medPrvNotifyOutptEmailContent = medPrvNotifyOutptEmailContent;
 }

 
 @Column(name="medPrvNotifyInptFax")
 public Boolean getMedPrvNotifyInptFax() {
     return this.medPrvNotifyInptFax;
 }
 
 public void setMedPrvNotifyInptFax(Boolean medPrvNotifyInptFax) {
     this.medPrvNotifyInptFax = medPrvNotifyInptFax;
 }

 
 @Column(name="medPrvNotifyInptFaxNum", length=100)
 public String getMedPrvNotifyInptFaxNum() {
     return this.medPrvNotifyInptFaxNum;
 }
 
 public void setMedPrvNotifyInptFaxNum(String medPrvNotifyInptFaxNum) {
     this.medPrvNotifyInptFaxNum = medPrvNotifyInptFaxNum;
 }

 
 @Column(name="medPrvNotifyInptEmail")
 public Boolean getMedPrvNotifyInptEmail() {
     return this.medPrvNotifyInptEmail;
 }
 
 public void setMedPrvNotifyInptEmail(Boolean medPrvNotifyInptEmail) {
     this.medPrvNotifyInptEmail = medPrvNotifyInptEmail;
 }

 
 @Column(name="medPrvNotifyInptEmailToAddr", length=250)
 public String getMedPrvNotifyInptEmailToAddr() {
     return this.medPrvNotifyInptEmailToAddr;
 }
 
 public void setMedPrvNotifyInptEmailToAddr(String medPrvNotifyInptEmailToAddr) {
     this.medPrvNotifyInptEmailToAddr = medPrvNotifyInptEmailToAddr;
 }

 
 @Column(name="medPrvNotifyInptEmailToCc", length=250)
 public String getMedPrvNotifyInptEmailToCc() {
     return this.medPrvNotifyInptEmailToCc;
 }
 
 public void setMedPrvNotifyInptEmailToCc(String medPrvNotifyInptEmailToCc) {
     this.medPrvNotifyInptEmailToCc = medPrvNotifyInptEmailToCc;
 }

 
 @Column(name="medPrvNotifyInptEmailToBcc", length=250)
 public String getMedPrvNotifyInptEmailToBcc() {
     return this.medPrvNotifyInptEmailToBcc;
 }
 
 public void setMedPrvNotifyInptEmailToBcc(String medPrvNotifyInptEmailToBcc) {
     this.medPrvNotifyInptEmailToBcc = medPrvNotifyInptEmailToBcc;
 }

 
 @Column(name="medPrvNotifyInptEmailSubject", length=250)
 public String getMedPrvNotifyInptEmailSubject() {
     return this.medPrvNotifyInptEmailSubject;
 }
 
 public void setMedPrvNotifyInptEmailSubject(String medPrvNotifyInptEmailSubject) {
     this.medPrvNotifyInptEmailSubject = medPrvNotifyInptEmailSubject;
 }

 
 @Column(name="medPrvNotifyInptEmailContent", length=16777215)
 public String getMedPrvNotifyInptEmailContent() {
     return this.medPrvNotifyInptEmailContent;
 }
 
 public void setMedPrvNotifyInptEmailContent(String medPrvNotifyInptEmailContent) {
     this.medPrvNotifyInptEmailContent = medPrvNotifyInptEmailContent;
 }

 
 @Column(name="medPrvClass", length=20)
 public String getMedPrvClass() {
     return this.medPrvClass;
 }
 
 public void setMedPrvClass(String medPrvClass) {
     this.medPrvClass = medPrvClass;
 }

 
 @Column(name="medPrvAccTaxId", length=50)
 public String getMedPrvAccTaxId() {
     return this.medPrvAccTaxId;
 }
 
 public void setMedPrvAccTaxId(String medPrvAccTaxId) {
     this.medPrvAccTaxId = medPrvAccTaxId;
 }

 
 @Column(name="medPrvAccDiscRate", precision=22, scale=0)
 public Double getMedPrvAccDiscRate() {
     return this.medPrvAccDiscRate;
 }
 
 public void setMedPrvAccDiscRate(Double medPrvAccDiscRate) {
     this.medPrvAccDiscRate = medPrvAccDiscRate;
 }

 
 @Column(name="medPrvAccWhtPercentage")
 public Integer getMedPrvAccWhtPercentage() {
     return this.medPrvAccWhtPercentage;
 }
 
 public void setMedPrvAccWhtPercentage(Integer medPrvAccWhtPercentage) {
     this.medPrvAccWhtPercentage = medPrvAccWhtPercentage;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvAccWhtStartDate", length=19)
 public Date getMedPrvAccWhtStartDate() {
     return this.medPrvAccWhtStartDate;
 }
 
 public void setMedPrvAccWhtStartDate(Date medPrvAccWhtStartDate) {
     this.medPrvAccWhtStartDate = medPrvAccWhtStartDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPrvAccWhtEndDate", length=19)
 public Date getMedPrvAccWhtEndDate() {
     return this.medPrvAccWhtEndDate;
 }
 
 public void setMedPrvAccWhtEndDate(Date medPrvAccWhtEndDate) {
     this.medPrvAccWhtEndDate = medPrvAccWhtEndDate;
 }

 
 @Column(name="medPrvAccWhtExclude", length=60)
 public String getMedPrvAccWhtExclude() {
     return this.medPrvAccWhtExclude;
 }
 
 public void setMedPrvAccWhtExclude(String medPrvAccWhtExclude) {
     this.medPrvAccWhtExclude = medPrvAccWhtExclude;
 }

 
 @Column(name="medPrvAccTaxName", length=250)
 public String getMedPrvAccTaxName() {
     return this.medPrvAccTaxName;
 }
 
 public void setMedPrvAccTaxName(String medPrvAccTaxName) {
     this.medPrvAccTaxName = medPrvAccTaxName;
 }

 
 @Column(name="medPrvAccTaxAddress", length=250)
 public String getMedPrvAccTaxAddress() {
     return this.medPrvAccTaxAddress;
 }
 
 public void setMedPrvAccTaxAddress(String medPrvAccTaxAddress) {
     this.medPrvAccTaxAddress = medPrvAccTaxAddress;
 }

 
 @Column(name="medPrvAccTaxCity", length=100)
 public String getMedPrvAccTaxCity() {
     return this.medPrvAccTaxCity;
 }
 
 public void setMedPrvAccTaxCity(String medPrvAccTaxCity) {
     this.medPrvAccTaxCity = medPrvAccTaxCity;
 }

 
 @Column(name="medPrvAccTaxProvince", length=50)
 public String getMedPrvAccTaxProvince() {
     return this.medPrvAccTaxProvince;
 }
 
 public void setMedPrvAccTaxProvince(String medPrvAccTaxProvince) {
     this.medPrvAccTaxProvince = medPrvAccTaxProvince;
 }

 
 @Column(name="medPrvAccTaxPostcode", length=50)
 public String getMedPrvAccTaxPostcode() {
     return this.medPrvAccTaxPostcode;
 }
 
 public void setMedPrvAccTaxPostcode(String medPrvAccTaxPostcode) {
     this.medPrvAccTaxPostcode = medPrvAccTaxPostcode;
 }

 
 @Column(name="medPrvAccTaxType", length=50)
 public String getMedPrvAccTaxType() {
     return this.medPrvAccTaxType;
 }
 
 public void setMedPrvAccTaxType(String medPrvAccTaxType) {
     this.medPrvAccTaxType = medPrvAccTaxType;
 }

 
 @Column(name="medprvCreditTerm", length=50)
 public String getMedprvCreditTerm() {
     return this.medprvCreditTerm;
 }
 
 public void setMedprvCreditTerm(String medprvCreditTerm) {
     this.medprvCreditTerm = medprvCreditTerm;
 }

 
 @Column(name="medPrvTitle", length=50)
 public String getMedPrvTitle() {
     return this.medPrvTitle;
 }
 
 public void setMedPrvTitle(String medPrvTitle) {
     this.medPrvTitle = medPrvTitle;
 }

 
 @Column(name="medPrvJciAccre")
 public Boolean getMedPrvJciAccre() {
     return this.medPrvJciAccre;
 }
 
 public void setMedPrvJciAccre(Boolean medPrvJciAccre) {
     this.medPrvJciAccre = medPrvJciAccre;
 }

 
 @Column(name="medPrvLocalCre")
 public Boolean getMedPrvLocalCre() {
     return this.medPrvLocalCre;
 }
 
 public void setMedPrvLocalCre(Boolean medPrvLocalCre) {
     this.medPrvLocalCre = medPrvLocalCre;
 }

 
 @Column(name="medPrvIsoAccre")
 public Boolean getMedPrvIsoAccre() {
     return this.medPrvIsoAccre;
 }
 
 public void setMedPrvIsoAccre(Boolean medPrvIsoAccre) {
     this.medPrvIsoAccre = medPrvIsoAccre;
 }

 
 @Column(name="medPrvHospMalprac")
 public Boolean getMedPrvHospMalprac() {
     return this.medPrvHospMalprac;
 }
 
 public void setMedPrvHospMalprac(Boolean medPrvHospMalprac) {
     this.medPrvHospMalprac = medPrvHospMalprac;
 }

 
 @Column(name="medPrvFullTimeDrMalprac")
 public Boolean getMedPrvFullTimeDrMalprac() {
     return this.medPrvFullTimeDrMalprac;
 }
 
 public void setMedPrvFullTimeDrMalprac(Boolean medPrvFullTimeDrMalprac) {
     this.medPrvFullTimeDrMalprac = medPrvFullTimeDrMalprac;
 }

 
 @Column(name="medPrvPartTimeDrMalprac")
 public Boolean getMedPrvPartTimeDrMalprac() {
     return this.medPrvPartTimeDrMalprac;
 }
 
 public void setMedPrvPartTimeDrMalprac(Boolean medPrvPartTimeDrMalprac) {
     this.medPrvPartTimeDrMalprac = medPrvPartTimeDrMalprac;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvJciAccreExpDate", length=10)
 public Date getMedPrvJciAccreExpDate() {
     return this.medPrvJciAccreExpDate;
 }
 
 public void setMedPrvJciAccreExpDate(Date medPrvJciAccreExpDate) {
     this.medPrvJciAccreExpDate = medPrvJciAccreExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvLocalCreExpDate", length=10)
 public Date getMedPrvLocalCreExpDate() {
     return this.medPrvLocalCreExpDate;
 }
 
 public void setMedPrvLocalCreExpDate(Date medPrvLocalCreExpDate) {
     this.medPrvLocalCreExpDate = medPrvLocalCreExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvIsoAccreExpDate", length=10)
 public Date getMedPrvIsoAccreExpDate() {
     return this.medPrvIsoAccreExpDate;
 }
 
 public void setMedPrvIsoAccreExpDate(Date medPrvIsoAccreExpDate) {
     this.medPrvIsoAccreExpDate = medPrvIsoAccreExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvHospMalpracExpDate", length=10)
 public Date getMedPrvHospMalpracExpDate() {
     return this.medPrvHospMalpracExpDate;
 }
 
 public void setMedPrvHospMalpracExpDate(Date medPrvHospMalpracExpDate) {
     this.medPrvHospMalpracExpDate = medPrvHospMalpracExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvFullTimeDrMalpracExpDate", length=10)
 public Date getMedPrvFullTimeDrMalpracExpDate() {
     return this.medPrvFullTimeDrMalpracExpDate;
 }
 
 public void setMedPrvFullTimeDrMalpracExpDate(Date medPrvFullTimeDrMalpracExpDate) {
     this.medPrvFullTimeDrMalpracExpDate = medPrvFullTimeDrMalpracExpDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="medPrvPartTimeDrMalpracExpDate", length=10)
 public Date getMedPrvPartTimeDrMalpracExpDate() {
     return this.medPrvPartTimeDrMalpracExpDate;
 }
 
 public void setMedPrvPartTimeDrMalpracExpDate(Date medPrvPartTimeDrMalpracExpDate) {
     this.medPrvPartTimeDrMalpracExpDate = medPrvPartTimeDrMalpracExpDate;
 }

 
 @Column(name="medPrvCapacity", length=50)
 public String getMedPrvCapacity() {
     return this.medPrvCapacity;
 }
 
 public void setMedPrvCapacity(String medPrvCapacity) {
     this.medPrvCapacity = medPrvCapacity;
 }

 
 @Column(name="medPrvSpecMedicine")
 public Boolean getMedPrvSpecMedicine() {
     return this.medPrvSpecMedicine;
 }
 
 public void setMedPrvSpecMedicine(Boolean medPrvSpecMedicine) {
     this.medPrvSpecMedicine = medPrvSpecMedicine;
 }

 
 @Column(name="medPrvSpecPlastic")
 public Boolean getMedPrvSpecPlastic() {
     return this.medPrvSpecPlastic;
 }
 
 public void setMedPrvSpecPlastic(Boolean medPrvSpecPlastic) {
     this.medPrvSpecPlastic = medPrvSpecPlastic;
 }

 
 @Column(name="medPrvSpecEar")
 public Boolean getMedPrvSpecEar() {
     return this.medPrvSpecEar;
 }
 
 public void setMedPrvSpecEar(Boolean medPrvSpecEar) {
     this.medPrvSpecEar = medPrvSpecEar;
 }

 
 @Column(name="medPrvSpecCardiology")
 public Boolean getMedPrvSpecCardiology() {
     return this.medPrvSpecCardiology;
 }
 
 public void setMedPrvSpecCardiology(Boolean medPrvSpecCardiology) {
     this.medPrvSpecCardiology = medPrvSpecCardiology;
 }

 
 @Column(name="medPrvSpecInfectious")
 public Boolean getMedPrvSpecInfectious() {
     return this.medPrvSpecInfectious;
 }
 
 public void setMedPrvSpecInfectious(Boolean medPrvSpecInfectious) {
     this.medPrvSpecInfectious = medPrvSpecInfectious;
 }

 
 @Column(name="medPrvSpecGi")
 public Boolean getMedPrvSpecGi() {
     return this.medPrvSpecGi;
 }
 
 public void setMedPrvSpecGi(Boolean medPrvSpecGi) {
     this.medPrvSpecGi = medPrvSpecGi;
 }

 
 @Column(name="medPrvSpecNutrition")
 public Boolean getMedPrvSpecNutrition() {
     return this.medPrvSpecNutrition;
 }
 
 public void setMedPrvSpecNutrition(Boolean medPrvSpecNutrition) {
     this.medPrvSpecNutrition = medPrvSpecNutrition;
 }

 
 @Column(name="medPrvSpecPsychiatry")
 public Boolean getMedPrvSpecPsychiatry() {
     return this.medPrvSpecPsychiatry;
 }
 
 public void setMedPrvSpecPsychiatry(Boolean medPrvSpecPsychiatry) {
     this.medPrvSpecPsychiatry = medPrvSpecPsychiatry;
 }

 
 @Column(name="medPrvSpecHypertension")
 public Boolean getMedPrvSpecHypertension() {
     return this.medPrvSpecHypertension;
 }
 
 public void setMedPrvSpecHypertension(Boolean medPrvSpecHypertension) {
     this.medPrvSpecHypertension = medPrvSpecHypertension;
 }

 
 @Column(name="medPrvSpecBreast")
 public Boolean getMedPrvSpecBreast() {
     return this.medPrvSpecBreast;
 }
 
 public void setMedPrvSpecBreast(Boolean medPrvSpecBreast) {
     this.medPrvSpecBreast = medPrvSpecBreast;
 }

 
 @Column(name="medPrvSpecCheckup")
 public Boolean getMedPrvSpecCheckup() {
     return this.medPrvSpecCheckup;
 }
 
 public void setMedPrvSpecCheckup(Boolean medPrvSpecCheckup) {
     this.medPrvSpecCheckup = medPrvSpecCheckup;
 }

 
 @Column(name="medPrvSpecDental")
 public Boolean getMedPrvSpecDental() {
     return this.medPrvSpecDental;
 }
 
 public void setMedPrvSpecDental(Boolean medPrvSpecDental) {
     this.medPrvSpecDental = medPrvSpecDental;
 }

 
 @Column(name="medPrvSpecNeurology")
 public Boolean getMedPrvSpecNeurology() {
     return this.medPrvSpecNeurology;
 }
 
 public void setMedPrvSpecNeurology(Boolean medPrvSpecNeurology) {
     this.medPrvSpecNeurology = medPrvSpecNeurology;
 }

 
 @Column(name="medPrvSpecHygiene")
 public Boolean getMedPrvSpecHygiene() {
     return this.medPrvSpecHygiene;
 }
 
 public void setMedPrvSpecHygiene(Boolean medPrvSpecHygiene) {
     this.medPrvSpecHygiene = medPrvSpecHygiene;
 }

 
 @Column(name="medPrvSpecNeuropathy")
 public Boolean getMedPrvSpecNeuropathy() {
     return this.medPrvSpecNeuropathy;
 }
 
 public void setMedPrvSpecNeuropathy(Boolean medPrvSpecNeuropathy) {
     this.medPrvSpecNeuropathy = medPrvSpecNeuropathy;
 }

 
 @Column(name="medPrvSpecGynecology")
 public Boolean getMedPrvSpecGynecology() {
     return this.medPrvSpecGynecology;
 }
 
 public void setMedPrvSpecGynecology(Boolean medPrvSpecGynecology) {
     this.medPrvSpecGynecology = medPrvSpecGynecology;
 }

 
 @Column(name="medPrvSpecEye")
 public Boolean getMedPrvSpecEye() {
     return this.medPrvSpecEye;
 }
 
 public void setMedPrvSpecEye(Boolean medPrvSpecEye) {
     this.medPrvSpecEye = medPrvSpecEye;
 }

 
 @Column(name="medPrvSpecPediatrics")
 public Boolean getMedPrvSpecPediatrics() {
     return this.medPrvSpecPediatrics;
 }
 
 public void setMedPrvSpecPediatrics(Boolean medPrvSpecPediatrics) {
     this.medPrvSpecPediatrics = medPrvSpecPediatrics;
 }

 
 @Column(name="medPrvSpecHematology")
 public Boolean getMedPrvSpecHematology() {
     return this.medPrvSpecHematology;
 }
 
 public void setMedPrvSpecHematology(Boolean medPrvSpecHematology) {
     this.medPrvSpecHematology = medPrvSpecHematology;
 }

 
 @Column(name="medPrvSpecNephrology")
 public Boolean getMedPrvSpecNephrology() {
     return this.medPrvSpecNephrology;
 }
 
 public void setMedPrvSpecNephrology(Boolean medPrvSpecNephrology) {
     this.medPrvSpecNephrology = medPrvSpecNephrology;
 }

 
 @Column(name="medPrvSpecOrthopaedic")
 public Boolean getMedPrvSpecOrthopaedic() {
     return this.medPrvSpecOrthopaedic;
 }
 
 public void setMedPrvSpecOrthopaedic(Boolean medPrvSpecOrthopaedic) {
     this.medPrvSpecOrthopaedic = medPrvSpecOrthopaedic;
 }

 
 @Column(name="medPrvSpecArthritis")
 public Boolean getMedPrvSpecArthritis() {
     return this.medPrvSpecArthritis;
 }
 
 public void setMedPrvSpecArthritis(Boolean medPrvSpecArthritis) {
     this.medPrvSpecArthritis = medPrvSpecArthritis;
 }

 
 @Column(name="medPrvSpecMedical")
 public Boolean getMedPrvSpecMedical() {
     return this.medPrvSpecMedical;
 }
 
 public void setMedPrvSpecMedical(Boolean medPrvSpecMedical) {
     this.medPrvSpecMedical = medPrvSpecMedical;
 }

 
 @Column(name="medPrvSpecForensic")
 public Boolean getMedPrvSpecForensic() {
     return this.medPrvSpecForensic;
 }
 
 public void setMedPrvSpecForensic(Boolean medPrvSpecForensic) {
     this.medPrvSpecForensic = medPrvSpecForensic;
 }

 
 @Column(name="medPrvSpecDiabetes")
 public Boolean getMedPrvSpecDiabetes() {
     return this.medPrvSpecDiabetes;
 }
 
 public void setMedPrvSpecDiabetes(Boolean medPrvSpecDiabetes) {
     this.medPrvSpecDiabetes = medPrvSpecDiabetes;
 }

 
 @Column(name="medPrvSpecEmergency")
 public Boolean getMedPrvSpecEmergency() {
     return this.medPrvSpecEmergency;
 }
 
 public void setMedPrvSpecEmergency(Boolean medPrvSpecEmergency) {
     this.medPrvSpecEmergency = medPrvSpecEmergency;
 }

 
 @Column(name="medPrvSpecDialysis")
 public Boolean getMedPrvSpecDialysis() {
     return this.medPrvSpecDialysis;
 }
 
 public void setMedPrvSpecDialysis(Boolean medPrvSpecDialysis) {
     this.medPrvSpecDialysis = medPrvSpecDialysis;
 }

 
 @Column(name="medPrvSpecUrology")
 public Boolean getMedPrvSpecUrology() {
     return this.medPrvSpecUrology;
 }
 
 public void setMedPrvSpecUrology(Boolean medPrvSpecUrology) {
     this.medPrvSpecUrology = medPrvSpecUrology;
 }

 
 @Column(name="medPrvSpecArthroplasty")
 public Boolean getMedPrvSpecArthroplasty() {
     return this.medPrvSpecArthroplasty;
 }
 
 public void setMedPrvSpecArthroplasty(Boolean medPrvSpecArthroplasty) {
     this.medPrvSpecArthroplasty = medPrvSpecArthroplasty;
 }

 
 @Column(name="medPrvSpecDermatosis")
 public Boolean getMedPrvSpecDermatosis() {
     return this.medPrvSpecDermatosis;
 }
 
 public void setMedPrvSpecDermatosis(Boolean medPrvSpecDermatosis) {
     this.medPrvSpecDermatosis = medPrvSpecDermatosis;
 }

 
 @Column(name="medPrvSpecOthers")
 public Boolean getMedPrvSpecOthers() {
     return this.medPrvSpecOthers;
 }
 
 public void setMedPrvSpecOthers(Boolean medPrvSpecOthers) {
     this.medPrvSpecOthers = medPrvSpecOthers;
 }

 
 @Column(name="medPrvSpecRemarks", length=50)
 public String getMedPrvSpecRemarks() {
     return this.medPrvSpecRemarks;
 }
 
 public void setMedPrvSpecRemarks(String medPrvSpecRemarks) {
     this.medPrvSpecRemarks = medPrvSpecRemarks;
 }

 
 @Column(name="medPrvCommEnglish")
 public Boolean getMedPrvCommEnglish() {
     return this.medPrvCommEnglish;
 }
 
 public void setMedPrvCommEnglish(Boolean medPrvCommEnglish) {
     this.medPrvCommEnglish = medPrvCommEnglish;
 }

 
 @Column(name="medPrvCommFrench")
 public Boolean getMedPrvCommFrench() {
     return this.medPrvCommFrench;
 }
 
 public void setMedPrvCommFrench(Boolean medPrvCommFrench) {
     this.medPrvCommFrench = medPrvCommFrench;
 }

 
 @Column(name="medPrvCommSpanish")
 public Boolean getMedPrvCommSpanish() {
     return this.medPrvCommSpanish;
 }
 
 public void setMedPrvCommSpanish(Boolean medPrvCommSpanish) {
     this.medPrvCommSpanish = medPrvCommSpanish;
 }

 
 @Column(name="medPrvCommJapanese")
 public Boolean getMedPrvCommJapanese() {
     return this.medPrvCommJapanese;
 }
 
 public void setMedPrvCommJapanese(Boolean medPrvCommJapanese) {
     this.medPrvCommJapanese = medPrvCommJapanese;
 }

 
 @Column(name="medPrvCommGerman")
 public Boolean getMedPrvCommGerman() {
     return this.medPrvCommGerman;
 }
 
 public void setMedPrvCommGerman(Boolean medPrvCommGerman) {
     this.medPrvCommGerman = medPrvCommGerman;
 }

 
 @Column(name="medPrvCommKorean")
 public Boolean getMedPrvCommKorean() {
     return this.medPrvCommKorean;
 }
 
 public void setMedPrvCommKorean(Boolean medPrvCommKorean) {
     this.medPrvCommKorean = medPrvCommKorean;
 }

 
 @Column(name="medPrvCommRussian")
 public Boolean getMedPrvCommRussian() {
     return this.medPrvCommRussian;
 }
 
 public void setMedPrvCommRussian(Boolean medPrvCommRussian) {
     this.medPrvCommRussian = medPrvCommRussian;
 }

 
 @Column(name="medPrvCommOthers")
 public Boolean getMedPrvCommOthers() {
     return this.medPrvCommOthers;
 }
 
 public void setMedPrvCommOthers(Boolean medPrvCommOthers) {
     this.medPrvCommOthers = medPrvCommOthers;
 }

 
 @Column(name="medPrvCommRemarks", length=50)
 public String getMedPrvCommRemarks() {
     return this.medPrvCommRemarks;
 }
 
 public void setMedPrvCommRemarks(String medPrvCommRemarks) {
     this.medPrvCommRemarks = medPrvCommRemarks;
 }

 
 @Column(name="medPrvGETSBCode", length=50)
 public String getMedPrvGetsbcode() {
     return this.medPrvGetsbcode;
 }
 
 public void setMedPrvGetsbcode(String medPrvGetsbcode) {
     this.medPrvGetsbcode = medPrvGetsbcode;
 }

 
 @Column(name="medPrvRoomRate1Bedded", precision=16)
 public BigDecimal getMedPrvRoomRate1bedded() {
     return this.medPrvRoomRate1bedded;
 }
 
 public void setMedPrvRoomRate1bedded(BigDecimal medPrvRoomRate1bedded) {
     this.medPrvRoomRate1bedded = medPrvRoomRate1bedded;
 }

 
 @Column(name="medPrvRoomRate2Bedded", precision=16)
 public BigDecimal getMedPrvRoomRate2bedded() {
     return this.medPrvRoomRate2bedded;
 }
 
 public void setMedPrvRoomRate2bedded(BigDecimal medPrvRoomRate2bedded) {
     this.medPrvRoomRate2bedded = medPrvRoomRate2bedded;
 }

 
 @Column(name="medPrvRoomRate4Bedded", precision=16)
 public BigDecimal getMedPrvRoomRate4bedded() {
     return this.medPrvRoomRate4bedded;
 }
 
 public void setMedPrvRoomRate4bedded(BigDecimal medPrvRoomRate4bedded) {
     this.medPrvRoomRate4bedded = medPrvRoomRate4bedded;
 }

 
 @Column(name="medPrvRoomRate8Bedded", precision=16)
 public BigDecimal getMedPrvRoomRate8bedded() {
     return this.medPrvRoomRate8bedded;
 }
 
 public void setMedPrvRoomRate8bedded(BigDecimal medPrvRoomRate8bedded) {
     this.medPrvRoomRate8bedded = medPrvRoomRate8bedded;
 }

 
 @Column(name="medPrvRoomRate16Bedded", precision=16)
 public BigDecimal getMedPrvRoomRate16bedded() {
     return this.medPrvRoomRate16bedded;
 }
 
 public void setMedPrvRoomRate16bedded(BigDecimal medPrvRoomRate16bedded) {
     this.medPrvRoomRate16bedded = medPrvRoomRate16bedded;
 }

 
 @Column(name="medPrvIsWatchlist", nullable=false)
 public boolean isMedPrvIsWatchlist() {
     return this.medPrvIsWatchlist;
 }
 
 public void setMedPrvIsWatchlist(boolean medPrvIsWatchlist) {
     this.medPrvIsWatchlist = medPrvIsWatchlist;
 }

 
 @Column(name="medPrvGePayeeCode", length=50)
 public String getMedPrvGePayeeCode() {
     return this.medPrvGePayeeCode;
 }
 
 public void setMedPrvGePayeeCode(String medPrvGePayeeCode) {
     this.medPrvGePayeeCode = medPrvGePayeeCode;
 }

 
 @Column(name="medPrvOpenHours", length=250)
 public String getMedPrvOpenHours() {
     return this.medPrvOpenHours;
 }
 
 public void setMedPrvOpenHours(String medPrvOpenHours) {
     this.medPrvOpenHours = medPrvOpenHours;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<InvestigationMedicalProvider> getInvestigationMedicalProviders() {
     return this.investigationMedicalProviders;
 }
 
 public void setInvestigationMedicalProviders(Set<InvestigationMedicalProvider> investigationMedicalProviders) {
     this.investigationMedicalProviders = investigationMedicalProviders;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<MedicalPanelProviders> getMedicalPanelProviderses() {
     return this.medicalPanelProviderses;
 }
 
 public void setMedicalPanelProviderses(Set<MedicalPanelProviders> medicalPanelProviderses) {
     this.medicalPanelProviderses = medicalPanelProviderses;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<MedicalProviderContactPerson> getMedicalProviderContactPersons() {
     return this.medicalProviderContactPersons;
 }
 
 public void setMedicalProviderContactPersons(Set<MedicalProviderContactPerson> medicalProviderContactPersons) {
     this.medicalProviderContactPersons = medicalProviderContactPersons;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<User> getUsers() {
     return this.users;
 }
 
 public void setUsers(Set<User> users) {
     this.users = users;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<OutptPaymentAdvice> getOutptPaymentAdvices() {
     return this.outptPaymentAdvices;
 }
 
 public void setOutptPaymentAdvices(Set<OutptPaymentAdvice> outptPaymentAdvices) {
     this.outptPaymentAdvices = outptPaymentAdvices;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<IftttCondition> getIftttConditions() {
     return this.iftttConditions;
 }
 
 public void setIftttConditions(Set<IftttCondition> iftttConditions) {
     this.iftttConditions = iftttConditions;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<MedicalProviderCoPay> getMedicalProviderCoPays() {
     return this.medicalProviderCoPays;
 }
 
 public void setMedicalProviderCoPays(Set<MedicalProviderCoPay> medicalProviderCoPays) {
     this.medicalProviderCoPays = medicalProviderCoPays;
 }
 
@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalProvider")
 public Set<OutptClaim> getOutptClaims() {
     return this.outptClaims;
 }
 
 public void setOutptClaims(Set<OutptClaim> outptClaims) {
     this.outptClaims = outptClaims;
 }

}
