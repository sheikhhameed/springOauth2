package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.inpt.InptCaseDoctor;
import com.test.demo.model.outpt.OutptClaimDoctor;

/**
 * This is Doctor class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="doctor"
 ,catalog="marcmy"
)
public class Doctor  implements java.io.Serializable {


  private Integer drId;
  private Specialization specialization;
  private Date drEnabledDate;
  private Date drDeletionDate;
  private Integer drCreatedBy;
  private Date drCreatedDate;
  private Date drLastEditedDate;
  private Integer drLastEditedBy;
  private String drOtherSpecialization;
  private String drSubSpecialization;
  private String drName;
  private String drCnName;
  private String drMobile;
  private String drPruCode;
  private String drRemark;
  private String drLicenseDoctorNo;
  private boolean drBlacklisted;
  private Set<IftttCondition> iftttConditions = new HashSet<IftttCondition>(0);
  private Set<InptCaseDoctor> inptCaseDoctors = new HashSet<InptCaseDoctor>(0);
  private Set<OutptClaimDoctor> outptClaimDoctors = new HashSet<OutptClaimDoctor>(0);
  private Set<BlacklistDoctor> blacklistDoctors = new HashSet<BlacklistDoctor>(0);

 public Doctor() {
 }

	
 public Doctor(boolean drBlacklisted) {
     this.drBlacklisted = drBlacklisted;
 }
 public Doctor(Specialization specialization, Date drEnabledDate, Date drDeletionDate, Integer drCreatedBy, Date drCreatedDate, Date drLastEditedDate, Integer drLastEditedBy, String drOtherSpecialization, String drSubSpecialization, String drName, String drCnName, String drMobile, String drPruCode, String drRemark, String drLicenseDoctorNo, boolean drBlacklisted, Set<IftttCondition> iftttConditions, Set<InptCaseDoctor> inptCaseDoctors, Set<OutptClaimDoctor> outptClaimDoctors, Set<BlacklistDoctor> blacklistDoctors) {
    this.specialization = specialization;
    this.drEnabledDate = drEnabledDate;
    this.drDeletionDate = drDeletionDate;
    this.drCreatedBy = drCreatedBy;
    this.drCreatedDate = drCreatedDate;
    this.drLastEditedDate = drLastEditedDate;
    this.drLastEditedBy = drLastEditedBy;
    this.drOtherSpecialization = drOtherSpecialization;
    this.drSubSpecialization = drSubSpecialization;
    this.drName = drName;
    this.drCnName = drCnName;
    this.drMobile = drMobile;
    this.drPruCode = drPruCode;
    this.drRemark = drRemark;
    this.drLicenseDoctorNo = drLicenseDoctorNo;
    this.drBlacklisted = drBlacklisted;
    this.iftttConditions = iftttConditions;
    this.inptCaseDoctors = inptCaseDoctors;
    this.outptClaimDoctors = outptClaimDoctors;
    this.blacklistDoctors = blacklistDoctors;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="drId", unique=true, nullable=false)
 public Integer getDrId() {
     return this.drId;
 }
 
 public void setDrId(Integer drId) {
     this.drId = drId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="drSpecializationId")
 public Specialization getSpecialization() {
     return this.specialization;
 }
 
 public void setSpecialization(Specialization specialization) {
     this.specialization = specialization;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drEnabledDate", length=19)
 public Date getDrEnabledDate() {
     return this.drEnabledDate;
 }
 
 public void setDrEnabledDate(Date drEnabledDate) {
     this.drEnabledDate = drEnabledDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drDeletionDate", length=19)
 public Date getDrDeletionDate() {
     return this.drDeletionDate;
 }
 
 public void setDrDeletionDate(Date drDeletionDate) {
     this.drDeletionDate = drDeletionDate;
 }

 
 @Column(name="drCreatedBy")
 public Integer getDrCreatedBy() {
     return this.drCreatedBy;
 }
 
 public void setDrCreatedBy(Integer drCreatedBy) {
     this.drCreatedBy = drCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drCreatedDate", length=19)
 public Date getDrCreatedDate() {
     return this.drCreatedDate;
 }
 
 public void setDrCreatedDate(Date drCreatedDate) {
     this.drCreatedDate = drCreatedDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drLastEditedDate", length=19)
 public Date getDrLastEditedDate() {
     return this.drLastEditedDate;
 }
 
 public void setDrLastEditedDate(Date drLastEditedDate) {
     this.drLastEditedDate = drLastEditedDate;
 }

 
 @Column(name="drLastEditedBy")
 public Integer getDrLastEditedBy() {
     return this.drLastEditedBy;
 }
 
 public void setDrLastEditedBy(Integer drLastEditedBy) {
     this.drLastEditedBy = drLastEditedBy;
 }

 
 @Column(name="drOtherSpecialization", length=150)
 public String getDrOtherSpecialization() {
     return this.drOtherSpecialization;
 }
 
 public void setDrOtherSpecialization(String drOtherSpecialization) {
     this.drOtherSpecialization = drOtherSpecialization;
 }

 
 @Column(name="drSubSpecialization", length=150)
 public String getDrSubSpecialization() {
     return this.drSubSpecialization;
 }
 
 public void setDrSubSpecialization(String drSubSpecialization) {
     this.drSubSpecialization = drSubSpecialization;
 }

 
 @Column(name="drName", length=150)
 public String getDrName() {
     return this.drName;
 }
 
 public void setDrName(String drName) {
     this.drName = drName;
 }

 
 @Column(name="drCnName", length=100)
 public String getDrCnName() {
     return this.drCnName;
 }
 
 public void setDrCnName(String drCnName) {
     this.drCnName = drCnName;
 }

 
 @Column(name="drMobile", length=12)
 public String getDrMobile() {
     return this.drMobile;
 }
 
 public void setDrMobile(String drMobile) {
     this.drMobile = drMobile;
 }

 
 @Column(name="drPruCode", length=10)
 public String getDrPruCode() {
     return this.drPruCode;
 }
 
 public void setDrPruCode(String drPruCode) {
     this.drPruCode = drPruCode;
 }

 
 @Column(name="drRemark", length=65535)
 public String getDrRemark() {
     return this.drRemark;
 }
 
 public void setDrRemark(String drRemark) {
     this.drRemark = drRemark;
 }

 
 @Column(name="drLicenseDoctorNo", length=10)
 public String getDrLicenseDoctorNo() {
     return this.drLicenseDoctorNo;
 }
 
 public void setDrLicenseDoctorNo(String drLicenseDoctorNo) {
     this.drLicenseDoctorNo = drLicenseDoctorNo;
 }

 
 @Column(name="drBlacklisted", nullable=false)
 public boolean isDrBlacklisted() {
     return this.drBlacklisted;
 }
 
 public void setDrBlacklisted(boolean drBlacklisted) {
     this.drBlacklisted = drBlacklisted;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="doctor")
 public Set<IftttCondition> getIftttConditions() {
     return this.iftttConditions;
 }
 
 public void setIftttConditions(Set<IftttCondition> iftttConditions) {
     this.iftttConditions = iftttConditions;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="doctor")
 public Set<InptCaseDoctor> getInptCaseDoctors() {
     return this.inptCaseDoctors;
 }
 
 public void setInptCaseDoctors(Set<InptCaseDoctor> inptCaseDoctors) {
     this.inptCaseDoctors = inptCaseDoctors;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="doctor")
 public Set<OutptClaimDoctor> getOutptClaimDoctors() {
     return this.outptClaimDoctors;
 }
 
 public void setOutptClaimDoctors(Set<OutptClaimDoctor> outptClaimDoctors) {
     this.outptClaimDoctors = outptClaimDoctors;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="doctor")
 public Set<BlacklistDoctor> getBlacklistDoctors() {
     return this.blacklistDoctors;
 }
 
 public void setBlacklistDoctors(Set<BlacklistDoctor> blacklistDoctors) {
     this.blacklistDoctors = blacklistDoctors;
 }




}


