package com.test.demo.cas.constant;

public class GlobalConstant {

	public static final Object JWT_AUTH = "JWT_AUTH";
	public static final Object BASIC_AUTH = "BASIC_AUTH";

}
