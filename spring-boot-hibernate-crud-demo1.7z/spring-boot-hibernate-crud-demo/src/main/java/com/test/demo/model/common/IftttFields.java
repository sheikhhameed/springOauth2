package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 * This is IfftttFields class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="ifttt_fields"
 ,catalog="marcmy"
 , uniqueConstraints = @UniqueConstraint(columnNames="iftttFieldShortName") 
)
public class IftttFields  implements java.io.Serializable {


  private Integer iftttFieldId;
  private Date iftttFieldCreatedDate;
  private Integer iftttFieldCreatedBy;
  private Date iftttFieldLastEditedDate;
  private Integer iftttFieldLastEditedBy;
  private String iftttFieldName;
  private String iftttFieldShortName;
  private String iftttFieldCondition;
  private String iftttFieldValue;
  private boolean iftttFieldIsDefault;
  private Boolean iftttFieldEnabled;
  private Set<IftttCondition> iftttConditions = new HashSet<IftttCondition>(0);

 public IftttFields() {
 }

	
 public IftttFields(String iftttFieldShortName, boolean iftttFieldIsDefault) {
     this.iftttFieldShortName = iftttFieldShortName;
     this.iftttFieldIsDefault = iftttFieldIsDefault;
 }
 public IftttFields(Date iftttFieldCreatedDate, Integer iftttFieldCreatedBy, Date iftttFieldLastEditedDate, Integer iftttFieldLastEditedBy, String iftttFieldName, String iftttFieldShortName, String iftttFieldCondition, String iftttFieldValue, boolean iftttFieldIsDefault, Boolean iftttFieldEnabled, Set<IftttCondition> iftttConditions) {
    this.iftttFieldCreatedDate = iftttFieldCreatedDate;
    this.iftttFieldCreatedBy = iftttFieldCreatedBy;
    this.iftttFieldLastEditedDate = iftttFieldLastEditedDate;
    this.iftttFieldLastEditedBy = iftttFieldLastEditedBy;
    this.iftttFieldName = iftttFieldName;
    this.iftttFieldShortName = iftttFieldShortName;
    this.iftttFieldCondition = iftttFieldCondition;
    this.iftttFieldValue = iftttFieldValue;
    this.iftttFieldIsDefault = iftttFieldIsDefault;
    this.iftttFieldEnabled = iftttFieldEnabled;
    this.iftttConditions = iftttConditions;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="iftttFieldId", unique=true, nullable=false)
 public Integer getIftttFieldId() {
     return this.iftttFieldId;
 }
 
 public void setIftttFieldId(Integer iftttFieldId) {
     this.iftttFieldId = iftttFieldId;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="iftttFieldCreatedDate", length=19)
 public Date getIftttFieldCreatedDate() {
     return this.iftttFieldCreatedDate;
 }
 
 public void setIftttFieldCreatedDate(Date iftttFieldCreatedDate) {
     this.iftttFieldCreatedDate = iftttFieldCreatedDate;
 }

 
 @Column(name="iftttFieldCreatedBy")
 public Integer getIftttFieldCreatedBy() {
     return this.iftttFieldCreatedBy;
 }
 
 public void setIftttFieldCreatedBy(Integer iftttFieldCreatedBy) {
     this.iftttFieldCreatedBy = iftttFieldCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="iftttFieldLastEditedDate", length=19)
 public Date getIftttFieldLastEditedDate() {
     return this.iftttFieldLastEditedDate;
 }
 
 public void setIftttFieldLastEditedDate(Date iftttFieldLastEditedDate) {
     this.iftttFieldLastEditedDate = iftttFieldLastEditedDate;
 }

 
 @Column(name="iftttFieldLastEditedBy")
 public Integer getIftttFieldLastEditedBy() {
     return this.iftttFieldLastEditedBy;
 }
 
 public void setIftttFieldLastEditedBy(Integer iftttFieldLastEditedBy) {
     this.iftttFieldLastEditedBy = iftttFieldLastEditedBy;
 }

 
 @Column(name="iftttFieldName", length=50)
 public String getIftttFieldName() {
     return this.iftttFieldName;
 }
 
 public void setIftttFieldName(String iftttFieldName) {
     this.iftttFieldName = iftttFieldName;
 }

 
 @Column(name="iftttFieldShortName", unique=true, nullable=false, length=15)
 public String getIftttFieldShortName() {
     return this.iftttFieldShortName;
 }
 
 public void setIftttFieldShortName(String iftttFieldShortName) {
     this.iftttFieldShortName = iftttFieldShortName;
 }

 
 @Column(name="iftttFieldCondition", length=250)
 public String getIftttFieldCondition() {
     return this.iftttFieldCondition;
 }
 
 public void setIftttFieldCondition(String iftttFieldCondition) {
     this.iftttFieldCondition = iftttFieldCondition;
 }

 
 @Column(name="iftttFieldValue", length=250)
 public String getIftttFieldValue() {
     return this.iftttFieldValue;
 }
 
 public void setIftttFieldValue(String iftttFieldValue) {
     this.iftttFieldValue = iftttFieldValue;
 }

 
 @Column(name="iftttFieldIsDefault", nullable=false)
 public boolean isIftttFieldIsDefault() {
     return this.iftttFieldIsDefault;
 }
 
 public void setIftttFieldIsDefault(boolean iftttFieldIsDefault) {
     this.iftttFieldIsDefault = iftttFieldIsDefault;
 }

 
 @Column(name="iftttFieldEnabled")
 public Boolean getIftttFieldEnabled() {
     return this.iftttFieldEnabled;
 }
 
 public void setIftttFieldEnabled(Boolean iftttFieldEnabled) {
     this.iftttFieldEnabled = iftttFieldEnabled;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="iftttFields")
 public Set<IftttCondition> getIftttConditions() {
     return this.iftttConditions;
 }
 
 public void setIftttConditions(Set<IftttCondition> iftttConditions) {
     this.iftttConditions = iftttConditions;
 }




}


