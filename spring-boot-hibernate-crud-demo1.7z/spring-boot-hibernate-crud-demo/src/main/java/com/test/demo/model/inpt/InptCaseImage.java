package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCaseImage class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_image"
 ,catalog="marcmy"
)
public class InptCaseImage  implements java.io.Serializable {


  private Integer id;
  private InptCase inptCase;
  private InptCaseCsu inptCaseCsu;
  private Integer createdBy;
  private Date createdDate;
  private String type;
  private String filename;
  private String originalFilename;
  private boolean showAtEclaim;
  private boolean showAtEmember;

 public InptCaseImage() {
 }

	
 public InptCaseImage(boolean showAtEclaim, boolean showAtEmember) {
     this.showAtEclaim = showAtEclaim;
     this.showAtEmember = showAtEmember;
 }
 public InptCaseImage(InptCase inptCase, InptCaseCsu inptCaseCsu, Integer createdBy, Date createdDate, String type, String filename, String originalFilename, boolean showAtEclaim, boolean showAtEmember) {
    this.inptCase = inptCase;
    this.inptCaseCsu = inptCaseCsu;
    this.createdBy = createdBy;
    this.createdDate = createdDate;
    this.type = type;
    this.filename = filename;
    this.originalFilename = originalFilename;
    this.showAtEclaim = showAtEclaim;
    this.showAtEmember = showAtEmember;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="id", unique=true, nullable=false)
 public Integer getId() {
     return this.id;
 }
 
 public void setId(Integer id) {
     this.id = id;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseId")
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseCsuId")
 public InptCaseCsu getInptCaseCsu() {
     return this.inptCaseCsu;
 }
 
 public void setInptCaseCsu(InptCaseCsu inptCaseCsu) {
     this.inptCaseCsu = inptCaseCsu;
 }

 
 @Column(name="createdBy")
 public Integer getCreatedBy() {
     return this.createdBy;
 }
 
 public void setCreatedBy(Integer createdBy) {
     this.createdBy = createdBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="createdDate", length=19)
 public Date getCreatedDate() {
     return this.createdDate;
 }
 
 public void setCreatedDate(Date createdDate) {
     this.createdDate = createdDate;
 }

 
 @Column(name="type", length=3)
 public String getType() {
     return this.type;
 }
 
 public void setType(String type) {
     this.type = type;
 }

 
 @Column(name="filename", length=100)
 public String getFilename() {
     return this.filename;
 }
 
 public void setFilename(String filename) {
     this.filename = filename;
 }

 
 @Column(name="originalFilename", length=100)
 public String getOriginalFilename() {
     return this.originalFilename;
 }
 
 public void setOriginalFilename(String originalFilename) {
     this.originalFilename = originalFilename;
 }

 
 @Column(name="showAtEclaim", nullable=false)
 public boolean isShowAtEclaim() {
     return this.showAtEclaim;
 }
 
 public void setShowAtEclaim(boolean showAtEclaim) {
     this.showAtEclaim = showAtEclaim;
 }

 
 @Column(name="showAtEmember", nullable=false)
 public boolean isShowAtEmember() {
     return this.showAtEmember;
 }
 
 public void setShowAtEmember(boolean showAtEmember) {
     this.showAtEmember = showAtEmember;
 }




}


