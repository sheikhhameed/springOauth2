package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is service class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="service"
 ,catalog="marcmy"
)
public class Service  implements java.io.Serializable {


  private Integer serviceId;
  private Boolean serviceEnabled;
  private Integer serviceCreatedBy;
  private Date serviceCreatedDate;
  private Integer serviceLastEdittedBy;
  private Date serviceLastEdittedDate;
  private String serviceName;
  private Set<ProgramService> programServices = new HashSet<ProgramService>(0);

 public Service() {
 }

 public Service(Boolean serviceEnabled, Integer serviceCreatedBy, Date serviceCreatedDate, Integer serviceLastEdittedBy, Date serviceLastEdittedDate, String serviceName, Set<ProgramService> programServices) {
    this.serviceEnabled = serviceEnabled;
    this.serviceCreatedBy = serviceCreatedBy;
    this.serviceCreatedDate = serviceCreatedDate;
    this.serviceLastEdittedBy = serviceLastEdittedBy;
    this.serviceLastEdittedDate = serviceLastEdittedDate;
    this.serviceName = serviceName;
    this.programServices = programServices;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="serviceId", unique=true, nullable=false)
 public Integer getServiceId() {
     return this.serviceId;
 }
 
 public void setServiceId(Integer serviceId) {
     this.serviceId = serviceId;
 }

 
 @Column(name="serviceEnabled")
 public Boolean getServiceEnabled() {
     return this.serviceEnabled;
 }
 
 public void setServiceEnabled(Boolean serviceEnabled) {
     this.serviceEnabled = serviceEnabled;
 }

 
 @Column(name="serviceCreatedBy")
 public Integer getServiceCreatedBy() {
     return this.serviceCreatedBy;
 }
 
 public void setServiceCreatedBy(Integer serviceCreatedBy) {
     this.serviceCreatedBy = serviceCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="serviceCreatedDate", length=19)
 public Date getServiceCreatedDate() {
     return this.serviceCreatedDate;
 }
 
 public void setServiceCreatedDate(Date serviceCreatedDate) {
     this.serviceCreatedDate = serviceCreatedDate;
 }

 
 @Column(name="serviceLastEdittedBy")
 public Integer getServiceLastEdittedBy() {
     return this.serviceLastEdittedBy;
 }
 
 public void setServiceLastEdittedBy(Integer serviceLastEdittedBy) {
     this.serviceLastEdittedBy = serviceLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="serviceLastEdittedDate", length=19)
 public Date getServiceLastEdittedDate() {
     return this.serviceLastEdittedDate;
 }
 
 public void setServiceLastEdittedDate(Date serviceLastEdittedDate) {
     this.serviceLastEdittedDate = serviceLastEdittedDate;
 }

 
 @Column(name="serviceName", length=30)
 public String getServiceName() {
     return this.serviceName;
 }
 
 public void setServiceName(String serviceName) {
     this.serviceName = serviceName;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="service")
 public Set<ProgramService> getProgramServices() {
     return this.programServices;
 }
 
 public void setProgramServices(Set<ProgramService> programServices) {
     this.programServices = programServices;
 }




}


