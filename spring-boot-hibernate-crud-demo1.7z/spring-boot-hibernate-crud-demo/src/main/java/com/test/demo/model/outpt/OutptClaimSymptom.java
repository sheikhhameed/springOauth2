package com.test.demo.model.outpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Symptom;

/**
 * This is OutptClaimSymptom class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_symptom"
 ,catalog="marcmy"
)
public class OutptClaimSymptom  implements java.io.Serializable {


  private Integer outptClaimSxId;
  private OutptClaim outptClaim;
  private Symptom symptom;
  private Integer outptClaimSxCreatedBy;
  private Date outptClaimSxCreatedDate;
  private String outptClaimSxRemarks;

 public OutptClaimSymptom() {
 }

	
 public OutptClaimSymptom(OutptClaim outptClaim, Symptom symptom) {
     this.outptClaim = outptClaim;
     this.symptom = symptom;
 }
 public OutptClaimSymptom(OutptClaim outptClaim, Symptom symptom, Integer outptClaimSxCreatedBy, Date outptClaimSxCreatedDate, String outptClaimSxRemarks) {
    this.outptClaim = outptClaim;
    this.symptom = symptom;
    this.outptClaimSxCreatedBy = outptClaimSxCreatedBy;
    this.outptClaimSxCreatedDate = outptClaimSxCreatedDate;
    this.outptClaimSxRemarks = outptClaimSxRemarks;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptClaimSxId", unique=true, nullable=false)
 public Integer getOutptClaimSxId() {
     return this.outptClaimSxId;
 }
 
 public void setOutptClaimSxId(Integer outptClaimSxId) {
     this.outptClaimSxId = outptClaimSxId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptClaimSxOutptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptClaimSxSymptomId", nullable=false)
 public Symptom getSymptom() {
     return this.symptom;
 }
 
 public void setSymptom(Symptom symptom) {
     this.symptom = symptom;
 }

 
 @Column(name="outptClaimSxCreatedBy")
 public Integer getOutptClaimSxCreatedBy() {
     return this.outptClaimSxCreatedBy;
 }
 
 public void setOutptClaimSxCreatedBy(Integer outptClaimSxCreatedBy) {
     this.outptClaimSxCreatedBy = outptClaimSxCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptClaimSxCreatedDate", length=19)
 public Date getOutptClaimSxCreatedDate() {
     return this.outptClaimSxCreatedDate;
 }
 
 public void setOutptClaimSxCreatedDate(Date outptClaimSxCreatedDate) {
     this.outptClaimSxCreatedDate = outptClaimSxCreatedDate;
 }

 
 @Column(name="outptClaimSxRemarks", length=150)
 public String getOutptClaimSxRemarks() {
     return this.outptClaimSxRemarks;
 }
 
 public void setOutptClaimSxRemarks(String outptClaimSxRemarks) {
     this.outptClaimSxRemarks = outptClaimSxRemarks;
 }




}


