package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 * This is user class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="user"
 ,catalog="marcmy"
 , uniqueConstraints = {@UniqueConstraint(columnNames="userLogIn"), @UniqueConstraint(columnNames="userShortName")} 
)
public class User  implements java.io.Serializable {


  private Integer userId;
  private Country country;
  private MedicalProvider medicalProvider;
  private Member member;
  private UserDepartment userDepartment;
  private UserPrivilege userPrivilege;
  private boolean userEnabled;
  private int userCreatedBy;
  private Date userCreatedDate;
  private Integer userLastEdittedBy;
  private Date userLastEdittedDate;
  private String userAxaGuid;
  private int userAssessmentAmt;
  private int userOpdAssessmentAmt;
  private String userAgentCode;
  private String userLogIn;
  private Integer userPin;
  private String userPassword;
  private String userFullName;
  private String userShortName;
  private String userEmail;
  private String userTel;
  private String userAssessmentCurrency;
  private boolean userIsSystemAdmin;
  private String userType;
  private int userAccessLevel;
  private String userLocale;
  private String userTimezone;
  private boolean userAllowRemoteLogin;
  private boolean userShowStatusDashboard;
  private String userEclaimRegCode;
  private Date userLoginTime;
  private Date userLogoutTime;
  private Date userLastLoginAttemptTime;
  private Integer userLoginAttempt;
  private String userLostPwdToken;
  private Date userLostPwdExpirationDate;
  private String userLastRequestToken;
  private String userLastLoginIpAddress;
  private boolean userIsLoggedIn;
  private boolean userIsAvailable;
  private Date userLastAssignmentDate;
  private Date userApiExpiryDate;
  private Integer userOtp;
  private Date userOtpExpiryTime;
  private boolean userIsAssessor;
  private Set<UserClient> userClients = new HashSet<UserClient>(0);
  private Set<UserClientProgram> userClientPrograms = new HashSet<UserClientProgram>(0);
  private Set<UserPassword> userPasswords = new HashSet<UserPassword>(0);

 public User() {
 }

	
 public User(UserPrivilege userPrivilege, boolean userEnabled, int userCreatedBy, Date userCreatedDate, int userAssessmentAmt, int userOpdAssessmentAmt, String userLogIn, String userFullName, String userShortName, String userEmail, String userAssessmentCurrency, boolean userIsSystemAdmin, String userType, int userAccessLevel, String userLocale, String userTimezone, boolean userAllowRemoteLogin, boolean userShowStatusDashboard, boolean userIsLoggedIn, boolean userIsAvailable, boolean userIsAssessor) {
     this.userPrivilege = userPrivilege;
     this.userEnabled = userEnabled;
     this.userCreatedBy = userCreatedBy;
     this.userCreatedDate = userCreatedDate;
     this.userAssessmentAmt = userAssessmentAmt;
     this.userOpdAssessmentAmt = userOpdAssessmentAmt;
     this.userLogIn = userLogIn;
     this.userFullName = userFullName;
     this.userShortName = userShortName;
     this.userEmail = userEmail;
     this.userAssessmentCurrency = userAssessmentCurrency;
     this.userIsSystemAdmin = userIsSystemAdmin;
     this.userType = userType;
     this.userAccessLevel = userAccessLevel;
     this.userLocale = userLocale;
     this.userTimezone = userTimezone;
     this.userAllowRemoteLogin = userAllowRemoteLogin;
     this.userShowStatusDashboard = userShowStatusDashboard;
     this.userIsLoggedIn = userIsLoggedIn;
     this.userIsAvailable = userIsAvailable;
     this.userIsAssessor = userIsAssessor;
 }
 public User(Country country, MedicalProvider medicalProvider, Member member, UserDepartment userDepartment, UserPrivilege userPrivilege, boolean userEnabled, int userCreatedBy, Date userCreatedDate, Integer userLastEdittedBy, Date userLastEdittedDate, String userAxaGuid, int userAssessmentAmt, int userOpdAssessmentAmt, String userAgentCode, String userLogIn, Integer userPin, String userPassword, String userFullName, String userShortName, String userEmail, String userTel, String userAssessmentCurrency, boolean userIsSystemAdmin, String userType, int userAccessLevel, String userLocale, String userTimezone, boolean userAllowRemoteLogin, boolean userShowStatusDashboard, String userEclaimRegCode, Date userLoginTime, Date userLogoutTime, Date userLastLoginAttemptTime, Integer userLoginAttempt, String userLostPwdToken, Date userLostPwdExpirationDate, String userLastRequestToken, String userLastLoginIpAddress, boolean userIsLoggedIn, boolean userIsAvailable, Date userLastAssignmentDate, Date userApiExpiryDate, Integer userOtp, Date userOtpExpiryTime, boolean userIsAssessor, Set<UserClient> userClients, Set<UserClientProgram> userClientPrograms, Set<UserPassword> userPasswords) {
    this.country = country;
    this.medicalProvider = medicalProvider;
    this.member = member;
    this.userDepartment = userDepartment;
    this.userPrivilege = userPrivilege;
    this.userEnabled = userEnabled;
    this.userCreatedBy = userCreatedBy;
    this.userCreatedDate = userCreatedDate;
    this.userLastEdittedBy = userLastEdittedBy;
    this.userLastEdittedDate = userLastEdittedDate;
    this.userAxaGuid = userAxaGuid;
    this.userAssessmentAmt = userAssessmentAmt;
    this.userOpdAssessmentAmt = userOpdAssessmentAmt;
    this.userAgentCode = userAgentCode;
    this.userLogIn = userLogIn;
    this.userPin = userPin;
    this.userPassword = userPassword;
    this.userFullName = userFullName;
    this.userShortName = userShortName;
    this.userEmail = userEmail;
    this.userTel = userTel;
    this.userAssessmentCurrency = userAssessmentCurrency;
    this.userIsSystemAdmin = userIsSystemAdmin;
    this.userType = userType;
    this.userAccessLevel = userAccessLevel;
    this.userLocale = userLocale;
    this.userTimezone = userTimezone;
    this.userAllowRemoteLogin = userAllowRemoteLogin;
    this.userShowStatusDashboard = userShowStatusDashboard;
    this.userEclaimRegCode = userEclaimRegCode;
    this.userLoginTime = userLoginTime;
    this.userLogoutTime = userLogoutTime;
    this.userLastLoginAttemptTime = userLastLoginAttemptTime;
    this.userLoginAttempt = userLoginAttempt;
    this.userLostPwdToken = userLostPwdToken;
    this.userLostPwdExpirationDate = userLostPwdExpirationDate;
    this.userLastRequestToken = userLastRequestToken;
    this.userLastLoginIpAddress = userLastLoginIpAddress;
    this.userIsLoggedIn = userIsLoggedIn;
    this.userIsAvailable = userIsAvailable;
    this.userLastAssignmentDate = userLastAssignmentDate;
    this.userApiExpiryDate = userApiExpiryDate;
    this.userOtp = userOtp;
    this.userOtpExpiryTime = userOtpExpiryTime;
    this.userIsAssessor = userIsAssessor;
    this.userClients = userClients;
    this.userClientPrograms = userClientPrograms;
    this.userPasswords = userPasswords;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="userId", unique=true, nullable=false)
 public Integer getUserId() {
     return this.userId;
 }
 
 public void setUserId(Integer userId) {
     this.userId = userId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userCountryId")
 public Country getCountry() {
     return this.country;
 }
 
 public void setCountry(Country country) {
     this.country = country;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userMedPrvId")
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }
 
 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userMemberId")
 public Member getMember() {
     return this.member;
 }
 
 public void setMember(Member member) {
     this.member = member;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userDepartmentId")
 public UserDepartment getUserDepartment() {
     return this.userDepartment;
 }
 
 public void setUserDepartment(UserDepartment userDepartment) {
     this.userDepartment = userDepartment;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="userUserPrivilegeId", nullable=false)
 public UserPrivilege getUserPrivilege() {
     return this.userPrivilege;
 }
 
 public void setUserPrivilege(UserPrivilege userPrivilege) {
     this.userPrivilege = userPrivilege;
 }

 
 @Column(name="userEnabled", nullable=false)
 public boolean isUserEnabled() {
     return this.userEnabled;
 }
 
 public void setUserEnabled(boolean userEnabled) {
     this.userEnabled = userEnabled;
 }

 
 @Column(name="userCreatedBy", nullable=false)
 public int getUserCreatedBy() {
     return this.userCreatedBy;
 }
 
 public void setUserCreatedBy(int userCreatedBy) {
     this.userCreatedBy = userCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userCreatedDate", nullable=false, length=19)
 public Date getUserCreatedDate() {
     return this.userCreatedDate;
 }
 
 public void setUserCreatedDate(Date userCreatedDate) {
     this.userCreatedDate = userCreatedDate;
 }

 
 @Column(name="userLastEdittedBy")
 public Integer getUserLastEdittedBy() {
     return this.userLastEdittedBy;
 }
 
 public void setUserLastEdittedBy(Integer userLastEdittedBy) {
     this.userLastEdittedBy = userLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLastEdittedDate", length=19)
 public Date getUserLastEdittedDate() {
     return this.userLastEdittedDate;
 }
 
 public void setUserLastEdittedDate(Date userLastEdittedDate) {
     this.userLastEdittedDate = userLastEdittedDate;
 }

 
 @Column(name="userAxaGuid", length=100)
 public String getUserAxaGuid() {
     return this.userAxaGuid;
 }
 
 public void setUserAxaGuid(String userAxaGuid) {
     this.userAxaGuid = userAxaGuid;
 }

 
 @Column(name="userAssessmentAmt", nullable=false)
 public int getUserAssessmentAmt() {
     return this.userAssessmentAmt;
 }
 
 public void setUserAssessmentAmt(int userAssessmentAmt) {
     this.userAssessmentAmt = userAssessmentAmt;
 }

 
 @Column(name="userOpdAssessmentAmt", nullable=false)
 public int getUserOpdAssessmentAmt() {
     return this.userOpdAssessmentAmt;
 }
 
 public void setUserOpdAssessmentAmt(int userOpdAssessmentAmt) {
     this.userOpdAssessmentAmt = userOpdAssessmentAmt;
 }

 
 @Column(name="userAgentCode", length=20)
 public String getUserAgentCode() {
     return this.userAgentCode;
 }
 
 public void setUserAgentCode(String userAgentCode) {
     this.userAgentCode = userAgentCode;
 }

 
 @Column(name="userLogIn", unique=true, nullable=false, length=20)
 public String getUserLogIn() {
     return this.userLogIn;
 }
 
 public void setUserLogIn(String userLogIn) {
     this.userLogIn = userLogIn;
 }

 
 @Column(name="userPin")
 public Integer getUserPin() {
     return this.userPin;
 }
 
 public void setUserPin(Integer userPin) {
     this.userPin = userPin;
 }

 
 @Column(name="userPassword", length=50)
 public String getUserPassword() {
     return this.userPassword;
 }
 
 public void setUserPassword(String userPassword) {
     this.userPassword = userPassword;
 }

 
 @Column(name="userFullName", nullable=false, length=100)
 public String getUserFullName() {
     return this.userFullName;
 }
 
 public void setUserFullName(String userFullName) {
     this.userFullName = userFullName;
 }

 
 @Column(name="userShortName", unique=true, nullable=false, length=8)
 public String getUserShortName() {
     return this.userShortName;
 }
 
 public void setUserShortName(String userShortName) {
     this.userShortName = userShortName;
 }

 
 @Column(name="userEmail", nullable=false, length=250)
 public String getUserEmail() {
     return this.userEmail;
 }
 
 public void setUserEmail(String userEmail) {
     this.userEmail = userEmail;
 }

 
 @Column(name="userTel", length=12)
 public String getUserTel() {
     return this.userTel;
 }
 
 public void setUserTel(String userTel) {
     this.userTel = userTel;
 }

 
 @Column(name="userAssessmentCurrency", nullable=false, length=4)
 public String getUserAssessmentCurrency() {
     return this.userAssessmentCurrency;
 }
 
 public void setUserAssessmentCurrency(String userAssessmentCurrency) {
     this.userAssessmentCurrency = userAssessmentCurrency;
 }

 
 @Column(name="userIsSystemAdmin", nullable=false)
 public boolean isUserIsSystemAdmin() {
     return this.userIsSystemAdmin;
 }
 
 public void setUserIsSystemAdmin(boolean userIsSystemAdmin) {
     this.userIsSystemAdmin = userIsSystemAdmin;
 }

 
 @Column(name="userType", nullable=false, length=5)
 public String getUserType() {
     return this.userType;
 }
 
 public void setUserType(String userType) {
     this.userType = userType;
 }

 
 @Column(name="userAccessLevel", nullable=false)
 public int getUserAccessLevel() {
     return this.userAccessLevel;
 }
 
 public void setUserAccessLevel(int userAccessLevel) {
     this.userAccessLevel = userAccessLevel;
 }

 
 @Column(name="userLocale", nullable=false, length=6)
 public String getUserLocale() {
     return this.userLocale;
 }
 
 public void setUserLocale(String userLocale) {
     this.userLocale = userLocale;
 }

 
 @Column(name="userTimezone", nullable=false, length=50)
 public String getUserTimezone() {
     return this.userTimezone;
 }
 
 public void setUserTimezone(String userTimezone) {
     this.userTimezone = userTimezone;
 }

 
 @Column(name="userAllowRemoteLogin", nullable=false)
 public boolean isUserAllowRemoteLogin() {
     return this.userAllowRemoteLogin;
 }
 
 public void setUserAllowRemoteLogin(boolean userAllowRemoteLogin) {
     this.userAllowRemoteLogin = userAllowRemoteLogin;
 }

 
 @Column(name="userShowStatusDashboard", nullable=false)
 public boolean isUserShowStatusDashboard() {
     return this.userShowStatusDashboard;
 }
 
 public void setUserShowStatusDashboard(boolean userShowStatusDashboard) {
     this.userShowStatusDashboard = userShowStatusDashboard;
 }

 
 @Column(name="userEClaimRegCode", length=8)
 public String getUserEclaimRegCode() {
     return this.userEclaimRegCode;
 }
 
 public void setUserEclaimRegCode(String userEclaimRegCode) {
     this.userEclaimRegCode = userEclaimRegCode;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLoginTime", length=19)
 public Date getUserLoginTime() {
     return this.userLoginTime;
 }
 
 public void setUserLoginTime(Date userLoginTime) {
     this.userLoginTime = userLoginTime;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLogoutTime", length=19)
 public Date getUserLogoutTime() {
     return this.userLogoutTime;
 }
 
 public void setUserLogoutTime(Date userLogoutTime) {
     this.userLogoutTime = userLogoutTime;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLastLoginAttemptTime", length=19)
 public Date getUserLastLoginAttemptTime() {
     return this.userLastLoginAttemptTime;
 }
 
 public void setUserLastLoginAttemptTime(Date userLastLoginAttemptTime) {
     this.userLastLoginAttemptTime = userLastLoginAttemptTime;
 }

 
 @Column(name="userLoginAttempt")
 public Integer getUserLoginAttempt() {
     return this.userLoginAttempt;
 }
 
 public void setUserLoginAttempt(Integer userLoginAttempt) {
     this.userLoginAttempt = userLoginAttempt;
 }

 
 @Column(name="userLostPwdToken", length=100)
 public String getUserLostPwdToken() {
     return this.userLostPwdToken;
 }
 
 public void setUserLostPwdToken(String userLostPwdToken) {
     this.userLostPwdToken = userLostPwdToken;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLostPwdExpirationDate", length=19)
 public Date getUserLostPwdExpirationDate() {
     return this.userLostPwdExpirationDate;
 }
 
 public void setUserLostPwdExpirationDate(Date userLostPwdExpirationDate) {
     this.userLostPwdExpirationDate = userLostPwdExpirationDate;
 }

 
 @Column(name="userLastRequestToken", length=65535)
 public String getUserLastRequestToken() {
     return this.userLastRequestToken;
 }
 
 public void setUserLastRequestToken(String userLastRequestToken) {
     this.userLastRequestToken = userLastRequestToken;
 }

 
 @Column(name="userLastLoginIpAddress", length=45)
 public String getUserLastLoginIpAddress() {
     return this.userLastLoginIpAddress;
 }
 
 public void setUserLastLoginIpAddress(String userLastLoginIpAddress) {
     this.userLastLoginIpAddress = userLastLoginIpAddress;
 }

 
 @Column(name="userIsLoggedIn", nullable=false)
 public boolean isUserIsLoggedIn() {
     return this.userIsLoggedIn;
 }
 
 public void setUserIsLoggedIn(boolean userIsLoggedIn) {
     this.userIsLoggedIn = userIsLoggedIn;
 }

 
 @Column(name="userIsAvailable", nullable=false)
 public boolean isUserIsAvailable() {
     return this.userIsAvailable;
 }
 
 public void setUserIsAvailable(boolean userIsAvailable) {
     this.userIsAvailable = userIsAvailable;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userLastAssignmentDate", length=19)
 public Date getUserLastAssignmentDate() {
     return this.userLastAssignmentDate;
 }
 
 public void setUserLastAssignmentDate(Date userLastAssignmentDate) {
     this.userLastAssignmentDate = userLastAssignmentDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="userApiExpiryDate", length=10)
 public Date getUserApiExpiryDate() {
     return this.userApiExpiryDate;
 }
 
 public void setUserApiExpiryDate(Date userApiExpiryDate) {
     this.userApiExpiryDate = userApiExpiryDate;
 }

 
 @Column(name="userOtp")
 public Integer getUserOtp() {
     return this.userOtp;
 }
 
 public void setUserOtp(Integer userOtp) {
     this.userOtp = userOtp;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="userOtpExpiryTime", length=19)
 public Date getUserOtpExpiryTime() {
     return this.userOtpExpiryTime;
 }
 
 public void setUserOtpExpiryTime(Date userOtpExpiryTime) {
     this.userOtpExpiryTime = userOtpExpiryTime;
 }

 
 @Column(name="userIsAssessor", nullable=false)
 public boolean isUserIsAssessor() {
     return this.userIsAssessor;
 }
 
 public void setUserIsAssessor(boolean userIsAssessor) {
     this.userIsAssessor = userIsAssessor;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="user")
 public Set<UserClient> getUserClients() {
     return this.userClients;
 }
 
 public void setUserClients(Set<UserClient> userClients) {
     this.userClients = userClients;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="user")
 public Set<UserClientProgram> getUserClientPrograms() {
     return this.userClientPrograms;
 }
 
 public void setUserClientPrograms(Set<UserClientProgram> userClientPrograms) {
     this.userClientPrograms = userClientPrograms;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="user")
 public Set<UserPassword> getUserPasswords() {
     return this.userPasswords;
 }
 
 public void setUserPasswords(Set<UserPassword> userPasswords) {
     this.userPasswords = userPasswords;
 }




}


