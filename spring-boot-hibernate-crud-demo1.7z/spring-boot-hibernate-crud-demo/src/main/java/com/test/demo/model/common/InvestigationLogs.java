package com.test.demo.model.common;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * InvestigationLogs 
 * @author smannan
 *
 */
@Entity
@Table(name="investigation_logs"
 ,catalog="marcmy"
)
public class InvestigationLogs  implements java.io.Serializable {


  private Integer invLogsId;
  private Investigation investigation;
  private InvestigationMedicalProvider investigationMedicalProvider;
  private String invLogsMedium;
  private String invLogsSpokenTo;
  private String invLogsEmailTel;
  private String invLogsContent;
  private Integer invLogsCreatedBy;
  private Date invLogsCreatedDate;

 public InvestigationLogs() {
 }

	
 public InvestigationLogs(Investigation investigation) {
     this.investigation = investigation;
 }
 public InvestigationLogs(Investigation investigation, InvestigationMedicalProvider investigationMedicalProvider, String invLogsMedium, String invLogsSpokenTo, String invLogsEmailTel, String invLogsContent, Integer invLogsCreatedBy, Date invLogsCreatedDate) {
    this.investigation = investigation;
    this.investigationMedicalProvider = investigationMedicalProvider;
    this.invLogsMedium = invLogsMedium;
    this.invLogsSpokenTo = invLogsSpokenTo;
    this.invLogsEmailTel = invLogsEmailTel;
    this.invLogsContent = invLogsContent;
    this.invLogsCreatedBy = invLogsCreatedBy;
    this.invLogsCreatedDate = invLogsCreatedDate;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="invLogsId", unique=true, nullable=false)
 public Integer getInvLogsId() {
     return this.invLogsId;
 }
 
 public void setInvLogsId(Integer invLogsId) {
     this.invLogsId = invLogsId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="invLogsInvId", nullable=false)
 public Investigation getInvestigation() {
     return this.investigation;
 }
 
 public void setInvestigation(Investigation investigation) {
     this.investigation = investigation;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="invLogsInvestigationMedPrvId")
 public InvestigationMedicalProvider getInvestigationMedicalProvider() {
     return this.investigationMedicalProvider;
 }
 
 public void setInvestigationMedicalProvider(InvestigationMedicalProvider investigationMedicalProvider) {
     this.investigationMedicalProvider = investigationMedicalProvider;
 }

 
 @Column(name="invLogsMedium", length=2)
 public String getInvLogsMedium() {
     return this.invLogsMedium;
 }
 
 public void setInvLogsMedium(String invLogsMedium) {
     this.invLogsMedium = invLogsMedium;
 }

 
 @Column(name="invLogsSpokenTo", length=250)
 public String getInvLogsSpokenTo() {
     return this.invLogsSpokenTo;
 }
 
 public void setInvLogsSpokenTo(String invLogsSpokenTo) {
     this.invLogsSpokenTo = invLogsSpokenTo;
 }

 
 @Column(name="invLogsEmailTel", length=250)
 public String getInvLogsEmailTel() {
     return this.invLogsEmailTel;
 }
 
 public void setInvLogsEmailTel(String invLogsEmailTel) {
     this.invLogsEmailTel = invLogsEmailTel;
 }

 
 @Column(name="invLogsContent", length=65535)
 public String getInvLogsContent() {
     return this.invLogsContent;
 }
 
 public void setInvLogsContent(String invLogsContent) {
     this.invLogsContent = invLogsContent;
 }

 
 @Column(name="invLogsCreatedBy")
 public Integer getInvLogsCreatedBy() {
     return this.invLogsCreatedBy;
 }
 
 public void setInvLogsCreatedBy(Integer invLogsCreatedBy) {
     this.invLogsCreatedBy = invLogsCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="invLogsCreatedDate", length=19)
 public Date getInvLogsCreatedDate() {
     return this.invLogsCreatedDate;
 }
 
 public void setInvLogsCreatedDate(Date invLogsCreatedDate) {
     this.invLogsCreatedDate = invLogsCreatedDate;
 }




}


