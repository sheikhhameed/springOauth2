package com.test.demo.cas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.cas.service.InOutOpdCASService;
import com.test.demo.model.common.User;
import com.test.demo.model.outpt.OutptClaim;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class handle all output patient request and responses 
 * 
 * @author smannan
 *
 */
@RestController
@RequestMapping("/outpt")
@Api(value="Outpt Security Management System", description="Operations for out patients Security management System")
public class InOutOpdCASController {

	@Autowired
	InOutOpdCASService outptServices; 
	
	@ApiOperation(value="Get a list of claims by claimId", response=ResponseEntity.class)
	@ApiResponses(value= {
			@ApiResponse(code=200, message="Successfully retrieve Eclaims !"),
			@ApiResponse(code=401, message="You are authorize to view the resource"),
			@ApiResponse(code=403, message="Accessing to the resource you were trying to reach is forbitten"),
			@ApiResponse(code=404, message="The resource you are trying to reach not found")
	})
	@GetMapping("/claim/{claimId}")
	public ResponseEntity<OutptClaim> getOutptClaim(@ApiParam(value="claimId from which claims can be retrieve") 
			@PathVariable("claimId") int claimId) throws Exception {

		ResponseEntity<OutptClaim> responseEntity = new ResponseEntity<OutptClaim>(HttpStatus.NOT_MODIFIED);
		User user =null;// (User) requestContext.getProperty("user");
		String authType =null;//(String) requestContext.getProperty("authType");
		System.out.println("claimId : " + claimId);
		
		
//            //Extract data from header
//            User user = (User) requestContext.getProperty("user");
//            String authType = (String) requestContext.getProperty("authType");
//            //Init object
//            OutptCaseService outptCaseService = new OutptCaseService();
//
		if (0 >= claimId) {
			throw new Exception("claimId parameter missing");
		}
		responseEntity = outptServices.getClaim(user,authType,claimId);

        

		
		return responseEntity;
	}
	
}
