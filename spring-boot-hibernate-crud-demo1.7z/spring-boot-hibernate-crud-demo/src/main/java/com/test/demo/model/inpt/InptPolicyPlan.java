package com.test.demo.model.inpt;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptPolicyplan class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_policy_plan"
 ,catalog="marcmy"
)
public class InptPolicyPlan  implements java.io.Serializable {


  private Integer ippId;
  private InptPlan inptPlan;
  private InptPolicy inptPolicy;
  private Boolean ippEnabled;
  private Integer ippCreatedBy;
  private Date ippCreatedDate;
  private Integer ippLastEdittedBy;
  private Date ippLastEdittedDate;
  private Set<InptMemberPolicyplan> inptMemberPolicyplans = new HashSet<InptMemberPolicyplan>(0);

 public InptPolicyPlan() {
 }

	
 public InptPolicyPlan(InptPlan inptPlan, InptPolicy inptPolicy) {
     this.inptPlan = inptPlan;
     this.inptPolicy = inptPolicy;
 }
 public InptPolicyPlan(InptPlan inptPlan, InptPolicy inptPolicy, Boolean ippEnabled, Integer ippCreatedBy, Date ippCreatedDate, Integer ippLastEdittedBy, Date ippLastEdittedDate, Set<InptMemberPolicyplan> inptMemberPolicyplans) {
    this.inptPlan = inptPlan;
    this.inptPolicy = inptPolicy;
    this.ippEnabled = ippEnabled;
    this.ippCreatedBy = ippCreatedBy;
    this.ippCreatedDate = ippCreatedDate;
    this.ippLastEdittedBy = ippLastEdittedBy;
    this.ippLastEdittedDate = ippLastEdittedDate;
    this.inptMemberPolicyplans = inptMemberPolicyplans;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="ippId", unique=true, nullable=false)
 public Integer getIppId() {
     return this.ippId;
 }
 
 public void setIppId(Integer ippId) {
     this.ippId = ippId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ippInptPlanId", nullable=false)
 public InptPlan getInptPlan() {
     return this.inptPlan;
 }
 
 public void setInptPlan(InptPlan inptPlan) {
     this.inptPlan = inptPlan;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="ippInptPolicyId", nullable=false)
 public InptPolicy getInptPolicy() {
     return this.inptPolicy;
 }
 
 public void setInptPolicy(InptPolicy inptPolicy) {
     this.inptPolicy = inptPolicy;
 }

 
 @Column(name="ippEnabled")
 public Boolean getIppEnabled() {
     return this.ippEnabled;
 }
 
 public void setIppEnabled(Boolean ippEnabled) {
     this.ippEnabled = ippEnabled;
 }

 
 @Column(name="ippCreatedBy")
 public Integer getIppCreatedBy() {
     return this.ippCreatedBy;
 }
 
 public void setIppCreatedBy(Integer ippCreatedBy) {
     this.ippCreatedBy = ippCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ippCreatedDate", length=19)
 public Date getIppCreatedDate() {
     return this.ippCreatedDate;
 }
 
 public void setIppCreatedDate(Date ippCreatedDate) {
     this.ippCreatedDate = ippCreatedDate;
 }

 
 @Column(name="ippLastEdittedBy")
 public Integer getIppLastEdittedBy() {
     return this.ippLastEdittedBy;
 }
 
 public void setIppLastEdittedBy(Integer ippLastEdittedBy) {
     this.ippLastEdittedBy = ippLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="ippLastEdittedDate", length=19)
 public Date getIppLastEdittedDate() {
     return this.ippLastEdittedDate;
 }
 
 public void setIppLastEdittedDate(Date ippLastEdittedDate) {
     this.ippLastEdittedDate = ippLastEdittedDate;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="inptPolicyPlan")
 public Set<InptMemberPolicyplan> getInptMemberPolicyplans() {
     return this.inptMemberPolicyplans;
 }
 
 public void setInptMemberPolicyplans(Set<InptMemberPolicyplan> inptMemberPolicyplans) {
     this.inptMemberPolicyplans = inptMemberPolicyplans;
 }




}


