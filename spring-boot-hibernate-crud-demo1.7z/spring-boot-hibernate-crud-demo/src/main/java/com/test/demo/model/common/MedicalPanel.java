package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is medicalPanel class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="medical_panel"
 ,catalog="marcmy"
)
public class MedicalPanel  implements java.io.Serializable {


  private Integer medPanelId;
  private Integer medPanelCreatedBy;
  private Date medPanelCreatedDate;
  private Integer medPanelLastEdittedBy;
  private Date medPanelLastEdittedDate;
  private String medPanelName;
  private Character medPanelType;
  private Boolean medPanelEnabled;
  private Date medPanelEnabledDate;
  private Set<ProgramService> programServices = new HashSet<ProgramService>(0);
  private Set<MedicalPanelProviders> medicalPanelProviderses = new HashSet<MedicalPanelProviders>(0);

 public MedicalPanel() {
 }

 public MedicalPanel(Integer medPanelCreatedBy, Date medPanelCreatedDate, Integer medPanelLastEdittedBy, Date medPanelLastEdittedDate, String medPanelName, Character medPanelType, Boolean medPanelEnabled, Date medPanelEnabledDate, Set<ProgramService> programServices, Set<MedicalPanelProviders> medicalPanelProviderses) {
    this.medPanelCreatedBy = medPanelCreatedBy;
    this.medPanelCreatedDate = medPanelCreatedDate;
    this.medPanelLastEdittedBy = medPanelLastEdittedBy;
    this.medPanelLastEdittedDate = medPanelLastEdittedDate;
    this.medPanelName = medPanelName;
    this.medPanelType = medPanelType;
    this.medPanelEnabled = medPanelEnabled;
    this.medPanelEnabledDate = medPanelEnabledDate;
    this.programServices = programServices;
    this.medicalPanelProviderses = medicalPanelProviderses;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="medPanelId", unique=true, nullable=false)
 public Integer getMedPanelId() {
     return this.medPanelId;
 }
 
 public void setMedPanelId(Integer medPanelId) {
     this.medPanelId = medPanelId;
 }

 
 @Column(name="medPanelCreatedBy")
 public Integer getMedPanelCreatedBy() {
     return this.medPanelCreatedBy;
 }
 
 public void setMedPanelCreatedBy(Integer medPanelCreatedBy) {
     this.medPanelCreatedBy = medPanelCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPanelCreatedDate", length=19)
 public Date getMedPanelCreatedDate() {
     return this.medPanelCreatedDate;
 }
 
 public void setMedPanelCreatedDate(Date medPanelCreatedDate) {
     this.medPanelCreatedDate = medPanelCreatedDate;
 }

 
 @Column(name="medPanelLastEdittedBy")
 public Integer getMedPanelLastEdittedBy() {
     return this.medPanelLastEdittedBy;
 }
 
 public void setMedPanelLastEdittedBy(Integer medPanelLastEdittedBy) {
     this.medPanelLastEdittedBy = medPanelLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPanelLastEdittedDate", length=19)
 public Date getMedPanelLastEdittedDate() {
     return this.medPanelLastEdittedDate;
 }
 
 public void setMedPanelLastEdittedDate(Date medPanelLastEdittedDate) {
     this.medPanelLastEdittedDate = medPanelLastEdittedDate;
 }

 
 @Column(name="medPanelName", length=50)
 public String getMedPanelName() {
     return this.medPanelName;
 }
 
 public void setMedPanelName(String medPanelName) {
     this.medPanelName = medPanelName;
 }

 
 @Column(name="medPanelType", length=1)
 public Character getMedPanelType() {
     return this.medPanelType;
 }
 
 public void setMedPanelType(Character medPanelType) {
     this.medPanelType = medPanelType;
 }

 
 @Column(name="medPanelEnabled")
 public Boolean getMedPanelEnabled() {
     return this.medPanelEnabled;
 }
 
 public void setMedPanelEnabled(Boolean medPanelEnabled) {
     this.medPanelEnabled = medPanelEnabled;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="medPanelEnabledDate", length=19)
 public Date getMedPanelEnabledDate() {
     return this.medPanelEnabledDate;
 }
 
 public void setMedPanelEnabledDate(Date medPanelEnabledDate) {
     this.medPanelEnabledDate = medPanelEnabledDate;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalPanel")
 public Set<ProgramService> getProgramServices() {
     return this.programServices;
 }
 
 public void setProgramServices(Set<ProgramService> programServices) {
     this.programServices = programServices;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="medicalPanel")
 public Set<MedicalPanelProviders> getMedicalPanelProviderses() {
     return this.medicalPanelProviderses;
 }
 
 public void setMedicalPanelProviderses(Set<MedicalPanelProviders> medicalPanelProviderses) {
     this.medicalPanelProviderses = medicalPanelProviderses;
 }




}


