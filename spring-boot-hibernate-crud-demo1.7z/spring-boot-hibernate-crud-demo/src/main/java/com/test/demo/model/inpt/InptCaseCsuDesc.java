package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCaseCsuDesc class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_csu_desc"
 ,catalog="marcmy"
)
public class InptCaseCsuDesc  implements java.io.Serializable {


  private Integer inptCaseCsuDescId;
  private InptCaseCsu inptCaseCsu;
  private Boolean inptCaseCsuDescEnabled;
  private String inptCaseCsuDescCreatedByAbbyName;
  private Integer inptCaseCsuDescCreatedBy;
  private Date inptCaseCsuDescCreatedDate;
  private String inptCaseCsuDescLastEdittedByAbbyName;
  private Integer inptCaseCsuDescLastEdittedBy;
  private Date inptCaseCsuDescLastEdittedDate;
  private String inptCaseCsuDescBillNo;
  private BigDecimal inptCaseCsuDescActualAmt;
  private BigDecimal inptCaseCsuDescApprovedAmt;
  private String inptCaseCsuDescConsRmk;
  private BigDecimal inptCaseCsuDescConsAmt;
  private String inptCaseCsuDescHosSuppRmk;
  private BigDecimal inptCaseCsuDescHosSuppAmt;
  private String inptCaseCsuDescPharmacyRmk;
  private BigDecimal inptCaseCsuDescPharmacyAmt;
  private String inptCaseCsuDescDiagRmk;
  private BigDecimal inptCaseCsuDescDiagAmt;
  private String inptCaseCsuDescProcRmk;
  private BigDecimal inptCaseCsuDescProcAmt;
  private String inptCaseCsuDescMiscRmk;
  private BigDecimal inptCaseCsuDescMiscAmt;
  private String inptCaseCsuDescExcessRmk;
  private BigDecimal inptCaseCsuDescExcessAmt;
  private String inptCaseCsuDescVisitType;
  private Boolean inptCaseCsuDescIsSurgicalCase;

 public InptCaseCsuDesc() {
 }

	
 public InptCaseCsuDesc(InptCaseCsu inptCaseCsu) {
     this.inptCaseCsu = inptCaseCsu;
 }
 public InptCaseCsuDesc(InptCaseCsu inptCaseCsu, Boolean inptCaseCsuDescEnabled, String inptCaseCsuDescCreatedByAbbyName, Integer inptCaseCsuDescCreatedBy, Date inptCaseCsuDescCreatedDate, String inptCaseCsuDescLastEdittedByAbbyName, Integer inptCaseCsuDescLastEdittedBy, Date inptCaseCsuDescLastEdittedDate, String inptCaseCsuDescBillNo, BigDecimal inptCaseCsuDescActualAmt, BigDecimal inptCaseCsuDescApprovedAmt, String inptCaseCsuDescConsRmk, BigDecimal inptCaseCsuDescConsAmt, String inptCaseCsuDescHosSuppRmk, BigDecimal inptCaseCsuDescHosSuppAmt, String inptCaseCsuDescPharmacyRmk, BigDecimal inptCaseCsuDescPharmacyAmt, String inptCaseCsuDescDiagRmk, BigDecimal inptCaseCsuDescDiagAmt, String inptCaseCsuDescProcRmk, BigDecimal inptCaseCsuDescProcAmt, String inptCaseCsuDescMiscRmk, BigDecimal inptCaseCsuDescMiscAmt, String inptCaseCsuDescExcessRmk, BigDecimal inptCaseCsuDescExcessAmt, String inptCaseCsuDescVisitType, Boolean inptCaseCsuDescIsSurgicalCase) {
    this.inptCaseCsu = inptCaseCsu;
    this.inptCaseCsuDescEnabled = inptCaseCsuDescEnabled;
    this.inptCaseCsuDescCreatedByAbbyName = inptCaseCsuDescCreatedByAbbyName;
    this.inptCaseCsuDescCreatedBy = inptCaseCsuDescCreatedBy;
    this.inptCaseCsuDescCreatedDate = inptCaseCsuDescCreatedDate;
    this.inptCaseCsuDescLastEdittedByAbbyName = inptCaseCsuDescLastEdittedByAbbyName;
    this.inptCaseCsuDescLastEdittedBy = inptCaseCsuDescLastEdittedBy;
    this.inptCaseCsuDescLastEdittedDate = inptCaseCsuDescLastEdittedDate;
    this.inptCaseCsuDescBillNo = inptCaseCsuDescBillNo;
    this.inptCaseCsuDescActualAmt = inptCaseCsuDescActualAmt;
    this.inptCaseCsuDescApprovedAmt = inptCaseCsuDescApprovedAmt;
    this.inptCaseCsuDescConsRmk = inptCaseCsuDescConsRmk;
    this.inptCaseCsuDescConsAmt = inptCaseCsuDescConsAmt;
    this.inptCaseCsuDescHosSuppRmk = inptCaseCsuDescHosSuppRmk;
    this.inptCaseCsuDescHosSuppAmt = inptCaseCsuDescHosSuppAmt;
    this.inptCaseCsuDescPharmacyRmk = inptCaseCsuDescPharmacyRmk;
    this.inptCaseCsuDescPharmacyAmt = inptCaseCsuDescPharmacyAmt;
    this.inptCaseCsuDescDiagRmk = inptCaseCsuDescDiagRmk;
    this.inptCaseCsuDescDiagAmt = inptCaseCsuDescDiagAmt;
    this.inptCaseCsuDescProcRmk = inptCaseCsuDescProcRmk;
    this.inptCaseCsuDescProcAmt = inptCaseCsuDescProcAmt;
    this.inptCaseCsuDescMiscRmk = inptCaseCsuDescMiscRmk;
    this.inptCaseCsuDescMiscAmt = inptCaseCsuDescMiscAmt;
    this.inptCaseCsuDescExcessRmk = inptCaseCsuDescExcessRmk;
    this.inptCaseCsuDescExcessAmt = inptCaseCsuDescExcessAmt;
    this.inptCaseCsuDescVisitType = inptCaseCsuDescVisitType;
    this.inptCaseCsuDescIsSurgicalCase = inptCaseCsuDescIsSurgicalCase;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseCsuDescId", unique=true, nullable=false)
 public Integer getInptCaseCsuDescId() {
     return this.inptCaseCsuDescId;
 }
 
 public void setInptCaseCsuDescId(Integer inptCaseCsuDescId) {
     this.inptCaseCsuDescId = inptCaseCsuDescId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseCsuDescPpId", nullable=false)
 public InptCaseCsu getInptCaseCsu() {
     return this.inptCaseCsu;
 }
 
 public void setInptCaseCsu(InptCaseCsu inptCaseCsu) {
     this.inptCaseCsu = inptCaseCsu;
 }

 
 @Column(name="inptCaseCsuDescEnabled")
 public Boolean getInptCaseCsuDescEnabled() {
     return this.inptCaseCsuDescEnabled;
 }
 
 public void setInptCaseCsuDescEnabled(Boolean inptCaseCsuDescEnabled) {
     this.inptCaseCsuDescEnabled = inptCaseCsuDescEnabled;
 }

 
 @Column(name="inptCaseCsuDescCreatedByAbbyName", length=8)
 public String getInptCaseCsuDescCreatedByAbbyName() {
     return this.inptCaseCsuDescCreatedByAbbyName;
 }
 
 public void setInptCaseCsuDescCreatedByAbbyName(String inptCaseCsuDescCreatedByAbbyName) {
     this.inptCaseCsuDescCreatedByAbbyName = inptCaseCsuDescCreatedByAbbyName;
 }

 
 @Column(name="inptCaseCsuDescCreatedBy")
 public Integer getInptCaseCsuDescCreatedBy() {
     return this.inptCaseCsuDescCreatedBy;
 }
 
 public void setInptCaseCsuDescCreatedBy(Integer inptCaseCsuDescCreatedBy) {
     this.inptCaseCsuDescCreatedBy = inptCaseCsuDescCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseCsuDescCreatedDate", length=19)
 public Date getInptCaseCsuDescCreatedDate() {
     return this.inptCaseCsuDescCreatedDate;
 }
 
 public void setInptCaseCsuDescCreatedDate(Date inptCaseCsuDescCreatedDate) {
     this.inptCaseCsuDescCreatedDate = inptCaseCsuDescCreatedDate;
 }

 
 @Column(name="inptCaseCsuDescLastEdittedByAbbyName", length=8)
 public String getInptCaseCsuDescLastEdittedByAbbyName() {
     return this.inptCaseCsuDescLastEdittedByAbbyName;
 }
 
 public void setInptCaseCsuDescLastEdittedByAbbyName(String inptCaseCsuDescLastEdittedByAbbyName) {
     this.inptCaseCsuDescLastEdittedByAbbyName = inptCaseCsuDescLastEdittedByAbbyName;
 }

 
 @Column(name="inptCaseCsuDescLastEdittedBy")
 public Integer getInptCaseCsuDescLastEdittedBy() {
     return this.inptCaseCsuDescLastEdittedBy;
 }
 
 public void setInptCaseCsuDescLastEdittedBy(Integer inptCaseCsuDescLastEdittedBy) {
     this.inptCaseCsuDescLastEdittedBy = inptCaseCsuDescLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseCsuDescLastEdittedDate", length=19)
 public Date getInptCaseCsuDescLastEdittedDate() {
     return this.inptCaseCsuDescLastEdittedDate;
 }
 
 public void setInptCaseCsuDescLastEdittedDate(Date inptCaseCsuDescLastEdittedDate) {
     this.inptCaseCsuDescLastEdittedDate = inptCaseCsuDescLastEdittedDate;
 }

 
 @Column(name="inptCaseCsuDescBillNo", length=100)
 public String getInptCaseCsuDescBillNo() {
     return this.inptCaseCsuDescBillNo;
 }
 
 public void setInptCaseCsuDescBillNo(String inptCaseCsuDescBillNo) {
     this.inptCaseCsuDescBillNo = inptCaseCsuDescBillNo;
 }

 
 @Column(name="inptCaseCsuDescActualAmt", precision=9)
 public BigDecimal getInptCaseCsuDescActualAmt() {
     return this.inptCaseCsuDescActualAmt;
 }
 
 public void setInptCaseCsuDescActualAmt(BigDecimal inptCaseCsuDescActualAmt) {
     this.inptCaseCsuDescActualAmt = inptCaseCsuDescActualAmt;
 }

 
 @Column(name="inptCaseCsuDescApprovedAmt", precision=9)
 public BigDecimal getInptCaseCsuDescApprovedAmt() {
     return this.inptCaseCsuDescApprovedAmt;
 }
 
 public void setInptCaseCsuDescApprovedAmt(BigDecimal inptCaseCsuDescApprovedAmt) {
     this.inptCaseCsuDescApprovedAmt = inptCaseCsuDescApprovedAmt;
 }

 
 @Column(name="inptCaseCsuDescConsRmk", length=16777215)
 public String getInptCaseCsuDescConsRmk() {
     return this.inptCaseCsuDescConsRmk;
 }
 
 public void setInptCaseCsuDescConsRmk(String inptCaseCsuDescConsRmk) {
     this.inptCaseCsuDescConsRmk = inptCaseCsuDescConsRmk;
 }

 
 @Column(name="inptCaseCsuDescConsAmt", precision=9)
 public BigDecimal getInptCaseCsuDescConsAmt() {
     return this.inptCaseCsuDescConsAmt;
 }
 
 public void setInptCaseCsuDescConsAmt(BigDecimal inptCaseCsuDescConsAmt) {
     this.inptCaseCsuDescConsAmt = inptCaseCsuDescConsAmt;
 }

 
 @Column(name="inptCaseCsuDescHosSuppRmk", length=16777215)
 public String getInptCaseCsuDescHosSuppRmk() {
     return this.inptCaseCsuDescHosSuppRmk;
 }
 
 public void setInptCaseCsuDescHosSuppRmk(String inptCaseCsuDescHosSuppRmk) {
     this.inptCaseCsuDescHosSuppRmk = inptCaseCsuDescHosSuppRmk;
 }

 
 @Column(name="inptCaseCsuDescHosSuppAmt", precision=9)
 public BigDecimal getInptCaseCsuDescHosSuppAmt() {
     return this.inptCaseCsuDescHosSuppAmt;
 }
 
 public void setInptCaseCsuDescHosSuppAmt(BigDecimal inptCaseCsuDescHosSuppAmt) {
     this.inptCaseCsuDescHosSuppAmt = inptCaseCsuDescHosSuppAmt;
 }

 
 @Column(name="inptCaseCsuDescPharmacyRmk", length=16777215)
 public String getInptCaseCsuDescPharmacyRmk() {
     return this.inptCaseCsuDescPharmacyRmk;
 }
 
 public void setInptCaseCsuDescPharmacyRmk(String inptCaseCsuDescPharmacyRmk) {
     this.inptCaseCsuDescPharmacyRmk = inptCaseCsuDescPharmacyRmk;
 }

 
 @Column(name="inptCaseCsuDescPharmacyAmt", precision=9)
 public BigDecimal getInptCaseCsuDescPharmacyAmt() {
     return this.inptCaseCsuDescPharmacyAmt;
 }
 
 public void setInptCaseCsuDescPharmacyAmt(BigDecimal inptCaseCsuDescPharmacyAmt) {
     this.inptCaseCsuDescPharmacyAmt = inptCaseCsuDescPharmacyAmt;
 }

 
 @Column(name="inptCaseCsuDescDiagRmk", length=16777215)
 public String getInptCaseCsuDescDiagRmk() {
     return this.inptCaseCsuDescDiagRmk;
 }
 
 public void setInptCaseCsuDescDiagRmk(String inptCaseCsuDescDiagRmk) {
     this.inptCaseCsuDescDiagRmk = inptCaseCsuDescDiagRmk;
 }

 
 @Column(name="inptCaseCsuDescDiagAmt", precision=9)
 public BigDecimal getInptCaseCsuDescDiagAmt() {
     return this.inptCaseCsuDescDiagAmt;
 }
 
 public void setInptCaseCsuDescDiagAmt(BigDecimal inptCaseCsuDescDiagAmt) {
     this.inptCaseCsuDescDiagAmt = inptCaseCsuDescDiagAmt;
 }

 
 @Column(name="inptCaseCsuDescProcRmk", length=16777215)
 public String getInptCaseCsuDescProcRmk() {
     return this.inptCaseCsuDescProcRmk;
 }
 
 public void setInptCaseCsuDescProcRmk(String inptCaseCsuDescProcRmk) {
     this.inptCaseCsuDescProcRmk = inptCaseCsuDescProcRmk;
 }

 
 @Column(name="inptCaseCsuDescProcAmt", precision=9)
 public BigDecimal getInptCaseCsuDescProcAmt() {
     return this.inptCaseCsuDescProcAmt;
 }
 
 public void setInptCaseCsuDescProcAmt(BigDecimal inptCaseCsuDescProcAmt) {
     this.inptCaseCsuDescProcAmt = inptCaseCsuDescProcAmt;
 }

 
 @Column(name="inptCaseCsuDescMiscRmk", length=16777215)
 public String getInptCaseCsuDescMiscRmk() {
     return this.inptCaseCsuDescMiscRmk;
 }
 
 public void setInptCaseCsuDescMiscRmk(String inptCaseCsuDescMiscRmk) {
     this.inptCaseCsuDescMiscRmk = inptCaseCsuDescMiscRmk;
 }

 
 @Column(name="inptCaseCsuDescMiscAmt", precision=9)
 public BigDecimal getInptCaseCsuDescMiscAmt() {
     return this.inptCaseCsuDescMiscAmt;
 }
 
 public void setInptCaseCsuDescMiscAmt(BigDecimal inptCaseCsuDescMiscAmt) {
     this.inptCaseCsuDescMiscAmt = inptCaseCsuDescMiscAmt;
 }

 
 @Column(name="inptCaseCsuDescExcessRmk", length=16777215)
 public String getInptCaseCsuDescExcessRmk() {
     return this.inptCaseCsuDescExcessRmk;
 }
 
 public void setInptCaseCsuDescExcessRmk(String inptCaseCsuDescExcessRmk) {
     this.inptCaseCsuDescExcessRmk = inptCaseCsuDescExcessRmk;
 }

 
 @Column(name="inptCaseCsuDescExcessAmt", precision=9)
 public BigDecimal getInptCaseCsuDescExcessAmt() {
     return this.inptCaseCsuDescExcessAmt;
 }
 
 public void setInptCaseCsuDescExcessAmt(BigDecimal inptCaseCsuDescExcessAmt) {
     this.inptCaseCsuDescExcessAmt = inptCaseCsuDescExcessAmt;
 }

 
 @Column(name="inptCaseCsuDescVisitType", length=2)
 public String getInptCaseCsuDescVisitType() {
     return this.inptCaseCsuDescVisitType;
 }
 
 public void setInptCaseCsuDescVisitType(String inptCaseCsuDescVisitType) {
     this.inptCaseCsuDescVisitType = inptCaseCsuDescVisitType;
 }

 
 @Column(name="inptCaseCsuDescIsSurgicalCase")
 public Boolean getInptCaseCsuDescIsSurgicalCase() {
     return this.inptCaseCsuDescIsSurgicalCase;
 }
 
 public void setInptCaseCsuDescIsSurgicalCase(Boolean inptCaseCsuDescIsSurgicalCase) {
     this.inptCaseCsuDescIsSurgicalCase = inptCaseCsuDescIsSurgicalCase;
 }




}


