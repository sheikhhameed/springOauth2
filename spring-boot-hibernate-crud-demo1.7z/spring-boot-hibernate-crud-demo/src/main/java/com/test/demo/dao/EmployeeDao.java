package com.test.demo.dao;

import java.util.List;

import com.test.demo.model.common.EmployeeEntity;
import com.test.demo.model.outpt.OutptClaim;

public interface EmployeeDao {


	List<EmployeeEntity> getAllEmployees();

	EmployeeEntity createOrUpdateEmployee(EmployeeEntity employee);

	EmployeeEntity getEmployeeById(Long id);

	void deleteEmployeeById(Long id);

	OutptClaim getOutptClaim(int claimId);

}
