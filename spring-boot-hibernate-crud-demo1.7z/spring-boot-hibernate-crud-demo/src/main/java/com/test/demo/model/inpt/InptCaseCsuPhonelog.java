package com.test.demo.model.inpt;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is inptCaseCsuPhoneLog class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_csu_phonelog"
 ,catalog="marcmy"
)
public class InptCaseCsuPhonelog  implements java.io.Serializable {


  private Integer inptCaseCsuPhLogId;
  private InptCaseCsu inptCaseCsu;
  private Integer inptCaseCsuPhLogCreatedBy;
  private String inptCaseCsuPhLogCreatedByAbbvName;
  private Date inptCaseCsuPhLogCreatedDate;
  private Character inptCaseCsuPhLogType;
  private String inptCaseCsuPhLogSpokeTo;
  private String inptCaseCsuPhLogDept;
  private String inptCaseCsuPhLogMedium;
  private String inptCaseCsuPhLogContactInfo;
  private String inptCaseCsuPhLogDesc;

 public InptCaseCsuPhonelog() {
 }

	
 public InptCaseCsuPhonelog(InptCaseCsu inptCaseCsu) {
     this.inptCaseCsu = inptCaseCsu;
 }
 public InptCaseCsuPhonelog(InptCaseCsu inptCaseCsu, Integer inptCaseCsuPhLogCreatedBy, String inptCaseCsuPhLogCreatedByAbbvName, Date inptCaseCsuPhLogCreatedDate, Character inptCaseCsuPhLogType, String inptCaseCsuPhLogSpokeTo, String inptCaseCsuPhLogDept, String inptCaseCsuPhLogMedium, String inptCaseCsuPhLogContactInfo, String inptCaseCsuPhLogDesc) {
    this.inptCaseCsu = inptCaseCsu;
    this.inptCaseCsuPhLogCreatedBy = inptCaseCsuPhLogCreatedBy;
    this.inptCaseCsuPhLogCreatedByAbbvName = inptCaseCsuPhLogCreatedByAbbvName;
    this.inptCaseCsuPhLogCreatedDate = inptCaseCsuPhLogCreatedDate;
    this.inptCaseCsuPhLogType = inptCaseCsuPhLogType;
    this.inptCaseCsuPhLogSpokeTo = inptCaseCsuPhLogSpokeTo;
    this.inptCaseCsuPhLogDept = inptCaseCsuPhLogDept;
    this.inptCaseCsuPhLogMedium = inptCaseCsuPhLogMedium;
    this.inptCaseCsuPhLogContactInfo = inptCaseCsuPhLogContactInfo;
    this.inptCaseCsuPhLogDesc = inptCaseCsuPhLogDesc;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseCsuPhLogId", unique=true, nullable=false)
 public Integer getInptCaseCsuPhLogId() {
     return this.inptCaseCsuPhLogId;
 }
 
 public void setInptCaseCsuPhLogId(Integer inptCaseCsuPhLogId) {
     this.inptCaseCsuPhLogId = inptCaseCsuPhLogId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseCsuPhLogPpId", nullable=false)
 public InptCaseCsu getInptCaseCsu() {
     return this.inptCaseCsu;
 }
 
 public void setInptCaseCsu(InptCaseCsu inptCaseCsu) {
     this.inptCaseCsu = inptCaseCsu;
 }

 
 @Column(name="inptCaseCsuPhLogCreatedBy")
 public Integer getInptCaseCsuPhLogCreatedBy() {
     return this.inptCaseCsuPhLogCreatedBy;
 }
 
 public void setInptCaseCsuPhLogCreatedBy(Integer inptCaseCsuPhLogCreatedBy) {
     this.inptCaseCsuPhLogCreatedBy = inptCaseCsuPhLogCreatedBy;
 }

 
 @Column(name="inptCaseCsuPhLogCreatedByAbbvName", length=8)
 public String getInptCaseCsuPhLogCreatedByAbbvName() {
     return this.inptCaseCsuPhLogCreatedByAbbvName;
 }
 
 public void setInptCaseCsuPhLogCreatedByAbbvName(String inptCaseCsuPhLogCreatedByAbbvName) {
     this.inptCaseCsuPhLogCreatedByAbbvName = inptCaseCsuPhLogCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseCsuPhLogCreatedDate", length=19)
 public Date getInptCaseCsuPhLogCreatedDate() {
     return this.inptCaseCsuPhLogCreatedDate;
 }
 
 public void setInptCaseCsuPhLogCreatedDate(Date inptCaseCsuPhLogCreatedDate) {
     this.inptCaseCsuPhLogCreatedDate = inptCaseCsuPhLogCreatedDate;
 }

 
 @Column(name="inptCaseCsuPhLogType", length=1)
 public Character getInptCaseCsuPhLogType() {
     return this.inptCaseCsuPhLogType;
 }
 
 public void setInptCaseCsuPhLogType(Character inptCaseCsuPhLogType) {
     this.inptCaseCsuPhLogType = inptCaseCsuPhLogType;
 }

 
 @Column(name="inptCaseCsuPhLogSpokeTo", length=50)
 public String getInptCaseCsuPhLogSpokeTo() {
     return this.inptCaseCsuPhLogSpokeTo;
 }
 
 public void setInptCaseCsuPhLogSpokeTo(String inptCaseCsuPhLogSpokeTo) {
     this.inptCaseCsuPhLogSpokeTo = inptCaseCsuPhLogSpokeTo;
 }

 
 @Column(name="inptCaseCsuPhLogDept", length=50)
 public String getInptCaseCsuPhLogDept() {
     return this.inptCaseCsuPhLogDept;
 }
 
 public void setInptCaseCsuPhLogDept(String inptCaseCsuPhLogDept) {
     this.inptCaseCsuPhLogDept = inptCaseCsuPhLogDept;
 }

 
 @Column(name="inptCaseCsuPhLogMedium", length=2)
 public String getInptCaseCsuPhLogMedium() {
     return this.inptCaseCsuPhLogMedium;
 }
 
 public void setInptCaseCsuPhLogMedium(String inptCaseCsuPhLogMedium) {
     this.inptCaseCsuPhLogMedium = inptCaseCsuPhLogMedium;
 }

 
 @Column(name="inptCaseCsuPhLogContactInfo", length=16777215)
 public String getInptCaseCsuPhLogContactInfo() {
     return this.inptCaseCsuPhLogContactInfo;
 }
 
 public void setInptCaseCsuPhLogContactInfo(String inptCaseCsuPhLogContactInfo) {
     this.inptCaseCsuPhLogContactInfo = inptCaseCsuPhLogContactInfo;
 }

 
 @Column(name="inptCaseCsuPhLogDesc", length=16777215)
 public String getInptCaseCsuPhLogDesc() {
     return this.inptCaseCsuPhLogDesc;
 }
 
 public void setInptCaseCsuPhLogDesc(String inptCaseCsuPhLogDesc) {
     this.inptCaseCsuPhLogDesc = inptCaseCsuPhLogDesc;
 }




}


