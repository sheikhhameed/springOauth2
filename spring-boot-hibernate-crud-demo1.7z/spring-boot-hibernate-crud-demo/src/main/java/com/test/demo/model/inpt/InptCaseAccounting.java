package com.test.demo.model.inpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.test.demo.model.common.Bank;

/**
 * This is InptCaseAccounting class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="inpt_case_accounting"
 ,catalog="marcmy"
)
public class InptCaseAccounting  implements java.io.Serializable {


  private Integer inptCaseAccId;
  private Bank bank;
  private InptCase inptCase;
  private Integer inptCaseAccCreatedBy;
  private Date inptCaseAccCreatedDate;
  private Integer inptCaseAccEdittedBy;
  private Date inptCaseAccEdittedDate;
  private String inptCaseAccType;
  private String inptCaseAccRemark;
  private String inptCaseAccChqNum;
  private String inptCaseAccIssueTo;
  private String inptCaseAccPayeeName;
  private String inptCaseAccRefNo;
  private Date inptCaseAccRefDate;
  private String inptCaseAccCurrency;
  private BigDecimal inptCaseAccDb;
  private BigDecimal inptCaseAccCollect;
  private BigDecimal inptCaseAccCr;
  private Date inptCaseAccRcptDate;
  private Date inptCaseAccBillDate;
  private String inptCaseAccActRemark;
  private Date inptCaseAccActionDate;
  private Boolean inptCaseAccVoid;

 public InptCaseAccounting() {
 }

	
 public InptCaseAccounting(InptCase inptCase) {
     this.inptCase = inptCase;
 }
 public InptCaseAccounting(Bank bank, InptCase inptCase, Integer inptCaseAccCreatedBy, Date inptCaseAccCreatedDate, Integer inptCaseAccEdittedBy, Date inptCaseAccEdittedDate, String inptCaseAccType, String inptCaseAccRemark, String inptCaseAccChqNum, String inptCaseAccIssueTo, String inptCaseAccPayeeName, String inptCaseAccRefNo, Date inptCaseAccRefDate, String inptCaseAccCurrency, BigDecimal inptCaseAccDb, BigDecimal inptCaseAccCollect, BigDecimal inptCaseAccCr, Date inptCaseAccRcptDate, Date inptCaseAccBillDate, String inptCaseAccActRemark, Date inptCaseAccActionDate, Boolean inptCaseAccVoid) {
    this.bank = bank;
    this.inptCase = inptCase;
    this.inptCaseAccCreatedBy = inptCaseAccCreatedBy;
    this.inptCaseAccCreatedDate = inptCaseAccCreatedDate;
    this.inptCaseAccEdittedBy = inptCaseAccEdittedBy;
    this.inptCaseAccEdittedDate = inptCaseAccEdittedDate;
    this.inptCaseAccType = inptCaseAccType;
    this.inptCaseAccRemark = inptCaseAccRemark;
    this.inptCaseAccChqNum = inptCaseAccChqNum;
    this.inptCaseAccIssueTo = inptCaseAccIssueTo;
    this.inptCaseAccPayeeName = inptCaseAccPayeeName;
    this.inptCaseAccRefNo = inptCaseAccRefNo;
    this.inptCaseAccRefDate = inptCaseAccRefDate;
    this.inptCaseAccCurrency = inptCaseAccCurrency;
    this.inptCaseAccDb = inptCaseAccDb;
    this.inptCaseAccCollect = inptCaseAccCollect;
    this.inptCaseAccCr = inptCaseAccCr;
    this.inptCaseAccRcptDate = inptCaseAccRcptDate;
    this.inptCaseAccBillDate = inptCaseAccBillDate;
    this.inptCaseAccActRemark = inptCaseAccActRemark;
    this.inptCaseAccActionDate = inptCaseAccActionDate;
    this.inptCaseAccVoid = inptCaseAccVoid;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="inptCaseAccId", unique=true, nullable=false)
 public Integer getInptCaseAccId() {
     return this.inptCaseAccId;
 }
 
 public void setInptCaseAccId(Integer inptCaseAccId) {
     this.inptCaseAccId = inptCaseAccId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseAccBankId")
 public Bank getBank() {
     return this.bank;
 }
 
 public void setBank(Bank bank) {
     this.bank = bank;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="inptCaseAccInptCaseId", nullable=false)
 public InptCase getInptCase() {
     return this.inptCase;
 }
 
 public void setInptCase(InptCase inptCase) {
     this.inptCase = inptCase;
 }

 
 @Column(name="inptCaseAccCreatedBy")
 public Integer getInptCaseAccCreatedBy() {
     return this.inptCaseAccCreatedBy;
 }
 
 public void setInptCaseAccCreatedBy(Integer inptCaseAccCreatedBy) {
     this.inptCaseAccCreatedBy = inptCaseAccCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAccCreatedDate", length=19)
 public Date getInptCaseAccCreatedDate() {
     return this.inptCaseAccCreatedDate;
 }
 
 public void setInptCaseAccCreatedDate(Date inptCaseAccCreatedDate) {
     this.inptCaseAccCreatedDate = inptCaseAccCreatedDate;
 }

 
 @Column(name="inptCaseAccEdittedBy")
 public Integer getInptCaseAccEdittedBy() {
     return this.inptCaseAccEdittedBy;
 }
 
 public void setInptCaseAccEdittedBy(Integer inptCaseAccEdittedBy) {
     this.inptCaseAccEdittedBy = inptCaseAccEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAccEdittedDate", length=19)
 public Date getInptCaseAccEdittedDate() {
     return this.inptCaseAccEdittedDate;
 }
 
 public void setInptCaseAccEdittedDate(Date inptCaseAccEdittedDate) {
     this.inptCaseAccEdittedDate = inptCaseAccEdittedDate;
 }

 
 @Column(name="inptCaseAccType", length=2)
 public String getInptCaseAccType() {
     return this.inptCaseAccType;
 }
 
 public void setInptCaseAccType(String inptCaseAccType) {
     this.inptCaseAccType = inptCaseAccType;
 }

 
 @Column(name="inptCaseAccRemark", length=250)
 public String getInptCaseAccRemark() {
     return this.inptCaseAccRemark;
 }
 
 public void setInptCaseAccRemark(String inptCaseAccRemark) {
     this.inptCaseAccRemark = inptCaseAccRemark;
 }

 
 @Column(name="inptCaseAccChqNum", length=50)
 public String getInptCaseAccChqNum() {
     return this.inptCaseAccChqNum;
 }
 
 public void setInptCaseAccChqNum(String inptCaseAccChqNum) {
     this.inptCaseAccChqNum = inptCaseAccChqNum;
 }

 
 @Column(name="inptCaseAccIssueTo", length=1)
 public String getInptCaseAccIssueTo() {
     return this.inptCaseAccIssueTo;
 }
 
 public void setInptCaseAccIssueTo(String inptCaseAccIssueTo) {
     this.inptCaseAccIssueTo = inptCaseAccIssueTo;
 }

 
 @Column(name="inptCaseAccPayeeName", length=200)
 public String getInptCaseAccPayeeName() {
     return this.inptCaseAccPayeeName;
 }
 
 public void setInptCaseAccPayeeName(String inptCaseAccPayeeName) {
     this.inptCaseAccPayeeName = inptCaseAccPayeeName;
 }

 
 @Column(name="inptCaseAccRefNo", length=30)
 public String getInptCaseAccRefNo() {
     return this.inptCaseAccRefNo;
 }
 
 public void setInptCaseAccRefNo(String inptCaseAccRefNo) {
     this.inptCaseAccRefNo = inptCaseAccRefNo;
 }

 @Temporal(TemporalType.DATE)
 @Column(name="inptCaseAccRefDate", length=10)
 public Date getInptCaseAccRefDate() {
     return this.inptCaseAccRefDate;
 }
 
 public void setInptCaseAccRefDate(Date inptCaseAccRefDate) {
     this.inptCaseAccRefDate = inptCaseAccRefDate;
 }

 
 @Column(name="inptCaseAccCurrency", length=3)
 public String getInptCaseAccCurrency() {
     return this.inptCaseAccCurrency;
 }
 
 public void setInptCaseAccCurrency(String inptCaseAccCurrency) {
     this.inptCaseAccCurrency = inptCaseAccCurrency;
 }

 
 @Column(name="inptCaseAccDb", precision=16)
 public BigDecimal getInptCaseAccDb() {
     return this.inptCaseAccDb;
 }
 
 public void setInptCaseAccDb(BigDecimal inptCaseAccDb) {
     this.inptCaseAccDb = inptCaseAccDb;
 }

 
 @Column(name="inptCaseAccCollect", precision=16)
 public BigDecimal getInptCaseAccCollect() {
     return this.inptCaseAccCollect;
 }
 
 public void setInptCaseAccCollect(BigDecimal inptCaseAccCollect) {
     this.inptCaseAccCollect = inptCaseAccCollect;
 }

 
 @Column(name="inptCaseAccCr", precision=16)
 public BigDecimal getInptCaseAccCr() {
     return this.inptCaseAccCr;
 }
 
 public void setInptCaseAccCr(BigDecimal inptCaseAccCr) {
     this.inptCaseAccCr = inptCaseAccCr;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAccRcptDate", length=19)
 public Date getInptCaseAccRcptDate() {
     return this.inptCaseAccRcptDate;
 }
 
 public void setInptCaseAccRcptDate(Date inptCaseAccRcptDate) {
     this.inptCaseAccRcptDate = inptCaseAccRcptDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAccBillDate", length=19)
 public Date getInptCaseAccBillDate() {
     return this.inptCaseAccBillDate;
 }
 
 public void setInptCaseAccBillDate(Date inptCaseAccBillDate) {
     this.inptCaseAccBillDate = inptCaseAccBillDate;
 }

 
 @Column(name="inptCaseAccActRemark", length=250)
 public String getInptCaseAccActRemark() {
     return this.inptCaseAccActRemark;
 }
 
 public void setInptCaseAccActRemark(String inptCaseAccActRemark) {
     this.inptCaseAccActRemark = inptCaseAccActRemark;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="inptCaseAccActionDate", length=19)
 public Date getInptCaseAccActionDate() {
     return this.inptCaseAccActionDate;
 }
 
 public void setInptCaseAccActionDate(Date inptCaseAccActionDate) {
     this.inptCaseAccActionDate = inptCaseAccActionDate;
 }

 
 @Column(name="inptCaseAccVoid")
 public Boolean getInptCaseAccVoid() {
     return this.inptCaseAccVoid;
 }
 
 public void setInptCaseAccVoid(Boolean inptCaseAccVoid) {
     this.inptCaseAccVoid = inptCaseAccVoid;
 }




}


