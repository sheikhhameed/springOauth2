package com.test.demo.cas.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.test.demo.cas.authentication.AuthenticateUser;
import com.test.demo.model.common.User;
import com.test.demo.model.outpt.OutptClaim;

@Service
public class InOutOpdCASService {

	
	public ResponseEntity<OutptClaim> getClaim(User user, String authType, int claimId) throws Exception  {
	    //Object from db
//			OutptClaim outptClaim = outptClaimService.getOutptClaim(claimId);
		RestTemplate restTemplate = new RestTemplate();	
		String url ="http://localhost:8080/cms/claim/{claimId}";
		ResponseEntity<OutptClaim> responseEntity = restTemplate.getForEntity(url, OutptClaim.class,claimId);
		
		OutptClaim outptClaim = (OutptClaim) responseEntity.getBody();
			if (outptClaim == null) {
				throw new Exception("No claim for the given claimId");
			}

			Boolean validClaimId = AuthenticateUser.validateClaimId(user, authType, outptClaim);

			 if (!validClaimId) {
		            throw new Exception("Unauthorized claim Id");
		        }
			 return responseEntity;
	}

	
	
}
