package com.test.demo.model.outpt;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is OutptPaymentbatch class 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_payment_batch"
 ,catalog="marcmy"
)
public class OutptPaymentBatch  implements java.io.Serializable {


  private Integer outptBatchId;
  private Integer outptBatchCreatedBy;
  private Date outptBatchCreatedDate;
  private String outptBatchFileName;
  private Set<OutptPaymentAdvice> outptPaymentAdvices = new HashSet<OutptPaymentAdvice>(0);

 public OutptPaymentBatch() {
 }

 public OutptPaymentBatch(Integer outptBatchCreatedBy, Date outptBatchCreatedDate, String outptBatchFileName, Set<OutptPaymentAdvice> outptPaymentAdvices) {
    this.outptBatchCreatedBy = outptBatchCreatedBy;
    this.outptBatchCreatedDate = outptBatchCreatedDate;
    this.outptBatchFileName = outptBatchFileName;
    this.outptPaymentAdvices = outptPaymentAdvices;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptBatchId", unique=true, nullable=false)
 public Integer getOutptBatchId() {
     return this.outptBatchId;
 }
 
 public void setOutptBatchId(Integer outptBatchId) {
     this.outptBatchId = outptBatchId;
 }

 
 @Column(name="outptBatchCreatedBy")
 public Integer getOutptBatchCreatedBy() {
     return this.outptBatchCreatedBy;
 }
 
 public void setOutptBatchCreatedBy(Integer outptBatchCreatedBy) {
     this.outptBatchCreatedBy = outptBatchCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptBatchCreatedDate", length=19)
 public Date getOutptBatchCreatedDate() {
     return this.outptBatchCreatedDate;
 }
 
 public void setOutptBatchCreatedDate(Date outptBatchCreatedDate) {
     this.outptBatchCreatedDate = outptBatchCreatedDate;
 }

 
 @Column(name="outptBatchFileName", length=250)
 public String getOutptBatchFileName() {
     return this.outptBatchFileName;
 }
 
 public void setOutptBatchFileName(String outptBatchFileName) {
     this.outptBatchFileName = outptBatchFileName;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="outptPaymentBatch")
 public Set<OutptPaymentAdvice> getOutptPaymentAdvices() {
     return this.outptPaymentAdvices;
 }
 
 public void setOutptPaymentAdvices(Set<OutptPaymentAdvice> outptPaymentAdvices) {
     this.outptPaymentAdvices = outptPaymentAdvices;
 }




}


