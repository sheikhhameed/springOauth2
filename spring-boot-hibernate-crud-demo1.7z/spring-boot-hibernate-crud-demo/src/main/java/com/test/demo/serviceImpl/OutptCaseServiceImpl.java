package com.test.demo.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.demo.dao.EmployeeDao;
import com.test.demo.model.common.EmployeeEntity;
import com.test.demo.model.outpt.OutptClaim;
import com.test.demo.service.OutptCaseService;
 
@Service
public class OutptCaseServiceImpl implements OutptCaseService{
     
	
	@Autowired
	EmployeeDao dao;

	/**
	 * This method is to get all the employees 
	 * 
	 */
	@Override
	public List<EmployeeEntity> getAllEmployees() {
		List<EmployeeEntity> list = new ArrayList<EmployeeEntity>();
		list = dao.getAllEmployees();
		return list;
	}

	/**
	 * This method is to create or update employee details
	 * 
	 * @param employee
	 */
	@Override
	public EmployeeEntity createOrUpdateEmployee(EmployeeEntity employee) {
		EmployeeEntity employeeResponse = new EmployeeEntity();
		employeeResponse = dao.createOrUpdateEmployee(employee);
		return employeeResponse;
	}

	/**
	 * This method to get the employeeEntity from userId 
	 * 
	 * @param id
	 */
	@Override
	public EmployeeEntity getEmployeeById(Long id) {
		EmployeeEntity employee = new EmployeeEntity();
		employee = dao.getEmployeeById(id);
		return employee;
	}

	/**
	 * This method is to delete the user
	 * 
	 * @param id
	 */
	@Override
	public void deleteEmployeeById(Long id) {
		dao.deleteEmployeeById(id);
		
	}

	@Override
	public OutptClaim getOutptClaim(int claimId) {
		
		OutptClaim outptClaim = dao.getOutptClaim(claimId);
		
		return outptClaim;
	} 
	
	
}