package com.test.demo.model.outpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptCaseAccounting class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_case_accounting"
 ,catalog="marcmy"
)
public class OutptCaseAccounting  implements java.io.Serializable {


  private Integer outptCaseAccId;
  private OutptCase outptCase;
  private Date outptCaseAccCreatedDate;
  private Integer outptCaseAccCreatedBy;
  private String outptCaseAccType;
  private String outptCaseAccRemark;
  private Integer outptCaseAccChqNum;
  private Character outptCaseAccIssueTo;
  private BigDecimal outptCaseAccDb;
  private BigDecimal outptCaseAccCollect;
  private BigDecimal outptCaseAccCr;
  private String outptCaseAccBeneName;
  private String outptCaseAccBankName;
  private String outptCaseAccBankBranch;
  private String outptCaseAccAccountNum;

 public OutptCaseAccounting() {
 }

	
 public OutptCaseAccounting(OutptCase outptCase) {
     this.outptCase = outptCase;
 }
 public OutptCaseAccounting(OutptCase outptCase, Date outptCaseAccCreatedDate, Integer outptCaseAccCreatedBy, String outptCaseAccType, String outptCaseAccRemark, Integer outptCaseAccChqNum, Character outptCaseAccIssueTo, BigDecimal outptCaseAccDb, BigDecimal outptCaseAccCollect, BigDecimal outptCaseAccCr, String outptCaseAccBeneName, String outptCaseAccBankName, String outptCaseAccBankBranch, String outptCaseAccAccountNum) {
    this.outptCase = outptCase;
    this.outptCaseAccCreatedDate = outptCaseAccCreatedDate;
    this.outptCaseAccCreatedBy = outptCaseAccCreatedBy;
    this.outptCaseAccType = outptCaseAccType;
    this.outptCaseAccRemark = outptCaseAccRemark;
    this.outptCaseAccChqNum = outptCaseAccChqNum;
    this.outptCaseAccIssueTo = outptCaseAccIssueTo;
    this.outptCaseAccDb = outptCaseAccDb;
    this.outptCaseAccCollect = outptCaseAccCollect;
    this.outptCaseAccCr = outptCaseAccCr;
    this.outptCaseAccBeneName = outptCaseAccBeneName;
    this.outptCaseAccBankName = outptCaseAccBankName;
    this.outptCaseAccBankBranch = outptCaseAccBankBranch;
    this.outptCaseAccAccountNum = outptCaseAccAccountNum;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="outptCaseAccId", unique=true, nullable=false)
 public Integer getOutptCaseAccId() {
     return this.outptCaseAccId;
 }
 
 public void setOutptCaseAccId(Integer outptCaseAccId) {
     this.outptCaseAccId = outptCaseAccId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="outptCaseAccOutptCaseId", nullable=false)
 public OutptCase getOutptCase() {
     return this.outptCase;
 }
 
 public void setOutptCase(OutptCase outptCase) {
     this.outptCase = outptCase;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="outptCaseAccCreatedDate", length=19)
 public Date getOutptCaseAccCreatedDate() {
     return this.outptCaseAccCreatedDate;
 }
 
 public void setOutptCaseAccCreatedDate(Date outptCaseAccCreatedDate) {
     this.outptCaseAccCreatedDate = outptCaseAccCreatedDate;
 }

 
 @Column(name="outptCaseAccCreatedBy")
 public Integer getOutptCaseAccCreatedBy() {
     return this.outptCaseAccCreatedBy;
 }
 
 public void setOutptCaseAccCreatedBy(Integer outptCaseAccCreatedBy) {
     this.outptCaseAccCreatedBy = outptCaseAccCreatedBy;
 }

 
 @Column(name="outptCaseAccType", length=2)
 public String getOutptCaseAccType() {
     return this.outptCaseAccType;
 }
 
 public void setOutptCaseAccType(String outptCaseAccType) {
     this.outptCaseAccType = outptCaseAccType;
 }

 
 @Column(name="outptCaseAccRemark", length=250)
 public String getOutptCaseAccRemark() {
     return this.outptCaseAccRemark;
 }
 
 public void setOutptCaseAccRemark(String outptCaseAccRemark) {
     this.outptCaseAccRemark = outptCaseAccRemark;
 }

 
 @Column(name="outptCaseAccChqNum")
 public Integer getOutptCaseAccChqNum() {
     return this.outptCaseAccChqNum;
 }
 
 public void setOutptCaseAccChqNum(Integer outptCaseAccChqNum) {
     this.outptCaseAccChqNum = outptCaseAccChqNum;
 }

 
 @Column(name="outptCaseAccIssueTo", length=1)
 public Character getOutptCaseAccIssueTo() {
     return this.outptCaseAccIssueTo;
 }
 
 public void setOutptCaseAccIssueTo(Character outptCaseAccIssueTo) {
     this.outptCaseAccIssueTo = outptCaseAccIssueTo;
 }

 
 @Column(name="outptCaseAccDb", precision=16)
 public BigDecimal getOutptCaseAccDb() {
     return this.outptCaseAccDb;
 }
 
 public void setOutptCaseAccDb(BigDecimal outptCaseAccDb) {
     this.outptCaseAccDb = outptCaseAccDb;
 }

 
 @Column(name="outptCaseAccCollect", precision=16)
 public BigDecimal getOutptCaseAccCollect() {
     return this.outptCaseAccCollect;
 }
 
 public void setOutptCaseAccCollect(BigDecimal outptCaseAccCollect) {
     this.outptCaseAccCollect = outptCaseAccCollect;
 }

 
 @Column(name="outptCaseAccCr", precision=16)
 public BigDecimal getOutptCaseAccCr() {
     return this.outptCaseAccCr;
 }
 
 public void setOutptCaseAccCr(BigDecimal outptCaseAccCr) {
     this.outptCaseAccCr = outptCaseAccCr;
 }

 
 @Column(name="outptCaseAccBeneName", length=150)
 public String getOutptCaseAccBeneName() {
     return this.outptCaseAccBeneName;
 }
 
 public void setOutptCaseAccBeneName(String outptCaseAccBeneName) {
     this.outptCaseAccBeneName = outptCaseAccBeneName;
 }

 
 @Column(name="outptCaseAccBankName", length=150)
 public String getOutptCaseAccBankName() {
     return this.outptCaseAccBankName;
 }
 
 public void setOutptCaseAccBankName(String outptCaseAccBankName) {
     this.outptCaseAccBankName = outptCaseAccBankName;
 }

 
 @Column(name="outptCaseAccBankBranch", length=150)
 public String getOutptCaseAccBankBranch() {
     return this.outptCaseAccBankBranch;
 }
 
 public void setOutptCaseAccBankBranch(String outptCaseAccBankBranch) {
     this.outptCaseAccBankBranch = outptCaseAccBankBranch;
 }

 
 @Column(name="outptCaseAccAccountNum", length=150)
 public String getOutptCaseAccAccountNum() {
     return this.outptCaseAccAccountNum;
 }
 
 public void setOutptCaseAccAccountNum(String outptCaseAccAccountNum) {
     this.outptCaseAccAccountNum = outptCaseAccAccountNum;
 }




}


