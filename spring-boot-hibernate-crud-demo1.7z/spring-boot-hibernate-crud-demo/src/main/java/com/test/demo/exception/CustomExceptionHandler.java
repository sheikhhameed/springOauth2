package com.test.demo.exception;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.test.demo.model.common.ResponseData;
/**
 * This class will handles all kind of exception in the application
 * 
 * @author smannan
 *
 */
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomExceptionHandler.class);
	
	
//	@ExceptionHandler(NoData.class)
//	public final ResponseEntity<Object> handleUserNotFoundException(RecordNotFoundException ex, WebRequest request){
//		LOGGER.info("Entering into the handleUserNotFoundException method");
//		List<String> details = new ArrayList<String>();
//		details.add(ex.getLocalizedMessage());
//		String errorCode="11";
//		ErrorResponse error = new ErrorResponse("Record Not found", errorCode);
//		return new ResponseEntity(error, HttpStatus.NOT_FOUND);
//	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllException(Exception ex, WebRequest request){
		LOGGER.info("Entering into the handleAllException method");
//		if(ex instanceof RecordNotFoundException){
//			return new RecordNotFoundException(id)
//		}else {
		System.out.println("Exception is : "+ex.getClass());
			List<String> details = new ArrayList<String>();
			details.add(ex.getLocalizedMessage());
			String errorCode ="14";
			ResponseData error = new ResponseData();
			error.setRespCode(HttpStatus.NOT_FOUND.toString());
			error.setRespMessage(ex.getLocalizedMessage());
			error.setTimestamp(LocalDateTime.now());
			return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
			
			
//		}
		
	}
	
	@ExceptionHandler(NullPointerException.class)
	public final ResponseEntity<Object> handleNullPointerException(NullPointerException ex, WebRequest request){
		LOGGER.info("Entering into the handleAllException method");
//		if(ex instanceof RecordNotFoundException){
//			return new RecordNotFoundException(id)
//		}else {
		System.out.println("Exception is : "+ex.getClass());
			ResponseData error = new ResponseData();
			error.setRespCode(HttpStatus.NOT_FOUND.toString());
			error.setRespMessage(ex.getLocalizedMessage());
			error.setTimestamp(LocalDateTime.now());
			return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
			
			
//		}
		
	}
	
	@ExceptionHandler(InvocationTargetException.class)
	public final ResponseEntity<Object> handleInvocationTargetException(InvocationTargetException ex, WebRequest request){
		LOGGER.info("Entering into the handleIllegalArgumentException method");
		ResponseData error = new ResponseData();
		error.setRespCode(HttpStatus.NOT_FOUND.toString());
		error.setRespMessage(ex.getLocalizedMessage());
		error.setTimestamp(LocalDateTime.now());
		return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(java.lang.IllegalArgumentException.class)
	public final ResponseEntity<Object> handleIllegalArgumentException(java.lang.IllegalArgumentException ex, WebRequest request){
		LOGGER.info("Entering into the handleIllegalArgumentException method");
		List<String> details = new ArrayList<String>();
		Map<String , String > errorMessage = new HashMap<String, String>();
		errorMessage.put("cause", ex.getCause().toString());
		errorMessage.put("message1", ex.getMessage());
		details.add(errorMessage.toString());
		String errorCode = "13";
//		ErrorResponse error  = new ErrorResponse("Illegal Argument Exception", errorCode);
		ResponseData error = new ResponseData();
		error.setRespCode(HttpStatus.NOT_FOUND.toString());
		error.setRespMessage(ex.getLocalizedMessage());
		error.setTimestamp(LocalDateTime.now());
		return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
