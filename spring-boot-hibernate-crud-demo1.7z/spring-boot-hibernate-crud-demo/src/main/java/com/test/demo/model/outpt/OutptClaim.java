package com.test.demo.model.outpt;

import static javax.persistence.GenerationType.IDENTITY;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.test.demo.model.common.MedicalProvider;

/**
 * This is outptClaim class
 * 
 * @author smannan
 *
 */

@Entity
@Table(name = "outpt_claim",
     catalog = "marcmy"
)
public class OutptClaim implements java.io.Serializable {

 private Integer outptClaimId;
 private String outptClaimPrefixId;
 
 @JsonIgnore
 private MedicalProvider medicalProvider;
 @JsonIgnore
 private OutptBdx outptBdxByOutptClaimAsoOutptBdxId;
 @JsonIgnore
 private OutptBdx outptBdxByOutptClaimInsOutptBdxId;
 @JsonIgnore
 private OutptCase outptCase;
 @JsonIgnore
 private OutptStatus outptStatus;
 
 private boolean outptClaimEnabled;
 
 private Date outptClaimCreatedDate;
 
 private String outptClaimCreatedByAbbvName;
 
 private Date outptClaimLastEdittedDate;
 
 private String outptClaimLastEdittedByAbbvName;
 
 private Integer outptClaimPrevOutptClaimId;
 
 private String outptClaimExtRefId;
 
 private Integer outptClaimOutptBenefitId;
 
 private String outptClaimOutptBenefitName;
 
 private String outptClaimOutptBenefitLocalName;
 
 private Integer outptClaimOutptPlanBenefitId;
 
 private String outptClaimOutptPlanBenefitExtCode;
 
 private Integer outptClaimOutptPlanBenefitGroupId;
 
 private String outptClaimOutptPlanBenefitGroupExtCode;
 
 private String outptClaimOtherMedPrvName;
 
 private String outptClaimType;
 
 private String outptClaimCleanType;
 
 private String outptClaimStatusRemark;
 
 private boolean outptClaimPossibleDuplicate;
 
 private boolean outptClaimImportedRecord;
 
 private boolean outptClaimIsEclaimRecord;
 
 private boolean outptClaimIsEmemberRecord;
 
 private boolean outptClaimIsAppRecord;
 
 private Boolean outptClaimSpecArrg;
 
 private Boolean outptClaimGovHospLg;

 private Boolean outptClaimB2b;
 
 private Boolean outptClaimPreAdm;
 
 private Boolean outptClaimAccident;
 
 private Boolean outptClaimAccidentDeath;
 
 private Boolean outptClaimAccidentDisable;
 
 private Date outptClaimIncidentDate;
 
 private Date outptClaimNotificationDate;
 
 private Date outptClaimVisitDate;
 
 private Date outptClaimPreAuthDate;
 
 private Date outptClaimAdmDateRecv;

 private Integer outptClaimAdmCountryId;
 private Date outptClaimDischargeDate;
 private Date outptClaimDischargeDateRecv;
 private Date outptClaimFullInfoReceivedDate;
 private Date outptClaimBillReceivedDate;
 private BigDecimal outptClaimEstLengthOfStay;
 private BigDecimal outptClaimLengthOfStay;
 private Integer outptClaimRoomBedType;
 private String outptClaimInitDiagnosis;
 private String outptClaimRemark;
 private String outptClaimPrvInvoiceNum;
 private String outptClaimPrvStatementNum;
 private Date outptClaimPrvInvoiceDate;
 private BigDecimal outptClaimPrvInvoiceOriginalAmount;
 private Date outptClaimFirstConsultationDate;
 private Date outptClaimSymptomOnsetDate;
 private Boolean outptClaimPastTreatment;
 private String outptClaimPastTreatmentNote;
 private String outptClaimHospitalMrnNumber;
 private String outptClaimHospitalAdmissionNumber;
 private String outptClaimCurrency;
 private BigDecimal outptClaimForexRate;
 private String outptClaimForexStr;
 private BigDecimal outptClaimEstCost;
 private BigDecimal outptClaimReservedAmount;
 private BigDecimal outptClaimInitialReservedAmount;
 private BigDecimal outptClaimEstInsurerAmt;
 private BigDecimal outptClaimEstPatientAmt;
 private String outptClaimEstRejectReason;
 private BigDecimal outptClaimEstSubmissionReservedAmt;
 private BigDecimal outptClaimEstSubmissionInsurerAmt;
 private BigDecimal outptClaimEstSubmissionPatientAmt;
 private String outptClaimEstSubmissionRejectReason;
 private BigDecimal outptClaimInvCurrAdjustAsoAmt;
 private BigDecimal outptClaimInvCurrAdjustPtAmt;
 private String outptClaimAdjustRemark;
 private BigDecimal outptClaimInvCurrTotalAmt;
 private BigDecimal outptClaimInvCurrTotalDiscountAmt;
 private BigDecimal outptClaimInvCurrTotalGstAmt;
 private BigDecimal outptClaimInvCurrTotalExcessAmt;
 private BigDecimal outptClaimInvCurrTotalGrandAmt;
 private BigDecimal outptClaimInvCurrTotalInsAmt;
 private BigDecimal outptClaimInvCurrTotalAsoAmt;
 private BigDecimal outptClaimInvCurrTotalPtAmt;
 private BigDecimal outptClaimInvCurrTotalExcessNonCoverAmt;
 private BigDecimal outptClaimInvCurrTotalExcessCoPayAmt;
 private BigDecimal outptClaimInvCurrTotalExcessCoInsAmt;
 private BigDecimal outptClaimInvCurrTotalExcessPrvCoInsAmt;
 private BigDecimal outptClaimInvCurrTotalExcessDeductAmt;
 private BigDecimal outptClaimInvCurrTotalExcessPvAmt;
 private BigDecimal outptClaimInvCurrTotalExcessAnnLimitAmt;
 private BigDecimal outptClaimInvCurrTotalExcessAnnMaxVisitAmt;
 private BigDecimal outptClaimInvCurrTotalExcessLtLimitAmt;
 private BigDecimal outptClaimInvCurrTotalExgratiaAmt;
 private String outptClaimPlanCurrency;
 private BigDecimal outptClaimPlanCurrTotalAmt;
 private BigDecimal outptClaimPlanCurrTotalDiscountAmt;
 private BigDecimal outptClaimPlanCurrTotalGstAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessAmt;
 private BigDecimal outptClaimPlanCurrTotalGrandAmt;
 private BigDecimal outptClaimPlanCurrTotalInsAmt;
 private BigDecimal outptClaimPlanCurrTotalAsoAmt;
 private BigDecimal outptClaimPlanCurrTotalPtAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessNonCoverAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessCoPayAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessCoInsAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessPrvCoInsAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessDeductAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessPvAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessAnnLimitAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessAnnMaxVisitAmt;
 private BigDecimal outptClaimPlanCurrTotalExcessLtLimitAmt;
 private BigDecimal outptClaimPlanCurrTotalExgratiaAmt;
 private Boolean outptClaimAutoAdjudicateApproval;
 private String outptClaimAutoAdjudicateMessage;
 private Date outptClaimMcStartDate;
 private Date outptClaimMcEndDate;
 private String outptClaimRejectType;
 private String outptClaimApprovalType;
 private String outptClaimApprovalRemarks;
 private Date outptClaimApprovalDate;
 private String outptClaimApprovalByAbbvName;
 private BigDecimal outptClaimApprovalBillCurrInsurerAmt;
 private BigDecimal outptClaimApprovalBillCurrAsoAmt;
 private BigDecimal outptClaimApprovalPlanCurrInsurerAmt;
 private BigDecimal outptClaimApprovalPlanCurrAsoAmt;
 private BigDecimal outptClaimOutptPayAdvAmount;
 private BigDecimal outptClaimOutptPayAdvWhtAmt;
 private BigDecimal outptClaimOutptPayAdvInterestAmt;
 private String outptClaimInsBdxCurrency;
 private BigDecimal outptClaimInsBdxAmount;
 private BigDecimal outptClaimInsBdxForexRate;
 private String outptClaimInsBdxForexStr;
 private BigDecimal outptClaimInsCollectionAmount;
 private Date outptClaimInsCollectionDate;
 private String outptClaimAsoBdxCurrency;
 private BigDecimal outptClaimAsoBdxAmount;
 private BigDecimal outptClaimAsoBdxForexRate;
 private String outptClaimAsoBdxForexStr;
 private BigDecimal outptClaimAsoCollectionAmount;
 private Date outptClaimAsoCollectionDate;
 private Date outptClaimEclaimSubmissionDate;
 private BigDecimal outptClaimEclaimDraftPerVisitLimit;
 private Integer outptClaimEclaimDraftAvaiVisit;
 private BigDecimal outptClaimEclaimDraftAvaiLimit;
 private BigDecimal outptClaimEclaimDraftDeductible;
 private String outptClaimEclaimDraftCoInsApplies;
 private BigDecimal outptClaimCorporateDiscountAmt;
 private BigDecimal outptClaimFurtherDiscountAmt;
 private String outptClaimOtherDoctorName;
 private String outptClaimOtherDoctorLisNum;
 private Boolean outptClaimIsAgiApiSend;
 private Boolean outptClaimIsAuditCase;
 private Boolean outptClaimIsComplainCase;
 private Boolean outptClaimIsCaseStudy;
 private Boolean outptClaimIsLetterIssued;
 private Date outptClaimAdmFaxInDate;
 private Date outptClaimAdmFaxOutDate;
 private Date outptClaimDiscFaxInDate;
 private Date outptClaimDiscFaxOutDate;
 private String outptClaimOtherDiagnosis;
 private Date outptClaimSpecificIllnessDate;
 private Date outptClaimGracePeriodDate;
 private Date outptClaimWaitingPeriodDate;
 private Date outptClaimIsoBdxDate;
 private Date outptClaimAsoBdxDate;
 private String outptClaimClientClaimId;
 private String outptClaimClientPortalNo;
 private String outptClaimPaymentTo;
 private String outptClaimPaymentMode;
 private String outptClaimPayeeName;
 private String outptClaimBankAccName;
 private String outptClaimBankAccNum;
//  private int outptClaimPlanAnnLimit;
//  private boolean outptClaimPlanUnlimitedAnnLimit;
 @JsonIgnore
 private Set<OutptClaimCalc> outptClaimCalcs = new HashSet<OutptClaimCalc>(0);
 @JsonIgnore
 private Set<OutptClaimSurgicalSchedule> outptClaimSurgicalSchedules = new HashSet<OutptClaimSurgicalSchedule>(0);
 @JsonIgnore
 private Set<OutptCasePhonelog> outptCasePhonelogs = new HashSet<OutptCasePhonelog>(0);
 @JsonIgnore
 private Set<OutptClaimDoctor> outptClaimDoctors = new HashSet<OutptClaimDoctor>(0);
 @JsonIgnore
 private Set<OutptClaimSymptom> outptClaimSymptoms = new HashSet<OutptClaimSymptom>(0);
 @JsonIgnore
 private Set<OutptPaymentActivityLog> outptPaymentActivityLogs = new HashSet<OutptPaymentActivityLog>(0);
 @JsonIgnore
 private Set<OutptClaimDrug> outptClaimDrugs = new HashSet<OutptClaimDrug>(0);
 @JsonIgnore
 private Set<OutptCaseWorkflowlog> outptCaseWorkflowlogs = new HashSet<OutptCaseWorkflowlog>(0);
 @JsonIgnore
 private Set<OutptCaseAdmin> outptCaseAdmins = new HashSet<OutptCaseAdmin>(0);
 @JsonIgnore
 private Set<OutptClaimApproval> outptClaimApprovals = new HashSet<OutptClaimApproval>(0);
 @JsonIgnore
 private Set<OutptCaseImage> outptCaseImages = new HashSet<OutptCaseImage>(0);
 @JsonIgnore
 private Set<OutptClaimDiagnosis> outptClaimDiagnosises = new HashSet<OutptClaimDiagnosis>(0);
 @JsonIgnore
 private Set<OutptClaimFwaResult> outptClaimFwaResults = new HashSet<OutptClaimFwaResult>(0);
 @JsonIgnore
 private Set<OutptClaimItem> outptClaimItems = new HashSet<OutptClaimItem>(0);
 
 public OutptClaim() {
 }

 public OutptClaim(OutptCase outptCase, OutptStatus outptStatus, boolean outptClaimEnabled, String outptClaimType, boolean outptClaimPossibleDuplicate, boolean outptClaimImportedRecord, boolean outptClaimIsEclaimRecord, boolean outptClaimIsEmemberRecord,boolean outptClaimIsAppRecord, BigDecimal outptClaimForexRate, BigDecimal outptClaimReservedAmount, BigDecimal outptClaimEstInsurerAmt, BigDecimal outptClaimEstPatientAmt, BigDecimal outptClaimEstSubmissionReservedAmt, BigDecimal outptClaimEstSubmissionInsurerAmt, BigDecimal outptClaimEstSubmissionPatientAmt, BigDecimal outptClaimInvCurrAdjustAsoAmt, BigDecimal outptClaimInvCurrAdjustPtAmt, BigDecimal outptClaimInvCurrTotalAmt, BigDecimal outptClaimInvCurrTotalDiscountAmt, BigDecimal outptClaimInvCurrTotalGstAmt, BigDecimal outptClaimInvCurrTotalExcessAmt, BigDecimal outptClaimInvCurrTotalGrandAmt, BigDecimal outptClaimInvCurrTotalInsAmt, BigDecimal outptClaimInvCurrTotalAsoAmt, BigDecimal outptClaimInvCurrTotalPtAmt, BigDecimal outptClaimInvCurrTotalExcessNonCoverAmt, BigDecimal outptClaimInvCurrTotalExcessCoPayAmt, BigDecimal outptClaimInvCurrTotalExcessCoInsAmt, BigDecimal outptClaimInvCurrTotalExcessPrvCoInsAmt, BigDecimal outptClaimInvCurrTotalExcessDeductAmt, BigDecimal outptClaimInvCurrTotalExcessPvAmt, BigDecimal outptClaimInvCurrTotalExcessAnnLimitAmt, BigDecimal outptClaimInvCurrTotalExcessAnnMaxVisitAmt, BigDecimal outptClaimInvCurrTotalExcessLtLimitAmt, BigDecimal outptClaimInvCurrTotalExgratiaAmt, BigDecimal outptClaimPlanCurrTotalAmt, BigDecimal outptClaimPlanCurrTotalDiscountAmt, BigDecimal outptClaimPlanCurrTotalGstAmt, BigDecimal outptClaimPlanCurrTotalExcessAmt, BigDecimal outptClaimPlanCurrTotalGrandAmt, BigDecimal outptClaimPlanCurrTotalInsAmt, BigDecimal outptClaimPlanCurrTotalAsoAmt, BigDecimal outptClaimPlanCurrTotalPtAmt, BigDecimal outptClaimPlanCurrTotalExcessNonCoverAmt, BigDecimal outptClaimPlanCurrTotalExcessCoPayAmt, BigDecimal outptClaimPlanCurrTotalExcessCoInsAmt, BigDecimal outptClaimPlanCurrTotalExcessPrvCoInsAmt, BigDecimal outptClaimPlanCurrTotalExcessDeductAmt, BigDecimal outptClaimPlanCurrTotalExcessPvAmt, BigDecimal outptClaimPlanCurrTotalExcessAnnLimitAmt, BigDecimal outptClaimPlanCurrTotalExcessAnnMaxVisitAmt, BigDecimal outptClaimPlanCurrTotalExcessLtLimitAmt, BigDecimal outptClaimPlanCurrTotalExgratiaAmt, String outptClaimPaymentTo, String outptClaimPaymentMode, String outptClaimPayeeName, String outptClaimBankAccName, String outptClaimBankAccNum) {
     this.outptCase = outptCase;
     this.outptStatus = outptStatus;
     this.outptClaimEnabled = outptClaimEnabled;
     this.outptClaimType = outptClaimType;
     this.outptClaimPossibleDuplicate = outptClaimPossibleDuplicate;
     this.outptClaimImportedRecord = outptClaimImportedRecord;
     this.outptClaimIsEclaimRecord = outptClaimIsEclaimRecord;
     this.outptClaimIsEmemberRecord = outptClaimIsEmemberRecord;
     this.outptClaimIsAppRecord = outptClaimIsAppRecord;
     this.outptClaimForexRate = outptClaimForexRate;
     this.outptClaimReservedAmount = outptClaimReservedAmount;
     this.outptClaimEstInsurerAmt = outptClaimEstInsurerAmt;
     this.outptClaimEstPatientAmt = outptClaimEstPatientAmt;
     this.outptClaimEstSubmissionReservedAmt = outptClaimEstSubmissionReservedAmt;
     this.outptClaimEstSubmissionInsurerAmt = outptClaimEstSubmissionInsurerAmt;
     this.outptClaimEstSubmissionPatientAmt = outptClaimEstSubmissionPatientAmt;
     this.outptClaimInvCurrAdjustAsoAmt = outptClaimInvCurrAdjustAsoAmt;
     this.outptClaimInvCurrAdjustPtAmt = outptClaimInvCurrAdjustPtAmt;
     this.outptClaimInvCurrTotalAmt = outptClaimInvCurrTotalAmt;
     this.outptClaimInvCurrTotalDiscountAmt = outptClaimInvCurrTotalDiscountAmt;
     this.outptClaimInvCurrTotalGstAmt = outptClaimInvCurrTotalGstAmt;
     this.outptClaimInvCurrTotalExcessAmt = outptClaimInvCurrTotalExcessAmt;
     this.outptClaimInvCurrTotalGrandAmt = outptClaimInvCurrTotalGrandAmt;
     this.outptClaimInvCurrTotalInsAmt = outptClaimInvCurrTotalInsAmt;
     this.outptClaimInvCurrTotalAsoAmt = outptClaimInvCurrTotalAsoAmt;
     this.outptClaimInvCurrTotalPtAmt = outptClaimInvCurrTotalPtAmt;
     this.outptClaimInvCurrTotalExcessNonCoverAmt = outptClaimInvCurrTotalExcessNonCoverAmt;
     this.outptClaimInvCurrTotalExcessCoPayAmt = outptClaimInvCurrTotalExcessCoPayAmt;
     this.outptClaimInvCurrTotalExcessCoInsAmt = outptClaimInvCurrTotalExcessCoInsAmt;
     this.outptClaimInvCurrTotalExcessPrvCoInsAmt = outptClaimInvCurrTotalExcessPrvCoInsAmt;
     this.outptClaimInvCurrTotalExcessDeductAmt = outptClaimInvCurrTotalExcessDeductAmt;
     this.outptClaimInvCurrTotalExcessPvAmt = outptClaimInvCurrTotalExcessPvAmt;
     this.outptClaimInvCurrTotalExcessAnnLimitAmt = outptClaimInvCurrTotalExcessAnnLimitAmt;
     this.outptClaimInvCurrTotalExcessAnnMaxVisitAmt = outptClaimInvCurrTotalExcessAnnMaxVisitAmt;
     this.outptClaimInvCurrTotalExcessLtLimitAmt = outptClaimInvCurrTotalExcessLtLimitAmt;
     this.outptClaimInvCurrTotalExgratiaAmt = outptClaimInvCurrTotalExgratiaAmt;
     this.outptClaimPlanCurrTotalAmt = outptClaimPlanCurrTotalAmt;
     this.outptClaimPlanCurrTotalDiscountAmt = outptClaimPlanCurrTotalDiscountAmt;
     this.outptClaimPlanCurrTotalGstAmt = outptClaimPlanCurrTotalGstAmt;
     this.outptClaimPlanCurrTotalExcessAmt = outptClaimPlanCurrTotalExcessAmt;
     this.outptClaimPlanCurrTotalGrandAmt = outptClaimPlanCurrTotalGrandAmt;
     this.outptClaimPlanCurrTotalInsAmt = outptClaimPlanCurrTotalInsAmt;
     this.outptClaimPlanCurrTotalAsoAmt = outptClaimPlanCurrTotalAsoAmt;
     this.outptClaimPlanCurrTotalPtAmt = outptClaimPlanCurrTotalPtAmt;
     this.outptClaimPlanCurrTotalExcessNonCoverAmt = outptClaimPlanCurrTotalExcessNonCoverAmt;
     this.outptClaimPlanCurrTotalExcessCoPayAmt = outptClaimPlanCurrTotalExcessCoPayAmt;
     this.outptClaimPlanCurrTotalExcessCoInsAmt = outptClaimPlanCurrTotalExcessCoInsAmt;
     this.outptClaimPlanCurrTotalExcessPrvCoInsAmt = outptClaimPlanCurrTotalExcessPrvCoInsAmt;
     this.outptClaimPlanCurrTotalExcessDeductAmt = outptClaimPlanCurrTotalExcessDeductAmt;
     this.outptClaimPlanCurrTotalExcessPvAmt = outptClaimPlanCurrTotalExcessPvAmt;
     this.outptClaimPlanCurrTotalExcessAnnLimitAmt = outptClaimPlanCurrTotalExcessAnnLimitAmt;
     this.outptClaimPlanCurrTotalExcessAnnMaxVisitAmt = outptClaimPlanCurrTotalExcessAnnMaxVisitAmt;
     this.outptClaimPlanCurrTotalExcessLtLimitAmt = outptClaimPlanCurrTotalExcessLtLimitAmt;
     this.outptClaimPlanCurrTotalExgratiaAmt = outptClaimPlanCurrTotalExgratiaAmt;
     this.outptClaimPaymentTo = outptClaimPaymentTo;
     this.outptClaimPaymentMode = outptClaimPaymentMode;
     this.outptClaimPayeeName = outptClaimPayeeName;
     this.outptClaimBankAccName = outptClaimBankAccName;
     this.outptClaimBankAccNum = outptClaimBankAccNum;

 }

 public OutptClaim(MedicalProvider medicalProvider, OutptBdx outptBdxByOutptClaimAsoOutptBdxId, OutptBdx outptBdxByOutptClaimInsOutptBdxId, OutptCase outptCase, OutptStatus outptStatus, String outptClaimPrefixId, boolean outptClaimEnabled, Date outptClaimCreatedDate, String outptClaimCreatedByAbbvName, Date outptClaimLastEdittedDate, String outptClaimLastEdittedByAbbvName, Integer outptClaimPrevOutptClaimId, String outptClaimExtRefId, Integer outptClaimOutptBenefitId, String outptClaimOutptBenefitName, String outptClaimOutptBenefitLocalName, Integer outptClaimOutptPlanBenefitId, String outptClaimOutptPlanBenefitExtCode, Integer outptClaimOutptPlanBenefitGroupId, String outptClaimOutptPlanBenefitGroupExtCode, String outptClaimOtherMedPrvName, String outptClaimType, String outptClaimCleanType, String outptClaimStatusRemark, boolean outptClaimPossibleDuplicate, boolean outptClaimImportedRecord, boolean outptClaimIsEclaimRecord, boolean outptClaimIsEmemberRecord,boolean outptClaimIsAppRecord, Boolean outptClaimSpecArrg, Boolean outptClaimGovHospLg, Boolean outptClaimB2b, Boolean outptClaimPreAdm, Boolean outptClaimAccident, Boolean outptClaimAccidentDeath, Boolean outptClaimAccidentDisable, Date outptClaimIncidentDate, Date outptClaimNotificationDate, Date outptClaimVisitDate, Date outptClaimPreAuthDate, Date outptClaimAdmDateRecv, Integer outptClaimAdmCountryId, Date outptClaimDischargeDate, Date outptClaimDischargeDateRecv, Date outptClaimFullInfoReceivedDate, Date outptClaimBillReceivedDate, BigDecimal outptClaimEstLengthOfStay, BigDecimal outptClaimLengthOfStay, Integer outptClaimRoomBedType, String outptClaimInitDiagnosis, String outptClaimRemark, String outptClaimPrvInvoiceNum, String outptClaimPrvStatementNum, Date outptClaimPrvInvoiceDate, BigDecimal outptClaimPrvInvoiceOriginalAmount, Date outptClaimFirstConsultationDate, Date outptClaimSymptomOnsetDate, Boolean outptClaimPastTreatment, String outptClaimPastTreatmentNote, String outptClaimHospitalMrnNumber, String outptClaimHospitalAdmissionNumber, String outptClaimCurrency, BigDecimal outptClaimForexRate, String outptClaimForexStr, BigDecimal outptClaimEstCost, BigDecimal outptClaimReservedAmount, BigDecimal outptClaimInitialReservedAmount, BigDecimal outptClaimEstInsurerAmt, BigDecimal outptClaimEstPatientAmt, String outptClaimEstRejectReason, BigDecimal outptClaimEstSubmissionReservedAmt, BigDecimal outptClaimEstSubmissionInsurerAmt, BigDecimal outptClaimEstSubmissionPatientAmt, String outptClaimEstSubmissionRejectReason, BigDecimal outptClaimInvCurrAdjustAsoAmt, BigDecimal outptClaimInvCurrAdjustPtAmt, String outptClaimAdjustRemark, BigDecimal outptClaimInvCurrTotalAmt, BigDecimal outptClaimInvCurrTotalDiscountAmt, BigDecimal outptClaimInvCurrTotalGstAmt, BigDecimal outptClaimInvCurrTotalExcessAmt, BigDecimal outptClaimInvCurrTotalGrandAmt, BigDecimal outptClaimInvCurrTotalInsAmt, BigDecimal outptClaimInvCurrTotalAsoAmt, BigDecimal outptClaimInvCurrTotalPtAmt, BigDecimal outptClaimInvCurrTotalExcessNonCoverAmt, BigDecimal outptClaimInvCurrTotalExcessCoPayAmt, BigDecimal outptClaimInvCurrTotalExcessCoInsAmt, BigDecimal outptClaimInvCurrTotalExcessPrvCoInsAmt, BigDecimal outptClaimInvCurrTotalExcessDeductAmt, BigDecimal outptClaimInvCurrTotalExcessPvAmt, BigDecimal outptClaimInvCurrTotalExcessAnnLimitAmt, BigDecimal outptClaimInvCurrTotalExcessAnnMaxVisitAmt, BigDecimal outptClaimInvCurrTotalExcessLtLimitAmt, BigDecimal outptClaimInvCurrTotalExgratiaAmt, String outptClaimPlanCurrency, BigDecimal outptClaimPlanCurrTotalAmt, BigDecimal outptClaimPlanCurrTotalDiscountAmt, BigDecimal outptClaimPlanCurrTotalGstAmt, BigDecimal outptClaimPlanCurrTotalExcessAmt, BigDecimal outptClaimPlanCurrTotalGrandAmt, BigDecimal outptClaimPlanCurrTotalInsAmt, BigDecimal outptClaimPlanCurrTotalAsoAmt, BigDecimal outptClaimPlanCurrTotalPtAmt, BigDecimal outptClaimPlanCurrTotalExcessNonCoverAmt, BigDecimal outptClaimPlanCurrTotalExcessCoPayAmt, BigDecimal outptClaimPlanCurrTotalExcessCoInsAmt, BigDecimal outptClaimPlanCurrTotalExcessPrvCoInsAmt, BigDecimal outptClaimPlanCurrTotalExcessDeductAmt, BigDecimal outptClaimPlanCurrTotalExcessPvAmt, BigDecimal outptClaimPlanCurrTotalExcessAnnLimitAmt, BigDecimal outptClaimPlanCurrTotalExcessAnnMaxVisitAmt, BigDecimal outptClaimPlanCurrTotalExcessLtLimitAmt, BigDecimal outptClaimPlanCurrTotalExgratiaAmt, Boolean outptClaimAutoAdjudicateApproval, String outptClaimAutoAdjudicateMessage, Date outptClaimMcStartDate, Date outptClaimMcEndDate, String outptClaimRejectType, String outptClaimApprovalType, String outptClaimApprovalRemarks, Date outptClaimApprovalDate, String outptClaimApprovalByAbbvName, BigDecimal outptClaimApprovalBillCurrInsurerAmt, BigDecimal outptClaimApprovalBillCurrAsoAmt, BigDecimal outptClaimApprovalPlanCurrInsurerAmt, BigDecimal outptClaimApprovalPlanCurrAsoAmt, BigDecimal outptClaimOutptPayAdvAmount, BigDecimal outptClaimOutptPayAdvWhtAmt, BigDecimal outptClaimOutptPayAdvInterestAmt, String outptClaimInsBdxCurrency, BigDecimal outptClaimInsBdxAmount, BigDecimal outptClaimInsBdxForexRate, String outptClaimInsBdxForexStr, BigDecimal outptClaimInsCollectionAmount, Date outptClaimInsCollectionDate, String outptClaimAsoBdxCurrency, BigDecimal outptClaimAsoBdxAmount, BigDecimal outptClaimAsoBdxForexRate, String outptClaimAsoBdxForexStr, BigDecimal outptClaimAsoCollectionAmount, Date outptClaimAsoCollectionDate, Date outptClaimEclaimSubmissionDate, BigDecimal outptClaimEclaimDraftPerVisitLimit, Integer outptClaimEclaimDraftAvaiVisit, BigDecimal outptClaimEclaimDraftAvaiLimit, BigDecimal outptClaimEclaimDraftDeductible, String outptClaimEclaimDraftCoInsApplies, BigDecimal outptClaimCorporateDiscountAmt, BigDecimal outptClaimFurtherDiscountAmt, String outptClaimOtherDoctorName, String outptClaimOtherDoctorLisNum, Boolean outptClaimIsAgiApiSend, Boolean outptClaimIsAuditCase, Boolean outptClaimIsComplainCase, Boolean outptClaimIsCaseStudy, Boolean outptClaimIsLetterIssued, Date outptClaimAdmFaxInDate, Date outptClaimAdmFaxOutDate, Date outptClaimDiscFaxInDate, Date outptClaimDiscFaxOutDate, String outptClaimOtherDiagnosis, Date outptClaimSpecificIllnessDate, Date outptClaimGracePeriodDate, Date outptClaimWaitingPeriodDate, String outptClaimClientClaimId, String outptClaimClientPortalNo, Set<OutptClaimCalc> outptClaimCalcs, Set<OutptClaimSurgicalSchedule> outptClaimSurgicalSchedules, Set<OutptCasePhonelog> outptCasePhonelogs, Set<OutptClaimDoctor> outptClaimDoctors, Set<OutptClaimSymptom> outptClaimSymptoms, Set<OutptPaymentActivityLog> outptPaymentActivityLogs, Set<OutptClaimDrug> outptClaimDrugs, Set<OutptCaseWorkflowlog> outptCaseWorkflowlogs, Set<OutptCaseAdmin> outptCaseAdmins, Set<OutptClaimApproval> outptClaimApprovals, Set<OutptCaseImage> outptCaseImages, Set<OutptClaimDiagnosis> outptClaimDiagnosises, Set<OutptClaimFwaResult> outptClaimFwaResults, Set<OutptClaimItem> outptClaimItems, String outptClaimPaymentTo, String outptClaimPaymentMode, String outptClaimPayeeName, String outptClaimBankAccName, String outptClaimBankAccNum) {
     this.medicalProvider = medicalProvider;
     this.outptBdxByOutptClaimAsoOutptBdxId = outptBdxByOutptClaimAsoOutptBdxId;
     this.outptBdxByOutptClaimInsOutptBdxId = outptBdxByOutptClaimInsOutptBdxId;
     this.outptCase = outptCase;
     this.outptStatus = outptStatus;
     this.outptClaimPrefixId = outptClaimPrefixId;
     this.outptClaimEnabled = outptClaimEnabled;
     this.outptClaimCreatedDate = outptClaimCreatedDate;
     this.outptClaimCreatedByAbbvName = outptClaimCreatedByAbbvName;
     this.outptClaimLastEdittedDate = outptClaimLastEdittedDate;
     this.outptClaimLastEdittedByAbbvName = outptClaimLastEdittedByAbbvName;
     this.outptClaimPrevOutptClaimId = outptClaimPrevOutptClaimId;
     this.outptClaimExtRefId = outptClaimExtRefId;
     this.outptClaimOutptBenefitId = outptClaimOutptBenefitId;
     this.outptClaimOutptBenefitName = outptClaimOutptBenefitName;
     this.outptClaimOutptBenefitLocalName = outptClaimOutptBenefitLocalName;
     this.outptClaimOutptPlanBenefitId = outptClaimOutptPlanBenefitId;
     this.outptClaimOutptPlanBenefitExtCode = outptClaimOutptPlanBenefitExtCode;
     this.outptClaimOutptPlanBenefitGroupId = outptClaimOutptPlanBenefitGroupId;
     this.outptClaimOutptPlanBenefitGroupExtCode = outptClaimOutptPlanBenefitGroupExtCode;
     this.outptClaimOtherMedPrvName = outptClaimOtherMedPrvName;
     this.outptClaimType = outptClaimType;
     this.outptClaimCleanType = outptClaimCleanType;
     this.outptClaimStatusRemark = outptClaimStatusRemark;
     this.outptClaimPossibleDuplicate = outptClaimPossibleDuplicate;
     this.outptClaimImportedRecord = outptClaimImportedRecord;
     this.outptClaimIsEclaimRecord = outptClaimIsEclaimRecord;
     this.outptClaimIsEmemberRecord = outptClaimIsEmemberRecord;
     this.outptClaimIsAppRecord = outptClaimIsAppRecord;
     this.outptClaimSpecArrg = outptClaimSpecArrg;
     this.outptClaimGovHospLg = outptClaimGovHospLg;
     this.outptClaimB2b = outptClaimB2b;
     this.outptClaimPreAdm = outptClaimPreAdm;
     this.outptClaimAccident = outptClaimAccident;
     this.outptClaimAccidentDeath = outptClaimAccidentDeath;
     this.outptClaimAccidentDisable = outptClaimAccidentDisable;
     this.outptClaimIncidentDate = outptClaimIncidentDate;
     this.outptClaimNotificationDate = outptClaimNotificationDate;
     this.outptClaimVisitDate = outptClaimVisitDate;
     this.outptClaimPreAuthDate = outptClaimPreAuthDate;
     this.outptClaimAdmDateRecv = outptClaimAdmDateRecv;
     this.outptClaimAdmCountryId = outptClaimAdmCountryId;
     this.outptClaimDischargeDate = outptClaimDischargeDate;
     this.outptClaimDischargeDateRecv = outptClaimDischargeDateRecv;
     this.outptClaimFullInfoReceivedDate = outptClaimFullInfoReceivedDate;
     this.outptClaimBillReceivedDate = outptClaimBillReceivedDate;
     this.outptClaimEstLengthOfStay = outptClaimEstLengthOfStay;
     this.outptClaimLengthOfStay = outptClaimLengthOfStay;
     this.outptClaimRoomBedType = outptClaimRoomBedType;
     this.outptClaimInitDiagnosis = outptClaimInitDiagnosis;
     this.outptClaimRemark = outptClaimRemark;
     this.outptClaimPrvInvoiceNum = outptClaimPrvInvoiceNum;
     this.outptClaimPrvStatementNum = outptClaimPrvStatementNum;
     this.outptClaimPrvInvoiceDate = outptClaimPrvInvoiceDate;
     this.outptClaimPrvInvoiceOriginalAmount = outptClaimPrvInvoiceOriginalAmount;
     this.outptClaimFirstConsultationDate = outptClaimFirstConsultationDate;
     this.outptClaimSymptomOnsetDate = outptClaimSymptomOnsetDate;
     this.outptClaimPastTreatment = outptClaimPastTreatment;
     this.outptClaimPastTreatmentNote = outptClaimPastTreatmentNote;
     this.outptClaimHospitalMrnNumber = outptClaimHospitalMrnNumber;
     this.outptClaimHospitalAdmissionNumber = outptClaimHospitalAdmissionNumber;
     this.outptClaimCurrency = outptClaimCurrency;
     this.outptClaimForexRate = outptClaimForexRate;
     this.outptClaimForexStr = outptClaimForexStr;
     this.outptClaimEstCost = outptClaimEstCost;
     this.outptClaimReservedAmount = outptClaimReservedAmount;
     this.outptClaimInitialReservedAmount = outptClaimInitialReservedAmount;
     this.outptClaimEstInsurerAmt = outptClaimEstInsurerAmt;
     this.outptClaimEstPatientAmt = outptClaimEstPatientAmt;
     this.outptClaimEstRejectReason = outptClaimEstRejectReason;
     this.outptClaimEstSubmissionReservedAmt = outptClaimEstSubmissionReservedAmt;
     this.outptClaimEstSubmissionInsurerAmt = outptClaimEstSubmissionInsurerAmt;
     this.outptClaimEstSubmissionPatientAmt = outptClaimEstSubmissionPatientAmt;
     this.outptClaimEstSubmissionRejectReason = outptClaimEstSubmissionRejectReason;
     this.outptClaimInvCurrAdjustAsoAmt = outptClaimInvCurrAdjustAsoAmt;
     this.outptClaimInvCurrAdjustPtAmt = outptClaimInvCurrAdjustPtAmt;
     this.outptClaimAdjustRemark = outptClaimAdjustRemark;
     this.outptClaimInvCurrTotalAmt = outptClaimInvCurrTotalAmt;
     this.outptClaimInvCurrTotalDiscountAmt = outptClaimInvCurrTotalDiscountAmt;
     this.outptClaimInvCurrTotalGstAmt = outptClaimInvCurrTotalGstAmt;
     this.outptClaimInvCurrTotalExcessAmt = outptClaimInvCurrTotalExcessAmt;
     this.outptClaimInvCurrTotalGrandAmt = outptClaimInvCurrTotalGrandAmt;
     this.outptClaimInvCurrTotalInsAmt = outptClaimInvCurrTotalInsAmt;
     this.outptClaimInvCurrTotalAsoAmt = outptClaimInvCurrTotalAsoAmt;
     this.outptClaimInvCurrTotalPtAmt = outptClaimInvCurrTotalPtAmt;
     this.outptClaimInvCurrTotalExcessNonCoverAmt = outptClaimInvCurrTotalExcessNonCoverAmt;
     this.outptClaimInvCurrTotalExcessCoPayAmt = outptClaimInvCurrTotalExcessCoPayAmt;
     this.outptClaimInvCurrTotalExcessCoInsAmt = outptClaimInvCurrTotalExcessCoInsAmt;
     this.outptClaimInvCurrTotalExcessPrvCoInsAmt = outptClaimInvCurrTotalExcessPrvCoInsAmt;
     this.outptClaimInvCurrTotalExcessDeductAmt = outptClaimInvCurrTotalExcessDeductAmt;
     this.outptClaimInvCurrTotalExcessPvAmt = outptClaimInvCurrTotalExcessPvAmt;
     this.outptClaimInvCurrTotalExcessAnnLimitAmt = outptClaimInvCurrTotalExcessAnnLimitAmt;
     this.outptClaimInvCurrTotalExcessAnnMaxVisitAmt = outptClaimInvCurrTotalExcessAnnMaxVisitAmt;
     this.outptClaimInvCurrTotalExcessLtLimitAmt = outptClaimInvCurrTotalExcessLtLimitAmt;
     this.outptClaimInvCurrTotalExgratiaAmt = outptClaimInvCurrTotalExgratiaAmt;
     this.outptClaimPlanCurrency = outptClaimPlanCurrency;
     this.outptClaimPlanCurrTotalAmt = outptClaimPlanCurrTotalAmt;
     this.outptClaimPlanCurrTotalDiscountAmt = outptClaimPlanCurrTotalDiscountAmt;
     this.outptClaimPlanCurrTotalGstAmt = outptClaimPlanCurrTotalGstAmt;
     this.outptClaimPlanCurrTotalExcessAmt = outptClaimPlanCurrTotalExcessAmt;
     this.outptClaimPlanCurrTotalGrandAmt = outptClaimPlanCurrTotalGrandAmt;
     this.outptClaimPlanCurrTotalInsAmt = outptClaimPlanCurrTotalInsAmt;
     this.outptClaimPlanCurrTotalAsoAmt = outptClaimPlanCurrTotalAsoAmt;
     this.outptClaimPlanCurrTotalPtAmt = outptClaimPlanCurrTotalPtAmt;
     this.outptClaimPlanCurrTotalExcessNonCoverAmt = outptClaimPlanCurrTotalExcessNonCoverAmt;
     this.outptClaimPlanCurrTotalExcessCoPayAmt = outptClaimPlanCurrTotalExcessCoPayAmt;
     this.outptClaimPlanCurrTotalExcessCoInsAmt = outptClaimPlanCurrTotalExcessCoInsAmt;
     this.outptClaimPlanCurrTotalExcessPrvCoInsAmt = outptClaimPlanCurrTotalExcessPrvCoInsAmt;
     this.outptClaimPlanCurrTotalExcessDeductAmt = outptClaimPlanCurrTotalExcessDeductAmt;
     this.outptClaimPlanCurrTotalExcessPvAmt = outptClaimPlanCurrTotalExcessPvAmt;
     this.outptClaimPlanCurrTotalExcessAnnLimitAmt = outptClaimPlanCurrTotalExcessAnnLimitAmt;
     this.outptClaimPlanCurrTotalExcessAnnMaxVisitAmt = outptClaimPlanCurrTotalExcessAnnMaxVisitAmt;
     this.outptClaimPlanCurrTotalExcessLtLimitAmt = outptClaimPlanCurrTotalExcessLtLimitAmt;
     this.outptClaimPlanCurrTotalExgratiaAmt = outptClaimPlanCurrTotalExgratiaAmt;
     this.outptClaimAutoAdjudicateApproval = outptClaimAutoAdjudicateApproval;
     this.outptClaimAutoAdjudicateMessage = outptClaimAutoAdjudicateMessage;
     this.outptClaimMcStartDate = outptClaimMcStartDate;
     this.outptClaimMcEndDate = outptClaimMcEndDate;
     this.outptClaimRejectType = outptClaimRejectType;
     this.outptClaimApprovalType = outptClaimApprovalType;
     this.outptClaimApprovalRemarks = outptClaimApprovalRemarks;
     this.outptClaimApprovalDate = outptClaimApprovalDate;
     this.outptClaimApprovalByAbbvName = outptClaimApprovalByAbbvName;
     this.outptClaimApprovalBillCurrInsurerAmt = outptClaimApprovalBillCurrInsurerAmt;
     this.outptClaimApprovalBillCurrAsoAmt = outptClaimApprovalBillCurrAsoAmt;
     this.outptClaimApprovalPlanCurrInsurerAmt = outptClaimApprovalPlanCurrInsurerAmt;
     this.outptClaimApprovalPlanCurrAsoAmt = outptClaimApprovalPlanCurrAsoAmt;
     this.outptClaimOutptPayAdvAmount = outptClaimOutptPayAdvAmount;
     this.outptClaimOutptPayAdvWhtAmt = outptClaimOutptPayAdvWhtAmt;
     this.outptClaimOutptPayAdvInterestAmt = outptClaimOutptPayAdvInterestAmt;
     this.outptClaimInsBdxCurrency = outptClaimInsBdxCurrency;
     this.outptClaimInsBdxAmount = outptClaimInsBdxAmount;
     this.outptClaimInsBdxForexRate = outptClaimInsBdxForexRate;
     this.outptClaimInsBdxForexStr = outptClaimInsBdxForexStr;
     this.outptClaimInsCollectionAmount = outptClaimInsCollectionAmount;
     this.outptClaimInsCollectionDate = outptClaimInsCollectionDate;
     this.outptClaimAsoBdxCurrency = outptClaimAsoBdxCurrency;
     this.outptClaimAsoBdxAmount = outptClaimAsoBdxAmount;
     this.outptClaimAsoBdxForexRate = outptClaimAsoBdxForexRate;
     this.outptClaimAsoBdxForexStr = outptClaimAsoBdxForexStr;
     this.outptClaimAsoCollectionAmount = outptClaimAsoCollectionAmount;
     this.outptClaimAsoCollectionDate = outptClaimAsoCollectionDate;
     this.outptClaimEclaimSubmissionDate = outptClaimEclaimSubmissionDate;
     this.outptClaimEclaimDraftPerVisitLimit = outptClaimEclaimDraftPerVisitLimit;
     this.outptClaimEclaimDraftAvaiVisit = outptClaimEclaimDraftAvaiVisit;
     this.outptClaimEclaimDraftAvaiLimit = outptClaimEclaimDraftAvaiLimit;
     this.outptClaimEclaimDraftDeductible = outptClaimEclaimDraftDeductible;
     this.outptClaimEclaimDraftCoInsApplies = outptClaimEclaimDraftCoInsApplies;
     this.outptClaimCorporateDiscountAmt = outptClaimCorporateDiscountAmt;
     this.outptClaimFurtherDiscountAmt = outptClaimFurtherDiscountAmt;
     this.outptClaimOtherDoctorName = outptClaimOtherDoctorName;
     this.outptClaimOtherDoctorLisNum = outptClaimOtherDoctorLisNum;
     this.outptClaimIsAgiApiSend = outptClaimIsAgiApiSend;
     this.outptClaimIsAuditCase = outptClaimIsAuditCase;
     this.outptClaimIsComplainCase = outptClaimIsComplainCase;
     this.outptClaimIsCaseStudy = outptClaimIsCaseStudy;
     this.outptClaimIsLetterIssued = outptClaimIsLetterIssued;
     this.outptClaimAdmFaxInDate = outptClaimAdmFaxInDate;
     this.outptClaimAdmFaxOutDate = outptClaimAdmFaxOutDate;
     this.outptClaimDiscFaxInDate = outptClaimDiscFaxInDate;
     this.outptClaimDiscFaxOutDate = outptClaimDiscFaxOutDate;
     this.outptClaimOtherDiagnosis = outptClaimOtherDiagnosis;
     this.outptClaimSpecificIllnessDate = outptClaimSpecificIllnessDate;
     this.outptClaimGracePeriodDate = outptClaimGracePeriodDate;
     this.outptClaimWaitingPeriodDate = outptClaimWaitingPeriodDate;
     this.outptClaimClientClaimId = outptClaimClientClaimId;
     this.outptClaimClientPortalNo = outptClaimClientPortalNo;
     this.outptClaimCalcs = outptClaimCalcs;
     this.outptClaimSurgicalSchedules = outptClaimSurgicalSchedules;
     this.outptCasePhonelogs = outptCasePhonelogs;
     this.outptClaimDoctors = outptClaimDoctors;
     this.outptClaimSymptoms = outptClaimSymptoms;
     this.outptPaymentActivityLogs = outptPaymentActivityLogs;
     this.outptClaimDrugs = outptClaimDrugs;
     this.outptCaseWorkflowlogs = outptCaseWorkflowlogs;
     this.outptCaseAdmins = outptCaseAdmins;
     this.outptClaimApprovals = outptClaimApprovals;
     this.outptCaseImages = outptCaseImages;
     this.outptClaimDiagnosises = outptClaimDiagnosises;
     this.outptClaimFwaResults = outptClaimFwaResults;
     this.outptClaimItems = outptClaimItems;
     this.outptClaimPaymentTo = outptClaimPaymentTo;
     this.outptClaimPaymentMode = outptClaimPaymentMode;
     this.outptClaimPayeeName = outptClaimPayeeName;
     this.outptClaimBankAccName = outptClaimBankAccName;
     this.outptClaimBankAccNum = outptClaimBankAccNum;
    
 }

 @Id
 @GeneratedValue(strategy = IDENTITY)

 @Column(name = "outptClaimId", unique = true, nullable = false)
 public Integer getOutptClaimId() {
     return this.outptClaimId;
 }

 public void setOutptClaimId(Integer outptClaimId) {
     this.outptClaimId = outptClaimId;
 }
 
 // New column to save claim id with prefix and type
 @Column(name = "outptClaimPrefixId", unique = true, nullable = true)
 public String getOutptClaimPrefixId() {
     return this.outptClaimPrefixId;
 }

 public void setOutptClaimPrefixId(String outptClaimPrefixId) {
     this.outptClaimPrefixId = outptClaimPrefixId;
 }
 
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptClaimMedicalProviderId")
 public MedicalProvider getMedicalProvider() {
     return this.medicalProvider;
 }

 public void setMedicalProvider(MedicalProvider medicalProvider) {
     this.medicalProvider = medicalProvider;
 }
 
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptClaimAsoOutptBdxId")
 public OutptBdx getOutptBdxByOutptClaimAsoOutptBdxId() {
     return this.outptBdxByOutptClaimAsoOutptBdxId;
 }

 public void setOutptBdxByOutptClaimAsoOutptBdxId(OutptBdx outptBdxByOutptClaimAsoOutptBdxId) {
     this.outptBdxByOutptClaimAsoOutptBdxId = outptBdxByOutptClaimAsoOutptBdxId;
 }
 
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptClaimInsOutptBdxId")
 public OutptBdx getOutptBdxByOutptClaimInsOutptBdxId() {
     return this.outptBdxByOutptClaimInsOutptBdxId;
 }

 public void setOutptBdxByOutptClaimInsOutptBdxId(OutptBdx outptBdxByOutptClaimInsOutptBdxId) {
     this.outptBdxByOutptClaimInsOutptBdxId = outptBdxByOutptClaimInsOutptBdxId;
 }
 
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptClaimOutptCaseId", nullable = false)
 public OutptCase getOutptCase() {
     return this.outptCase;
 }

 public void setOutptCase(OutptCase outptCase) {
     this.outptCase = outptCase;
 }
 
 @ManyToOne(fetch = FetchType.LAZY)
 @JoinColumn(name = "outptClaimOutptStatusId", nullable = false)
 public OutptStatus getOutptStatus() {
     return this.outptStatus;
 }

 public void setOutptStatus(OutptStatus outptStatus) {
     this.outptStatus = outptStatus;
 }

 @Column(name = "outptClaimEnabled", nullable = false)
 public boolean isOutptClaimEnabled() {
     return this.outptClaimEnabled;
 }

 public void setOutptClaimEnabled(boolean outptClaimEnabled) {
     this.outptClaimEnabled = outptClaimEnabled;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimCreatedDate", length = 19)
 public Date getOutptClaimCreatedDate() {
     return this.outptClaimCreatedDate;
 }

 public void setOutptClaimCreatedDate(Date outptClaimCreatedDate) {
     this.outptClaimCreatedDate = outptClaimCreatedDate;
 }

 @Column(name = "outptClaimCreatedByAbbvName", length = 8)
 public String getOutptClaimCreatedByAbbvName() {
     return this.outptClaimCreatedByAbbvName;
 }

 public void setOutptClaimCreatedByAbbvName(String outptClaimCreatedByAbbvName) {
     this.outptClaimCreatedByAbbvName = outptClaimCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimLastEdittedDate", length = 19)
 public Date getOutptClaimLastEdittedDate() {
     return this.outptClaimLastEdittedDate;
 }

 public void setOutptClaimLastEdittedDate(Date outptClaimLastEdittedDate) {
     this.outptClaimLastEdittedDate = outptClaimLastEdittedDate;
 }

 @Column(name = "outptClaimLastEdittedByAbbvName", length = 8)
 public String getOutptClaimLastEdittedByAbbvName() {
     return this.outptClaimLastEdittedByAbbvName;
 }

 public void setOutptClaimLastEdittedByAbbvName(String outptClaimLastEdittedByAbbvName) {
     this.outptClaimLastEdittedByAbbvName = outptClaimLastEdittedByAbbvName;
 }

 @Column(name = "outptClaimPrevOutptClaimId")
 public Integer getOutptClaimPrevOutptClaimId() {
     return this.outptClaimPrevOutptClaimId;
 }

 public void setOutptClaimPrevOutptClaimId(Integer outptClaimPrevOutptClaimId) {
     this.outptClaimPrevOutptClaimId = outptClaimPrevOutptClaimId;
 }

 @Column(name = "outptClaimExtRefId", length = 20)
 public String getOutptClaimExtRefId() {
     return this.outptClaimExtRefId;
 }

 public void setOutptClaimExtRefId(String outptClaimExtRefId) {
     this.outptClaimExtRefId = outptClaimExtRefId;
 }

 @Column(name = "outptClaimOutptBenefitId")
 public Integer getOutptClaimOutptBenefitId() {
     return this.outptClaimOutptBenefitId;
 }

 public void setOutptClaimOutptBenefitId(Integer outptClaimOutptBenefitId) {
     this.outptClaimOutptBenefitId = outptClaimOutptBenefitId;
 }

 @Column(name = "outptClaimOutptBenefitName", length = 250)
 public String getOutptClaimOutptBenefitName() {
     return this.outptClaimOutptBenefitName;
 }

 public void setOutptClaimOutptBenefitName(String outptClaimOutptBenefitName) {
     this.outptClaimOutptBenefitName = outptClaimOutptBenefitName;
 }

 @Column(name = "outptClaimOutptBenefitLocalName", length = 250)
 public String getOutptClaimOutptBenefitLocalName() {
     return this.outptClaimOutptBenefitLocalName;
 }

 public void setOutptClaimOutptBenefitLocalName(String outptClaimOutptBenefitLocalName) {
     this.outptClaimOutptBenefitLocalName = outptClaimOutptBenefitLocalName;
 }

 @Column(name = "outptClaimOutptPlanBenefitId")
 public Integer getOutptClaimOutptPlanBenefitId() {
     return this.outptClaimOutptPlanBenefitId;
 }

 public void setOutptClaimOutptPlanBenefitId(Integer outptClaimOutptPlanBenefitId) {
     this.outptClaimOutptPlanBenefitId = outptClaimOutptPlanBenefitId;
 }

 @Column(name = "outptClaimOutptPlanBenefitExtCode", length = 20)
 public String getOutptClaimOutptPlanBenefitExtCode() {
     return this.outptClaimOutptPlanBenefitExtCode;
 }

 public void setOutptClaimOutptPlanBenefitExtCode(String outptClaimOutptPlanBenefitExtCode) {
     this.outptClaimOutptPlanBenefitExtCode = outptClaimOutptPlanBenefitExtCode;
 }

 @Column(name = "outptClaimOutptPlanBenefitGroupId")
 public Integer getOutptClaimOutptPlanBenefitGroupId() {
     return this.outptClaimOutptPlanBenefitGroupId;
 }

 public void setOutptClaimOutptPlanBenefitGroupId(Integer outptClaimOutptPlanBenefitGroupId) {
     this.outptClaimOutptPlanBenefitGroupId = outptClaimOutptPlanBenefitGroupId;
 }

 @Column(name = "outptClaimOutptPlanBenefitGroupExtCode", length = 20)
 public String getOutptClaimOutptPlanBenefitGroupExtCode() {
     return this.outptClaimOutptPlanBenefitGroupExtCode;
 }

 public void setOutptClaimOutptPlanBenefitGroupExtCode(String outptClaimOutptPlanBenefitGroupExtCode) {
     this.outptClaimOutptPlanBenefitGroupExtCode = outptClaimOutptPlanBenefitGroupExtCode;
 }

 @Column(name = "outptClaimOtherMedPrvName", length = 150)
 public String getOutptClaimOtherMedPrvName() {
     return this.outptClaimOtherMedPrvName;
 }

 public void setOutptClaimOtherMedPrvName(String outptClaimOtherMedPrvName) {
     this.outptClaimOtherMedPrvName = outptClaimOtherMedPrvName;
 }

 @Column(name = "outptClaimType", nullable = false, length = 2)
 public String getOutptClaimType() {
     return this.outptClaimType;
 }

 public void setOutptClaimType(String outptClaimType) {
     this.outptClaimType = outptClaimType;
 }

 @Column(name = "outptClaimCleanType", length = 10)
 public String getOutptClaimCleanType() {
     return this.outptClaimCleanType;
 }

 public void setOutptClaimCleanType(String outptClaimCleanType) {
     this.outptClaimCleanType = outptClaimCleanType;
 }

 @Column(name = "outptClaimStatusRemark", length = 250)
 public String getOutptClaimStatusRemark() {
     return this.outptClaimStatusRemark;
 }

 public void setOutptClaimStatusRemark(String outptClaimStatusRemark) {
     this.outptClaimStatusRemark = outptClaimStatusRemark;
 }

 @Column(name = "outptClaimPossibleDuplicate", nullable = false)
 public boolean isOutptClaimPossibleDuplicate() {
     return this.outptClaimPossibleDuplicate;
 }

 public void setOutptClaimPossibleDuplicate(boolean outptClaimPossibleDuplicate) {
     this.outptClaimPossibleDuplicate = outptClaimPossibleDuplicate;
 }

 @Column(name = "outptClaimImportedRecord", nullable = false)
 public boolean isOutptClaimImportedRecord() {
     return this.outptClaimImportedRecord;
 }

 public void setOutptClaimImportedRecord(boolean outptClaimImportedRecord) {
     this.outptClaimImportedRecord = outptClaimImportedRecord;
 }

 @Column(name = "outptClaimIsEclaimRecord", nullable = false)
 public boolean isOutptClaimIsEclaimRecord() {
     return this.outptClaimIsEclaimRecord;
 }

 public void setOutptClaimIsEclaimRecord(boolean outptClaimIsEclaimRecord) {
     this.outptClaimIsEclaimRecord = outptClaimIsEclaimRecord;
 }

 @Column(name = "outptClaimIsEmemberRecord", nullable = false)
 public boolean isOutptClaimIsEmemberRecord() {
     return this.outptClaimIsEmemberRecord;
 }

 public void setOutptClaimIsEmemberRecord(boolean outptClaimIsEmemberRecord) {
     this.outptClaimIsEmemberRecord = outptClaimIsEmemberRecord;
 }
 @Column(name="outptClaimIsAppRecord", nullable = false)
 public boolean isOutptClaimIsAppRecord(){
     return this.outptClaimIsAppRecord;
 }
 
 public void setOutptClaimIsAppRecord(boolean outptClaimIsAppRecord){
     this.outptClaimIsAppRecord = outptClaimIsAppRecord;
 }

 @Column(name = "outptClaimSpecArrg")
 public Boolean getOutptClaimSpecArrg() {
     return this.outptClaimSpecArrg;
 }

 public void setOutptClaimSpecArrg(Boolean outptClaimSpecArrg) {
     this.outptClaimSpecArrg = outptClaimSpecArrg;
 }

 @Column(name = "outptClaimGovHospLg")
 public Boolean getOutptClaimGovHospLg() {
     return this.outptClaimGovHospLg;
 }

 public void setOutptClaimGovHospLg(Boolean outptClaimGovHospLg) {
     this.outptClaimGovHospLg = outptClaimGovHospLg;
 }

 @Column(name = "outptClaimB2B")
 public Boolean getOutptClaimB2b() {
     return this.outptClaimB2b;
 }

 public void setOutptClaimB2b(Boolean outptClaimB2b) {
     this.outptClaimB2b = outptClaimB2b;
 }

 @Column(name = "outptClaimPreAdm")
 public Boolean getOutptClaimPreAdm() {
     return this.outptClaimPreAdm;
 }

 public void setOutptClaimPreAdm(Boolean outptClaimPreAdm) {
     this.outptClaimPreAdm = outptClaimPreAdm;
 }

 @Column(name = "outptClaimAccident")
 public Boolean getOutptClaimAccident() {
     return this.outptClaimAccident;
 }

 public void setOutptClaimAccident(Boolean outptClaimAccident) {
     this.outptClaimAccident = outptClaimAccident;
 }

 @Column(name = "outptClaimAccidentDeath")
 public Boolean getOutptClaimAccidentDeath() {
     return this.outptClaimAccidentDeath;
 }

 public void setOutptClaimAccidentDeath(Boolean outptClaimAccidentDeath) {
     this.outptClaimAccidentDeath = outptClaimAccidentDeath;
 }

 @Column(name = "outptClaimAccidentDisable")
 public Boolean getOutptClaimAccidentDisable() {
     return this.outptClaimAccidentDisable;
 }

 public void setOutptClaimAccidentDisable(Boolean outptClaimAccidentDisable) {
     this.outptClaimAccidentDisable = outptClaimAccidentDisable;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimIncidentDate", length = 19)
 public Date getOutptClaimIncidentDate() {
     return this.outptClaimIncidentDate;
 }

 public void setOutptClaimIncidentDate(Date outptClaimIncidentDate) {
     this.outptClaimIncidentDate = outptClaimIncidentDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimNotificationDate", length = 19)
 public Date getOutptClaimNotificationDate() {
     return this.outptClaimNotificationDate;
 }

 public void setOutptClaimNotificationDate(Date outptClaimNotificationDate) {
     this.outptClaimNotificationDate = outptClaimNotificationDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimVisitDate", length = 19)
 public Date getOutptClaimVisitDate() {
     return this.outptClaimVisitDate;
 }

 public void setOutptClaimVisitDate(Date outptClaimVisitDate) {
     this.outptClaimVisitDate = outptClaimVisitDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimPreAuthDate", length = 19)
 public Date getOutptClaimPreAuthDate() {
     return this.outptClaimPreAuthDate;
 }

 public void setOutptClaimPreAuthDate(Date outptClaimPreAuthDate) {
     this.outptClaimPreAuthDate = outptClaimPreAuthDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimAdmDateRecv", length = 19)
 public Date getOutptClaimAdmDateRecv() {
     return this.outptClaimAdmDateRecv;
 }

 public void setOutptClaimAdmDateRecv(Date outptClaimAdmDateRecv) {
     this.outptClaimAdmDateRecv = outptClaimAdmDateRecv;
 }

 @Column(name = "outptClaimAdmCountryId")
 public Integer getOutptClaimAdmCountryId() {
     return this.outptClaimAdmCountryId;
 }

 public void setOutptClaimAdmCountryId(Integer outptClaimAdmCountryId) {
     this.outptClaimAdmCountryId = outptClaimAdmCountryId;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimDischargeDate", length = 19)
 public Date getOutptClaimDischargeDate() {
     return this.outptClaimDischargeDate;
 }

 public void setOutptClaimDischargeDate(Date outptClaimDischargeDate) {
     this.outptClaimDischargeDate = outptClaimDischargeDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimDischargeDateRecv", length = 19)
 public Date getOutptClaimDischargeDateRecv() {
     return this.outptClaimDischargeDateRecv;
 }

 public void setOutptClaimDischargeDateRecv(Date outptClaimDischargeDateRecv) {
     this.outptClaimDischargeDateRecv = outptClaimDischargeDateRecv;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimFullInfoReceivedDate", length = 19)
 public Date getOutptClaimFullInfoReceivedDate() {
     return this.outptClaimFullInfoReceivedDate;
 }

 public void setOutptClaimFullInfoReceivedDate(Date outptClaimFullInfoReceivedDate) {
     this.outptClaimFullInfoReceivedDate = outptClaimFullInfoReceivedDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimBillReceivedDate", length = 19)
 public Date getOutptClaimBillReceivedDate() {
     return this.outptClaimBillReceivedDate;
 }

 public void setOutptClaimBillReceivedDate(Date outptClaimBillReceivedDate) {
     this.outptClaimBillReceivedDate = outptClaimBillReceivedDate;
 }

 @Column(name = "outptClaimEstLengthOfStay", precision = 5)
 public BigDecimal getOutptClaimEstLengthOfStay() {
     return this.outptClaimEstLengthOfStay;
 }

 public void setOutptClaimEstLengthOfStay(BigDecimal outptClaimEstLengthOfStay) {
     this.outptClaimEstLengthOfStay = outptClaimEstLengthOfStay;
 }

 @Column(name = "outptClaimLengthOfStay", precision = 5)
 public BigDecimal getOutptClaimLengthOfStay() {
     return this.outptClaimLengthOfStay;
 }

 public void setOutptClaimLengthOfStay(BigDecimal outptClaimLengthOfStay) {
     this.outptClaimLengthOfStay = outptClaimLengthOfStay;
 }

 @Column(name = "outptClaimRoomBedType")
 public Integer getOutptClaimRoomBedType() {
     return this.outptClaimRoomBedType;
 }

 public void setOutptClaimRoomBedType(Integer outptClaimRoomBedType) {
     this.outptClaimRoomBedType = outptClaimRoomBedType;
 }

 @Column(name = "outptClaimInitDiagnosis", length = 65535)
 public String getOutptClaimInitDiagnosis() {
     return this.outptClaimInitDiagnosis;
 }

 public void setOutptClaimInitDiagnosis(String outptClaimInitDiagnosis) {
     this.outptClaimInitDiagnosis = outptClaimInitDiagnosis;
 }

 @Column(name = "outptClaimRemark", length = 16777215)
 public String getOutptClaimRemark() {
     return this.outptClaimRemark;
 }

 public void setOutptClaimRemark(String outptClaimRemark) {
     this.outptClaimRemark = outptClaimRemark;
 }

 @Column(name = "outptClaimPrvInvoiceNum", length = 45)
 public String getOutptClaimPrvInvoiceNum() {
     return this.outptClaimPrvInvoiceNum;
 }

 public void setOutptClaimPrvInvoiceNum(String outptClaimPrvInvoiceNum) {
     this.outptClaimPrvInvoiceNum = outptClaimPrvInvoiceNum;
 }

 @Column(name = "outptClaimPrvStatementNum", length = 45)
 public String getOutptClaimPrvStatementNum() {
     return this.outptClaimPrvStatementNum;
 }

 public void setOutptClaimPrvStatementNum(String outptClaimPrvStatementNum) {
     this.outptClaimPrvStatementNum = outptClaimPrvStatementNum;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimPrvInvoiceDate", length = 10)
 public Date getOutptClaimPrvInvoiceDate() {
     return this.outptClaimPrvInvoiceDate;
 }

 public void setOutptClaimPrvInvoiceDate(Date outptClaimPrvInvoiceDate) {
     this.outptClaimPrvInvoiceDate = outptClaimPrvInvoiceDate;
 }

 @Column(name = "outptClaimPrvInvoiceOriginalAmount", precision = 16)
 public BigDecimal getOutptClaimPrvInvoiceOriginalAmount() {
     return this.outptClaimPrvInvoiceOriginalAmount;
 }

 public void setOutptClaimPrvInvoiceOriginalAmount(BigDecimal outptClaimPrvInvoiceOriginalAmount) {
     this.outptClaimPrvInvoiceOriginalAmount = outptClaimPrvInvoiceOriginalAmount;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimFirstConsultationDate", length = 10)
 public Date getOutptClaimFirstConsultationDate() {
     return this.outptClaimFirstConsultationDate;
 }

 public void setOutptClaimFirstConsultationDate(Date outptClaimFirstConsultationDate) {
     this.outptClaimFirstConsultationDate = outptClaimFirstConsultationDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimSymptomOnsetDate", length = 10)
 public Date getOutptClaimSymptomOnsetDate() {
     return this.outptClaimSymptomOnsetDate;
 }

 public void setOutptClaimSymptomOnsetDate(Date outptClaimSymptomOnsetDate) {
     this.outptClaimSymptomOnsetDate = outptClaimSymptomOnsetDate;
 }

 @Column(name = "outptClaimPastTreatment")
 public Boolean getOutptClaimPastTreatment() {
     return this.outptClaimPastTreatment;
 }

 public void setOutptClaimPastTreatment(Boolean outptClaimPastTreatment) {
     this.outptClaimPastTreatment = outptClaimPastTreatment;
 }

 @Column(name = "outptClaimPastTreatmentNote", length = 250)
 public String getOutptClaimPastTreatmentNote() {
     return this.outptClaimPastTreatmentNote;
 }

 public void setOutptClaimPastTreatmentNote(String outptClaimPastTreatmentNote) {
     this.outptClaimPastTreatmentNote = outptClaimPastTreatmentNote;
 }

 @Column(name = "outptClaimHospitalMrnNumber", length = 50)
 public String getOutptClaimHospitalMrnNumber() {
     return this.outptClaimHospitalMrnNumber;
 }

 public void setOutptClaimHospitalMrnNumber(String outptClaimHospitalMrnNumber) {
     this.outptClaimHospitalMrnNumber = outptClaimHospitalMrnNumber;
 }

 @Column(name = "outptClaimHospitalAdmissionNumber", length = 50)
 public String getOutptClaimHospitalAdmissionNumber() {
     return this.outptClaimHospitalAdmissionNumber;
 }

 public void setOutptClaimHospitalAdmissionNumber(String outptClaimHospitalAdmissionNumber) {
     this.outptClaimHospitalAdmissionNumber = outptClaimHospitalAdmissionNumber;
 }

 @Column(name = "outptClaimCurrency", length = 5)
 public String getOutptClaimCurrency() {
     return this.outptClaimCurrency;
 }

 public void setOutptClaimCurrency(String outptClaimCurrency) {
     this.outptClaimCurrency = outptClaimCurrency;
 }

 @Column(name = "outptClaimForexRate", nullable = false, precision = 10, scale = 6)
 public BigDecimal getOutptClaimForexRate() {
     return this.outptClaimForexRate;
 }

 public void setOutptClaimForexRate(BigDecimal outptClaimForexRate) {
     this.outptClaimForexRate = outptClaimForexRate;
 }

 @Column(name = "outptClaimForexStr", length = 10)
 public String getOutptClaimForexStr() {
     return this.outptClaimForexStr;
 }

 public void setOutptClaimForexStr(String outptClaimForexStr) {
     this.outptClaimForexStr = outptClaimForexStr;
 }

 @Column(name = "outptClaimEstCost", precision = 16)
 public BigDecimal getOutptClaimEstCost() {
     return this.outptClaimEstCost;
 }

 public void setOutptClaimEstCost(BigDecimal outptClaimEstCost) {
     this.outptClaimEstCost = outptClaimEstCost;
 }

 @Column(name = "outptClaimReservedAmount", nullable = false, precision = 16)
 public BigDecimal getOutptClaimReservedAmount() {
     return this.outptClaimReservedAmount;
 }

 public void setOutptClaimReservedAmount(BigDecimal outptClaimReservedAmount) {
     this.outptClaimReservedAmount = outptClaimReservedAmount;
 }

 @Column(name = "outptClaimInitialReservedAmount", precision = 16)
 public BigDecimal getOutptClaimInitialReservedAmount() {
     return this.outptClaimInitialReservedAmount;
 }

 public void setOutptClaimInitialReservedAmount(BigDecimal outptClaimInitialReservedAmount) {
     this.outptClaimInitialReservedAmount = outptClaimInitialReservedAmount;
 }

 @Column(name = "outptClaimEstInsurerAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimEstInsurerAmt() {
     return this.outptClaimEstInsurerAmt;
 }

 public void setOutptClaimEstInsurerAmt(BigDecimal outptClaimEstInsurerAmt) {
     this.outptClaimEstInsurerAmt = outptClaimEstInsurerAmt;
 }

 @Column(name = "outptClaimEstPatientAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimEstPatientAmt() {
     return this.outptClaimEstPatientAmt;
 }

 public void setOutptClaimEstPatientAmt(BigDecimal outptClaimEstPatientAmt) {
     this.outptClaimEstPatientAmt = outptClaimEstPatientAmt;
 }

 @Column(name = "outptClaimEstRejectReason", length = 250)
 public String getOutptClaimEstRejectReason() {
     return this.outptClaimEstRejectReason;
 }

 public void setOutptClaimEstRejectReason(String outptClaimEstRejectReason) {
     this.outptClaimEstRejectReason = outptClaimEstRejectReason;
 }

 @Column(name = "outptClaimEstSubmissionReservedAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimEstSubmissionReservedAmt() {
     return this.outptClaimEstSubmissionReservedAmt;
 }

 public void setOutptClaimEstSubmissionReservedAmt(BigDecimal outptClaimEstSubmissionReservedAmt) {
     this.outptClaimEstSubmissionReservedAmt = outptClaimEstSubmissionReservedAmt;
 }

 @Column(name = "outptClaimEstSubmissionInsurerAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimEstSubmissionInsurerAmt() {
     return this.outptClaimEstSubmissionInsurerAmt;
 }

 public void setOutptClaimEstSubmissionInsurerAmt(BigDecimal outptClaimEstSubmissionInsurerAmt) {
     this.outptClaimEstSubmissionInsurerAmt = outptClaimEstSubmissionInsurerAmt;
 }

 @Column(name = "outptClaimEstSubmissionPatientAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimEstSubmissionPatientAmt() {
     return this.outptClaimEstSubmissionPatientAmt;
 }

 public void setOutptClaimEstSubmissionPatientAmt(BigDecimal outptClaimEstSubmissionPatientAmt) {
     this.outptClaimEstSubmissionPatientAmt = outptClaimEstSubmissionPatientAmt;
 }

 @Column(name = "outptClaimEstSubmissionRejectReason", length = 250)
 public String getOutptClaimEstSubmissionRejectReason() {
     return this.outptClaimEstSubmissionRejectReason;
 }

 public void setOutptClaimEstSubmissionRejectReason(String outptClaimEstSubmissionRejectReason) {
     this.outptClaimEstSubmissionRejectReason = outptClaimEstSubmissionRejectReason;
 }

 @Column(name = "outptClaimInvCurrAdjustAsoAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrAdjustAsoAmt() {
     return this.outptClaimInvCurrAdjustAsoAmt;
 }

 public void setOutptClaimInvCurrAdjustAsoAmt(BigDecimal outptClaimInvCurrAdjustAsoAmt) {
     this.outptClaimInvCurrAdjustAsoAmt = outptClaimInvCurrAdjustAsoAmt;
 }

 @Column(name = "outptClaimInvCurrAdjustPtAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrAdjustPtAmt() {
     return this.outptClaimInvCurrAdjustPtAmt;
 }

 public void setOutptClaimInvCurrAdjustPtAmt(BigDecimal outptClaimInvCurrAdjustPtAmt) {
     this.outptClaimInvCurrAdjustPtAmt = outptClaimInvCurrAdjustPtAmt;
 }

 @Column(name = "outptClaimAdjustRemark", length = 250)
 public String getOutptClaimAdjustRemark() {
     return this.outptClaimAdjustRemark;
 }

 public void setOutptClaimAdjustRemark(String outptClaimAdjustRemark) {
     this.outptClaimAdjustRemark = outptClaimAdjustRemark;
 }

 @Column(name = "outptClaimInvCurrTotalAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalAmt() {
     return this.outptClaimInvCurrTotalAmt;
 }

 public void setOutptClaimInvCurrTotalAmt(BigDecimal outptClaimInvCurrTotalAmt) {
     this.outptClaimInvCurrTotalAmt = outptClaimInvCurrTotalAmt;
 }

 @Column(name = "outptClaimInvCurrTotalDiscountAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalDiscountAmt() {
     return this.outptClaimInvCurrTotalDiscountAmt;
 }

 public void setOutptClaimInvCurrTotalDiscountAmt(BigDecimal outptClaimInvCurrTotalDiscountAmt) {
     this.outptClaimInvCurrTotalDiscountAmt = outptClaimInvCurrTotalDiscountAmt;
 }

 @Column(name = "outptClaimInvCurrTotalGstAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalGstAmt() {
     return this.outptClaimInvCurrTotalGstAmt;
 }

 public void setOutptClaimInvCurrTotalGstAmt(BigDecimal outptClaimInvCurrTotalGstAmt) {
     this.outptClaimInvCurrTotalGstAmt = outptClaimInvCurrTotalGstAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessAmt() {
     return this.outptClaimInvCurrTotalExcessAmt;
 }

 public void setOutptClaimInvCurrTotalExcessAmt(BigDecimal outptClaimInvCurrTotalExcessAmt) {
     this.outptClaimInvCurrTotalExcessAmt = outptClaimInvCurrTotalExcessAmt;
 }

 @Column(name = "outptClaimInvCurrTotalGrandAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalGrandAmt() {
     return this.outptClaimInvCurrTotalGrandAmt;
 }

 public void setOutptClaimInvCurrTotalGrandAmt(BigDecimal outptClaimInvCurrTotalGrandAmt) {
     this.outptClaimInvCurrTotalGrandAmt = outptClaimInvCurrTotalGrandAmt;
 }

 @Column(name = "outptClaimInvCurrTotalInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalInsAmt() {
     return this.outptClaimInvCurrTotalInsAmt;
 }

 public void setOutptClaimInvCurrTotalInsAmt(BigDecimal outptClaimInvCurrTotalInsAmt) {
     this.outptClaimInvCurrTotalInsAmt = outptClaimInvCurrTotalInsAmt;
 }

 @Column(name = "outptClaimInvCurrTotalAsoAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalAsoAmt() {
     return this.outptClaimInvCurrTotalAsoAmt;
 }

 public void setOutptClaimInvCurrTotalAsoAmt(BigDecimal outptClaimInvCurrTotalAsoAmt) {
     this.outptClaimInvCurrTotalAsoAmt = outptClaimInvCurrTotalAsoAmt;
 }

 @Column(name = "outptClaimInvCurrTotalPtAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalPtAmt() {
     return this.outptClaimInvCurrTotalPtAmt;
 }

 public void setOutptClaimInvCurrTotalPtAmt(BigDecimal outptClaimInvCurrTotalPtAmt) {
     this.outptClaimInvCurrTotalPtAmt = outptClaimInvCurrTotalPtAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessNonCoverAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessNonCoverAmt() {
     return this.outptClaimInvCurrTotalExcessNonCoverAmt;
 }

 public void setOutptClaimInvCurrTotalExcessNonCoverAmt(BigDecimal outptClaimInvCurrTotalExcessNonCoverAmt) {
     this.outptClaimInvCurrTotalExcessNonCoverAmt = outptClaimInvCurrTotalExcessNonCoverAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessCoPayAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessCoPayAmt() {
     return this.outptClaimInvCurrTotalExcessCoPayAmt;
 }

 public void setOutptClaimInvCurrTotalExcessCoPayAmt(BigDecimal outptClaimInvCurrTotalExcessCoPayAmt) {
     this.outptClaimInvCurrTotalExcessCoPayAmt = outptClaimInvCurrTotalExcessCoPayAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessCoInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessCoInsAmt() {
     return this.outptClaimInvCurrTotalExcessCoInsAmt;
 }

 public void setOutptClaimInvCurrTotalExcessCoInsAmt(BigDecimal outptClaimInvCurrTotalExcessCoInsAmt) {
     this.outptClaimInvCurrTotalExcessCoInsAmt = outptClaimInvCurrTotalExcessCoInsAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessPrvCoInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessPrvCoInsAmt() {
     return this.outptClaimInvCurrTotalExcessPrvCoInsAmt;
 }

 public void setOutptClaimInvCurrTotalExcessPrvCoInsAmt(BigDecimal outptClaimInvCurrTotalExcessPrvCoInsAmt) {
     this.outptClaimInvCurrTotalExcessPrvCoInsAmt = outptClaimInvCurrTotalExcessPrvCoInsAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessDeductAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessDeductAmt() {
     return this.outptClaimInvCurrTotalExcessDeductAmt;
 }

 public void setOutptClaimInvCurrTotalExcessDeductAmt(BigDecimal outptClaimInvCurrTotalExcessDeductAmt) {
     this.outptClaimInvCurrTotalExcessDeductAmt = outptClaimInvCurrTotalExcessDeductAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessPvAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessPvAmt() {
     return this.outptClaimInvCurrTotalExcessPvAmt;
 }

 public void setOutptClaimInvCurrTotalExcessPvAmt(BigDecimal outptClaimInvCurrTotalExcessPvAmt) {
     this.outptClaimInvCurrTotalExcessPvAmt = outptClaimInvCurrTotalExcessPvAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessAnnLimitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessAnnLimitAmt() {
     return this.outptClaimInvCurrTotalExcessAnnLimitAmt;
 }

 public void setOutptClaimInvCurrTotalExcessAnnLimitAmt(BigDecimal outptClaimInvCurrTotalExcessAnnLimitAmt) {
     this.outptClaimInvCurrTotalExcessAnnLimitAmt = outptClaimInvCurrTotalExcessAnnLimitAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessAnnMaxVisitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessAnnMaxVisitAmt() {
     return this.outptClaimInvCurrTotalExcessAnnMaxVisitAmt;
 }

 public void setOutptClaimInvCurrTotalExcessAnnMaxVisitAmt(BigDecimal outptClaimInvCurrTotalExcessAnnMaxVisitAmt) {
     this.outptClaimInvCurrTotalExcessAnnMaxVisitAmt = outptClaimInvCurrTotalExcessAnnMaxVisitAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExcessLtLimitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExcessLtLimitAmt() {
     return this.outptClaimInvCurrTotalExcessLtLimitAmt;
 }

 public void setOutptClaimInvCurrTotalExcessLtLimitAmt(BigDecimal outptClaimInvCurrTotalExcessLtLimitAmt) {
     this.outptClaimInvCurrTotalExcessLtLimitAmt = outptClaimInvCurrTotalExcessLtLimitAmt;
 }

 @Column(name = "outptClaimInvCurrTotalExgratiaAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimInvCurrTotalExgratiaAmt() {
     return this.outptClaimInvCurrTotalExgratiaAmt;
 }

 public void setOutptClaimInvCurrTotalExgratiaAmt(BigDecimal outptClaimInvCurrTotalExgratiaAmt) {
     this.outptClaimInvCurrTotalExgratiaAmt = outptClaimInvCurrTotalExgratiaAmt;
 }

 @Column(name = "outptClaimPlanCurrency", length = 5)
 public String getOutptClaimPlanCurrency() {
     return this.outptClaimPlanCurrency;
 }

 public void setOutptClaimPlanCurrency(String outptClaimPlanCurrency) {
     this.outptClaimPlanCurrency = outptClaimPlanCurrency;
 }

 @Column(name = "outptClaimPlanCurrTotalAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalAmt() {
     return this.outptClaimPlanCurrTotalAmt;
 }

 public void setOutptClaimPlanCurrTotalAmt(BigDecimal outptClaimPlanCurrTotalAmt) {
     this.outptClaimPlanCurrTotalAmt = outptClaimPlanCurrTotalAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalDiscountAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalDiscountAmt() {
     return this.outptClaimPlanCurrTotalDiscountAmt;
 }

 public void setOutptClaimPlanCurrTotalDiscountAmt(BigDecimal outptClaimPlanCurrTotalDiscountAmt) {
     this.outptClaimPlanCurrTotalDiscountAmt = outptClaimPlanCurrTotalDiscountAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalGstAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalGstAmt() {
     return this.outptClaimPlanCurrTotalGstAmt;
 }

 public void setOutptClaimPlanCurrTotalGstAmt(BigDecimal outptClaimPlanCurrTotalGstAmt) {
     this.outptClaimPlanCurrTotalGstAmt = outptClaimPlanCurrTotalGstAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessAmt() {
     return this.outptClaimPlanCurrTotalExcessAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessAmt(BigDecimal outptClaimPlanCurrTotalExcessAmt) {
     this.outptClaimPlanCurrTotalExcessAmt = outptClaimPlanCurrTotalExcessAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalGrandAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalGrandAmt() {
     return this.outptClaimPlanCurrTotalGrandAmt;
 }

 public void setOutptClaimPlanCurrTotalGrandAmt(BigDecimal outptClaimPlanCurrTotalGrandAmt) {
     this.outptClaimPlanCurrTotalGrandAmt = outptClaimPlanCurrTotalGrandAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalInsAmt() {
     return this.outptClaimPlanCurrTotalInsAmt;
 }

 public void setOutptClaimPlanCurrTotalInsAmt(BigDecimal outptClaimPlanCurrTotalInsAmt) {
     this.outptClaimPlanCurrTotalInsAmt = outptClaimPlanCurrTotalInsAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalAsoAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalAsoAmt() {
     return this.outptClaimPlanCurrTotalAsoAmt;
 }

 public void setOutptClaimPlanCurrTotalAsoAmt(BigDecimal outptClaimPlanCurrTotalAsoAmt) {
     this.outptClaimPlanCurrTotalAsoAmt = outptClaimPlanCurrTotalAsoAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalPtAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalPtAmt() {
     return this.outptClaimPlanCurrTotalPtAmt;
 }

 public void setOutptClaimPlanCurrTotalPtAmt(BigDecimal outptClaimPlanCurrTotalPtAmt) {
     this.outptClaimPlanCurrTotalPtAmt = outptClaimPlanCurrTotalPtAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessNonCoverAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessNonCoverAmt() {
     return this.outptClaimPlanCurrTotalExcessNonCoverAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessNonCoverAmt(BigDecimal outptClaimPlanCurrTotalExcessNonCoverAmt) {
     this.outptClaimPlanCurrTotalExcessNonCoverAmt = outptClaimPlanCurrTotalExcessNonCoverAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessCoPayAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessCoPayAmt() {
     return this.outptClaimPlanCurrTotalExcessCoPayAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessCoPayAmt(BigDecimal outptClaimPlanCurrTotalExcessCoPayAmt) {
     this.outptClaimPlanCurrTotalExcessCoPayAmt = outptClaimPlanCurrTotalExcessCoPayAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessCoInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessCoInsAmt() {
     return this.outptClaimPlanCurrTotalExcessCoInsAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessCoInsAmt(BigDecimal outptClaimPlanCurrTotalExcessCoInsAmt) {
     this.outptClaimPlanCurrTotalExcessCoInsAmt = outptClaimPlanCurrTotalExcessCoInsAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessPrvCoInsAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessPrvCoInsAmt() {
     return this.outptClaimPlanCurrTotalExcessPrvCoInsAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessPrvCoInsAmt(BigDecimal outptClaimPlanCurrTotalExcessPrvCoInsAmt) {
     this.outptClaimPlanCurrTotalExcessPrvCoInsAmt = outptClaimPlanCurrTotalExcessPrvCoInsAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessDeductAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessDeductAmt() {
     return this.outptClaimPlanCurrTotalExcessDeductAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessDeductAmt(BigDecimal outptClaimPlanCurrTotalExcessDeductAmt) {
     this.outptClaimPlanCurrTotalExcessDeductAmt = outptClaimPlanCurrTotalExcessDeductAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessPvAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessPvAmt() {
     return this.outptClaimPlanCurrTotalExcessPvAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessPvAmt(BigDecimal outptClaimPlanCurrTotalExcessPvAmt) {
     this.outptClaimPlanCurrTotalExcessPvAmt = outptClaimPlanCurrTotalExcessPvAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessAnnLimitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessAnnLimitAmt() {
     return this.outptClaimPlanCurrTotalExcessAnnLimitAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessAnnLimitAmt(BigDecimal outptClaimPlanCurrTotalExcessAnnLimitAmt) {
     this.outptClaimPlanCurrTotalExcessAnnLimitAmt = outptClaimPlanCurrTotalExcessAnnLimitAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessAnnMaxVisitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessAnnMaxVisitAmt() {
     return this.outptClaimPlanCurrTotalExcessAnnMaxVisitAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessAnnMaxVisitAmt(BigDecimal outptClaimPlanCurrTotalExcessAnnMaxVisitAmt) {
     this.outptClaimPlanCurrTotalExcessAnnMaxVisitAmt = outptClaimPlanCurrTotalExcessAnnMaxVisitAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExcessLtLimitAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExcessLtLimitAmt() {
     return this.outptClaimPlanCurrTotalExcessLtLimitAmt;
 }

 public void setOutptClaimPlanCurrTotalExcessLtLimitAmt(BigDecimal outptClaimPlanCurrTotalExcessLtLimitAmt) {
     this.outptClaimPlanCurrTotalExcessLtLimitAmt = outptClaimPlanCurrTotalExcessLtLimitAmt;
 }

 @Column(name = "outptClaimPlanCurrTotalExgratiaAmt", nullable = false, precision = 16)
 public BigDecimal getOutptClaimPlanCurrTotalExgratiaAmt() {
     return this.outptClaimPlanCurrTotalExgratiaAmt;
 }

 public void setOutptClaimPlanCurrTotalExgratiaAmt(BigDecimal outptClaimPlanCurrTotalExgratiaAmt) {
     this.outptClaimPlanCurrTotalExgratiaAmt = outptClaimPlanCurrTotalExgratiaAmt;
 }

 @Column(name = "outptClaimAutoAdjudicateApproval")
 public Boolean getOutptClaimAutoAdjudicateApproval() {
     return this.outptClaimAutoAdjudicateApproval;
 }

 public void setOutptClaimAutoAdjudicateApproval(Boolean outptClaimAutoAdjudicateApproval) {
     this.outptClaimAutoAdjudicateApproval = outptClaimAutoAdjudicateApproval;
 }

 @Column(name = "outptClaimAutoAdjudicateMessage", length = 16777215)
 public String getOutptClaimAutoAdjudicateMessage() {
     return this.outptClaimAutoAdjudicateMessage;
 }

 public void setOutptClaimAutoAdjudicateMessage(String outptClaimAutoAdjudicateMessage) {
     this.outptClaimAutoAdjudicateMessage = outptClaimAutoAdjudicateMessage;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimMcStartDate", length = 10)
 public Date getOutptClaimMcStartDate() {
     return this.outptClaimMcStartDate;
 }

 public void setOutptClaimMcStartDate(Date outptClaimMcStartDate) {
     this.outptClaimMcStartDate = outptClaimMcStartDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimMcEndDate", length = 10)
 public Date getOutptClaimMcEndDate() {
     return this.outptClaimMcEndDate;
 }

 public void setOutptClaimMcEndDate(Date outptClaimMcEndDate) {
     this.outptClaimMcEndDate = outptClaimMcEndDate;
 }

 @Column(name = "outptClaimRejectType", length = 2)
 public String getOutptClaimRejectType() {
     return this.outptClaimRejectType;
 }

 public void setOutptClaimRejectType(String outptClaimRejectType) {
     this.outptClaimRejectType = outptClaimRejectType;
 }

 @Column(name = "outptClaimApprovalType", length = 1)
 public String getOutptClaimApprovalType() {
     return this.outptClaimApprovalType;
 }

 public void setOutptClaimApprovalType(String outptClaimApprovalType) {
     this.outptClaimApprovalType = outptClaimApprovalType;
 }

 @Column(name = "outptClaimApprovalRemarks", length = 250)
 public String getOutptClaimApprovalRemarks() {
     return this.outptClaimApprovalRemarks;
 }

 public void setOutptClaimApprovalRemarks(String outptClaimApprovalRemarks) {
     this.outptClaimApprovalRemarks = outptClaimApprovalRemarks;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimApprovalDate", length = 19)
 public Date getOutptClaimApprovalDate() {
     return this.outptClaimApprovalDate;
 }

 public void setOutptClaimApprovalDate(Date outptClaimApprovalDate) {
     this.outptClaimApprovalDate = outptClaimApprovalDate;
 }

 @Column(name = "outptClaimApprovalByAbbvName", length = 8)
 public String getOutptClaimApprovalByAbbvName() {
     return this.outptClaimApprovalByAbbvName;
 }

 public void setOutptClaimApprovalByAbbvName(String outptClaimApprovalByAbbvName) {
     this.outptClaimApprovalByAbbvName = outptClaimApprovalByAbbvName;
 }

 @Column(name = "outptClaimApprovalBillCurrInsurerAmt", precision = 16)
 public BigDecimal getOutptClaimApprovalBillCurrInsurerAmt() {
     return this.outptClaimApprovalBillCurrInsurerAmt;
 }

 public void setOutptClaimApprovalBillCurrInsurerAmt(BigDecimal outptClaimApprovalBillCurrInsurerAmt) {
     this.outptClaimApprovalBillCurrInsurerAmt = outptClaimApprovalBillCurrInsurerAmt;
 }

 @Column(name = "outptClaimApprovalBillCurrAsoAmt", precision = 16)
 public BigDecimal getOutptClaimApprovalBillCurrAsoAmt() {
     return this.outptClaimApprovalBillCurrAsoAmt;
 }

 public void setOutptClaimApprovalBillCurrAsoAmt(BigDecimal outptClaimApprovalBillCurrAsoAmt) {
     this.outptClaimApprovalBillCurrAsoAmt = outptClaimApprovalBillCurrAsoAmt;
 }

 @Column(name = "outptClaimApprovalPlanCurrInsurerAmt", precision = 16)
 public BigDecimal getOutptClaimApprovalPlanCurrInsurerAmt() {
     return this.outptClaimApprovalPlanCurrInsurerAmt;
 }

 public void setOutptClaimApprovalPlanCurrInsurerAmt(BigDecimal outptClaimApprovalPlanCurrInsurerAmt) {
     this.outptClaimApprovalPlanCurrInsurerAmt = outptClaimApprovalPlanCurrInsurerAmt;
 }

 @Column(name = "outptClaimApprovalPlanCurrAsoAmt", precision = 16)
 public BigDecimal getOutptClaimApprovalPlanCurrAsoAmt() {
     return this.outptClaimApprovalPlanCurrAsoAmt;
 }

 public void setOutptClaimApprovalPlanCurrAsoAmt(BigDecimal outptClaimApprovalPlanCurrAsoAmt) {
     this.outptClaimApprovalPlanCurrAsoAmt = outptClaimApprovalPlanCurrAsoAmt;
 }

 @Column(name = "outptClaimOutptPayAdvAmount", precision = 16)
 public BigDecimal getOutptClaimOutptPayAdvAmount() {
     return this.outptClaimOutptPayAdvAmount;
 }

 public void setOutptClaimOutptPayAdvAmount(BigDecimal outptClaimOutptPayAdvAmount) {
     this.outptClaimOutptPayAdvAmount = outptClaimOutptPayAdvAmount;
 }

 @Column(name = "outptClaimOutptPayAdvWhtAmt", precision = 16)
 public BigDecimal getOutptClaimOutptPayAdvWhtAmt() {
     return this.outptClaimOutptPayAdvWhtAmt;
 }

 public void setOutptClaimOutptPayAdvWhtAmt(BigDecimal outptClaimOutptPayAdvWhtAmt) {
     this.outptClaimOutptPayAdvWhtAmt = outptClaimOutptPayAdvWhtAmt;
 }

 @Column(name = "outptClaimOutptPayAdvInterestAmt", precision = 16)
 public BigDecimal getOutptClaimOutptPayAdvInterestAmt() {
     return this.outptClaimOutptPayAdvInterestAmt;
 }

 public void setOutptClaimOutptPayAdvInterestAmt(BigDecimal outptClaimOutptPayAdvInterestAmt) {
     this.outptClaimOutptPayAdvInterestAmt = outptClaimOutptPayAdvInterestAmt;
 }

 @Column(name = "outptClaimInsBdxCurrency", length = 3)
 public String getOutptClaimInsBdxCurrency() {
     return this.outptClaimInsBdxCurrency;
 }

 public void setOutptClaimInsBdxCurrency(String outptClaimInsBdxCurrency) {
     this.outptClaimInsBdxCurrency = outptClaimInsBdxCurrency;
 }

 @Column(name = "outptClaimInsBdxAmount", precision = 16)
 public BigDecimal getOutptClaimInsBdxAmount() {
     return this.outptClaimInsBdxAmount;
 }

 public void setOutptClaimInsBdxAmount(BigDecimal outptClaimInsBdxAmount) {
     this.outptClaimInsBdxAmount = outptClaimInsBdxAmount;
 }

 @Column(name = "outptClaimInsBdxForexRate", precision = 10, scale = 6)
 public BigDecimal getOutptClaimInsBdxForexRate() {
     return this.outptClaimInsBdxForexRate;
 }

 public void setOutptClaimInsBdxForexRate(BigDecimal outptClaimInsBdxForexRate) {
     this.outptClaimInsBdxForexRate = outptClaimInsBdxForexRate;
 }

 @Column(name = "outptClaimInsBdxForexStr", length = 10)
 public String getOutptClaimInsBdxForexStr() {
     return this.outptClaimInsBdxForexStr;
 }

 public void setOutptClaimInsBdxForexStr(String outptClaimInsBdxForexStr) {
     this.outptClaimInsBdxForexStr = outptClaimInsBdxForexStr;
 }

 @Column(name = "outptClaimInsCollectionAmount", precision = 16)
 public BigDecimal getOutptClaimInsCollectionAmount() {
     return this.outptClaimInsCollectionAmount;
 }

 public void setOutptClaimInsCollectionAmount(BigDecimal outptClaimInsCollectionAmount) {
     this.outptClaimInsCollectionAmount = outptClaimInsCollectionAmount;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimInsCollectionDate", length = 19)
 public Date getOutptClaimInsCollectionDate() {
     return this.outptClaimInsCollectionDate;
 }

 public void setOutptClaimInsCollectionDate(Date outptClaimInsCollectionDate) {
     this.outptClaimInsCollectionDate = outptClaimInsCollectionDate;
 }

 @Column(name = "outptClaimAsoBdxCurrency", length = 3)
 public String getOutptClaimAsoBdxCurrency() {
     return this.outptClaimAsoBdxCurrency;
 }

 public void setOutptClaimAsoBdxCurrency(String outptClaimAsoBdxCurrency) {
     this.outptClaimAsoBdxCurrency = outptClaimAsoBdxCurrency;
 }

 @Column(name = "outptClaimAsoBdxAmount", precision = 16)
 public BigDecimal getOutptClaimAsoBdxAmount() {
     return this.outptClaimAsoBdxAmount;
 }

 public void setOutptClaimAsoBdxAmount(BigDecimal outptClaimAsoBdxAmount) {
     this.outptClaimAsoBdxAmount = outptClaimAsoBdxAmount;
 }

 @Column(name = "outptClaimAsoBdxForexRate", precision = 10, scale = 6)
 public BigDecimal getOutptClaimAsoBdxForexRate() {
     return this.outptClaimAsoBdxForexRate;
 }

 public void setOutptClaimAsoBdxForexRate(BigDecimal outptClaimAsoBdxForexRate) {
     this.outptClaimAsoBdxForexRate = outptClaimAsoBdxForexRate;
 }

 @Column(name = "outptClaimAsoBdxForexStr", length = 10)
 public String getOutptClaimAsoBdxForexStr() {
     return this.outptClaimAsoBdxForexStr;
 }

 public void setOutptClaimAsoBdxForexStr(String outptClaimAsoBdxForexStr) {
     this.outptClaimAsoBdxForexStr = outptClaimAsoBdxForexStr;
 }

 @Column(name = "outptClaimAsoCollectionAmount", precision = 16)
 public BigDecimal getOutptClaimAsoCollectionAmount() {
     return this.outptClaimAsoCollectionAmount;
 }

 public void setOutptClaimAsoCollectionAmount(BigDecimal outptClaimAsoCollectionAmount) {
     this.outptClaimAsoCollectionAmount = outptClaimAsoCollectionAmount;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimAsoCollectionDate", length = 19)
 public Date getOutptClaimAsoCollectionDate() {
     return this.outptClaimAsoCollectionDate;
 }

 public void setOutptClaimAsoCollectionDate(Date outptClaimAsoCollectionDate) {
     this.outptClaimAsoCollectionDate = outptClaimAsoCollectionDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimEclaimSubmissionDate", length = 19)
 public Date getOutptClaimEclaimSubmissionDate() {
     return this.outptClaimEclaimSubmissionDate;
 }

 public void setOutptClaimEclaimSubmissionDate(Date outptClaimEclaimSubmissionDate) {
     this.outptClaimEclaimSubmissionDate = outptClaimEclaimSubmissionDate;
 }

 @Column(name = "outptClaimEclaimDraftPerVisitLimit", precision = 16)
 public BigDecimal getOutptClaimEclaimDraftPerVisitLimit() {
     return this.outptClaimEclaimDraftPerVisitLimit;
 }

 public void setOutptClaimEclaimDraftPerVisitLimit(BigDecimal outptClaimEclaimDraftPerVisitLimit) {
     this.outptClaimEclaimDraftPerVisitLimit = outptClaimEclaimDraftPerVisitLimit;
 }

 @Column(name = "outptClaimEclaimDraftAvaiVisit")
 public Integer getOutptClaimEclaimDraftAvaiVisit() {
     return this.outptClaimEclaimDraftAvaiVisit;
 }

 public void setOutptClaimEclaimDraftAvaiVisit(Integer outptClaimEclaimDraftAvaiVisit) {
     this.outptClaimEclaimDraftAvaiVisit = outptClaimEclaimDraftAvaiVisit;
 }

 @Column(name = "outptClaimEclaimDraftAvaiLimit", precision = 16)
 public BigDecimal getOutptClaimEclaimDraftAvaiLimit() {
     return this.outptClaimEclaimDraftAvaiLimit;
 }

 public void setOutptClaimEclaimDraftAvaiLimit(BigDecimal outptClaimEclaimDraftAvaiLimit) {
     this.outptClaimEclaimDraftAvaiLimit = outptClaimEclaimDraftAvaiLimit;
 }

 @Column(name = "outptClaimEclaimDraftDeductible", precision = 16)
 public BigDecimal getOutptClaimEclaimDraftDeductible() {
     return this.outptClaimEclaimDraftDeductible;
 }

 public void setOutptClaimEclaimDraftDeductible(BigDecimal outptClaimEclaimDraftDeductible) {
     this.outptClaimEclaimDraftDeductible = outptClaimEclaimDraftDeductible;
 }

 @Column(name = "outptClaimEclaimDraftCoInsApplies", length = 1)
 public String getOutptClaimEclaimDraftCoInsApplies() {
     return this.outptClaimEclaimDraftCoInsApplies;
 }

 public void setOutptClaimEclaimDraftCoInsApplies(String outptClaimEclaimDraftCoInsApplies) {
     this.outptClaimEclaimDraftCoInsApplies = outptClaimEclaimDraftCoInsApplies;
 }

 @Column(name = "outptClaimCorporateDiscountAmt", precision = 16)
 public BigDecimal getOutptClaimCorporateDiscountAmt() {
     return this.outptClaimCorporateDiscountAmt;
 }

 public void setOutptClaimCorporateDiscountAmt(BigDecimal outptClaimCorporateDiscountAmt) {
     this.outptClaimCorporateDiscountAmt = outptClaimCorporateDiscountAmt;
 }

 @Column(name = "outptClaimFurtherDiscountAmt", precision = 16)
 public BigDecimal getOutptClaimFurtherDiscountAmt() {
     return this.outptClaimFurtherDiscountAmt;
 }

 public void setOutptClaimFurtherDiscountAmt(BigDecimal outptClaimFurtherDiscountAmt) {
     this.outptClaimFurtherDiscountAmt = outptClaimFurtherDiscountAmt;
 }

 @Column(name = "outptClaimOtherDoctorName", length = 150)
 public String getOutptClaimOtherDoctorName() {
     return this.outptClaimOtherDoctorName;
 }

 public void setOutptClaimOtherDoctorName(String outptClaimOtherDoctorName) {
     this.outptClaimOtherDoctorName = outptClaimOtherDoctorName;
 }

 @Column(name = "outptClaimOtherDoctorLisNum", length = 100)
 public String getOutptClaimOtherDoctorLisNum() {
     return this.outptClaimOtherDoctorLisNum;
 }

 public void setOutptClaimOtherDoctorLisNum(String outptClaimOtherDoctorLisNum) {
     this.outptClaimOtherDoctorLisNum = outptClaimOtherDoctorLisNum;
 }

 @Column(name = "outptClaimIsAgiApiSend")
 public Boolean getOutptClaimIsAgiApiSend() {
     return this.outptClaimIsAgiApiSend;
 }

 public void setOutptClaimIsAgiApiSend(Boolean outptClaimIsAgiApiSend) {
     this.outptClaimIsAgiApiSend = outptClaimIsAgiApiSend;
 }

 @Column(name = "outptClaimIsAuditCase")
 public Boolean getOutptClaimIsAuditCase() {
     return this.outptClaimIsAuditCase;
 }

 public void setOutptClaimIsAuditCase(Boolean outptClaimIsAuditCase) {
     this.outptClaimIsAuditCase = outptClaimIsAuditCase;
 }

 @Column(name = "outptClaimIsComplainCase")
 public Boolean getOutptClaimIsComplainCase() {
     return this.outptClaimIsComplainCase;
 }

 public void setOutptClaimIsComplainCase(Boolean outptClaimIsComplainCase) {
     this.outptClaimIsComplainCase = outptClaimIsComplainCase;
 }

 @Column(name = "outptClaimIsCaseStudy")
 public Boolean getOutptClaimIsCaseStudy() {
     return this.outptClaimIsCaseStudy;
 }

 public void setOutptClaimIsCaseStudy(Boolean outptClaimIsCaseStudy) {
     this.outptClaimIsCaseStudy = outptClaimIsCaseStudy;
 }

 @Column(name = "outptClaimIsLetterIssued")
 public Boolean getOutptClaimIsLetterIssued() {
     return this.outptClaimIsLetterIssued;
 }

 public void setOutptClaimIsLetterIssued(Boolean outptClaimIsLetterIssued) {
     this.outptClaimIsLetterIssued = outptClaimIsLetterIssued;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimAdmFaxInDate", length = 19)
 public Date getOutptClaimAdmFaxInDate() {
     return this.outptClaimAdmFaxInDate;
 }

 public void setOutptClaimAdmFaxInDate(Date outptClaimAdmFaxInDate) {
     this.outptClaimAdmFaxInDate = outptClaimAdmFaxInDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimAdmFaxOutDate", length = 19)
 public Date getOutptClaimAdmFaxOutDate() {
     return this.outptClaimAdmFaxOutDate;
 }

 public void setOutptClaimAdmFaxOutDate(Date outptClaimAdmFaxOutDate) {
     this.outptClaimAdmFaxOutDate = outptClaimAdmFaxOutDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimDiscFaxInDate", length = 19)
 public Date getOutptClaimDiscFaxInDate() {
     return this.outptClaimDiscFaxInDate;
 }

 public void setOutptClaimDiscFaxInDate(Date outptClaimDiscFaxInDate) {
     this.outptClaimDiscFaxInDate = outptClaimDiscFaxInDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimDiscFaxOutDate", length = 19)
 public Date getOutptClaimDiscFaxOutDate() {
     return this.outptClaimDiscFaxOutDate;
 }

 public void setOutptClaimDiscFaxOutDate(Date outptClaimDiscFaxOutDate) {
     this.outptClaimDiscFaxOutDate = outptClaimDiscFaxOutDate;
 }

 @Column(name = "outptClaimOtherDiagnosis", length = 200)
 public String getOutptClaimOtherDiagnosis() {
     return this.outptClaimOtherDiagnosis;
 }

 public void setOutptClaimOtherDiagnosis(String outptClaimOtherDiagnosis) {
     this.outptClaimOtherDiagnosis = outptClaimOtherDiagnosis;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimSpecificIllnessDate", length = 10)
 public Date getOutptClaimSpecificIllnessDate() {
     return this.outptClaimSpecificIllnessDate;
 }

 public void setOutptClaimSpecificIllnessDate(Date outptClaimSpecificIllnessDate) {
     this.outptClaimSpecificIllnessDate = outptClaimSpecificIllnessDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimGracePeriodDate", length = 10)
 public Date getOutptClaimGracePeriodDate() {
     return this.outptClaimGracePeriodDate;
 }

 public void setOutptClaimGracePeriodDate(Date outptClaimGracePeriodDate) {
     this.outptClaimGracePeriodDate = outptClaimGracePeriodDate;
 }

 @Temporal(TemporalType.DATE)
 @Column(name = "outptClaimWaitingPeriodDate", length = 10)
 public Date getOutptClaimWaitingPeriodDate() {
     return this.outptClaimWaitingPeriodDate;
 }

 public void setOutptClaimWaitingPeriodDate(Date outptClaimWaitingPeriodDate) {
     this.outptClaimWaitingPeriodDate = outptClaimWaitingPeriodDate;
 }

 @Column(name = "outptClaimClientClaimId", length = 20)
 public String getOutptClaimClientClaimId() {
     return this.outptClaimClientClaimId;
 }

 public void setOutptClaimClientClaimId(String outptClaimClientClaimId) {
     this.outptClaimClientClaimId = outptClaimClientClaimId;
 }

 @Column(name = "outptClaimClientPortalNo", length = 50)
 public String getOutptClaimClientPortalNo() {
     return this.outptClaimClientPortalNo;
 }

 public void setOutptClaimClientPortalNo(String outptClaimClientPortalNo) {
     this.outptClaimClientPortalNo = outptClaimClientPortalNo;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimCalc> getOutptClaimCalcs() {
     return this.outptClaimCalcs;
 }

 public void setOutptClaimCalcs(Set<OutptClaimCalc> outptClaimCalcs) {
     this.outptClaimCalcs = outptClaimCalcs;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimSurgicalSchedule> getOutptClaimSurgicalSchedules() {
     return this.outptClaimSurgicalSchedules;
 }

 public void setOutptClaimSurgicalSchedules(Set<OutptClaimSurgicalSchedule> outptClaimSurgicalSchedules) {
     this.outptClaimSurgicalSchedules = outptClaimSurgicalSchedules;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptCasePhonelog> getOutptCasePhonelogs() {
     return this.outptCasePhonelogs;
 }

 public void setOutptCasePhonelogs(Set<OutptCasePhonelog> outptCasePhonelogs) {
     this.outptCasePhonelogs = outptCasePhonelogs;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimDoctor> getOutptClaimDoctors() {
     return this.outptClaimDoctors;
 }

 public void setOutptClaimDoctors(Set<OutptClaimDoctor> outptClaimDoctors) {
     this.outptClaimDoctors = outptClaimDoctors;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimSymptom> getOutptClaimSymptoms() {
     return this.outptClaimSymptoms;
 }

 public void setOutptClaimSymptoms(Set<OutptClaimSymptom> outptClaimSymptoms) {
     this.outptClaimSymptoms = outptClaimSymptoms;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptPaymentActivityLog> getOutptPaymentActivityLogs() {
     return this.outptPaymentActivityLogs;
 }

 public void setOutptPaymentActivityLogs(Set<OutptPaymentActivityLog> outptPaymentActivityLogs) {
     this.outptPaymentActivityLogs = outptPaymentActivityLogs;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimDrug> getOutptClaimDrugs() {
     return this.outptClaimDrugs;
 }

 public void setOutptClaimDrugs(Set<OutptClaimDrug> outptClaimDrugs) {
     this.outptClaimDrugs = outptClaimDrugs;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptCaseWorkflowlog> getOutptCaseWorkflowlogs() {
     return this.outptCaseWorkflowlogs;
 }

 public void setOutptCaseWorkflowlogs(Set<OutptCaseWorkflowlog> outptCaseWorkflowlogs) {
     this.outptCaseWorkflowlogs = outptCaseWorkflowlogs;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptCaseAdmin> getOutptCaseAdmins() {
     return this.outptCaseAdmins;
 }

 public void setOutptCaseAdmins(Set<OutptCaseAdmin> outptCaseAdmins) {
     this.outptCaseAdmins = outptCaseAdmins;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimApproval> getOutptClaimApprovals() {
     return this.outptClaimApprovals;
 }

 public void setOutptClaimApprovals(Set<OutptClaimApproval> outptClaimApprovals) {
     this.outptClaimApprovals = outptClaimApprovals;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptCaseImage> getOutptCaseImages() {
     return this.outptCaseImages;
 }

 public void setOutptCaseImages(Set<OutptCaseImage> outptCaseImages) {
     this.outptCaseImages = outptCaseImages;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimDiagnosis> getOutptClaimDiagnosises() {
     return this.outptClaimDiagnosises;
 }

 public void setOutptClaimDiagnosises(Set<OutptClaimDiagnosis> outptClaimDiagnosises) {
     this.outptClaimDiagnosises = outptClaimDiagnosises;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimFwaResult> getOutptClaimFwaResults() {
     return this.outptClaimFwaResults;
 }

 public void setOutptClaimFwaResults(Set<OutptClaimFwaResult> outptClaimFwaResults) {
     this.outptClaimFwaResults = outptClaimFwaResults;
 }
 
 @OneToMany(fetch = FetchType.LAZY, mappedBy = "outptClaim")
 public Set<OutptClaimItem> getOutptClaimItems() {
     return this.outptClaimItems;
 }

 public void setOutptClaimItems(Set<OutptClaimItem> outptClaimItems) {
     this.outptClaimItems = outptClaimItems;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimIsoBdxDate", length = 19)
 public Date getOutptClaimIsoBdxDate() {
     return outptClaimIsoBdxDate;
 }

 public void setOutptClaimIsoBdxDate(Date outptClaimIsoBdxDate) {
     this.outptClaimIsoBdxDate = outptClaimIsoBdxDate;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "outptClaimAsoBdxDate", length = 19)
 public Date getOutptClaimAsoBdxDate() {
     return outptClaimAsoBdxDate;
 }

 public void setOutptClaimAsoBdxDate(Date outptClaimAsoBdxDate) {
     this.outptClaimAsoBdxDate = outptClaimAsoBdxDate;
 }

 @Column(name = "outptClaimPaymentTo", length = 2)
 public String getOutptClaimPaymentTo() {
     return outptClaimPaymentTo;
 }

 public void setOutptClaimPaymentTo(String outptClaimPaymentTo) {
     this.outptClaimPaymentTo = outptClaimPaymentTo;
 }

 @Column(name = "outptClaimPaymentMode", length = 2)
 public String getOutptClaimPaymentMode() {
     return outptClaimPaymentMode;
 }

 public void setOutptClaimPaymentMode(String outptClaimPaymentMode) {
     this.outptClaimPaymentMode = outptClaimPaymentMode;
 }
 
 @Column(name = "outptClaimPayeeName", length = 100)
	public String getOutptClaimPayeeName() {
		return outptClaimPayeeName;
	}

	public void setOutptClaimPayeeName(String outptClaimPayeeName) {
		this.outptClaimPayeeName = outptClaimPayeeName;
	}
	
	@Column(name = "outptClaimBankAccName", length = 100)
	public String getOutptClaimBankAccName() {
		return outptClaimBankAccName;
	}

	public void setOutptClaimBankAccName(String outptClaimBankAccName) {
		this.outptClaimBankAccName = outptClaimBankAccName;
	}
	
	@Column(name = "outptClaimBankAccNum", length = 30)
	public String getOutptClaimBankAccNum() {
		return outptClaimBankAccNum;
	}
	
	public void setOutptClaimBankAccNum(String outptClaimBankAccNum) {
		this.outptClaimBankAccNum = outptClaimBankAccNum;
	}
 

}
