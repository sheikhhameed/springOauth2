package com.test.demo.model.outpt;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is outptClaimDrug class
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="outpt_claim_drug"
 ,catalog="marcmy"
)
public class OutptClaimDrug  implements java.io.Serializable {


  private Integer drugId;
  private OutptClaim outptClaim;
  private Integer drugCreatedBy;
  private Date drugCreatedDate;
  private Integer drugLastEdittedBy;
  private Date drugLastEdittedDate;
  private String drugName;
  private Integer drugDays;
  private String drugDosage;
  private BigDecimal drugAmt;
  private BigDecimal drugDiscountAmt;
  private BigDecimal drugGstAmt;
  private BigDecimal drugTotalAmt;
  private BigDecimal drugNonPayableAmt;
  private String drugNonPayableRemark;
  private BigDecimal drugExgratiaAmt;
  private Integer drugDrugId;
  private Integer drugQuantity;
  
 public OutptClaimDrug() {
 }

	
 public OutptClaimDrug(OutptClaim outptClaim, BigDecimal drugAmt, BigDecimal drugDiscountAmt, BigDecimal drugGstAmt, BigDecimal drugTotalAmt, BigDecimal drugNonPayableAmt, BigDecimal drugExgratiaAmt) {
     this.outptClaim = outptClaim;
     this.drugAmt = drugAmt;
     this.drugDiscountAmt = drugDiscountAmt;
     this.drugGstAmt = drugGstAmt;
     this.drugTotalAmt = drugTotalAmt;
     this.drugNonPayableAmt = drugNonPayableAmt;
     this.drugExgratiaAmt = drugExgratiaAmt;
 }
 public OutptClaimDrug(OutptClaim outptClaim, Integer drugCreatedBy, Date drugCreatedDate, Integer drugLastEdittedBy, Date drugLastEdittedDate, String drugName, Integer drugDays, String drugDosage, BigDecimal drugAmt, BigDecimal drugDiscountAmt, BigDecimal drugGstAmt, BigDecimal drugTotalAmt, BigDecimal drugNonPayableAmt, String drugNonPayableRemark, BigDecimal drugExgratiaAmt, Integer drugDrugId, Integer drugQuantity) {
    this.outptClaim = outptClaim;
    this.drugCreatedBy = drugCreatedBy;
    this.drugCreatedDate = drugCreatedDate;
    this.drugLastEdittedBy = drugLastEdittedBy;
    this.drugLastEdittedDate = drugLastEdittedDate;
    this.drugName = drugName;
    this.drugDays = drugDays;
    this.drugDosage = drugDosage;
    this.drugAmt = drugAmt;
    this.drugDiscountAmt = drugDiscountAmt;
    this.drugGstAmt = drugGstAmt;
    this.drugTotalAmt = drugTotalAmt;
    this.drugNonPayableAmt = drugNonPayableAmt;
    this.drugNonPayableRemark = drugNonPayableRemark;
    this.drugExgratiaAmt = drugExgratiaAmt;
    this.drugDrugId = drugDrugId;
    this.drugQuantity = drugQuantity;
    
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="drugId", unique=true, nullable=false)
 public Integer getDrugId() {
     return this.drugId;
 }
 
 public void setDrugId(Integer drugId) {
     this.drugId = drugId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="drugOutptClaimId", nullable=false)
 public OutptClaim getOutptClaim() {
     return this.outptClaim;
 }
 
 public void setOutptClaim(OutptClaim outptClaim) {
     this.outptClaim = outptClaim;
 }

 
 @Column(name="drugCreatedBy")
 public Integer getDrugCreatedBy() {
     return this.drugCreatedBy;
 }
 
 public void setDrugCreatedBy(Integer drugCreatedBy) {
     this.drugCreatedBy = drugCreatedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drugCreatedDate", length=19)
 public Date getDrugCreatedDate() {
     return this.drugCreatedDate;
 }
 
 public void setDrugCreatedDate(Date drugCreatedDate) {
     this.drugCreatedDate = drugCreatedDate;
 }

 
 @Column(name="drugLastEdittedBy")
 public Integer getDrugLastEdittedBy() {
     return this.drugLastEdittedBy;
 }
 
 public void setDrugLastEdittedBy(Integer drugLastEdittedBy) {
     this.drugLastEdittedBy = drugLastEdittedBy;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="drugLastEdittedDate", length=19)
 public Date getDrugLastEdittedDate() {
     return this.drugLastEdittedDate;
 }
 
 public void setDrugLastEdittedDate(Date drugLastEdittedDate) {
     this.drugLastEdittedDate = drugLastEdittedDate;
 }

 
 @Column(name="drugName", length=150)
 public String getDrugName() {
     return this.drugName;
 }
 
 public void setDrugName(String drugName) {
     this.drugName = drugName;
 }

 
 @Column(name="drugDays")
 public Integer getDrugDays() {
     return this.drugDays;
 }
 
 public void setDrugDays(Integer drugDays) {
     this.drugDays = drugDays;
 }

 
 @Column(name="drugDosage", length=100)
 public String getDrugDosage() {
     return this.drugDosage;
 }
 
 public void setDrugDosage(String drugDosage) {
     this.drugDosage = drugDosage;
 }

 
 @Column(name="drugAmt", nullable=false, precision=16)
 public BigDecimal getDrugAmt() {
     return this.drugAmt;
 }
 
 public void setDrugAmt(BigDecimal drugAmt) {
     this.drugAmt = drugAmt;
 }

 
 @Column(name="drugDiscountAmt", nullable=false, precision=16)
 public BigDecimal getDrugDiscountAmt() {
     return this.drugDiscountAmt;
 }
 
 public void setDrugDiscountAmt(BigDecimal drugDiscountAmt) {
     this.drugDiscountAmt = drugDiscountAmt;
 }

 
 @Column(name="drugGstAmt", nullable=false, precision=16)
 public BigDecimal getDrugGstAmt() {
     return this.drugGstAmt;
 }
 
 public void setDrugGstAmt(BigDecimal drugGstAmt) {
     this.drugGstAmt = drugGstAmt;
 }

 
 @Column(name="drugTotalAmt", nullable=false, precision=16)
 public BigDecimal getDrugTotalAmt() {
     return this.drugTotalAmt;
 }
 
 public void setDrugTotalAmt(BigDecimal drugTotalAmt) {
     this.drugTotalAmt = drugTotalAmt;
 }

 
 @Column(name="drugNonPayableAmt", nullable=false, precision=16)
 public BigDecimal getDrugNonPayableAmt() {
     return this.drugNonPayableAmt;
 }
 
 public void setDrugNonPayableAmt(BigDecimal drugNonPayableAmt) {
     this.drugNonPayableAmt = drugNonPayableAmt;
 }

 
 @Column(name="drugNonPayableRemark", length=65535)
 public String getDrugNonPayableRemark() {
     return this.drugNonPayableRemark;
 }
 
 public void setDrugNonPayableRemark(String drugNonPayableRemark) {
     this.drugNonPayableRemark = drugNonPayableRemark;
 }

 
 @Column(name="drugExgratiaAmt", nullable=false, precision=16)
 public BigDecimal getDrugExgratiaAmt() {
     return this.drugExgratiaAmt;
 }
 
 public void setDrugExgratiaAmt(BigDecimal drugExgratiaAmt) {
     this.drugExgratiaAmt = drugExgratiaAmt;
 }

 
 @Column(name="drugDrugId")
 public Integer getDrugDrugId() {
     return this.drugDrugId;
 }
 
 public void setDrugDrugId(Integer drugDrugId) {
     this.drugDrugId = drugDrugId;
 }
 
 @Column(name="drugQuantity")
 public Integer getDrugQuantity() {
     return this.drugQuantity;
 }
 
 public void setDrugQuantity(Integer drugQuantity) {
     this.drugQuantity = drugQuantity;
 }

}


