package com.test.demo.model.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This is clientMailList class 
 * 
 * @author smannan
 *
 */
@Entity
@Table(name="client_mail_list"
 ,catalog="marcmy"
)
public class ClientMailList  implements java.io.Serializable {


  private Integer clientMailId;
  private Client client;
  private Boolean clientMailEnabled;
  private String clientMailCreatedByAbbvName;
  private Date clientMailCreatedDate;
  private String clientMailLastEdittedByAbbvName;
  private Date clientMailLastEdittedDate;
  private String clientMailName;
  private String clientMailEmail;
  private String clientMailBccEmail;
  private String clientMailAddress;
  private Set<ProgramService> programServices = new HashSet<ProgramService>(0);

 public ClientMailList() {
 }

	
 public ClientMailList(Client client) {
     this.client = client;
 }
 public ClientMailList(Client client, Boolean clientMailEnabled, String clientMailCreatedByAbbvName, Date clientMailCreatedDate, String clientMailLastEdittedByAbbvName, Date clientMailLastEdittedDate, String clientMailName, String clientMailEmail, String clientMailBccEmail, String clientMailAddress, Set<ProgramService> programServices) {
    this.client = client;
    this.clientMailEnabled = clientMailEnabled;
    this.clientMailCreatedByAbbvName = clientMailCreatedByAbbvName;
    this.clientMailCreatedDate = clientMailCreatedDate;
    this.clientMailLastEdittedByAbbvName = clientMailLastEdittedByAbbvName;
    this.clientMailLastEdittedDate = clientMailLastEdittedDate;
    this.clientMailName = clientMailName;
    this.clientMailEmail = clientMailEmail;
    this.clientMailBccEmail = clientMailBccEmail;
    this.clientMailAddress = clientMailAddress;
    this.programServices = programServices;
 }

  @Id @GeneratedValue(strategy=IDENTITY)

 
 @Column(name="clientMailId", unique=true, nullable=false)
 public Integer getClientMailId() {
     return this.clientMailId;
 }
 
 public void setClientMailId(Integer clientMailId) {
     this.clientMailId = clientMailId;
 }

@ManyToOne(fetch=FetchType.LAZY)
 @JoinColumn(name="clientMailClientId", nullable=false)
 public Client getClient() {
     return this.client;
 }
 
 public void setClient(Client client) {
     this.client = client;
 }

 
 @Column(name="clientMailEnabled")
 public Boolean getClientMailEnabled() {
     return this.clientMailEnabled;
 }
 
 public void setClientMailEnabled(Boolean clientMailEnabled) {
     this.clientMailEnabled = clientMailEnabled;
 }

 
 @Column(name="clientMailCreatedByAbbvName", length=8)
 public String getClientMailCreatedByAbbvName() {
     return this.clientMailCreatedByAbbvName;
 }
 
 public void setClientMailCreatedByAbbvName(String clientMailCreatedByAbbvName) {
     this.clientMailCreatedByAbbvName = clientMailCreatedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="clientMailCreatedDate", length=19)
 public Date getClientMailCreatedDate() {
     return this.clientMailCreatedDate;
 }
 
 public void setClientMailCreatedDate(Date clientMailCreatedDate) {
     this.clientMailCreatedDate = clientMailCreatedDate;
 }

 
 @Column(name="clientMailLastEdittedByAbbvName", length=8)
 public String getClientMailLastEdittedByAbbvName() {
     return this.clientMailLastEdittedByAbbvName;
 }
 
 public void setClientMailLastEdittedByAbbvName(String clientMailLastEdittedByAbbvName) {
     this.clientMailLastEdittedByAbbvName = clientMailLastEdittedByAbbvName;
 }

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name="clientMailLastEdittedDate", length=19)
 public Date getClientMailLastEdittedDate() {
     return this.clientMailLastEdittedDate;
 }
 
 public void setClientMailLastEdittedDate(Date clientMailLastEdittedDate) {
     this.clientMailLastEdittedDate = clientMailLastEdittedDate;
 }

 
 @Column(name="clientMailName", length=100)
 public String getClientMailName() {
     return this.clientMailName;
 }
 
 public void setClientMailName(String clientMailName) {
     this.clientMailName = clientMailName;
 }

 
 @Column(name="clientMailEmail", length=16777215)
 public String getClientMailEmail() {
     return this.clientMailEmail;
 }
 
 public void setClientMailEmail(String clientMailEmail) {
     this.clientMailEmail = clientMailEmail;
 }

 
 @Column(name="clientMailBccEmail", length=16777215)
 public String getClientMailBccEmail() {
     return this.clientMailBccEmail;
 }
 
 public void setClientMailBccEmail(String clientMailBccEmail) {
     this.clientMailBccEmail = clientMailBccEmail;
 }

 
 @Column(name="clientMailAddress", length=16777215)
 public String getClientMailAddress() {
     return this.clientMailAddress;
 }
 
 public void setClientMailAddress(String clientMailAddress) {
     this.clientMailAddress = clientMailAddress;
 }

@OneToMany(fetch=FetchType.LAZY, mappedBy="clientMailList")
 public Set<ProgramService> getProgramServices() {
     return this.programServices;
 }
 
 public void setProgramServices(Set<ProgramService> programServices) {
     this.programServices = programServices;
 }




}


