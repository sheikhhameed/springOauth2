//package com.test.demo.controllerTest;
//
//import org.junit.Before;
//import org.junit.runner.RunWith;
//import org.mockito.Mock;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.test.demo.controller.EmployeeController;
//import com.test.demo.model.common.EmployeeEntity;
//import com.test.demo.repository.EmployeeRepository;
//
//@RunWith(SpringRunner.class)
//public class EmployeeControllerTest {
//
//	@Mock
//	EmployeeRepository repository;
//	
//	@Autowired 
//	MockMvc mockMvc; 
//	
//	private ObjectMapper mapper = new ObjectMapper();
//	
//	@Before 
//	public void setup() {
//		EmployeeEntity e = new EmployeeEntity(2L,"frstName", "lstName", "abc@gamil.com");
//		e.setId(1L);
////		when(repository.add(Mockito.any(EmployeeEntity.class))).thenReturn(e);
////		when(repository.findById(1L)).thenReturn(e);
//		
//	}
//}
